#!/bin/sh
# SUPABASE_URL ও SUPABASE_ANON_KEY এনভায়রনমেন্ট ভ্যারিয়েবল থাকলে js/config.js নতুন করে লেখে।
# না থাকলে ইমেজের ভেতরের আগের js/config.js-ই থাকে (কোনো পরিবর্তন হয় না)।
set -e
CONFIG=/usr/share/nginx/html/js/config.js

if [ -z "${SUPABASE_URL:-}" ] || [ -z "${SUPABASE_ANON_KEY:-}" ]; then
  echo "[accoflow] SUPABASE_URL/SUPABASE_ANON_KEY দেওয়া হয়নি — ইমেজের ডিফল্ট js/config.js ব্যবহার হচ্ছে"
  exit 0
fi

# JS স্ট্রিং ভেঙে দিতে পারে এমন ক্যারেক্টার থাকলে থেমে যাওয়া (ভুল .env ধরার জন্য)
case "$SUPABASE_URL$SUPABASE_ANON_KEY" in
  *\'*|*\"*|*\\*|*\`*|*' '*)
    echo "[accoflow] ত্রুটি: SUPABASE_URL/SUPABASE_ANON_KEY-তে কোটেশন, ব্যাকস্ল্যাশ বা স্পেস আছে — .env ঠিক করুন" >&2
    exit 1 ;;
esac

cat > "$CONFIG" << CFG
/* স্বয়ংক্রিয়ভাবে তৈরি — কন্টেইনার চালুর সময় (docker-app/40-accoflow-config.sh) */
const ACCOFLOW_CONFIG = {
  SUPABASE_URL: '${SUPABASE_URL}',
  SUPABASE_ANON_KEY: '${SUPABASE_ANON_KEY}'
};
CFG
echo "[accoflow] js/config.js তৈরি হয়েছে → ${SUPABASE_URL}"
