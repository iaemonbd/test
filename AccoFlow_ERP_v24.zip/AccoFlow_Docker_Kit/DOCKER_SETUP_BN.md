# AccoFlow ERP — Docker ইমেজ + লোকাল Supabase সেটআপ (বাংলা গাইড)

## কী তৈরি হবে
একটাই `docker compose` কমান্ডে দুইটা জিনিস চালু হবে:
1. **Supabase স্ট্যাক** (ডাটাবেস, Auth, API, Studio, Edge Functions) — আপনার প্রজেক্টের `docker/docker-compose.yml`
2. **AccoFlow অ্যাপ কন্টেইনার** (`accoflow-app`) — nginx দিয়ে আপনার HTML/CSS/JS সার্ভ করে (পোর্ট 3000)

> আপনার প্রজেক্টে আগে শুধু Supabase স্ট্যাক ছিল, অ্যাপের নিজের কোনো কন্টেইনার ছিল না — এই কিট সেটাই যোগ করে।

## ধাপ ১ — কিটের ফাইল প্রজেক্টে বসান
| কিটের ফাইল | প্রজেক্টের কোথায় বসবে |
|---|---|
| `docker-app/` (ফোল্ডার) | প্রজেক্টের রুটে (যেখানে `index.html` আছে) |
| `.dockerignore` | প্রজেক্টের রুটে |
| `docker/docker-compose.app.yml` | প্রজেক্টের `docker/` ফোল্ডারে |

## ধাপ ২ — `docker/.env` তৈরি
```bash
cd docker
cp .env.example .env
```
`.env` খুলে অবশ্যই বদলান (এখানে `192.168.1.50` = আপনার সার্ভার পিসির LAN IP):
```
POSTGRES_PASSWORD=<শক্তিশালী পাসওয়ার্ড>
JWT_SECRET=<অন্তত ৩২ অক্ষরের সিক্রেট>
ANON_KEY=<JWT_SECRET দিয়ে বানানো anon key>
SERVICE_ROLE_KEY=<JWT_SECRET দিয়ে বানানো service_role key>
DASHBOARD_USERNAME=<Studio লগইন>
DASHBOARD_PASSWORD=<Studio পাসওয়ার্ড>
SUPABASE_PUBLIC_URL=http://192.168.1.50:8000
API_EXTERNAL_URL=http://192.168.1.50:8000/auth/v1
SITE_URL=http://192.168.1.50:3000
FUNCTIONS_VERIFY_JWT=false
```
- `.env.example`-এর বাকি সিক্রেটগুলোও (SECRET_KEY_BASE, VAULT_ENC_KEY, PG_META_CRYPTO_KEY ইত্যাদি) ডিফল্ট না রেখে নতুন বানান।
- ANON_KEY/SERVICE_ROLE_KEY বানানোর নিয়ম: https://supabase.com/docs/guides/self-hosting/docker#securing-your-services
- ⚠️ `SUPABASE_PUBLIC_URL`-এ **`localhost` দেবেন না** — অফিসের অন্য পিসির ব্রাউজার সরাসরি এই ঠিকানা দিয়ে Supabase-এর সাথে কথা বলে।

## ধাপ ৩ — চালু করা
```bash
cd docker
docker compose -f docker-compose.yml -f docker-compose.app.yml up -d --build
docker compose -f docker-compose.yml -f docker-compose.app.yml ps
```
সব কন্টেইনার `healthy`/`running` হতে কয়েক মিনিট লাগে। (প্রথমবার ইন্টারনেট লাগবে — Docker ইমেজ ডাউনলোডের জন্য।)

> নিচের কমান্ডগুলো সংক্ষেপে লিখতে `docker/` ফোল্ডারে ঢুকে `export COMPOSE_FILE=docker-compose.yml:docker-compose.app.yml` দিয়ে রাখতে পারেন (Windows PowerShell-এ: `$env:COMPOSE_FILE="docker-compose.yml;docker-compose.app.yml"`), তখন শুধু `docker compose ...` লিখলেই চলবে।

## ধাপ ৪ — ডাটাবেস স্কিমা বসানো (একটাই ফাইল)
শুধু **`accoflow_combined_schema_v24.sql`** রান করুন (এতে schema + v13 থেকে v24 সব আছে)।
⚠️ `docker/README_SELF_HOST.md`-এ যে পুরনো ফাইলের নাম (`accoflow_combined_schema.sql`, `migration_v22_offline_sync.sql`) লেখা আছে, সেগুলো আর লাগবে না।

**Linux/Mac:**
```bash
docker compose exec -T db psql -U postgres -d postgres -v ON_ERROR_STOP=1 < ../accoflow_combined_schema_v24.sql
```
**Windows PowerShell:**
```powershell
Get-Content ..\accoflow_combined_schema_v24.sql -Raw | docker compose exec -T db psql -U postgres -d postgres -v ON_ERROR_STOP=1
```
অথবা Studio (`http://192.168.1.50:8000`) → SQL Editor-এ ফাইলের পুরো লেখা পেস্ট করে Run।

## ধাপ ৫ — Edge Function (ইউজার তৈরি/ডিলিটের জন্য)
`docker/volumes/functions/admin-manage-user/index.ts` প্রজেক্টে ইতিমধ্যে আছে। শুধু রিস্টার্ট করুন:
```bash
docker compose restart functions
```
(প্রথমবার ফাংশনটা চলার সময় একবার ইন্টারনেট লাগে — `esm.sh` থেকে ছোট লাইব্রেরি নামানোর জন্য, এরপর ক্যাশ হয়ে যায়।)

## ধাপ ৬ — প্রথম Super Admin তৈরি
1. Studio → **Authentication → Users → Add user**
   - Email: `emon@accoflow.internal` (অ্যাপের ডিফল্ট Super Admin ইউজারনেম `emon`; অন্য নাম হলে `<username>@accoflow.internal`)
   - Password: কমপক্ষে ৬ অক্ষর, **Auto Confirm User** টিক দিন
2. SQL Editor-এ:
```sql
insert into profiles (id, username, role, status)
select id, 'emon', 'superadmin', 'Active'
from auth.users where email = 'emon@accoflow.internal';
```

## ধাপ ৭ — ব্যবহার
অফিসের যেকোনো পিসির ব্রাউজারে: **`http://192.168.1.50:3000`** → `emon` + ধাপ ৬-এর পাসওয়ার্ড দিয়ে লগইন।

## দরকারি কমান্ড
| কাজ | কমান্ড |
|---|---|
| লগ দেখা | `docker compose logs -f accoflow-app` |
| বন্ধ করা | `docker compose down` (ডেটা থাকবে) |
| অ্যাপ কোড বদলালে আবার বিল্ড | `docker compose up -d --build accoflow-app` |
| ডাটাবেস ব্যাকআপ | `docker compose exec -T db pg_dump -U postgres postgres > backup.sql` |
| অ্যাপ ইমেজ অন্য পিসিতে নেওয়া | `docker save accoflow-erp:latest \| gzip > accoflow-erp.tar.gz` → অন্য পিসিতে `docker load < accoflow-erp.tar.gz` |

## ⚠️ জানা সীমাবদ্ধতা (সততার সাথে)
1. **ইন্টারনেট ছাড়া ব্রাউজার চলবে না:** `index.html` এখন Supabase JS, Chart.js, ExcelJS, Bootstrap Icons ও Google Fonts **ইন্টারনেট (CDN) থেকে** লোড করে। অফিসের নেট বন্ধ থাকলে ব্রাউজারে এগুলো নামবে না — অ্যাপ লগইন/ডাটা লোডই করতে পারবে না। সম্পূর্ণ অফলাইন LAN চাইলে এই লাইব্রেরিগুলো ইমেজের ভেতরেই রেখে দিতে হবে (এটা আলাদা কাজ, `index.html` বদলাতে হয় — এই কিটে করা হয়নি)।
2. **PWA/Service Worker:** `http://` LAN ঠিকানায় ব্রাউজার service worker চালু করে না — অ্যাপ স্বাভাবিক চলবে, শুধু "Install App" ও অফলাইন-ক্যাশ কাজ করবে না (HTTPS লাগে)।
3. **নিরাপত্তা:** ডিফল্ট সিক্রেট রাখবেন না; সার্ভার পিসির ৮০০০ ও ৩০০০ পোর্ট শুধু অফিস LAN-এ খোলা রাখুন, ইন্টারনেটে নয়।
4. **টেস্টের সীমা:** nginx কনফিগ ও config.js জেনারেটর স্ক্রিপ্ট আলাদাভাবে টেস্ট করা হয়েছে (সব ঠিক ছিল)। কিন্তু আসল `docker build`/`docker compose up` এই এনভায়রনমেন্টে চালানো যায়নি (Docker Hub-এ নেটওয়ার্ক নেই) — প্রথমবার চালানোর সময় কোনো এরর এলে লগ পাঠালে ঠিক করে দেব।
