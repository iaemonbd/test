/**
 * AccoFlow ERP — ZKTeco Attendance Bridge/Agent v2.2
 * ------------------------------------------------
 * Runs on a PC near the ZKTeco device. It reads attendance punches from the device over TCP
 * and PUSHES them straight into Supabase (HR > Attendance) every few minutes -- no Telegram,
 * and the ERP browser does not need to reach this PC at all (so it also works when AccoFlow
 * is hosted online over HTTPS).
 *
 * v2.2 changes:
 * - REMOVED the Telegram relay. The bot token no longer lives in config.json.
 * - NEW direct Supabase push (supabase-push.js): signs in as a dedicated, low-privilege
 *   "device" account and calls the record_zk_attendance() database function (migration v24).
 *   Employee matching (ZKTeco Device User ID / NID), Late/Present status and duplicate
 *   protection now happen inside the database, identical to the old in-browser sync.
 * - Missed punches are self-healing: every run re-reads the last `backfillDays` days from
 *   the device, so a bridge/network outage never loses a check-in or check-out.
 * - SECURITY: optional `apiKey` protects every HTTP endpoint (except /ping); without an
 *   apiKey the bridge only listens on 127.0.0.1. CORS is limited to `allowedOrigins` when set.
 *   /users no longer returns device passwords.
 * - Secrets can come from environment variables instead of config.json:
 *   ACCOFLOW_SUPABASE_URL, ACCOFLOW_SUPABASE_ANON_KEY, ACCOFLOW_BRIDGE_USERNAME,
 *   ACCOFLOW_BRIDGE_PASSWORD, ACCOFLOW_BRIDGE_API_KEY
 *
 * Earlier (v2.1): local-calendar-date grouping, serialized device access, clock-drift check,
 * rawPunchCount cross-check, CLI spinner/heartbeat.
 *
 * Before running, configure config.json (see config.example.json and README.md).
 */

const express = require('express');
const cors = require('cors');
const readline = require('readline');
const ZKLib = require('node-zklib');
const crypto = require('crypto');
const { createSupabasePusher } = require('./supabase-push');

const config = Object.assign({}, require('./config.json'));
// Environment variables win over config.json (keeps secrets out of the folder if you prefer)
if (process.env.ACCOFLOW_SUPABASE_URL) config.supabaseUrl = process.env.ACCOFLOW_SUPABASE_URL;
if (process.env.ACCOFLOW_SUPABASE_ANON_KEY) config.supabaseAnonKey = process.env.ACCOFLOW_SUPABASE_ANON_KEY;
if (process.env.ACCOFLOW_BRIDGE_USERNAME) config.bridgeUsername = process.env.ACCOFLOW_BRIDGE_USERNAME;
if (process.env.ACCOFLOW_BRIDGE_PASSWORD) config.bridgePassword = process.env.ACCOFLOW_BRIDGE_PASSWORD;
if (process.env.ACCOFLOW_BRIDGE_API_KEY) config.apiKey = process.env.ACCOFLOW_BRIDGE_API_KEY;

const BRIDGE_VERSION = '2.2.0';
const API_KEY = String(config.apiKey || '').trim();
const allowedOrigins = Array.isArray(config.allowedOrigins) ? config.allowedOrigins.filter(Boolean) : [];

// ============================================================
// ===== CLI presentation helpers (colors, spinner, banner) ====
// ============================================================
const isTTY = !!process.stdout.isTTY;
const C = isTTY ? {
  reset: '\x1b[0m', dim: '\x1b[2m', bold: '\x1b[1m',
  red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m',
  blue: '\x1b[34m', magenta: '\x1b[35m', cyan: '\x1b[36m', gray: '\x1b[90m'
} : { reset: '', dim: '', bold: '', red: '', green: '', yellow: '', blue: '', magenta: '', cyan: '', gray: '' };

function clearCurrentLine() {
  if (!isTTY) return;
  readline.cursorTo(process.stdout, 0);
  readline.clearLine(process.stdout, 0);
}

// Small braille-dot spinner used while the bridge is actively talking to
// the physical device (connecting / reading logs) — gives the operator
// visual proof the terminal isn't frozen during slow device reads.
class Spinner {
  constructor(label) {
    this.frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
    this.i = 0;
    this.label = label;
    this.timer = null;
  }
  start() {
    if (!isTTY) { console.log(`${this.label} ...`); return; }
    heartbeat.suspend();
    this.timer = setInterval(() => {
      clearCurrentLine();
      process.stdout.write(`${C.cyan}${this.frames[this.i]}${C.reset} ${this.label}`);
      this.i = (this.i + 1) % this.frames.length;
    }, 80);
  }
  stop(finalText, ok = true) {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    clearCurrentLine();
    const icon = ok ? `${C.green}✓${C.reset}` : `${C.red}✗${C.reset}`;
    console.log(`${icon} ${finalText}`);
    heartbeat.resume();
  }
}

// Idle "heartbeat" line — pulses quietly on a single line (never spams
// scrollback) so a glance at the terminal confirms the bridge is alive
// even when nothing has happened for a while.
const heartbeat = {
  timer: null,
  suspended: false,
  startedAt: Date.now(),
  deviceLastOkAt: null,
  pulseIdx: 0,
  pulses: ['●', '◉', '○', '◉'],
  line() {
    const upSec = Math.floor((Date.now() - this.startedAt) / 1000);
    const up = `${Math.floor(upSec / 60)}m${String(upSec % 60).padStart(2, '0')}s`;
    const dev = this.deviceLastOkAt
      ? `${C.green}ডিভাইস OK${C.reset} (${Math.floor((Date.now() - this.deviceLastOkAt) / 1000)}s আগে)`
      : `${C.gray}ডিভাইস — এখনও চেক হয়নি${C.reset}`;
    const pulse = this.pulses[this.pulseIdx % this.pulses.length];
    this.pulseIdx++;
    return `${C.dim}${pulse} ব্রিজ চালু আছে — আপটাইম ${up} · ${dev}${C.reset}`;
  },
  start() {
    if (!isTTY) return;
    this.timer = setInterval(() => {
      if (this.suspended) return;
      clearCurrentLine();
      process.stdout.write(this.line());
    }, 4000);
  },
  suspend() { this.suspended = true; clearCurrentLine(); },
  resume() { this.suspended = false; },
  markDeviceOk() { this.deviceLastOkAt = Date.now(); }
};

function bootBanner() {
  const line = '═'.repeat(56);
  console.log(`${C.cyan}${line}${C.reset}`);
  console.log(` ${C.bold}${C.cyan}⛭  AccoFlow ZKTeco Bridge${C.reset}  ${C.dim}v${BRIDGE_VERSION}${C.reset}`);
  console.log(`${C.cyan}${line}${C.reset}`);
}

// ===== Safety net: prevent process crash on network errors =====
process.on('uncaughtException', (err) => {
  clearCurrentLine();
  console.error(`${C.red}[SAFETY]${C.reset} Uncaught exception (server stays running):`, err.message || err);
});
process.on('unhandledRejection', (err) => {
  clearCurrentLine();
  console.error(`${C.red}[SAFETY]${C.reset} Unhandled promise rejection (server stays running):`, (err && err.message) || err);
});

const app = express();
app.use(cors({
  origin: allowedOrigins.length ? allowedOrigins : true,
  allowedHeaders: ['Content-Type', 'x-api-key']
}));
app.use(express.json());

// API-key protection (everything except /ping). If config.apiKey is empty the bridge only
// listens on 127.0.0.1 (see app.listen below), so nobody else on the network can reach it.
function keyMatches(given) {
  const a = Buffer.from(String(given || ''));
  const b = Buffer.from(API_KEY);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
app.use((req, res, next) => {
  if (!API_KEY || req.method === 'OPTIONS' || req.path === '/ping') return next();
  if (keyMatches(req.get('x-api-key') || req.query.key)) return next();
  return res.status(401).json({ ok: false, error: 'Unauthorized: missing or wrong API key (x-api-key)' });
});

// Request logging middleware with response time + color-coded status
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const ms = Date.now() - start;
    const code = res.statusCode;
    const color = code >= 500 ? C.red : code >= 400 ? C.yellow : C.green;
    clearCurrentLine(); // wipe any in-place heartbeat/spinner text first
    console.log(`${C.dim}[${new Date().toLocaleTimeString('en-GB')}]${C.reset} ${req.method} ${req.originalUrl} → ${color}${code}${C.reset} ${C.dim}(${ms}ms)${C.reset}`);
  });
  next();
});

// ============================================================
// ===== Date helpers — LOCAL calendar date, not UTC =====
// This is the core data-integrity fix: grouping/filtering attendance
// by UTC date (via toISOString()) silently shifts the calendar date
// for any punch between local midnight and local-midnight+UTC-offset.
// Both this bridge AND the ERP's request must agree on "today" using
// the machine's own local date, so we never disagree with each other.
// ============================================================
function pad2(n) { return String(n).padStart(2, '0'); }
function localDateStr(d) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

// Helper: extract human-readable error message from any error type
function describeError(err) {
  if (!err) return 'Unknown error';
  if (typeof err.toast === 'function') {
    try { const t = err.toast(); if (t) return t; } catch (e) { /* ignore */ }
  }
  if (err.err && err.err.message) return err.err.message;
  if (err.message) return err.message;
  return String(err);
}

// Helper: wrap a promise with a timeout to prevent infinite hanging
function withTimeout(promise, ms, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${label} timed out (${ms}ms) — check device IP/Port and ensure device is powered on and on the same network`)), ms))
  ]);
}

// ============================================================
// ===== Device access serialization (mutex/queue) =====
// Prevents two overlapping requests (e.g. dashboard auto-sync firing
// while an operator clicks "Sync Now") from opening a second TCP
// session to the device at the same time. Several ZKTeco firmwares
// return truncated/garbled logs — or just time out — under concurrent
// sessions, which is a real source of silent data mismatch.
// ============================================================
let _deviceQueue = Promise.resolve();
function withDeviceLock(fn) {
  const run = _deviceQueue.then(fn, fn);
  _deviceQueue = run.then(() => {}, () => {});
  return run;
}

// Create a fresh ZKLib connection for each request (no stale connections)
function createDeviceConnection() {
  return new ZKLib(
    config.deviceIp,
    config.devicePort,
    config.deviceTimeoutMs || 10000,
    config.deviceInportMs || 4000
  );
}

// Connection pool — reuse a single connection for rapid sequential requests
let _cachedConnection = null;
let _cachedAt = 0;
const CACHE_TTL = 55000; // 55 seconds

async function getDeviceConnection(timeoutMs, { silent } = {}) {
  const now = Date.now();
  if (_cachedConnection && (now - _cachedAt) < CACHE_TTL) {
    return _cachedConnection;
  }
  const spinner = silent ? null : new Spinner('ডিভাইসের সাথে সংযোগ করা হচ্ছে...');
  if (spinner) spinner.start();
  try {
    const zk = createDeviceConnection();
    await withTimeout(zk.createSocket(), timeoutMs, 'Device connection');
    _cachedConnection = zk;
    _cachedAt = now;
    heartbeat.markDeviceOk();
    if (spinner) spinner.stop('ডিভাইসের সাথে সংযোগ সফল হয়েছে');
    return zk;
  } catch (err) {
    if (spinner) spinner.stop(`সংযোগ ব্যর্থ: ${describeError(err)}`, false);
    throw err;
  }
}

async function closeDeviceConnection() {
  if (_cachedConnection) {
    try { await _cachedConnection.disconnect(); } catch (e) { /* ignore */ }
    _cachedConnection = null;
    _cachedAt = 0;
  }
}

// ============================================================
// ===== Shared attendance-read logic (used by /attendance AND the Supabase push) =====
// ============================================================
// One device read, grouped per local calendar day -> first punch = "in", last = "out".
async function readAttendanceDays(dateList) {
  const timeoutMs = (config.deviceTimeoutMs || 10000) + 3000;
  const wanted = new Set(dateList);

  const records = await withDeviceLock(async () => {
    const zk = await getDeviceConnection(timeoutMs);
    const result = await withTimeout(zk.getAttendances(), timeoutMs, 'Attendance log');
    return (result && Array.isArray(result.data)) ? result.data : [];
  });

  const perDay = {};
  records.forEach(r => {
    const t = new Date(r.recordTime);
    if (isNaN(t)) return;
    const day = localDateStr(t);
    if (!wanted.has(day)) return;
    const uid = String(r.deviceUserId);
    const d = perDay[day] || (perDay[day] = { punches: 0, users: {} });
    d.punches++;
    const u = d.users[uid];
    if (!u) d.users[uid] = { first: t, last: t };
    else { if (t < u.first) u.first = t; if (t > u.last) u.last = t; }
  });

  return dateList.map(date => {
    const d = perDay[date] || { punches: 0, users: {} };
    const out = [];
    Object.keys(d.users).forEach(uid => {
      const { first, last } = d.users[uid];
      out.push({ userId: uid, timestamp: first.toISOString(), time: `${pad2(first.getHours())}:${pad2(first.getMinutes())}`, type: 'in' });
      if (last.getTime() !== first.getTime()) {
        out.push({ userId: uid, timestamp: last.toISOString(), time: `${pad2(last.getHours())}:${pad2(last.getMinutes())}`, type: 'out' });
      }
    });
    return { date, records: out, rawPunchCount: d.punches, rawUserCount: Object.keys(d.users).length };
  });
}

async function readTodayAttendance(dateStr) {
  const day = dateStr || localDateStr(new Date());
  return (await readAttendanceDays([day]))[0];
}

// ============================================================
// ===== Direct Supabase push (replaces the Telegram relay) =====
// ============================================================
const pusher = createSupabasePusher({
  url: config.supabaseUrl,
  anonKey: config.supabaseAnonKey,
  username: config.bridgeUsername,
  password: config.bridgePassword,
  timeoutMs: 20000
});
const pushEnabled = pusher.configured();
const _push = { running: false, runs: 0, lastRunAt: null, lastResults: null, lastError: null };

async function pushAttendanceToSupabase() {
  if (!pushEnabled) return { ok: false, error: 'Supabase push is not configured in config.json' };
  if (_push.running) return { ok: false, error: 'A push is already running' };
  _push.running = true;
  const spinner = new Spinner('Supabase-এ অ্যাটেনডেন্স পাঠানো হচ্ছে...');
  spinner.start();
  try {
    const backfill = Math.min(Math.max(parseInt(config.backfillDays, 10) || 2, 0), 31);
    const days = [];
    for (let i = backfill; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      days.push(localDateStr(d));
    }
    const data = await readAttendanceDays(days);
    const results = [];
    for (const day of data) {
      if (!day.records.length) continue;
      const summary = await pusher.pushDay(day.date, day.records);
      results.push({ date: day.date, rawPunchCount: day.rawPunchCount, ...summary });
    }
    _push.runs++;
    _push.lastRunAt = new Date().toISOString();
    _push.lastResults = results;
    _push.lastError = null;
    const matched = results.reduce((s, r) => s + (r.matched || 0), 0);
    const added = results.reduce((s, r) => s + (r.added || 0), 0);
    const unmatched = [...new Set(results.flatMap(r => r.unmatched || []))];
    const conflicts = [...new Set(results.flatMap(r => r.conflicts || []))];
    spinner.stop(`Supabase-এ পাঠানো হয়েছে — ${matched}টি লগ মেলানো, ${added}টি নতুন এন্ট্রি` +
      (unmatched.length ? ` | ⚠️ মেলেনি (Device User ID): ${unmatched.join(', ')}` : '') +
      (conflicts.length ? ` | ⚠️ একাধিক কর্মচারীর সাথে যুক্ত: ${conflicts.join(', ')}` : ''));
    return { ok: true, results, matched, added, unmatched, conflicts };
  } catch (err) {
    await closeDeviceConnection(); // force a fresh device connection next time
    _push.lastError = describeError(err);
    _push.lastRunAt = new Date().toISOString();
    spinner.stop(`Supabase push ব্যর্থ: ${_push.lastError}`, false);
    return { ok: false, error: _push.lastError };
  } finally {
    _push.running = false;
  }
}

if (pushEnabled) {
  const intervalMin = Math.max(1, Number(config.pushIntervalMinutes) || 5);
  setInterval(pushAttendanceToSupabase, intervalMin * 60 * 1000);
}

app.get('/ping', (req, res) => {
  res.json({ ok: true, bridge: 'accoflow-zkteco-bridge', version: BRIDGE_VERSION, supabasePush: pushEnabled, apiKeyRequired: !!API_KEY, time: new Date().toISOString() });
});

// ===== Device Status — check actual device connectivity + clock drift =====
app.get('/device-status', async (req, res) => {
  const timeoutMs = (config.deviceTimeoutMs || 10000) + 3000;
  try {
    const result = await withDeviceLock(async () => {
      const zk = await getDeviceConnection(timeoutMs);
      const info = await withTimeout(zk.getInfo(), timeoutMs, 'Device info');

      // Best-effort device clock check — not all ZKTeco firmwares/libs
      // expose getTime(), so this degrades gracefully when unsupported.
      let clockDrift = null;
      if (typeof zk.getTime === 'function') {
        try {
          const deviceTime = await withTimeout(zk.getTime(), 5000, 'Device time read');
          const deviceMs = new Date(deviceTime).getTime();
          if (!isNaN(deviceMs)) {
            clockDrift = {
              deviceTime: new Date(deviceMs).toISOString(),
              bridgeTime: new Date().toISOString(),
              driftSeconds: Math.round((deviceMs - Date.now()) / 1000)
            };
          }
        } catch (e) { /* device doesn't support getTime() — skip silently */ }
      }
      return { info, clockDrift };
    });
    res.json({ ok: true, deviceIp: config.deviceIp, devicePort: config.devicePort, info: result.info, clockDrift: result.clockDrift });
  } catch (err) {
    await closeDeviceConnection();
    res.status(500).json({ ok: false, deviceIp: config.deviceIp, devicePort: config.devicePort, error: describeError(err) });
  }
});

// ===== List Users enrolled on the device =====
app.get('/users', async (req, res) => {
  const timeoutMs = (config.deviceTimeoutMs || 10000) + 3000;
  try {
    const users = await withDeviceLock(async () => {
      const zk = await getDeviceConnection(timeoutMs);
      return withTimeout(zk.getUsers(), timeoutMs, 'User list');
    });
    res.json({ ok: true, count: (users && users.data) ? users.data.length : 0, users: (users && users.data) ? users.data.map(u => ({ userId: String(u.uid || u.userId), name: u.name || '', role: u.role || '' })) : [] });
  } catch (err) {
    await closeDeviceConnection();
    res.status(500).json({ ok: false, error: describeError(err) });
  }
});

// ===== Attendance Log — Main endpoint used by AccoFlow ERP =====
// GET /attendance?date=YYYY-MM-DD
// Response: { records: [{ userId, timestamp, type: "in"|"out" }, ...],
//             rawPunchCount, rawUserCount }
// NOTE (v2.1): this used to respond with a bare JSON array. It's now an
// object so rawPunchCount/rawUserCount can travel with it (JSON.stringify
// silently drops extra properties tacked onto an array, which is why the
// first draft of this cross-check metadata never actually reached the
// ERP). AccoFlow ERP v2.1+ reads `.records`; it also still falls back to
// treating the whole payload as the array itself, so an old bridge still
// talking to a new ERP keeps working during a staggered upgrade.
app.get('/attendance', async (req, res) => {
  try {
    const data = await readTodayAttendance(req.query.date);
    // rawPunchCount/rawUserCount let the ERP side cross-check "device had
    // N raw punches from M users today" against how many it actually
    // matched to employees, so a silent drop (e.g. an unmapped Device
    // User ID) becomes visible instead of just quietly missing from
    // Attendance.
    res.json({ records: data.records, rawPunchCount: data.rawPunchCount, rawUserCount: data.rawUserCount });
  } catch (err) {
    console.error('Attendance read error:', describeError(err));
    await closeDeviceConnection();
    res.status(500).json({ error: describeError(err) });
  }
});

// ===== Multi-Date Attendance Range =====
// GET /attendance-range?from=YYYY-MM-DD&to=YYYY-MM-DD
// Response: { records: [{ date, userId, checkIn, checkOut }, ...], rawPunchCount }
app.get('/attendance-range', async (req, res) => {
  const fromStr = req.query.from || localDateStr(new Date());
  const toStr = req.query.to || fromStr;
  const timeoutMs = (config.deviceTimeoutMs || 10000) + 5000;

  try {
    const records = await withDeviceLock(async () => {
      const zk = await getDeviceConnection(timeoutMs);
      const result = await withTimeout(zk.getAttendances(), timeoutMs, 'Attendance log (range)');
      return (result && Array.isArray(result.data)) ? result.data : [];
    });

    // Local-date range comparison — build local-midnight boundaries
    // instead of parsing the query strings as UTC.
    const [fy, fm, fd] = fromStr.split('-').map(Number);
    const [ty, tm, td] = toStr.split('-').map(Number);
    const fromDate = new Date(fy, (fm || 1) - 1, fd || 1, 0, 0, 0, 0);
    const toDate = new Date(ty, (tm || 1) - 1, td || 1, 23, 59, 59, 999);

    const rangeRecords = records.filter(r => {
      const t = new Date(r.recordTime);
      return !isNaN(t) && t >= fromDate && t <= toDate;
    });

    const byDay = {};
    rangeRecords.forEach(r => {
      const t = new Date(r.recordTime);
      const day = localDateStr(t);
      const uid = String(r.deviceUserId);
      if (!byDay[day]) byDay[day] = {};
      if (!byDay[day][uid]) byDay[day][uid] = { first: t, last: t };
      if (t < byDay[day][uid].first) byDay[day][uid].first = t;
      if (t > byDay[day][uid].last) byDay[day][uid].last = t;
    });

    const output = [];
    Object.keys(byDay).sort().forEach(day => {
      Object.keys(byDay[day]).forEach(uid => {
        const { first, last } = byDay[day][uid];
        output.push({ date: day, userId: uid, checkIn: first.toISOString(), checkOut: last.getTime() !== first.getTime() ? last.toISOString() : null });
      });
    });

    res.json({ records: output, rawPunchCount: rangeRecords.length });
  } catch (err) {
    console.error('Attendance range error:', describeError(err));
    await closeDeviceConnection();
    res.status(500).json({ error: describeError(err) });
  }
});

// ===== Push to Supabase right now (ERP "Sync Now" calls this; GET or POST) =====
async function syncNowHandler(req, res) {
  if (!pushEnabled) return res.status(400).json({ ok: false, error: 'config.json-এ supabaseUrl/supabaseAnonKey/bridgeUsername/bridgePassword সেট করা নেই' });
  const r = await pushAttendanceToSupabase();
  res.status(r.ok ? 200 : 500).json(r);
}
app.get('/sync-now', syncNowHandler);
app.post('/sync-now', syncNowHandler);

// ===== Status of the Supabase push (last run, last error, run count) =====
app.get('/sync-status', (req, res) => {
  res.json({
    enabled: pushEnabled,
    intervalMinutes: Math.max(1, Number(config.pushIntervalMinutes) || 5),
    backfillDays: Math.min(Math.max(parseInt(config.backfillDays, 10) || 2, 0), 31),
    running: _push.running, runs: _push.runs, lastRunAt: _push.lastRunAt,
    lastResults: _push.lastResults, lastError: _push.lastError,
    supabase: pusher.status()
  });
});

// 404 handler
app.use((req, res) => res.status(404).json({ error: 'Route not found. Available endpoints: /ping, /device-status, /users, /attendance, /attendance-range, /sync-now, /sync-status' }));

// Graceful shutdown
process.on('SIGINT', async () => {
  clearCurrentLine();
  console.log(`\n${C.yellow}[BRIDGE]${C.reset} Shutting down gracefully...`);
  if (heartbeat.timer) clearInterval(heartbeat.timer);
  await closeDeviceConnection();
  process.exit(0);
});

const bindHost = config.bindHost || (API_KEY ? '0.0.0.0' : '127.0.0.1');
app.listen(config.bridgePort, bindHost, async () => {
  bootBanner();
  console.log(`${C.bold}URL:${C.reset}             http://${bindHost === '0.0.0.0' ? 'localhost' : bindHost}:${config.bridgePort}  ${C.dim}(listening on ${bindHost})${C.reset}`);
  console.log(`${C.bold}Device IP:Port:${C.reset}  ${config.deviceIp}:${config.devicePort}`);
  console.log(`${C.bold}Supabase Push:${C.reset}   ${pushEnabled ? `${C.green}চালু${C.reset} (প্রতি ${Math.max(1, Number(config.pushIntervalMinutes) || 5)} মিনিটে, শেষ ${Math.min(Math.max(parseInt(config.backfillDays, 10) || 2, 0), 31) + 1} দিন)` : `${C.yellow}বন্ধ — config.json-এ supabaseUrl/supabaseAnonKey/bridgeUsername/bridgePassword দিন${C.reset}`}`);
  console.log(`${C.bold}API Key:${C.reset}         ${API_KEY ? `${C.green}চালু${C.reset} (x-api-key লাগবে)` : `${C.yellow}নেই — তাই শুধু এই পিসি (127.0.0.1) থেকে অ্যাক্সেস চলবে${C.reset}`}`);
  console.log('');
  console.log(`${C.bold}Available Endpoints:${C.reset}`);
  console.log('   GET /ping              — Health check (no key needed)');
  console.log('   GET /device-status     — Check device connectivity + clock drift');
  console.log('   GET /users             — List enrolled device users (no passwords)');
  console.log('   GET /attendance        — Today attendance (?date=YYYY-MM-DD)');
  console.log('   GET /attendance-range  — Multi-day attendance (?from=&to=)');
  console.log('   GET|POST /sync-now     — এখনই Supabase-এ পুশ করুন');
  console.log('   GET /sync-status       — শেষ পুশের অবস্থা');
  console.log('');
  console.log(`${C.yellow}Do NOT close this window — AccoFlow ERP needs it running.${C.reset}`);
  console.log(`${'═'.repeat(56)}`);

  // Boot-time device connectivity check (with spinner) so the operator
  // immediately sees whether the device is reachable, not just the bridge.
  try {
    await getDeviceConnection((config.deviceTimeoutMs || 10000) + 3000);
  } catch (e) {
    console.log(`${C.yellow}(এখনো ডিভাইসের সাথে সংযোগ হয়নি — ERP থেকে "Test Connection" চাপলে আবার চেষ্টা হবে)${C.reset}`);
  }
  // Supabase push চালু থাকলে বুট হওয়ার সাথে সাথেই একবার পুশ করে দেওয়া হয় (প্রথম ইন্টারভ্যালের
  // জন্য অপেক্ষা না করেই), যাতে AccoFlow ERP সাথে সাথেই একটা তাজা স্ন্যাপশট পায়
  if (pushEnabled) await pushAttendanceToSupabase();
  heartbeat.start();
});
