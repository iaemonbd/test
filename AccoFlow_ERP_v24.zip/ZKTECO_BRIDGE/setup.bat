@echo off
title AccoFlow ZKTeco Bridge - Setup
echo =====================================================
echo   AccoFlow ZKTeco Bridge - Installation BY : IA EMON
echo =====================================================
echo.

:: Check if Node.js is installed
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not in PATH.
    echo Please install Node.js from https://nodejs.org/ and try again.
    echo.
    pause
    exit /b 1
)

echo [INFO] Node.js found:
node --version
echo.

:: Install dependencies
echo [INFO] Installing dependencies...
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install dependencies.
    pause
    exit /b 1
)

echo.
echo =====================================================
echo   Setup complete!
echo   Run 'run.bat' to start the bridge.
echo =====================================================
echo.
pause