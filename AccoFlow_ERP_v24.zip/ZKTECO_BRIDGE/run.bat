@echo off
title AccoFlow ZKTeco Bridge
echo =====================================================
echo   AccoFlow ZKTeco Bridge - BY IA EMON - Starting...
echo =====================================================
echo.

:: Check if Node.js is installed
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not in PATH.
    echo Please install Node.js from https://nodejs.org/ and try again.
    echo.
    pause
    exit /b 1
)

:: Check if node_modules exists
if not exist "node_modules" (
    echo [INFO] node_modules not found. Running setup first...
    call setup.bat
    if %errorlevel% neq 0 (
        echo [ERROR] Setup failed. Please check the errors above.
        pause
        exit /b 1
    )
    echo.
)

echo [INFO] Starting bridge server...
echo [INFO] Press Ctrl+C to stop the server.
echo.
node server.js
pause