/**
 * AccoFlow ZKTeco Bridge -- direct Supabase pusher (replaces the old Telegram relay)
 * ---------------------------------------------------------------------------------
 * Signs in to Supabase Auth as a dedicated low-privilege "device" account and calls the
 * record_zk_attendance() Postgres function (migration v24).  No npm packages are needed:
 * it uses Node 18+'s built-in fetch.
 *
 * Why a dedicated account and not the service_role key?  The device account can ONLY call
 * record_zk_attendance().  It cannot read PI / accounts / HR tables, so even if this PC or
 * config file is compromised, business data is not exposed.
 */

'use strict';

const EMAIL_DOMAIN = 'accoflow.internal';

function trimSlash(s) { return String(s || '').trim().replace(/\/+$/, ''); }

/**
 * @param {object} opts
 *   url, anonKey, username, password          -- Supabase connection + the device account
 *   timeoutMs                                 -- per-request timeout (default 15000)
 *   fetchImpl                                 -- injectable for tests (default global fetch)
 */
function createSupabasePusher(opts) {
  const url = trimSlash(opts.url);
  const anonKey = String(opts.anonKey || '').trim();
  const username = String(opts.username || '').trim().toLowerCase();
  const password = String(opts.password || '');
  const timeoutMs = opts.timeoutMs || 15000;
  const doFetch = opts.fetchImpl || ((...a) => fetch(...a));

  let session = null; // { accessToken, refreshToken, expiresAt }
  let lastOk = null;
  let lastError = null;
  let pushCount = 0;

  // Placeholder values copied from config.example.json count as "not configured"
  const isPlaceholder = (v) => /PASTE-|YOUR-PROJECT/i.test(String(v || ''));
  function configured() {
    return !!(url && anonKey && username && password) &&
      !(isPlaceholder(url) || isPlaceholder(anonKey) || isPlaceholder(password));
  }

  async function request(path, { method = 'POST', headers = {}, body } = {}) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), timeoutMs);
    try {
      const res = await doFetch(url + path, {
        method,
        headers: { apikey: anonKey, 'Content-Type': 'application/json', ...headers },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: ctl.signal
      });
      let json = null;
      const text = await res.text();
      try { json = text ? JSON.parse(text) : null; } catch (e) { json = { raw: text }; }
      return { status: res.status, ok: res.ok, json };
    } catch (e) {
      if (e && e.name === 'AbortError') throw new Error(`Supabase request timed out (${timeoutMs}ms): ${path}`);
      throw new Error(`Could not reach Supabase (${e && e.message ? e.message : e})`);
    } finally {
      clearTimeout(timer);
    }
  }

  function storeSession(json) {
    session = {
      accessToken: json.access_token,
      refreshToken: json.refresh_token,
      // refresh a minute early
      expiresAt: Date.now() + Math.max(30, (json.expires_in || 3600) - 60) * 1000
    };
  }

  async function signIn() {
    const r = await request('/auth/v1/token?grant_type=password', {
      body: { email: `${username}@${EMAIL_DOMAIN}`, password }
    });
    if (!r.ok || !r.json || !r.json.access_token) {
      session = null;
      const why = (r.json && (r.json.error_description || r.json.msg || r.json.message)) || `HTTP ${r.status}`;
      throw new Error(`Supabase sign-in failed for "${username}": ${why}`);
    }
    storeSession(r.json);
  }

  async function ensureSession() {
    if (session && Date.now() < session.expiresAt) return;
    if (session && session.refreshToken) {
      const r = await request('/auth/v1/token?grant_type=refresh_token', { body: { refresh_token: session.refreshToken } });
      if (r.ok && r.json && r.json.access_token) { storeSession(r.json); return; }
    }
    await signIn();
  }

  async function rpc(fn, args, retried) {
    await ensureSession();
    const r = await request(`/rest/v1/rpc/${fn}`, {
      headers: { Authorization: `Bearer ${session.accessToken}` },
      body: args
    });
    if (r.status === 401 && !retried) { // token rejected -> sign in fresh once
      session = null;
      return rpc(fn, args, true);
    }
    if (!r.ok) {
      const why = (r.json && (r.json.message || r.json.error || r.json.hint)) || `HTTP ${r.status}`;
      throw new Error(`${fn} failed: ${why}`);
    }
    return r.json;
  }

  /**
   * Push one day's punches.  records: [{ userId, time:"HH:MM", type:"in"|"out", timestamp }]
   * Returns the RPC summary ({ ok, matched, added, updated, unmatched, conflicts }).
   */
  async function pushDay(dateStr, records) {
    if (!configured()) throw new Error('Supabase push is not configured (config.json: supabaseUrl / supabaseAnonKey / bridgeUsername / bridgePassword)');
    try {
      const summary = await rpc('record_zk_attendance', { p_date: dateStr, p_punches: records });
      lastOk = new Date().toISOString();
      lastError = null;
      pushCount++;
      return summary;
    } catch (e) {
      lastError = e.message;
      throw e;
    }
  }

  return {
    configured,
    pushDay,
    status() { return { configured: configured(), lastOk, lastError, pushCount }; }
  };
}

module.exports = { createSupabasePusher, EMAIL_DOMAIN };
