# AccoFlow ZKTeco Bridge v2.2 — ব্যবহার নির্দেশিকা

> **v2.2-এ বড় পরিবর্তন:** Telegram রিলে **সম্পূর্ণ বাদ**। ব্রিজ এখন ZKTeco ডিভাইস থেকে পাঞ্চ পড়ে
> **সরাসরি Supabase-এ** (HR > Attendance) পাঠায়। ERP শুধু Supabase থেকে পড়ে — তাই অ্যাপ অনলাইনে (HTTPS)
> হোস্ট করা থাকলেও কাজ করে, ব্রাউজারকে ব্রিজের পিসিতে পৌঁছাতে হয় না।

```
[ZKTeco ডিভাইস] --TCP:4370--> [ব্রিজ (এই প্রোগ্রাম)] --HTTPS--> [Supabase: HR > Attendance] <-- [AccoFlow ERP]
```

## কীভাবে নিরাপদ রাখা হয়েছে

- ব্রিজ নিজের আলাদা **"device" অ্যাকাউন্ট** দিয়ে লগইন করে — সাধারণ ইউজার বা `service_role` key নয়।
  এই অ্যাকাউন্ট **শুধু** `record_zk_attendance()` ফাংশন চালাতে পারে; PI, Accounts, HR, ইউজার — কিছুই পড়তে পারে না।
  তাই `config.json` ফাঁস হলেও ব্যবসায়িক ডেটা নিরাপদ।
- `apiKey` দিলে ব্রিজের সব HTTP এন্ডপয়েন্টে (`/ping` বাদে) `x-api-key` লাগে। `apiKey` খালি থাকলে ব্রিজ **শুধু
  এই পিসি (127.0.0.1)** থেকে অ্যাক্সেস দেয়।
- `/users` আর ডিভাইসের পাসওয়ার্ড/PIN ফেরত দেয় না।
- কর্মচারী মেলানো (Device User ID / NID), Late/Present নির্ধারণ, ডুপ্লিকেট এড়ানো — সবই ডাটাবেসের ভেতরে হয়,
  আগের ইন-ব্রাউজার সিঙ্কের মতোই নিয়মে।
- ব্রিজ প্রতিবার শেষ `backfillDays` (ডিফল্ট ২) দিনের পাঞ্চ আবার পাঠায় — ব্রিজ/ইন্টারনেট কিছুক্ষণ বন্ধ থাকলেও
  কোনো চেক-ইন/চেক-আউট হারায় না। বারবার পাঠালে ডুপ্লিকেট হয় না।

## সেটআপ (একবারই)

### ধাপ ১ — ডাটাবেস মাইগ্রেশন
Supabase **SQL Editor**-এ রান করুন (আগে ব্যাকআপ নিন):
- নতুন ইনস্টল হলে: `accoflow_combined_schema_v24.sql`
- v23 আগে থেকেই চালানো থাকলে: শুধু `migration_v24_hardening_zkbridge.sql`

### ধাপ ২ — ব্রিজের "device" অ্যাকাউন্ট তৈরি
আপনার নিজের কম্পিউটারে (Node.js লাগবে):
```bash
cd AccoFlow_ERP_Update
npm install @supabase/supabase-js
SUPABASE_URL="https://xxxx.supabase.co" SUPABASE_SERVICE_ROLE_KEY="<service_role/secret key>" node scripts/create-bridge-user.mjs
```
স্ক্রিপ্টটি `bridgeUsername` ও একটা র‍্যান্ডম `bridgePassword` প্রিন্ট করবে — কপি করে রাখুন। (`service_role` key
শুধু এই এক কাজে, শুধু আপনার টার্মিনালে লাগে; কাউকে/কোনো চ্যাটে পাঠাবেন না।) পাসওয়ার্ড হারালে `--reset` দিয়ে আবার চালান।

### ধাপ ৩ — `config.json` পূরণ
`config.example.json` দেখুন; মূল ফিল্ড:

| ফিল্ড | অর্থ |
|---|---|
| `deviceIp`, `devicePort` | ZKTeco ডিভাইসের IP / পোর্ট (ডিফল্ট 4370) |
| `supabaseUrl`, `supabaseAnonKey` | Supabase Dashboard → Project Settings → API (anon/publishable key) |
| `bridgeUsername`, `bridgePassword` | ধাপ ২-এর device অ্যাকাউন্ট |
| `pushIntervalMinutes` | কত মিনিট পরপর পাঠাবে (ডিফল্ট 5) |
| `backfillDays` | আগের কত দিনের পাঞ্চ আবার পাঠাবে (ডিফল্ট 2, সর্বোচ্চ 31) |
| `apiKey` | ঐচ্ছিক। দিলে ব্রিজ LAN-এ খোলে ও কী ছাড়া চলে না। লম্বা র‍্যান্ডম কী দিন |
| `allowedOrigins` | ঐচ্ছিক। ERP-র ঠিকানার তালিকা (CORS সীমিত করতে) |

পাসওয়ার্ড/কী ফাইলে না রাখতে চাইলে এনভায়রনমেন্ট ভ্যারিয়েবল ব্যবহার করুন:
`ACCOFLOW_SUPABASE_URL`, `ACCOFLOW_SUPABASE_ANON_KEY`, `ACCOFLOW_BRIDGE_USERNAME`, `ACCOFLOW_BRIDGE_PASSWORD`, `ACCOFLOW_BRIDGE_API_KEY`
(এগুলো `config.json`-এর চেয়ে অগ্রাধিকার পায়)।

### ধাপ ৪ — চালু করুন
Windows-এ `setup.bat` (একবার), তারপর `run.bat`। Node.js ≥ 18 লাগবে। চালু হলে ব্যানারে দেখাবে
"Supabase Push: চালু" এবং প্রথম পুশের ফলাফল (কতগুলো লগ মেলানো হলো, কোন Device User ID মেলেনি)।

### ধাপ ৫ — ERP-তে
Settings → ZKTeco: সুইচ চালু করুন। **Bridge URL ও API Key ঐচ্ছিক** — দিলে "Sync Now" ব্রিজকে সাথে সাথে পুশ করতে বলে;
না দিলে (বা ব্রাউজার থেকে ব্রিজে পৌঁছানো না গেলে) শুধু Supabase-এ ব্রিজের পাঠানো সর্বশেষ ডেটা রিলোড করে।
"Test Bridge" দেখায় ব্রিজ সর্বশেষ কত মিনিট আগে ডেটা পাঠিয়েছে। কর্মচারী মেলাতে HR → Employees-এ
"ZKTeco Device User ID" দিন (খালি থাকলে NID দিয়ে মেলে)।

> **একাধিক ডাটাবেস (Online + Offline LAN)?** ব্রিজ যে Supabase-এ লেখে, ERP-ও সেটিই পড়ে — ব্রিজ সেই এন্ডপয়েন্টেই
> কনফিগার করুন যেটা আপনার ERP সাধারণত ব্যবহার করে।

## এন্ডপয়েন্ট
`GET /ping` (কী লাগে না) · `GET /device-status` · `GET /users` · `GET /attendance?date=` · `GET /attendance-range?from=&to=` ·
`GET|POST /sync-now` (এখনই Supabase-এ পুশ) · `GET /sync-status` (শেষ পুশের অবস্থা)। কী লাগলে হেডার: `x-api-key: <আপনার কী>`।

## সমস্যা হলে
- **"Supabase sign-in failed"** — `bridgeUsername/bridgePassword` ভুল, বা ধাপ ২ করা হয়নি।
- **"record_zk_attendance failed … not authorised"** — অ্যাকাউন্টটা `device` রোলের নয়/পারমিশন নেই; `create-bridge-user.mjs --reset` চালান।
- **"function … does not exist"** — ধাপ ১-এর মাইগ্রেশন রান হয়নি।
- **"মেলেনি (Device User ID)"** — HR → Employees-এ সেই কর্মচারীর "ZKTeco Device User ID" বসান।
- **ডিভাইসে সংযোগ ব্যর্থ** — `deviceIp` ঠিক আছে কিনা, ব্রিজের পিসি ও ডিভাইস একই নেটওয়ার্কে আছে কিনা দেখুন।

## পুরনো Telegram সেটআপ থেকে আপডেট করলে
১) Telegram **Bot Token revoke করুন** (BotFather → /revoke) — পুরনো `config.json` ফাঁস হয়ে থাকতে পারে। ২) ধাপ ১–৪ করুন।
৩) migration v24 নিজে থেকেই ডাটাবেসের `settings` থেকে সংরক্ষিত Telegram token মুছে দেয়।
