/**
 * AccoFlow ERP — Service Worker
 * -----------------------------
 * এটি PWA (Progressive Web App) ফিচারের অংশ — ব্রাউজার থেকে "Install App" করার পর অ্যাপটি
 * নেটিভ অ্যাপের মতো কাজ করে এবং অ্যাপ শেল (HTML/CSS/JS/আইকন) ক্যাশ করে রাখায় ইন্টারনেট সাময়িকভাবে
 * বিচ্ছিন্ন থাকলেও অ্যাপ খুলতে পারে।
 *
 * গুরুত্বপূর্ণ: Supabase API-এর কোনো রিকোয়েস্ট (ভিন্ন origin) এখানে কখনো ক্যাশ করা হয় না — শুধুমাত্র
 * এই অ্যাপের নিজস্ব স্ট্যাটিক ফাইল (HTML/CSS/JS/ছবি) ক্যাশ হয়, যাতে ডাটাবেসের তথ্য কখনোই পুরনো
 * ক্যাশ থেকে দেখানো না হয় — সবসময় সরাসরি Supabase থেকে আসে।
 */

const CACHE_NAME = 'accoflow-erp-v4';
const APP_SHELL = [
  './',
  './index.html',
  './css/styles.css',
  './js/config.js',
  './js/default-data.js',
  './js/supabase-api.js',
  './js/offline-sync.js',
  './js/app.js',
  './manifest.json',
  './assets/logo.png',
  './assets/bg.png',
  './assets/icon-192.png',
  './assets/icon-512.png',
  './assets/ico.png'
];

// ⚠️ বাগ ফিক্স: আগে cache.addAll(APP_SHELL) ব্যবহার হতো, যেটা atomic — তালিকার একটা ফাইলও
// fetch করতে ব্যর্থ হলে (যেমন কোনো ফাইলের নাম case-mismatch হলে, বা কোনো ঐচ্ছিক আইকন এখনো
// আপলোড না করা থাকলে) পুরো cache.addAll() ব্যর্থ হয়ে যেত এবং একটাও ফাইল ক্যাশ হতো না — ফলে
// PWA install ও offline mode দুটোই সম্পূর্ণ অকার্যকর হয়ে যেত। এখন প্রতিটি ফাইল আলাদাভাবে fetch/cache
// করা হয়, তাই একটা ফাইল ব্যর্থ হলেও (শুধু কনসোলে সতর্কতা দেখিয়ে) বাকি সবগুলো ঠিকভাবে ক্যাশ হয়ে যায়।
async function cacheAppShellResilient(cache) {
  const results = await Promise.allSettled(
    APP_SHELL.map((url) => cache.add(url))
  );
  results.forEach((r, i) => {
    if (r.status === 'rejected') {
      console.warn(`[SW] "${APP_SHELL[i]}" ক্যাশ করা যায়নি (ফাইলটি নেই বা নাম/কেসিং মিলছে না) — বাকি ফাইলগুলো ঠিকভাবে ক্যাশ হয়েছে।`, r.reason);
    }
  });
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cacheAppShellResilient(cache))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;

  // শুধুমাত্র GET রিকোয়েস্ট এবং এই অ্যাপের নিজস্ব (same-origin) ফাইলই হ্যান্ডেল করা হয়।
  // Supabase/CDN-এর মতো ভিন্ন origin বা POST/PUT/DELETE রিকোয়েস্ট এখানে স্পর্শ করা হয় না —
  // সেগুলো স্বাভাবিকভাবে সরাসরি নেটওয়ার্কে চলে যাবে।
  let url;
  try { url = new URL(req.url); } catch (e) { return; }
  if (req.method !== 'GET' || url.origin !== self.location.origin) return;

  // ⚠️ বাগ ফিক্স (অফলাইন fallback): আগে নেটওয়ার্ক বন্ধ থাকা অবস্থায় কোনো URL ক্যাশে না থাকলে
  // ব্রাউজারের ডিফল্ট "অফলাইন ডাইনোসর" পেজ দেখাত। এখন নেভিগেশন রিকোয়েস্টের (পেজ লোড/রিফ্রেশ) ক্ষেত্রে
  // নেটওয়ার্ক ব্যর্থ হলে এবং সেই URL ক্যাশেও না থাকলে, ক্যাশে থাকা index.html দেখানো হয় — যেহেতু এটা
  // সিঙ্গেল-পেজ অ্যাপ, তাই এটাই সঠিক আচরণ (অ্যাপ অন্তত খুলবে, ভেতরের ডেটা পরে নেট ফিরলে সিঙ্ক হবে)।
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req).catch(() =>
        caches.match(req).then((cached) => cached || caches.match('./index.html'))
      )
    );
    return;
  }

  // Stale-while-revalidate: ক্যাশে থাকলে সাথে সাথে সেটাই দেখানো হয় (দ্রুত + অফলাইন সাপোর্ট),
  // পাশাপাশি ব্যাকগ্রাউন্ডে নতুন ভার্সন নেটওয়ার্ক থেকে এনে ক্যাশ আপডেট করা হয় (পরের বার আরও ফ্রেশ থাকবে)
  event.respondWith(
    caches.match(req).then((cached) => {
      const networkFetch = fetch(req)
        .then((res) => {
          if (res && res.status === 200) {
            const resClone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
          }
          return res;
        })
        .catch(() => cached);
      return cached || networkFetch;
    })
  );
});
