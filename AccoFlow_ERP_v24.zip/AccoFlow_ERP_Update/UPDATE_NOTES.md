# AccoFlow ERP -- Update Notes (this delivery)

You asked for this zip before the Bangla-to-English translation was fully finished.
Here is the exact, honest state of everything in this package.

## ✅ Fully done and tested

**All 8 previously-found bugs -- fixed and verified against a real PostgreSQL 16 instance:**
1. Amount-in-words dropping cents -- fixed
2. HR Attendance XSS gap (missing escapeHtml) -- fixed
3. Payment RPC overpayment validation -- fixed, tested (a $5000 payment against a $700 due was rejected)
4. auditLog ID collision -- `auditLog.id` converted to an identity column
5. users.role privilege spoofing -- RLS policy now requires self-row role updates to match the real `profiles.role`; tested live, confirmed blocked
6. Offline<->Online delete resurrection -- `sync_tombstones` table + reconcile logic added
7. CORS wildcard in the Edge Function -- replaced with a configurable `ALLOWED_ORIGINS` allowlist
8. `admin-manage-user` Edge Function missing from the self-hosted Docker package -- copied into `docker/volumes/functions/admin-manage-user/`, and `docker/README_SELF_HOST.md`'s deployment steps corrected (the old instructions used cloud-only CLI commands that don't apply to this self-hosted volume-mount setup)

All the related SQL is combined into **one file**: `accoflow_combined_schema_v24.sql` (supersedes v23 — see `MD/CHANGELOG_FIX_v24.md`).
This replaces `schema.sql`, `supabase/migration.sql`, and every separate
`migration_v13...v22.sql` file -- do not run the old files, only this one.
Tested 3x for idempotency (fresh install + 2 re-runs, all error-free) and functionally
tested (payment RPC, overpayment block, role-spoof block, identity columns, tombstone table).

**The requested UI text block removed** from the Roles page in `index.html`.

**Bangla -> English (UK) translation -- fully done in:**
- `index.html`
- `js/offline-sync.js`
- `js/supabase-api.js`
- `js/config.js` (also fixed a stale comment there that incorrectly claimed RLS was still disabled)
- `js/default-data.js` (already had no Bangla text)

## ⚠️ Not yet finished

**`js/app.js` -- translation is 84% done (901 of 1078 Bangla lines translated), ~177 lines remain.**

This is the single largest file in the app, and its Bangla text is spread across roughly
400 separate small comments and user-facing messages rather than a few big blocks, so each
needed individual, careful translation to avoid breaking a template literal or an inline
`onclick` handler.

The remaining Bangla is concentrated mainly in:
- QC Center Settings / ZKTeco device integration section
- A few scattered comments and notify() messages further down the file

**What was verified before sending this package**, so you can trust the parts that are
translated:
- `node --check` passes on every modified `.js` file
- Brace `{}` / parenthesis `()` counts in `app.js` are exactly balanced (2180=2180 braces,
  5931=5931 parens) -- tracked continuously through every edit, not just checked once
- `app.js` was actually `require()`'d in Node (not just syntax-checked) -- it parsed
  completely and began executing before hitting an expected "localStorage is not defined"
  error (localStorage is a browser-only API), confirming the file's structure is fully intact

No functional code logic was changed anywhere during translation -- only comment text and
user-facing message strings. The one security-critical spot (the Super Admin self-escalation
check in `saveUser()`) was double-checked afterward with a separate `grep` to confirm the
actual `if` condition is byte-for-byte unchanged.

## If you'd like the rest finished

Just say so and the remaining ~177 lines in `app.js` can be completed the same careful way,
and a final, fully-translated package can follow.
