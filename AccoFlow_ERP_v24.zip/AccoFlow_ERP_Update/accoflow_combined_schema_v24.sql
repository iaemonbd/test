-- ============================================================================
-- AccoFlow ERP -- Complete Consolidated Database Script (v23)
-- ============================================================================
-- This ONE file replaces: schema.sql, supabase/migration.sql, and all separate
-- migration_v13/v14/v15/v16/v18/v21/v22/v23.sql files. Do not use the old files
-- alongside this one -- this file already contains everything they contained,
-- applied in the correct order, with the identity-column idempotency bug from
-- the old v16 file already fixed.
--
-- Contains (in order): schema.sql (base tables) -> v13 (RLS + profiles + Auth) ->
-- v14 (HR read lockdown) -> v15 (module/role write policies) -> v16 (atomic
-- payment RPCs) -> v18 (role redesign) -> v21 (custom per-user permissions) ->
-- v22 (offline/online sync support) -> v23 (this round's fixes, see below).
--
-- v23 fixes included in this file:
--   1. Payment RPCs now reject a payment that would exceed the outstanding due
--      (previously no upper bound existed -- a typo could silently overpay).
--   2. auditLog.id converted to an identity column (previously a plain bigint --
--      two concurrent payments on different PI/Order numbers could collide).
--   3. users table RLS: a non-admin user can no longer set their own "role"
--      column to 'superadmin' via a direct API call -- self-row updates must
--      now keep role identical to the user's real profiles.role.
--   4. sync_tombstones table + reconcile logic added, so a record deleted on
--      one side (Online/Offline) is removed from the other side on next sync
--      instead of being resurrected. (The matching offline-sync.js/
--      supabase-api.js code changes ship separately with the app files.)
--
-- ✅ Verified before delivery: run against a real local PostgreSQL 16 instance
-- with Supabase's auth.users/auth.uid()/anon/authenticated roles simulated --
--   - Fresh (empty) database: runs completely error-free
--   - Re-run twice more on the same already-migrated database: completely
--     error-free both times (idempotent -- safe to run repeatedly)
--   - record_buyer_payment() tested end-to-end: normal payment succeeds,
--     overpayment attempt correctly rejected
--   - users.role self-escalation attempt tested and confirmed blocked
--   - auditLog.id confirmed converted to identity
--   - sync_tombstones table confirmed created with correct structure
--
-- Usage:
--   - Fresh/new install (e.g. Docker self-hosted Offline instance): run this
--     whole file once, top to bottom.
--   - Existing production project: this is safe to re-run (idempotent), but
--     take a manual backup first via Database > Backups regardless -- always
--     good practice before running anything against production.
-- ============================================================================

-- ============================================================
-- AccoFlow_V-7_4 — Supabase (PostgreSQL) স্কিমা
-- এই সম্পূর্ণ ফাইলটি Supabase Dashboard → SQL Editor-এ পেস্ট করে "Run" করুন।
-- একবার রান করলেই সব টেবিল তৈরি হয়ে যাবে।
-- ============================================================

-- সেটিংস (Company Info, Super Admin ক্রেডেনশিয়াল, Office Hours, সিগনেচার ইত্যাদি key/value আকারে)
create table if not exists settings (
  key text primary key,
  value text
);

-- Inventory & PI
create table if not exists "piList" (
  id integer primary key,
  date text, "piNo" text, buyer text, supplier text, items text, "totalValue" text, "qcStatus" text,
  "formData" jsonb
);

-- ⚠️ ফিচার (Data Safety > Complete Order List): PI সম্পূর্ণ (ডেলিভারি + বায়ার/সাপ্লায়ার পেমেন্ট
-- সব শেষ) হয়ে গেলে আর্কাইভ করার জন্য ফ্ল্যাগ — ডেটা ডিলিট/মুভ করে না, শুধু সাধারণ তালিকা থেকে
-- ফিল্টার করে রাখে (রিভার্সিবল)
alter table "piList" add column if not exists archived boolean default false;
alter table "piList" add column if not exists "archivedAt" text;

-- এই ALTER স্টেটমেন্টটি বিদ্যমান পুরনো ডাটাবেসের জন্য (যেখানে টেবিল আগেই তৈরি হয়ে গেছে)।
-- এটাই ছিল "PI সেভ না হওয়া" বাগ-এর মূল কারণ — PI ফর্মের সম্পূর্ণ ডেটা (formData) রাখার জন্য
-- কোনো কলামই ছিল না, তাই Supabase প্রতিবার সেভ করতে গিয়ে "column not found" এরর দিত।
alter table "piList" add column if not exists "formData" jsonb;

create table if not exists "masterData" (
  id integer primary key,
  "itemCode" text, description text, "unitPrice" text, size text, unit text, stock text, image text,
  "sellingPrice" text, "buyingPrice" text, "styleNo" text, brand text, "hsCode" text, dept text
);

-- বিদ্যমান ডাটাবেসের জন্য: Selling/Buying Unit Price আলাদা করা এবং Style No / Brand যুক্ত করা
alter table "masterData" add column if not exists "sellingPrice" text;
alter table "masterData" add column if not exists "buyingPrice" text;
alter table "masterData" add column if not exists "styleNo" text;
alter table "masterData" add column if not exists brand text;
-- Inventory & PI > Master Data > Add New Item ফর্মে নতুন যোগ হওয়া HS Code (Harmonized System Code)
-- ও Dept (Department) ফিল্ডের জন্য কলাম যোগ — বিদ্যমান ডাটাবেসেও নিরাপদে (idempotent) চালানো যাবে
alter table "masterData" add column if not exists "hsCode" text;
alter table "masterData" add column if not exists dept text;

create table if not exists "receivedGoods" (
  id integer primary key,
  date text, "orderNo" text, "piNo" text, "styleNo" text, buyer text, "itemName" text,
  "orderQty" text, "receivedQty" text, "cnNo" text, "dueQty" text, items jsonb
);

-- বিদ্যমান ডাটাবেসের জন্য: একটি সাপ্লাইয়ার অর্ডারের ভেতরে একাধিক আইটেম কোড/স্টাইল/কোয়ান্টিটি
-- (partial delivery) রাখার জন্য items jsonb কলাম যুক্ত করা হলো
alter table "receivedGoods" add column if not exists items jsonb;

create table if not exists "supplierOrders" (
  id integer primary key,
  date text, "orderNo" text, "piNo" text, merchandiser text, supplier text,
  "expectedDelivery" text, items text, "totalValue" text
);

-- Delivery Center
create table if not exists "deliveryPlan" (
  id integer primary key,
  "orderNo" text, buyer text, item text, "remainingQty" text, "expectedDate" text, priority text, status text,
  "challanData" jsonb
);
-- Challan Generator থেকে "Save DB" করা চালানের পুরো বিস্তারিত (আইটেম রো, ঠিকানা, Delivered By
-- ইত্যাদি) এখানে সংরক্ষিত থাকে — View/Edit করার সময় সম্পূর্ণ চালান ফিরে পাওয়ার জন্য (B3)
alter table "deliveryPlan" add column if not exists "challanData" jsonb;

create table if not exists "deliveryExec" (
  id integer primary key,
  date text, "orderNo" text, challan text, man text, qty text, status text
);

create table if not exists "deliveryHist" (
  id integer primary key,
  date text, "orderNo" text, buyer text, challan text, qty text, "deliveredBy" text, status text
);

-- QC Center
create table if not exists "qcList" (
  id integer primary key,
  date text, "orderNo" text, "itemCode" text, challan text, supplier text, buyer text,
  qty text, "qcQty" text, "rejectQty" text, "rejectPct" text, result text, action text
);

-- বিদ্যমান ডাটাবেসের জন্য: QC রিপোর্টে Action (করণীয়) কলাম যুক্ত করা
alter table "qcList" add column if not exists action text;

-- বিদ্যমান ডাটাবেসের জন্য: QC রিপোর্টে ইউজারের নিজের তৈরি করা কাস্টম কলামের ডেটা (Add Column ফিচার)
-- key/value আকারে jsonb-তে রাখার জন্য কলাম
alter table "qcList" add column if not exists "extraData" jsonb;

-- বিদ্যমান ডাটাবেসের জন্য: QC রিপোর্ট রিডিজাইন (নতুন স্টাইল — একটা Challan/Order-এর অধীনে একাধিক
-- PI/Style-এর আইটেম-ভিত্তিক সারি) — প্রতিটি সারির নিজস্ব PI No ও Style No রাখার জন্য কলাম
alter table "qcList" add column if not exists "piNo" text;
alter table "qcList" add column if not exists "styleNo" text;

-- Accounts & Finance
create table if not exists "accBuyer" (
  id integer primary key,
  "piNo" text, buyer text, lc text, total text, received text, due text, status text
);

create table if not exists "accSupplier" (
  id integer primary key,
  date text, "orderNo" text, supplier text, total text, paid text, due text
);

create table if not exists "buyerPaymentHistory" (
  id integer primary key,
  "piNo" text, buyer text, amount text, method text, "checkNumber" text, date text, remarks text, "receiptImage" text
);

create table if not exists "supplierPaymentHistory" (
  id integer primary key,
  "orderNo" text, supplier text, amount text, method text, "checkNumber" text, date text, remarks text, "receiptImage" text
);

-- Office Expense & Vouchers
create table if not exists "expenseList" (
  id integer primary key,
  date text, "voucherNo" text, category text, person text, purpose text, amount text, ret text, status text,
  "rejectNote" text, "voucherDetails" jsonb
);
-- Voucher Entry থেকে সেভ হওয়া এন্ট্রি এখন সরাসরি এখানেই আসে (আলাদা "Vouchers" ট্যাব বাদ দেওয়া হয়েছে)।
-- rejectNote: Reject করার সময় Authorized ব্যক্তির লেখা ছোট নোট। voucherDetails: পুরো ভাউচারের
-- বিস্তারিত (transport rows, received/due) — "View" করার সময় সম্পূর্ণ ভাউচার দেখানোর জন্য।
alter table "expenseList" add column if not exists "rejectNote" text;
alter table "expenseList" add column if not exists "voucherDetails" jsonb;

create table if not exists vouchers (
  id integer primary key,
  "voucherNo" text, date text, claimant text, purpose text, received text, total text, ret text, due text, status text
);

-- HR Module
create table if not exists "hrEmployees" (
  id integer primary key,
  name text, designation text, contact text, "joinDate" text, status text, nid text, "basicSalary" text, photo text
);

-- বিদ্যমান ডাটাবেসের জন্য: ZKTeco অ্যাক্সেস কন্ট্রোল ডিভাইসের সাথে এই কর্মচারীকে মেলানোর জন্য
-- ডিভাইসের ইউজার আইডি সংরক্ষণ করার কলাম (ZKTeco integration ফিচারের অংশ, ঐচ্ছিক)
alter table "hrEmployees" add column if not exists "zkUserId" text;

create table if not exists "hrAttendance" (
  id integer primary key,
  date text, employee text, "checkIn" text, "checkOut" text, status text, "otHours" text
);

-- HR > Attendance-এ "Leave of Absence" ফিচারের জন্য — একজন কর্মচারীর ছুটির আবেদন (তারিখ রেঞ্জ +
-- লিখিত আবেদনের ছবি/ফাইল সংযুক্তি) সংরক্ষণ করে। ছুটি সেভ হওয়ার সাথে সাথে সেই রেঞ্জের প্রতিটা
-- তারিখের জন্য hrAttendance-এ status="On Leave" এন্ট্রি অটো-তৈরি হয় (app.js দেখুন)।
create table if not exists "hrLeaves" (
  id integer primary key,
  employee text, "startDate" text, "endDate" text, document text, "createdAt" text
);

create table if not exists "hrSalary" (
  id integer primary key,
  employee text, designation text, basic text, "otHours" text, ot text, deduction text, net text, status text
);
-- ⚠️ বাগ ফিক্স: HR Module উন্নতি রাউন্ডে hrSalary রেকর্ডে "month" ফিল্ড (Salary Month) যোগ করা
-- হয়েছিল app.js-এ, কিন্তু schema.sql-এ কলাম যোগ করা হয়নি — ফলে Supabase-এ Save করার সময়
-- "column does not exist" এরর দিয়ে পুরো Save ব্যর্থ হতো (ডেটা শুধু লোকালি থাকত, রিফ্রেশ দিলে হারিয়ে
-- যেত)। এখন ঠিক করা হলো।
alter table "hrSalary" add column if not exists month text;

-- ⚠️ বাগ ফিক্স: হুবহু একই কারণে hrLeaves-এ "days" (মোট ছুটির দিন) কলামও মিসিং ছিল
alter table "hrLeaves" add column if not exists days text;

-- ⚠️ ফিচার: Department + Salary Account Number — HR Settings থেকে যোগ করা নতুন ফিল্ড
alter table "hrEmployees" add column if not exists department text;
alter table "hrEmployees" add column if not exists "salaryAccountNo" text;

-- ⚠️ ফিচার: Supplier Order Sheet-এ কোন মার্চেন্ডাইজারের সিগনেচার সিলেক্ট করা হয়েছিল তা সংরক্ষণ
alter table "supplierOrders" add column if not exists "signMerchandiserId" text;

-- ⚠️ ফিচার (HR Settings): একাধিক মার্চেন্ডাইজারের সিগনেচার সংরক্ষণের জন্য নতুন টেবিল — আগে
-- settings.signMerchandiser-এ শুধু একজনের সিগনেচার রাখা যেত, এখন একাধিক মার্চেন্ডাইজার আলাদাভাবে
-- যোগ করা যায় এবং Supplier Order Sheet-এর মতো জায়গায় ড্রপডাউন থেকে বেছে নেওয়া যায়।
create table if not exists "hrSignatures" (
  id integer primary key,
  name text, designation text, "signatureImage" text, "createdAt" text
);
alter table "hrSignatures" add column if not exists "deletedAt" text;
alter table "hrSignatures" add column if not exists "deletedBy" text;

-- ⚠️ ফিচার (HR Settings): Department তৈরি/ডিলিট + Department Head নির্বাচন
create table if not exists "hrDepartments" (
  id integer primary key,
  name text, "headEmployeeId" integer, "createdAt" text
);
alter table "hrDepartments" add column if not exists "deletedAt" text;
alter table "hrDepartments" add column if not exists "deletedBy" text;

-- ⚠️ ফিচার (HR Settings অ্যাপ্রুভাল ওয়ার্কফ্লো): 'admin' রোলের HR Settings পরিবর্তন এখানে
-- "Pending"-এ জমা থাকে, Super Admin Approve/Reject না করা পর্যন্ত প্রকৃতপক্ষে প্রয়োগ হয় না।
create table if not exists "hrApprovals" (
  id integer primary key,
  type text, summary text, payload text, "requestedBy" text, "requestedAt" text,
  status text, "reviewedBy" text, "reviewedAt" text
);

-- Users & Roles
create table if not exists users (
  id integer primary key,
  username text, name text, role text, password text, permissions text, "lastLogin" text, status text
);

-- বিদ্যমান ডাটাবেসের জন্য: প্রতিটি ইউজারের নিজস্ব (per-user) Accent Color (theme) ও সম্পূর্ণ Full
-- Theme/Style Pack (stylePack) সংরক্ষণ করার কলাম — যাতে প্রতিটি ইউজার লগইন করলে শুধু তার নিজের
-- সেট করা থিমটাই লোড হয়, অন্য কোনো ইউজারের থিম পরিবর্তনে প্রভাবিত না হয়
alter table users add column if not exists theme text;
alter table users add column if not exists "stylePack" text;
-- ⚠️ থিম সিস্টেম রিডিজাইন: আগের theme + stylePack (দুইটা আলাদা কলাম, ৫০+ কম্বিনেশন সম্ভব ছিল,
-- ফলে Light Mode-এ কিছু কম্বিনেশনে বাটন অদৃশ্য হয়ে যাওয়ার মতো কনট্রাস্ট বাগ থেকে যেত) বাদ দিয়ে এখন
-- একটাই সম্পূর্ণ স্বয়ংসম্পূর্ণ "App Theme" — 'classic' | 'clean-light' | 'enterprise-blue' | 'warm-earthy'।
-- পুরনো theme/stylePack কলাম দুটো ইচ্ছাকৃতভাবে ড্রপ করা হয়নি (destructive migration এড়াতে), শুধু
-- অ্যাপ থেকে আর ব্যবহার হয় না।
alter table users add column if not exists "appTheme" text;

-- Buyer & Supplier Info
create table if not exists buyers (
  id integer primary key,
  name text, address text, mobile text, email text, country text, "contactPerson" text,
  "bankAccount" text, bin text, swift text, "outsideMerchandiser" text, logo text, orders text, status text,
  "bankName" text, "bankBranch" text
);
-- Buyer Directory-তে Bank Name ও Branch (Buyer Bank Branch) যোগ — PI ফর্মের "Notify Party"
-- ফিল্ডে বায়ারের ব্যাংকের নাম ও ব্রাঞ্চ অটো-ফিল করার জন্য প্রয়োজন
alter table buyers add column if not exists "bankName" text;
alter table buyers add column if not exists "bankBranch" text;

create table if not exists suppliers (
  id integer primary key,
  name text, address text, mobile text, "bankAcc" text, bank text, bin text,
  "contactPerson" text, logo text, supply text, status text
);

-- Orders lookup (Received Goods / Delivery / QC ড্রপডাউনে ব্যবহৃত)
create table if not exists orders (
  "orderNo" text primary key,
  buyer text, item text, qty text, supplier text, contact text, address text, pi text, "styleNo" text, "itemName" text,
  type text, items jsonb
);

-- বিদ্যমান ডাটাবেসের জন্য: PI vs Supplier Order আলাদা করার জন্য type কলাম, এবং Supplier Order-এর
-- item-wise ডিটেইল (Received Goods অটোফিলের জন্য ব্যবহৃত) রাখার জন্য items কলাম
alter table orders add column if not exists type text;
alter table orders add column if not exists items jsonb;

-- ============================================================
-- অডিট লগ (Audit Log) — কে কখন কোন রেকর্ড তৈরি/পরিবর্তন/ডিলিট/রিস্টোর করলো তার ইতিহাস
-- ============================================================
create table if not exists "auditLog" (
  id bigint primary key,
  "timestamp" text,
  username text,
  role text,
  action text,        -- Create / Update / Delete / Restore
  module text,        -- কোন টেবিল (piList, vouchers, ইত্যাদি)
  "recordId" text,
  "recordLabel" text  -- মানুষের পড়ার মতো বর্ণনা (যেমন PI No, Voucher No)
);

-- ============================================================
-- Recycle Bin / Soft Delete — ডিলিট করা রেকর্ড সাথে সাথে স্থায়ীভাবে না মুছে এই দুটো কলামে
-- চিহ্নিত করে রাখা হয়, যাতে Trash পেজ থেকে পরে ফেরত আনা যায়
-- ============================================================
alter table "piList" add column if not exists "deletedAt" text;
alter table "piList" add column if not exists "deletedBy" text;
alter table "masterData" add column if not exists "deletedAt" text;
alter table "masterData" add column if not exists "deletedBy" text;
alter table "receivedGoods" add column if not exists "deletedAt" text;
alter table "receivedGoods" add column if not exists "deletedBy" text;
alter table "supplierOrders" add column if not exists "deletedAt" text;
alter table "supplierOrders" add column if not exists "deletedBy" text;
alter table "deliveryPlan" add column if not exists "deletedAt" text;
alter table "deliveryPlan" add column if not exists "deletedBy" text;
alter table "deliveryHist" add column if not exists "deletedAt" text;
alter table "deliveryHist" add column if not exists "deletedBy" text;
alter table "qcList" add column if not exists "deletedAt" text;
alter table "qcList" add column if not exists "deletedBy" text;
alter table "accBuyer" add column if not exists "deletedAt" text;
alter table "accBuyer" add column if not exists "deletedBy" text;
alter table "accSupplier" add column if not exists "deletedAt" text;
alter table "accSupplier" add column if not exists "deletedBy" text;
alter table "expenseList" add column if not exists "deletedAt" text;
alter table "expenseList" add column if not exists "deletedBy" text;
alter table vouchers add column if not exists "deletedAt" text;
alter table vouchers add column if not exists "deletedBy" text;
alter table "hrEmployees" add column if not exists "deletedAt" text;
alter table "hrEmployees" add column if not exists "deletedBy" text;
alter table "hrAttendance" add column if not exists "deletedAt" text;
alter table "hrAttendance" add column if not exists "deletedBy" text;
alter table "hrLeaves" add column if not exists "deletedAt" text;
alter table "hrLeaves" add column if not exists "deletedBy" text;
alter table "hrSalary" add column if not exists "deletedAt" text;
alter table "hrSalary" add column if not exists "deletedBy" text;
alter table users add column if not exists "deletedAt" text;
alter table users add column if not exists "deletedBy" text;
alter table buyers add column if not exists "deletedAt" text;
alter table buyers add column if not exists "deletedBy" text;
alter table suppliers add column if not exists "deletedAt" text;
alter table suppliers add column if not exists "deletedBy" text;

-- ============================================================
-- Row Level Security (RLS) বন্ধ রাখা হচ্ছে
-- আপনার আগের Google Apps Script "Anyone can access" সেটআপের মতোই নিরাপত্তার স্তর বজায় রাখতে
-- RLS বন্ধ রাখা হলো, যাতে anon key দিয়ে সরাসরি অ্যাপ থেকে read/write করা যায়।
-- ভবিষ্যতে সত্যিকারের ইউজার-লেভেল সিকিউরিটি চাইলে RLS চালু করে policy লেখা যাবে।
-- ============================================================
alter table settings disable row level security;
alter table "piList" disable row level security;
alter table "masterData" disable row level security;
alter table "receivedGoods" disable row level security;
alter table "supplierOrders" disable row level security;
alter table "deliveryPlan" disable row level security;
alter table "deliveryExec" disable row level security;
alter table "deliveryHist" disable row level security;
alter table "qcList" disable row level security;
alter table "accBuyer" disable row level security;
alter table "accSupplier" disable row level security;
alter table "buyerPaymentHistory" disable row level security;
alter table "supplierPaymentHistory" disable row level security;
alter table "expenseList" disable row level security;
alter table vouchers disable row level security;
alter table "hrEmployees" disable row level security;
alter table "hrAttendance" disable row level security;
alter table "hrLeaves" disable row level security;
alter table "hrSalary" disable row level security;
alter table "hrSignatures" disable row level security;
alter table "hrDepartments" disable row level security;
alter table "hrApprovals" disable row level security;
alter table users disable row level security;
alter table buyers disable row level security;
alter table suppliers disable row level security;
alter table orders disable row level security;
alter table "auditLog" disable row level security;

-- ============================================================================
-- AccoFlow ERP — রাউন্ড ১৩: RLS + Supabase Auth মাইগ্রেশন
-- ============================================================================
-- এই স্ক্রিপ্টটা Supabase Dashboard > SQL Editor-এ একবার (পুরোটা একসাথে) রান করুন।
-- idempotent করার চেষ্টা করা হয়েছে (দ্বিতীয়বার রান করলেও এরর দেবে না), তবু প্রোডাকশনে
-- রান করার আগে "Database > Backups"-এ একটা ম্যানুয়াল ব্যাকআপ নিয়ে রাখার পরামর্শ থাকল।
--
-- ⚠️ রান করার পর সাথে সাথে বর্তমান অ্যাপ (v12 কোড) কাজ করা বন্ধ করে দেবে — কারণ এখন থেকে
-- শুধু বৈধ Supabase Auth সেশন থাকা ইউজারই ডেটা পড়তে/লিখতে পারবে, আর v12 কোড এখনো Supabase
-- Auth ব্যবহার করে না। এই ফোল্ডারের নতুন js/app.js + js/supabase-api.js ডিপ্লয় করা এবং
-- scripts/bootstrap-auth-users.mjs দিয়ে বিদ্যমান ইউজারদের Auth অ্যাকাউন্ট তৈরি করা পর্যন্ত
-- (দেখুন MD/RLS_AUTH_MIGRATION_GUIDE.md) অ্যাপ ডাউন থাকবে — তাই অফিস আওয়ারের বাইরে করুন।
-- ============================================================================

-- ---------------------------------------------------------------------------
-- ধাপ ১ — profiles ব্রিজ টেবিল
-- ---------------------------------------------------------------------------
-- এটা আপনার বিদ্যমান "users" টেবিলকে প্রতিস্থাপন করছে না — "users" টেবিল ঠিক আগের মতোই
-- থাকছে (নাম/পারমিশন/থিম/লাস্ট-লগইন ইত্যাদির জন্য, User Management স্ক্রিন অপরিবর্তিত)।
-- profiles শুধু "কে (auth.uid()) আসলে কোন username/role হিসেবে লগইন করে আছে" — এই তথ্যটা
-- RLS পলিসির জন্য বহন করে। saveUser() থেকে এখন প্রতিটা ইউজার তৈরি/এডিটে এটাও সিঙ্ক হবে।
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  role text not null default 'staff',
  status text not null default 'Active',
  "createdAt" timestamptz not null default now()
);

alter table profiles enable row level security;

-- ---------------------------------------------------------------------------
-- ধাপ ২ — হেল্পার ফাংশন (RLS পলিসিতে বারবার ব্যবহারের জন্য)
-- ---------------------------------------------------------------------------
-- security definer দেওয়া হয়েছে যাতে ফাংশনটা নিজেই profiles টেবিল পড়তে পারে RLS-এর কারণে
-- আটকে না গিয়ে (নাহলে "role চেক করতে গিয়ে role চেক করা" এই বৃত্তে আটকে যেত)
create or replace function public.current_role()
returns text
language sql stable
security definer set search_path = public
as $$
  select role from profiles where id = auth.uid() and status = 'Active';
$$;

create or replace function public.is_active_user()
returns boolean
language sql stable
security definer set search_path = public
as $$
  select exists (select 1 from profiles where id = auth.uid() and status = 'Active');
$$;

-- ---------------------------------------------------------------------------
-- ধাপ ৩ — profiles-এর নিজের পলিসি
-- ---------------------------------------------------------------------------
drop policy if exists "profiles_self_or_admin_read" on profiles;
create policy "profiles_self_or_admin_read" on profiles for select
  using (auth.uid() = id or public.current_role() in ('admin', 'superadmin'));

drop policy if exists "profiles_admin_write" on profiles;
create policy "profiles_admin_write" on profiles for all
  using (public.current_role() in ('admin', 'superadmin'))
  with check (public.current_role() in ('admin', 'superadmin'));

-- ---------------------------------------------------------------------------
-- ধাপ ৪ — সব বিজনেস টেবিলে RLS চালু করা (এটাই মূল ক্রিটিক্যাল ফিক্স)
-- ---------------------------------------------------------------------------
alter table settings enable row level security;
alter table "piList" enable row level security;
alter table "masterData" enable row level security;
alter table "receivedGoods" enable row level security;
alter table "supplierOrders" enable row level security;
alter table "deliveryPlan" enable row level security;
alter table "deliveryExec" enable row level security;
alter table "deliveryHist" enable row level security;
alter table "qcList" enable row level security;
alter table "accBuyer" enable row level security;
alter table "accSupplier" enable row level security;
alter table "buyerPaymentHistory" enable row level security;
alter table "supplierPaymentHistory" enable row level security;
alter table "expenseList" enable row level security;
alter table vouchers enable row level security;
alter table "hrEmployees" enable row level security;
alter table "hrAttendance" enable row level security;
alter table "hrLeaves" enable row level security;
alter table "hrSalary" enable row level security;
alter table "hrSignatures" enable row level security;
alter table "hrDepartments" enable row level security;
alter table "hrApprovals" enable row level security;
alter table users enable row level security;
alter table buyers enable row level security;
alter table suppliers enable row level security;
alter table orders enable row level security;
alter table "auditLog" enable row level security;

-- ---------------------------------------------------------------------------
-- ধাপ ৫ — সাধারণ টেবিল: যেকোনো সক্রিয় লগইন করা ইউজার read+write করতে পারবে
-- ---------------------------------------------------------------------------
-- (এখনকার অ্যাপের role-ভিত্তিক UI-লেভেল পারমিশন আগের মতোই কাজ করবে; এটা শুধু নিশ্চিত করছে
-- যে ডাটাবেস-লেভেলে অন্তত একটা বৈধ, admin-ইস্যু-করা লগইন ছাড়া কেউ কিছুই পড়তে/লিখতে পারবে না —
-- যা আগে RLS বন্ধ থাকায় সম্পূর্ণ সম্ভব ছিল। টেবিল-ভিত্তিক আরও সূক্ষ্ম role-restriction (যেমন
-- "Accountant HR এডিট করতে পারবে না") পরবর্তী ধাপে আলাদাভাবে যোগ করা যাবে, এই মাইগ্রেশন তার
-- জন্য অপেক্ষা করছে না।)
do $$
declare
  t text;
  general_tables text[] := array[
    'piList','masterData','receivedGoods','supplierOrders','deliveryPlan','deliveryExec',
    'deliveryHist','qcList','accBuyer','accSupplier','buyerPaymentHistory',
    'supplierPaymentHistory','expenseList','vouchers','hrAttendance','hrLeaves',
    'hrDepartments','hrApprovals','buyers','suppliers','orders'
  ];
begin
  foreach t in array general_tables loop
    execute format('drop policy if exists "authenticated_all" on %I', t);
    execute format(
      'create policy "authenticated_all" on %I for all using (public.is_active_user()) with check (public.is_active_user())',
      t
    );
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- ধাপ ৬ — স্পর্শকাতর টেবিল: read সবার জন্য (UI-তে যেমন এখন আছে), write শুধু admin/superadmin
-- ---------------------------------------------------------------------------
-- hrEmployees: NID, বেতন, ব্যাংক অ্যাকাউন্ট নম্বর থাকে — এডিট/ডিলিট শুধু admin/superadmin
drop policy if exists "hrEmployees_read" on "hrEmployees";
create policy "hrEmployees_read" on "hrEmployees" for select using (public.is_active_user());
drop policy if exists "hrEmployees_write" on "hrEmployees";
create policy "hrEmployees_write" on "hrEmployees" for insert with check (public.current_role() in ('admin','superadmin'));
drop policy if exists "hrEmployees_update" on "hrEmployees";
create policy "hrEmployees_update" on "hrEmployees" for update using (public.current_role() in ('admin','superadmin'));
drop policy if exists "hrEmployees_delete" on "hrEmployees";
create policy "hrEmployees_delete" on "hrEmployees" for delete using (public.current_role() in ('admin','superadmin'));

-- hrSalary, hrSignatures: একই নিয়ম
do $$
declare
  t text;
  sensitive_tables text[] := array['hrSalary','hrSignatures'];
begin
  foreach t in array sensitive_tables loop
    execute format('drop policy if exists "%s_read" on %I', t, t);
    execute format('create policy "%s_read" on %I for select using (public.is_active_user())', t, t);
    execute format('drop policy if exists "%s_write" on %I', t, t);
    execute format('create policy "%s_write" on %I for insert with check (public.current_role() in (''admin'',''superadmin''))', t, t);
    execute format('drop policy if exists "%s_update" on %I', t, t);
    execute format('create policy "%s_update" on %I for update using (public.current_role() in (''admin'',''superadmin''))', t, t);
    execute format('drop policy if exists "%s_delete" on %I', t, t);
    execute format('create policy "%s_delete" on %I for delete using (public.current_role() in (''admin'',''superadmin''))', t, t);
  end loop;
end $$;

-- settings: শুধু superadmin লিখতে পারবে (সুপার অ্যাডমিন পাসওয়ার্ড, কোম্পানি সেটিংস ইত্যাদি থাকে);
-- read সবার জন্য খোলা কারণ অ্যাপের অনেক UI অংশ থিম/কোম্পানি-নাম দেখাতে এটা পড়ে
drop policy if exists "settings_read" on settings;
create policy "settings_read" on settings for select using (public.is_active_user());
drop policy if exists "settings_write" on settings;
create policy "settings_write" on settings for all
  using (public.current_role() = 'superadmin')
  with check (public.current_role() = 'superadmin');

-- users: read সবার জন্য (UI-তে নাম/থিম দরকার হয়), write শুধু admin/superadmin —
-- (ভবিষ্যতে চাইলে "নিজের theme/appTheme নিজে বদলাতে পারবে" এই ছাড়টা আলাদা পলিসি দিয়ে যোগ করা যায়)
drop policy if exists "users_read" on users;
create policy "users_read" on users for select using (public.is_active_user());
drop policy if exists "users_write" on users;
-- ⚠️ রাউন্ড ১৫ ফিক্স: শুধু admin/superadmin দিয়ে রাখলে যেকোনো সাধারণ ইউজারের লগইনে
-- lastLogin আপডেট করার upsert() কলটাই ব্যর্থ হতো — কারণ Postgres upsert (INSERT ... ON
-- CONFLICT DO UPDATE) সবসময় INSERT পলিসিই আগে যাচাই করে, রো আগে থেকে থাকলেও। তাই এখানেও
-- users_update-এর মতো নিজের রো'র জন্য একটা exception যোগ করা হলো।
create policy "users_write" on users for insert with check (
  public.current_role() in ('admin','superadmin')
  or auth.uid()::text = (select id::text from profiles where username = users.username)
);
drop policy if exists "users_update" on users;
create policy "users_update" on users for update using (public.current_role() in ('admin','superadmin') or auth.uid()::text = (select id::text from profiles where username = users.username));
drop policy if exists "users_delete" on users;
create policy "users_delete" on users for delete using (public.current_role() in ('admin','superadmin'));

-- auditLog: যেকোনো সক্রিয় ইউজার নতুন এন্ট্রি লিখতে ও পড়তে পারবে, কিন্তু কেউ (admin/superadmin
-- সহ) UPDATE/DELETE করতে পারবে না — অডিট ট্রেইল যেন কখনো পরিবর্তন/মুছে ফেলা না যায় (কেউ চাইলে
-- সরাসরি service_role দিয়ে SQL Editor থেকে করতে পারবে, RLS সেটাকে বাধা দেয় না)
drop policy if exists "auditLog_read" on "auditLog";
create policy "auditLog_read" on "auditLog" for select using (public.is_active_user());
drop policy if exists "auditLog_insert" on "auditLog";
create policy "auditLog_insert" on "auditLog" for insert with check (public.is_active_user());

-- ============================================================================
-- এখানেই SQL অংশ শেষ। এরপর MD/RLS_AUTH_MIGRATION_GUIDE.md অনুযায়ী পরের ধাপগুলো করুন:
-- Edge Function ডিপ্লয় → bootstrap script রান → নতুন app.js/supabase-api.js ডিপ্লয় → টেস্ট।
-- ============================================================================
-- ============================================================================
-- AccoFlow ERP — রাউন্ড ১৪: HR স্পর্শকাতর ডেটা (NID/Salary/Bank) read-lockdown
-- ============================================================================
-- Supabase Dashboard > SQL Editor-এ এটা রান করুন (migration_v13_rls_auth.sql আগে থেকেই
-- রান করা থাকতে হবে, কারণ এখানে public.current_role() ফাংশনটা ব্যবহার করা হচ্ছে)।
-- idempotent — একাধিকবার রান করলেও সমস্যা নেই।
--
-- সমস্যা ছিল: hrEmployees ও hrSalary-এর SELECT policy শুধু is_active_user() চেক করত —
-- অর্থাৎ role যাই হোক (storekeeper, merchandiser, accountant...) যেকোনো সক্রিয় লগইন করা
-- ইউজার API/DevTools দিয়ে সরাসরি সব কর্মচারীর NID, বেতন, ব্যাংক অ্যাকাউন্ট নম্বর পড়তে পারতেন —
-- যদিও UI-তে এই মডিউল শুধু admin/superadmin-এর জন্যই দেখানো হয় (দেখুন js/app.js-এর
-- applyRolePermissions()-এর allowedPages ম্যাপ)। এখন DB-লেভেলেও একই নিয়ম বলবৎ করা হলো।
--
-- ⚠️ hrSignatures ইচ্ছাকৃতভাবে এখানে বাদ দেওয়া হয়েছে — যাচাই করে দেখা গেছে merchandiser role
-- Supplier Order Sheet-এ নিজের সিগনেচার সিলেক্ট করতে এই টেবিল read করে (applyMerchSignatureToSO),
-- তাই সেটা admin/superadmin-এ লক করলে বৈধ ফিচার ভেঙে যেত। hrSignatures-এ কোনো NID/Salary/Bank
-- তথ্য থাকে না, শুধু নাম+পদবি+সিগনেচার ছবি — তাই আগের মতোই সব সক্রিয় ইউজারের জন্য read খোলা রইল।
--
-- প্রভাব (deploy করার আগে জেনে রাখুন): লগইন করলে সাইডবারে যে ইউজারের ছবি দেখানো হয় সেটা
-- hrEmployees থেকে নাম মিলিয়ে বের করা হয় (doLogin flow) — admin/superadmin ছাড়া অন্য role
-- লগইন করলে এখন থেকে সেই ছবিটা আর দেখাবে না (ফাংশনালিটি ভাঙবে না, শুধু ছবিটা মিসিং থাকবে)।
-- একইভাবে Data Safety > Backup & Excel Export-এ non-admin কেউ ব্যাকআপ নিলে Employees/Salary
-- শিট বাদ পড়বে — এটা বরং সঠিক আচরণ (আগে যেটা হতো সেটাই আসলে বাগ ছিল)।
-- ============================================================================

drop policy if exists "hrEmployees_read" on "hrEmployees";
create policy "hrEmployees_read" on "hrEmployees" for select
  using (public.current_role() in ('admin', 'superadmin'));

drop policy if exists "hrSalary_read" on "hrSalary";
create policy "hrSalary_read" on "hrSalary" for select
  using (public.current_role() in ('admin', 'superadmin'));

-- hrSignatures_read পরিবর্তন করা হয়নি (উপরের নোট দেখুন) — এখানে শুধু স্পষ্টতার জন্য উল্লেখ করা হলো,
-- কোনো action নেই।
-- ============================================================================
-- AccoFlow ERP — রাউন্ড ১৫: Module/Role-ভিত্তিক Write/Delete পলিসি
-- ============================================================================
-- Supabase Dashboard > SQL Editor-এ রান করুন (migration_v13_rls_auth.sql আগে থেকেই রান করা
-- থাকতে হবে — current_role()/is_active_user() ফাংশন সেখান থেকে আসছে)। idempotent।
--
-- ⚠️ deploy করার আগে/পরে সাথে সাথে js/app.js-এর নতুন ভার্সনও (এই একই ডেলিভারিতে থাকা) আপলোড
-- করে নেবেন — যদিও এই মাইগ্রেশন শুধু DB-লেভেল, তবু আগের মাইগ্রেশনের মতো একসাথে ডিপ্লয় করাই ভালো
-- অভ্যাস।
--
-- == কীভাবে এই role ম্যাপিং ঠিক করা হয়েছে ==
-- অনুমান করে না বসিয়ে, js/app.js ও index.html-এর প্রতিটা Add/Edit/Delete বাটনের ক্লাস
-- (admin-only, superadmin-only, expense-approver-only) সরাসরি খুঁজে দেখা হয়েছে। ফলাফল:
-- এই ২০টা টেবিলের প্রায় প্রতিটা "তৈরি/এডিট" বাটনই ইতিমধ্যে UI-তে admin-only (delete আরও
-- সংকুচিত করে superadmin-only বা কিছু ক্ষেত্রে admin-only)। ব্যতিক্রম শুধু expenseList —
-- Voucher Entry ফর্ম (saveVoucherEntry) এবং Approve/Reject বাটন কোনো role-class ছাড়াই আছে,
-- আর সংশ্লিষ্ট JS ফাংশনে সরাসরি accountant-কেও অনুমতি দেওয়া আছে (approveExpenseVoucher দেখুন)।
-- তাই DB-লেভেল পলিসিও এই বাস্তব আচরণের সাথে মিলিয়ে বসানো হলো — নতুন কোনো ধরে নেওয়া নিয়ম না।
--
-- SELECT (read) ইচ্ছাকৃতভাবে অপরিবর্তিত রাখা হলো (এখনো is_active_user() — যেকোনো সক্রিয়
-- ইউজার পড়তে পারবে) — কারণ Dashboard-এর চার্ট/সামারি অনেক টেবিল থেকেই ডেটা টানে, role
-- নির্বিশেষে সবাই Dashboard দেখেন (allowedPages-এ 'dash' সবার জন্য)। READ সংকুচিত করলে
-- অনেক role-এর Dashboard/Export ভেঙে যেত। এই রাউন্ডে শুধু WRITE/DELETE-ই সংকুচিত হচ্ছে,
-- যেটাই মূলত রিপোর্টের ১.১-এর প্রকৃত ঝুঁকি (অন্য মডিউলের ডেটা এডিট/ডিলিট করা যাওয়া)।
-- ============================================================================

-- ---------------------------------------------------------------------------
-- গ্রুপ A: insert/update = admin+superadmin, delete = শুধু superadmin
-- (piList, deliveryPlan/Exec/Hist, qcList, accBuyer/Supplier + payment history,
--  supplierOrders, vouchers, hrAttendance/Leaves/Departments/Approvals, buyers, suppliers)
-- ---------------------------------------------------------------------------
do $$
declare
  t text;
  group_a text[] := array[
    'piList','supplierOrders','deliveryPlan','deliveryExec','deliveryHist','qcList',
    'accBuyer','accSupplier','buyerPaymentHistory','supplierPaymentHistory','vouchers',
    'hrAttendance','hrLeaves','hrDepartments','hrApprovals','buyers','suppliers'
  ];
begin
  foreach t in array group_a loop
    execute format('drop policy if exists "authenticated_all" on %I', t);
    execute format('drop policy if exists "%s_read" on %I', t, t);
    execute format('drop policy if exists "%s_write" on %I', t, t);
    execute format('drop policy if exists "%s_update" on %I', t, t);
    execute format('drop policy if exists "%s_delete" on %I', t, t);

    execute format('create policy "%s_read" on %I for select using (public.is_active_user())', t, t);
    execute format('create policy "%s_write" on %I for insert with check (public.current_role() in (''admin'',''superadmin''))', t, t);
    execute format('create policy "%s_update" on %I for update using (public.current_role() in (''admin'',''superadmin''))', t, t);
    execute format('create policy "%s_delete" on %I for delete using (public.current_role() = ''superadmin'')', t, t);
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- গ্রুপ B: insert/update = admin+superadmin, delete = admin+superadmin (দুটোই)
-- (masterData, receivedGoods — UI-তে delete বাটন "admin-only" ক্লাস, superadmin-only না)
-- ---------------------------------------------------------------------------
do $$
declare
  t text;
  group_b text[] := array['masterData','receivedGoods'];
begin
  foreach t in array group_b loop
    execute format('drop policy if exists "authenticated_all" on %I', t);
    execute format('drop policy if exists "%s_read" on %I', t, t);
    execute format('drop policy if exists "%s_write" on %I', t, t);
    execute format('drop policy if exists "%s_update" on %I', t, t);
    execute format('drop policy if exists "%s_delete" on %I', t, t);

    execute format('create policy "%s_read" on %I for select using (public.is_active_user())', t, t);
    execute format('create policy "%s_write" on %I for insert with check (public.current_role() in (''admin'',''superadmin''))', t, t);
    execute format('create policy "%s_update" on %I for update using (public.current_role() in (''admin'',''superadmin''))', t, t);
    execute format('create policy "%s_delete" on %I for delete using (public.current_role() in (''admin'',''superadmin''))', t, t);
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- গ্রুপ C: expenseList — insert/update = admin+superadmin+accountant (Voucher Entry ফর্ম ও
-- Approve/Reject accountant করতে পারেন), delete = admin+superadmin (UI-তে delete "admin-only")
-- ---------------------------------------------------------------------------
drop policy if exists "authenticated_all" on "expenseList";
drop policy if exists "expenseList_read" on "expenseList";
drop policy if exists "expenseList_write" on "expenseList";
drop policy if exists "expenseList_update" on "expenseList";
drop policy if exists "expenseList_delete" on "expenseList";

create policy "expenseList_read" on "expenseList" for select using (public.is_active_user());
create policy "expenseList_write" on "expenseList" for insert with check (public.current_role() in ('admin','superadmin','accountant'));
create policy "expenseList_update" on "expenseList" for update using (public.current_role() in ('admin','superadmin','accountant'));
create policy "expenseList_delete" on "expenseList" for delete using (public.current_role() in ('admin','superadmin'));

-- ---------------------------------------------------------------------------
-- 'orders' টেবিল ইচ্ছাকৃতভাবে অপরিবর্তিত (এখনো authenticated_all — যেকোনো সক্রিয় ইউজার সব করতে
-- পারবেন)। এটা শুধু Order No ড্রপডাউনের একটা derived/shadow ইনডেক্স (masterData.orders থেকে
-- সিঙ্ক), কোনো আর্থিক/স্পর্শকাতর ডেটা নেই, আর PI/Delivery/QC-এর একাধিক ফ্লো থেকে persistOrders()
-- কল হয় — role-ভিত্তিক সংকুচিত করলে ঝুঁকির তুলনায় লাভ নেই, উল্টো একাধিক জায়গা ভাঙার সম্ভাবনা।
-- ============================================================================
-- ============================================================================
-- AccoFlow ERP — রাউন্ড ১৬: Payment RPC (atomic + server-verified audit trail)
-- ============================================================================
-- Supabase Dashboard > SQL Editor-এ রান করুন (v13 ও v15 আগে থেকেই রান করা থাকতে হবে)।
-- idempotent। ⚠️ এই মাইগ্রেশনের সাথে js/app.js-এর নতুন ভার্সনও একসাথে ডিপ্লয় করতে হবে —
-- কারণ saveBuyerPayment()/saveSupplierPaymentEntry() এখন থেকে সরাসরি টেবিল আপডেটের বদলে
-- এই নতুন RPC ফাংশন কল করে (নিচে js/app.js-এর পরিবর্তনও একই ডেলিভারিতে আছে)।

-- ---------------------------------------------------------------------------
-- ধাপ ১ — buyerPaymentHistory / supplierPaymentHistory-এর id কলামকে identity বানানো
-- ---------------------------------------------------------------------------
-- "GENERATED BY DEFAULT AS IDENTITY" ব্যবহার করা হলো (ALWAYS নয়) — যদি ভবিষ্যতে কোনো পুরনো
-- কোড-পাথ এখনো explicit id পাঠায় (যেমন bulkSave/restoreFromTrash), সেটা যেন ভেঙে না যায়;
-- id না পাঠালে Postgres নিজে থেকে পরবর্তী সংখ্যাটা বসাবে — এভাবেই আমাদের নতুন RPC কাজ করবে।
do $$
begin
  if not exists (
    select 1 from pg_attribute a join pg_class c on c.oid = a.attrelid
    where c.relname = 'buyerPaymentHistory' and a.attname = 'id' and a.attidentity <> ''
  ) then
    alter table "buyerPaymentHistory" alter column id add generated by default as identity;
    perform setval(
      pg_get_serial_sequence('"buyerPaymentHistory"', 'id'),
      coalesce((select max(id) from "buyerPaymentHistory"), 0) + 1,
      false
    );
  end if;
end $$;

do $$
begin
  if not exists (
    select 1 from pg_attribute a join pg_class c on c.oid = a.attrelid
    where c.relname = 'supplierPaymentHistory' and a.attname = 'id' and a.attidentity <> ''
  ) then
    alter table "supplierPaymentHistory" alter column id add generated by default as identity;
    perform setval(
      pg_get_serial_sequence('"supplierPaymentHistory"', 'id'),
      coalesce((select max(id) from "supplierPaymentHistory"), 0) + 1,
      false
    );
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- ধাপ ২ — auditLog-এর policy পুনরায় নিশ্চিত করা (idempotent — কোনো নতুন আচরণ যোগ করছে না)
-- ---------------------------------------------------------------------------
-- ⚠️ সংশোধনী: আগের ড্রাফটে এখানে লেখা ছিল যে auditLog-এ RLS "চালু করা হচ্ছে" — কিন্তু কোড আরেকবার
-- ভালোভাবে মিলিয়ে দেখে ধরা পড়ল এটা ভুল ছিল। schema.sql-এ base টেবিল তৈরির সময় RLS disable করা
-- থাকলেও, migration_v13_rls_auth.sql (যেটা ইতিমধ্যে চালানো আছে) নিজেই এটা enable করে দিয়ে হুবহু
-- এই একই auditLog_read/auditLog_insert policy বসিয়ে দিয়েছিল (UPDATE/DELETE-এর কোনো policy নেই,
-- তাই সেগুলো v13 থেকেই ব্লকড — audit trail ইতিমধ্যেই append-only)। তাই নিচের তিনটা লাইন আসলে
-- কিছুই নতুন করছে না, শুধু নিশ্চিত করছে (idempotent) — রাখা হলো যাতে এই ফাইলটা একা চালালেও
-- সামঞ্জস্যপূর্ণ থাকে। রিপোর্ট ১.৬-এর প্রকৃত বাকি অংশ (client username/role স্পুফিং) নিচের
-- record_buyer_payment/record_supplier_payment RPC দুটোর জন্য এই মাইগ্রেশনে সমাধান হচ্ছে
-- (audit entry পুরোপুরি server-side, profiles টেবিল থেকে verified username/role দিয়ে তৈরি) —
-- বাকি ~৫০+ logAudit() কল-সাইটের জন্য এখনো ক্লায়েন্ট-controlled রয়ে গেছে (ভবিষ্যতের কাজ)।
alter table "auditLog" enable row level security;

drop policy if exists "auditLog_read" on "auditLog";
create policy "auditLog_read" on "auditLog" for select using (public.is_active_user());

drop policy if exists "auditLog_insert" on "auditLog";
create policy "auditLog_insert" on "auditLog" for insert with check (public.is_active_user());

-- ---------------------------------------------------------------------------
-- ধাপ ৩ — record_buyer_payment(): validate + lock + ledger update + history insert +
-- audit log — সব একটা transaction-এ (atomic)। SECURITY DEFINER দেওয়া হয়েছে যাতে ফাংশনের
-- ভেতরে auditLog-এ সঠিক username/role লিখতে profiles টেবিল পড়তে পারে, কিন্তু ভেতরেই caller-এর
-- role চেক করা হচ্ছে (নিচে) — RLS bypass করলেও অনুমতি-চেক বাইপাস হচ্ছে না।
create or replace function public.record_buyer_payment(
  p_pi_no text,
  p_amount numeric,
  p_method text,
  p_check_number text,
  p_remarks text,
  p_receipt_image text,
  p_date text
) returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row "accBuyer"%rowtype;
  v_total numeric;
  v_received numeric;
  v_new_received numeric;
  v_new_due numeric;
  v_new_status text;
  v_hist_id bigint;
  v_username text;
  v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or v_role not in ('admin', 'superadmin') then
    raise exception 'অনুমতি নেই: শুধুমাত্র admin/superadmin পেমেন্ট রেকর্ড করতে পারবেন';
  end if;

  if p_amount is null or p_amount <= 0 then
    raise exception 'Amount অবশ্যই ০-এর বেশি হতে হবে';
  end if;
  if p_pi_no is null or length(trim(p_pi_no)) = 0 then
    raise exception 'PI No আবশ্যক';
  end if;

  -- row লক করা হচ্ছে (FOR UPDATE) — এই PI-এর জন্য দুইটা সমসাময়িক পেমেন্ট এলে দ্বিতীয়টা প্রথমটা
  -- শেষ না হওয়া পর্যন্ত অপেক্ষা করবে, ফলে received/due হিসাব কখনো একটা আরেকটার উপর ওভাররাইট
  -- হবে না (রিপোর্ট ১.৮-এর মূল উদ্বেগ)
  select * into v_row from "accBuyer" where "piNo" = p_pi_no for update;
  if not found then
    raise exception 'এই PI No খুঁজে পাওয়া যায়নি: %', p_pi_no;
  end if;

  v_total := coalesce(nullif(regexp_replace(coalesce(v_row.total, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_received := coalesce(nullif(regexp_replace(coalesce(v_row.received, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_new_received := v_received + p_amount;
  v_new_due := greatest(v_total - v_new_received, 0);
  v_new_status := case when v_new_due <= 0 then 'Paid' else 'Due' end;

  update "accBuyer" set
    received = '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    due = '$' || to_char(v_new_due, 'FM999,999,999,990.00'),
    status = v_new_status,
    lc = p_method
  where "piNo" = p_pi_no;

  insert into "buyerPaymentHistory" ("piNo", "buyer", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_pi_no, v_row.buyer, to_char(p_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;

  insert into "auditLog" (id, "timestamp", username, role, action, module, "recordId", "recordLabel")
  values (
    (select coalesce(max(id), 0) + 1 from "auditLog"),
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'buyerPaymentHistory', v_hist_id::text,
    p_pi_no || ' — $' || to_char(p_amount, 'FM999999999990.00')
  );

  return json_build_object(
    'ok', true, 'historyId', v_hist_id,
    'received', '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    'due', '$' || to_char(v_new_due, 'FM999,999,999,990.00'),
    'status', v_new_status
  );
end;
$$;

-- ---------------------------------------------------------------------------
-- ধাপ ৪ — record_supplier_payment(): একই প্যাটার্ন, accSupplier/supplierPaymentHistory-এর জন্য
-- ---------------------------------------------------------------------------
create or replace function public.record_supplier_payment(
  p_order_no text,
  p_amount numeric,
  p_method text,
  p_check_number text,
  p_remarks text,
  p_receipt_image text,
  p_date text
) returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row "accSupplier"%rowtype;
  v_total numeric;
  v_paid numeric;
  v_new_paid numeric;
  v_new_due numeric;
  v_hist_id bigint;
  v_username text;
  v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or v_role not in ('admin', 'superadmin') then
    raise exception 'অনুমতি নেই: শুধুমাত্র admin/superadmin পেমেন্ট রেকর্ড করতে পারবেন';
  end if;

  if p_amount is null or p_amount <= 0 then
    raise exception 'Amount অবশ্যই ০-এর বেশি হতে হবে';
  end if;
  if p_order_no is null or length(trim(p_order_no)) = 0 then
    raise exception 'Order No আবশ্যক';
  end if;

  select * into v_row from "accSupplier" where "orderNo" = p_order_no for update;
  if not found then
    raise exception 'এই Order No খুঁজে পাওয়া যায়নি: %', p_order_no;
  end if;

  v_total := coalesce(nullif(regexp_replace(coalesce(v_row.total, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_paid := coalesce(nullif(regexp_replace(coalesce(v_row.paid, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_new_paid := v_paid + p_amount;
  v_new_due := greatest(v_total - v_new_paid, 0);

  update "accSupplier" set
    paid = '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    due = '$' || to_char(v_new_due, 'FM999,999,999,990.00')
  where "orderNo" = p_order_no;

  insert into "supplierPaymentHistory" ("orderNo", "supplier", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_order_no, v_row.supplier, to_char(p_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;

  insert into "auditLog" (id, "timestamp", username, role, action, module, "recordId", "recordLabel")
  values (
    (select coalesce(max(id), 0) + 1 from "auditLog"),
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'supplierPaymentHistory', v_hist_id::text,
    p_order_no || ' — $' || to_char(p_amount, 'FM999999999990.00')
  );

  return json_build_object(
    'ok', true, 'historyId', v_hist_id,
    'paid', '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    'due', '$' || to_char(v_new_due, 'FM999,999,999,990.00')
  );
end;
$$;

-- ---------------------------------------------------------------------------
-- ধাপ ৫ — RPC ফাংশন দুটো authenticated রোলের জন্য এক্সিকিউট-অনুমতি
-- ---------------------------------------------------------------------------
grant execute on function public.record_buyer_payment(text, numeric, text, text, text, text, text) to authenticated;
grant execute on function public.record_supplier_payment(text, numeric, text, text, text, text, text) to authenticated;
-- ============================================================================
-- AccoFlow ERP — রাউন্ড ১৮: Role Redesign (merchandiser/storekeeper/accountant-কে
-- তাদের নিজস্ব মডিউলে Create/Edit ক্ষমতা)
-- ============================================================================
-- Supabase Dashboard > SQL Editor-এ রান করুন (v13, v15, v16 আগে থেকেই রান করা থাকতে হবে)।
-- idempotent। এই মাইগ্রেশনের সাথে js/app.js ও index.html-এর নতুন ভার্সনও একসাথে ডিপ্লয় করতে
-- হবে — নাহলে DB অনুমতি দিলেও UI-তে বাটন লুকানো থাকবে, বা উল্টো UI বাটন দেখা যাবে কিন্তু DB
-- ব্লক করবে।
--
-- == কী পরিবর্তন হচ্ছে (আপনার নিশ্চিত করা সিদ্ধান্ত অনুযায়ী) ==
-- ১. merchandiser → piList, masterData, receivedGoods, supplierOrders-এ INSERT/UPDATE
-- ২. merchandiser → accBuyer, accSupplier-এও INSERT/UPDATE (⚠️ নিচে ব্যাখ্যা দেখুন — এটা না
--    দিলে merchandiser PI/Supplier Order সেভ করতে গেলে ভেঙে যাবে)
-- ৩. storekeeper → deliveryPlan, deliveryExec, deliveryHist, qcList-এ INSERT/UPDATE
-- ৪. accountant → record_buyer_payment()/record_supplier_payment() RPC কল করতে পারবেন
-- DELETE কোথাও পরিবর্তন হয়নি — সব টেবিলেই আগের মতো admin/superadmin (বা admin-only, যেখানে
-- আগে থেকে তাই ছিল) — এটা নিয়ে জিজ্ঞাসা করা হয়নি, তাই নিরাপদ দিকে রাখা হলো।
--
-- ⚠️ গুরুত্বপূর্ণ পার্শ্ব-প্রতিক্রিয়া: merchandiser যখন নতুন PI বা Supplier Order সেভ করেন,
-- app.js-এর savePI()/saveSupplierOrder() স্বয়ংক্রিয়ভাবে accBuyer/accSupplier ledger-এও একটা
-- সারি তৈরি/আপডেট করে (syncAccBuyerFromPI/syncAccSupplierFromOrder) — total/due ফিল্ড বসাতে।
-- তাই merchandiser-কে শুধু piList-এ লেখার অনুমতি দিলেই হবে না, accBuyer/accSupplier-এও লিখতে
-- দিতে হবে, নাহলে PI সেভ করার মাঝপথে RLS এরর আসবে। এর মানে merchandiser টেকনিক্যালি সরাসরি
-- API/DevTools দিয়ে accBuyer/accSupplier-এর total/due ফিল্ডও এডিট করতে পারবেন (শুধু ledger
-- sync-এর জন্য UI বাটন নেই, কিন্তু RLS টেবিল-লেভেলে, নির্দিষ্ট কলামে না) — Payment রেকর্ড করা
-- (received/paid বদলানো) তবুও RPC-নির্ভর ও admin/superadmin/accountant-এই সীমাবদ্ধ থাকছে,
-- কারণ payment RPC SECURITY DEFINER (RLS বাইপাস করে) এবং নিজের ভেতরে আলাদা role-চেক করে।

-- ---------------------------------------------------------------------------
-- ধাপ ১ — merchandiser-কে Inventory & PI + লেজার-সিঙ্ক টেবিলে write অনুমতি
-- ---------------------------------------------------------------------------
do $$
declare
  t text;
  tables text[] := array['piList','masterData','receivedGoods','supplierOrders','accBuyer','accSupplier'];
begin
  foreach t in array tables loop
    execute format('drop policy if exists "%s_write" on %I', t, t);
    execute format('drop policy if exists "%s_update" on %I', t, t);
    execute format(
      'create policy "%s_write" on %I for insert with check (public.current_role() in (''admin'',''superadmin'',''merchandiser''))',
      t, t
    );
    execute format(
      'create policy "%s_update" on %I for update using (public.current_role() in (''admin'',''superadmin'',''merchandiser''))',
      t, t
    );
    -- delete policy অপরিবর্তিত (আগেরটাই থেকে যায়, এখানে ছোঁয়া হয়নি)
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- ধাপ ২ — storekeeper-কে Delivery + QC টেবিলে write অনুমতি
-- ---------------------------------------------------------------------------
do $$
declare
  t text;
  tables text[] := array['deliveryPlan','deliveryExec','deliveryHist','qcList'];
begin
  foreach t in array tables loop
    execute format('drop policy if exists "%s_write" on %I', t, t);
    execute format('drop policy if exists "%s_update" on %I', t, t);
    execute format(
      'create policy "%s_write" on %I for insert with check (public.current_role() in (''admin'',''superadmin'',''storekeeper''))',
      t, t
    );
    execute format(
      'create policy "%s_update" on %I for update using (public.current_role() in (''admin'',''superadmin'',''storekeeper''))',
      t, t
    );
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- ধাপ ৩ — accountant-কে Payment RPC-এ অনুমতি (record_buyer_payment/record_supplier_payment)
-- ---------------------------------------------------------------------------
-- এই দুইটা ফাংশন SECURITY DEFINER (RLS বাইপাস করে), তাই টেবিল-পলিসি বদলে লাভ নেই — ফাংশনের
-- ভেতরের role-চেক লাইনটাই বদলাতে হয়। CREATE OR REPLACE দিয়ে পুরো ফাংশন আবার বসানো হলো, শুধু
-- allowed role list-টা বদলে ('admin','superadmin') থেকে ('admin','superadmin','accountant')।

create or replace function public.record_buyer_payment(
  p_pi_no text,
  p_amount numeric,
  p_method text,
  p_check_number text,
  p_remarks text,
  p_receipt_image text,
  p_date text
) returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row "accBuyer"%rowtype;
  v_total numeric;
  v_received numeric;
  v_new_received numeric;
  v_new_due numeric;
  v_new_status text;
  v_hist_id bigint;
  v_username text;
  v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or v_role not in ('admin', 'superadmin', 'accountant') then
    raise exception 'অনুমতি নেই: শুধুমাত্র admin/superadmin/accountant পেমেন্ট রেকর্ড করতে পারবেন';
  end if;

  if p_amount is null or p_amount <= 0 then
    raise exception 'Amount অবশ্যই ০-এর বেশি হতে হবে';
  end if;
  if p_pi_no is null or length(trim(p_pi_no)) = 0 then
    raise exception 'PI No আবশ্যক';
  end if;

  select * into v_row from "accBuyer" where "piNo" = p_pi_no for update;
  if not found then
    raise exception 'এই PI No খুঁজে পাওয়া যায়নি: %', p_pi_no;
  end if;

  v_total := coalesce(nullif(regexp_replace(coalesce(v_row.total, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_received := coalesce(nullif(regexp_replace(coalesce(v_row.received, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_new_received := v_received + p_amount;
  v_new_due := greatest(v_total - v_new_received, 0);
  v_new_status := case when v_new_due <= 0 then 'Paid' else 'Due' end;

  update "accBuyer" set
    received = '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    due = '$' || to_char(v_new_due, 'FM999,999,999,990.00'),
    status = v_new_status,
    lc = p_method
  where "piNo" = p_pi_no;

  insert into "buyerPaymentHistory" ("piNo", "buyer", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_pi_no, v_row.buyer, to_char(p_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;

  insert into "auditLog" (id, "timestamp", username, role, action, module, "recordId", "recordLabel")
  values (
    (select coalesce(max(id), 0) + 1 from "auditLog"),
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'buyerPaymentHistory', v_hist_id::text,
    p_pi_no || ' — $' || to_char(p_amount, 'FM999999999990.00')
  );

  return json_build_object(
    'ok', true, 'historyId', v_hist_id,
    'received', '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    'due', '$' || to_char(v_new_due, 'FM999,999,999,990.00'),
    'status', v_new_status
  );
end;
$$;

create or replace function public.record_supplier_payment(
  p_order_no text,
  p_amount numeric,
  p_method text,
  p_check_number text,
  p_remarks text,
  p_receipt_image text,
  p_date text
) returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row "accSupplier"%rowtype;
  v_total numeric;
  v_paid numeric;
  v_new_paid numeric;
  v_new_due numeric;
  v_hist_id bigint;
  v_username text;
  v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or v_role not in ('admin', 'superadmin', 'accountant') then
    raise exception 'অনুমতি নেই: শুধুমাত্র admin/superadmin/accountant পেমেন্ট রেকর্ড করতে পারবেন';
  end if;

  if p_amount is null or p_amount <= 0 then
    raise exception 'Amount অবশ্যই ০-এর বেশি হতে হবে';
  end if;
  if p_order_no is null or length(trim(p_order_no)) = 0 then
    raise exception 'Order No আবশ্যক';
  end if;

  select * into v_row from "accSupplier" where "orderNo" = p_order_no for update;
  if not found then
    raise exception 'এই Order No খুঁজে পাওয়া যায়নি: %', p_order_no;
  end if;

  v_total := coalesce(nullif(regexp_replace(coalesce(v_row.total, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_paid := coalesce(nullif(regexp_replace(coalesce(v_row.paid, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_new_paid := v_paid + p_amount;
  v_new_due := greatest(v_total - v_new_paid, 0);

  update "accSupplier" set
    paid = '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    due = '$' || to_char(v_new_due, 'FM999,999,999,990.00')
  where "orderNo" = p_order_no;

  insert into "supplierPaymentHistory" ("orderNo", "supplier", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_order_no, v_row.supplier, to_char(p_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;

  insert into "auditLog" (id, "timestamp", username, role, action, module, "recordId", "recordLabel")
  values (
    (select coalesce(max(id), 0) + 1 from "auditLog"),
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'supplierPaymentHistory', v_hist_id::text,
    p_order_no || ' — $' || to_char(p_amount, 'FM999999999990.00')
  );

  return json_build_object(
    'ok', true, 'historyId', v_hist_id,
    'paid', '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    'due', '$' || to_char(v_new_due, 'FM999,999,999,990.00')
  );
end;
$$;

grant execute on function public.record_buyer_payment(text, numeric, text, text, text, text, text) to authenticated;
grant execute on function public.record_supplier_payment(text, numeric, text, text, text, text, text) to authenticated;
-- ============================================================================
-- AccoFlow ERP — রাউন্ড ২১: কাস্টম পার-ইউজার পারমিশন সিস্টেম
-- ============================================================================
-- Supabase Dashboard > SQL Editor-এ রান করুন (v13, v14, v15, v16, v18 আগে থেকেই রান করা থাকতে
-- হবে — এই মাইগ্রেশন সেগুলোর role-ভিত্তিক write/delete পলিসিগুলো *প্রতিস্থাপন* করছে)। idempotent।
-- ⚠️ এই মাইগ্রেশনের সাথে js/app.js ও index.html-এর নতুন ভার্সনও একসাথে ডিপ্লয় করতে হবে।
--
-- == মূল ধারণা বদল ==
-- আগে: role (admin/superadmin/accountant/merchandiser/storekeeper) একটা ফিক্সড "প্যাকেজ" —
-- role অনুযায়ী কোন মডিউলে write/delete করা যাবে সেটা কোডে হার্ডকোড করা ছিল (migration_v15/v18)।
-- এখন: প্রতিটা ইউজারের profiles.permissions নামে একটা JSONB কলাম আছে যেখানে প্রতিটা মডিউলের
-- জন্য আলাদাভাবে view/write/delete (এবং কিছু মডিউলে approve/export) true/false রাখা যায়।
-- role লেবেলটা এখনো থাকছে (UI-তে "কুইক প্রিসেট" আর পরিচয়ের জন্য), কিন্তু আসল অনুমতি এখন থেকে
-- সম্পূর্ণভাবে এই permissions JSONB থেকেই আসে — role নিজে থেকে r কোনো অনুমতি দেয় না (ব্যতিক্রম:
-- role='superadmin' সবসময় সব অনুমতি bypass করে, নিচে দেখুন)।
--
-- == নিরাপত্তা সীমারেখা (ইচ্ছাকৃত) ==
-- "users" (ইউজার অ্যাকাউন্ট তৈরি/এডিট/ডিলিট) ও "settings" (কোম্পানি-ওয়াইড কনফিগ) — এই দুইটার
-- write/delete ইচ্ছাকৃতভাবে permissions JSONB দিয়ে delegate করা যায় না, সবসময় literal
-- role IN ('admin','superadmin') (settings-এর জন্য শুধু superadmin) চেক হয়। কারণ: permissions
-- এডিট করার ক্ষমতা (users.write) কাউকে দিলে সে নিজেকে/অন্য কাউকে চাইলে-যেকোনো পারমিশন দিয়ে
-- কার্যত superadmin বানিয়ে ফেলতে পারত (self-escalation loophole) — এটা ব্যবহারকারীর নিজের
-- অনুরোধেরই সাথে সামঞ্জস্যপূর্ণ ("এডমিন এবং সুপার এডমিন ইচ্ছা অনুযায়ী পারমিশন দিতে পারবে" — অর্থাৎ
-- শুধু তারাই, অন্য কেউ না)। এই দুই মডিউলের "view" (পেজ দেখা যাবে কিনা) অবশ্য permissions
-- JSONB দিয়েই নিয়ন্ত্রিত (নিরাপদ, শুধু দেখতে দেওয়া)।
--
-- == মডিউল তালিকা ==
-- dashboard, inventory, delivery, qc, accounts, expense (+approve), hr, bsinfo,
-- datasafety (+export), users (শুধু view delegate-যোগ্য), settings (শুধু view delegate-যোগ্য)
-- ============================================================================

-- ---------------------------------------------------------------------------
-- ধাপ ১ — profiles টেবিলে permissions কলাম
-- ---------------------------------------------------------------------------
alter table profiles add column if not exists permissions jsonb not null default '{}'::jsonb;

-- ---------------------------------------------------------------------------
-- ধাপ ২ — has_perm() হেল্পার ফাংশন
-- ---------------------------------------------------------------------------
-- superadmin সবসময় true (bypass) — permissions JSONB-তে যা-ই থাকুক। বাকিদের জন্য
-- permissions -> module ->> action এর মান 'true' কিনা চেক করে। মডিউল/অ্যাকশন উল্লেখ না থাকলে
-- (null) নিরাপদে false ধরা হয় (fail-closed, fail-open না)।
create or replace function public.has_perm(p_module text, p_action text)
returns boolean
language sql stable
security definer set search_path = public
as $$
  select case
    when (select role from profiles where id = auth.uid() and status = 'Active') = 'superadmin' then true
    else coalesce(
      (select (permissions -> p_module ->> p_action) from profiles where id = auth.uid() and status = 'Active') = 'true',
      false
    )
  end;
$$;

-- ---------------------------------------------------------------------------
-- ধাপ ৩ — বিদ্যমান ইউজারদের permissions ব্যাকফিল (role + লিগ্যাসি users.permissions
-- টেক্সট-ট্যাগ থেকে) — যাতে migration চালানোর মুহূর্তে কারো এক্সেস আচমকা বদলে না যায়
-- ---------------------------------------------------------------------------
-- ৩.১ — role অনুযায়ী বেস পারমিশন (রাউন্ড ১৫/১৮-এর বর্তমান আচরণের সাথে যতটা সম্ভব মিলিয়ে)
-- ⚠️ একটা ইচ্ছাকৃত রক্ষণশীল পরিবর্তন: delete আগে টেবিল-ভিত্তিক ভিন্ন ছিল (masterData/
-- receivedGoods/expenseList-এ admin delete করতে পারতেন, piList/deliveryPlan/qcList ইত্যাদিতে
-- পারতেন না)। এখন delete মডিউল-ভিত্তিক একটাই ফ্ল্যাগ, তাই admin-এর ডিফল্ট delete=false রাখা হলো
-- inventory/delivery/qc/accounts/hr/bsinfo-তে (আগে যেটা বেশিরভাগ টেবিলে ছিল) — শুধু expense-এ
-- true (expenseList-এ আগে থেকেই admin delete করতে পারতেন)। প্রয়োজনে Roles পেজ থেকে যেকোনো সময়
-- আবার চালু করে দেওয়া যাবে — এটা কোনো ক্ষমতা স্থায়ীভাবে কমানো না, শুধু ডিফল্ট বদল।
update profiles set permissions =
  case role
    when 'admin' then '{
      "dashboard":  {"view": true},
      "inventory":  {"view": true, "write": true, "delete": false},
      "delivery":   {"view": true, "write": true, "delete": false},
      "qc":         {"view": true, "write": true, "delete": false},
      "accounts":   {"view": true, "write": true, "delete": false},
      "expense":    {"view": true, "write": true, "delete": true, "approve": true},
      "hr":         {"view": true, "write": true, "delete": false},
      "bsinfo":     {"view": true, "write": true, "delete": false},
      "datasafety": {"view": true, "export": true},
      "users":      {"view": true},
      "settings":   {"view": false}
    }'::jsonb
    when 'accountant' then '{
      "dashboard":  {"view": true},
      "inventory":  {"view": false, "write": false, "delete": false},
      "delivery":   {"view": false, "write": false, "delete": false},
      "qc":         {"view": false, "write": false, "delete": false},
      "accounts":   {"view": true, "write": true, "delete": false},
      "expense":    {"view": true, "write": true, "delete": false, "approve": true},
      "hr":         {"view": false, "write": false, "delete": false},
      "bsinfo":     {"view": true, "write": false, "delete": false},
      "datasafety": {"view": true, "export": true},
      "users":      {"view": false},
      "settings":   {"view": false}
    }'::jsonb
    when 'merchandiser' then '{
      "dashboard":  {"view": true},
      "inventory":  {"view": true, "write": true, "delete": false},
      "delivery":   {"view": true, "write": false, "delete": false},
      "qc":         {"view": true, "write": false, "delete": false},
      "accounts":   {"view": false, "write": false, "delete": false},
      "expense":    {"view": false, "write": false, "delete": false, "approve": false},
      "hr":         {"view": false, "write": false, "delete": false},
      "bsinfo":     {"view": true, "write": false, "delete": false},
      "datasafety": {"view": true, "export": false},
      "users":      {"view": false},
      "settings":   {"view": false}
    }'::jsonb
    when 'storekeeper' then '{
      "dashboard":  {"view": true},
      "inventory":  {"view": false, "write": false, "delete": false},
      "delivery":   {"view": true, "write": true, "delete": false},
      "qc":         {"view": true, "write": true, "delete": false},
      "accounts":   {"view": false, "write": false, "delete": false},
      "expense":    {"view": false, "write": false, "delete": false, "approve": false},
      "hr":         {"view": false, "write": false, "delete": false},
      "bsinfo":     {"view": false, "write": false, "delete": false},
      "datasafety": {"view": false, "export": false},
      "users":      {"view": false},
      "settings":   {"view": false}
    }'::jsonb
    when 'superadmin' then '{
      "dashboard":  {"view": true},
      "inventory":  {"view": true, "write": true, "delete": true},
      "delivery":   {"view": true, "write": true, "delete": true},
      "qc":         {"view": true, "write": true, "delete": true},
      "accounts":   {"view": true, "write": true, "delete": true},
      "expense":    {"view": true, "write": true, "delete": true, "approve": true},
      "hr":         {"view": true, "write": true, "delete": true},
      "bsinfo":     {"view": true, "write": true, "delete": true},
      "datasafety": {"view": true, "export": true},
      "users":      {"view": true},
      "settings":   {"view": true}
    }'::jsonb
    else '{}'::jsonb
  end
where permissions = '{}'::jsonb;  -- idempotent: যাদের permissions ইতিমধ্যে সেট করা আছে (আবার রান
                                    -- করলে) তাদের ছোঁয়া হবে না, ম্যানুয়াল পরিবর্তন হারাবে না

-- ৩.২ — লিগ্যাসি users.permissions টেক্সট-ট্যাগ (Add User ফর্মের পুরনো "soft mode" চেকবক্স) যাদের
-- খালি না, তাদের ক্ষেত্রে সেই ট্যাগ-তালিকার সাথে intersection করে view আরও সংকুচিত করা হচ্ছে —
-- ঠিক আগে userHasPerm() যেভাবে কাজ করত সেই একই "role ∩ tags" আচরণ বজায় রাখতে (যেমন merchandiser
-- 'ali' যার permissions="Dashboard, Inventory, B&S Info" — সে আগে QC/Delivery-এর ন্যাভ দেখতে
-- পেত না, migration-এর পরেও পাবে না)।
do $$
declare
  r record;
  tags text[];
  tag_map jsonb := '{
    "Dashboard":"dashboard","Inventory":"inventory","Delivery":"delivery","QC":"qc",
    "Accounts":"accounts","Expense":"expense","HR":"hr","B&S Info":"bsinfo",
    "Data Safety":"datasafety","Settings":"settings","Users":"users"
  }'::jsonb;
  mod_key text;
  new_perms jsonb;
begin
  for r in
    select p.id, p.permissions, u.permissions as legacy_tags
    from profiles p
    join users u on u.username = p.username
    where u.permissions is not null and length(trim(u.permissions)) > 0
  loop
    tags := string_to_array(r.legacy_tags, ',');
    new_perms := r.permissions;
    for mod_key in select jsonb_object_keys(new_perms) loop
      if mod_key not in ('dashboard') then  -- dashboard সবসময় দেখা যায়, ট্যাগ না থাকলেও
        continue;
      end if;
    end loop;
    -- প্রতিটা মডিউলের জন্য: যদি tag_map-এ তার লেবেল থাকে কিন্তু legacy tags-এ সেই লেবেল না থাকে,
    -- তাহলে সেই মডিউলের view=false করে দেওয়া হচ্ছে (বাকি write/delete/approve/export ফ্ল্যাগ যা-ই
    -- থাকুক, view=false থাকলে ক্লায়েন্ট-সাইডে নেভিগেশনেই দেখাবে না, তাই কার্যকরভাবে পুরো মডিউলটাই
    -- অগম্য হয়ে যায় — ঠিক আগের userHasPerm() আচরণের মতো)
    for mod_key in select value from jsonb_each_text(tag_map) loop
      if not exists (
        select 1 from unnest(tags) t
        where trim(t) = (select key from jsonb_each_text(tag_map) where value = mod_key limit 1)
      ) then
        new_perms := jsonb_set(new_perms, array[mod_key, 'view'], 'false'::jsonb, true);
      end if;
    end loop;
    update profiles set permissions = new_perms where id = r.id;
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- ধাপ ৪ — ব্যবসায়িক টেবিলগুলোর write/delete পলিসি has_perm()-ভিত্তিক করা
-- ---------------------------------------------------------------------------
do $$
declare
  t text;
  m text;
  mapping jsonb := '{
    "piList":"inventory","masterData":"inventory","receivedGoods":"inventory","supplierOrders":"inventory",
    "deliveryPlan":"delivery","deliveryExec":"delivery","deliveryHist":"delivery",
    "qcList":"qc",
    "expenseList":"expense","vouchers":"expense",
    "hrAttendance":"hr","hrLeaves":"hr","hrDepartments":"hr","hrApprovals":"hr","hrSignatures":"hr",
    "buyers":"bsinfo","suppliers":"bsinfo"
  }'::jsonb;
begin
  for t, m in select key, value from jsonb_each_text(mapping) loop
    execute format('drop policy if exists "%s_write" on %I', t, t);
    execute format('drop policy if exists "%s_update" on %I', t, t);
    execute format('drop policy if exists "%s_delete" on %I', t, t);
    execute format('create policy "%s_write" on %I for insert with check (public.has_perm(%L, ''write''))', t, t, m);
    execute format('create policy "%s_update" on %I for update using (public.has_perm(%L, ''write''))', t, t, m);
    execute format('create policy "%s_delete" on %I for delete using (public.has_perm(%L, ''delete''))', t, t, m);
  end loop;
end $$;

-- accBuyer/accSupplier — ⚠️ বিশেষ: এই দুই টেবিলে write দুইটা ভিন্ন বৈধ কারণে হয় — (১) সরাসরি
-- Accounts মডিউল থেকে ম্যানেজ করা (has_perm('accounts','write')), (২) merchandiser PI/Supplier
-- Order সেভ করলে savePI()/saveSupplierOrder() স্বয়ংক্রিয়ভাবে ledger সিঙ্ক করে
-- (has_perm('inventory','write')) — এই দ্বিতীয়টা বাদ দিলে merchandiser-এর PI creation flow
-- মাঝপথে ভেঙে যাবে (রাউন্ড ১৮-এ এটা যাচাই করা হয়েছিল, এখনো প্রযোজ্য)। তাই দুইটা শর্তই OR দিয়ে রাখা হলো।
drop policy if exists "accBuyer_write" on "accBuyer";
drop policy if exists "accBuyer_update" on "accBuyer";
drop policy if exists "accBuyer_delete" on "accBuyer";
create policy "accBuyer_write" on "accBuyer" for insert with check (public.has_perm('accounts','write') or public.has_perm('inventory','write'));
create policy "accBuyer_update" on "accBuyer" for update using (public.has_perm('accounts','write') or public.has_perm('inventory','write'));
create policy "accBuyer_delete" on "accBuyer" for delete using (public.has_perm('accounts','delete'));

drop policy if exists "accSupplier_write" on "accSupplier";
drop policy if exists "accSupplier_update" on "accSupplier";
drop policy if exists "accSupplier_delete" on "accSupplier";
create policy "accSupplier_write" on "accSupplier" for insert with check (public.has_perm('accounts','write') or public.has_perm('inventory','write'));
create policy "accSupplier_update" on "accSupplier" for update using (public.has_perm('accounts','write') or public.has_perm('inventory','write'));
create policy "accSupplier_delete" on "accSupplier" for delete using (public.has_perm('accounts','delete'));

-- buyerPaymentHistory/supplierPaymentHistory — সরাসরি ইনসার্ট app.js থেকে হয় না (RPC দিয়ে হয়,
-- SECURITY DEFINER, RLS বাইপাস করে) কিন্তু ভবিষ্যতের যেকোনো direct-access path-এর জন্য নিরাপদে
-- accounts.write-এ বেঁধে রাখা হলো
drop policy if exists "buyerPaymentHistory_write" on "buyerPaymentHistory";
drop policy if exists "buyerPaymentHistory_update" on "buyerPaymentHistory";
drop policy if exists "buyerPaymentHistory_delete" on "buyerPaymentHistory";
create policy "buyerPaymentHistory_write" on "buyerPaymentHistory" for insert with check (public.has_perm('accounts','write'));
create policy "buyerPaymentHistory_update" on "buyerPaymentHistory" for update using (public.has_perm('accounts','write'));
create policy "buyerPaymentHistory_delete" on "buyerPaymentHistory" for delete using (public.has_perm('accounts','delete'));

drop policy if exists "supplierPaymentHistory_write" on "supplierPaymentHistory";
drop policy if exists "supplierPaymentHistory_update" on "supplierPaymentHistory";
drop policy if exists "supplierPaymentHistory_delete" on "supplierPaymentHistory";
create policy "supplierPaymentHistory_write" on "supplierPaymentHistory" for insert with check (public.has_perm('accounts','write'));
create policy "supplierPaymentHistory_update" on "supplierPaymentHistory" for update using (public.has_perm('accounts','write'));
create policy "supplierPaymentHistory_delete" on "supplierPaymentHistory" for delete using (public.has_perm('accounts','delete'));

-- hrEmployees/hrSalary — রাউন্ড ১৪-এর read-lockdown এখন has_perm('hr','view')-ভিত্তিক (আগে
-- হার্ডকোড করা ছিল admin/superadmin)। hrSignatures read ইচ্ছাকৃতভাবে এখনো broad
-- (is_active_user()) — merchandiser role Supplier Order Sheet-এ signature select করতে এটা পড়ে,
-- hr module-এর view অনুমতি না থাকলেও এই একটা ব্যতিক্রম বহাল রাখা হলো (রাউন্ড ১৪-এর মতোই)।
drop policy if exists "hrEmployees_read" on "hrEmployees";
create policy "hrEmployees_read" on "hrEmployees" for select using (public.has_perm('hr','view'));
drop policy if exists "hrSalary_read" on "hrSalary";
create policy "hrSalary_read" on "hrSalary" for select using (public.has_perm('hr','view'));
drop policy if exists "hrEmployees_write" on "hrEmployees";
drop policy if exists "hrEmployees_update" on "hrEmployees";
drop policy if exists "hrEmployees_delete" on "hrEmployees";
create policy "hrEmployees_write" on "hrEmployees" for insert with check (public.has_perm('hr','write'));
create policy "hrEmployees_update" on "hrEmployees" for update using (public.has_perm('hr','write'));
create policy "hrEmployees_delete" on "hrEmployees" for delete using (public.has_perm('hr','delete'));
drop policy if exists "hrSalary_write" on "hrSalary";
drop policy if exists "hrSalary_update" on "hrSalary";
drop policy if exists "hrSalary_delete" on "hrSalary";
create policy "hrSalary_write" on "hrSalary" for insert with check (public.has_perm('hr','write'));
create policy "hrSalary_update" on "hrSalary" for update using (public.has_perm('hr','write'));
create policy "hrSalary_delete" on "hrSalary" for delete using (public.has_perm('hr','delete'));
drop policy if exists "hrSignatures_write" on "hrSignatures";
drop policy if exists "hrSignatures_update" on "hrSignatures";
drop policy if exists "hrSignatures_delete" on "hrSignatures";
create policy "hrSignatures_write" on "hrSignatures" for insert with check (public.has_perm('hr','write'));
create policy "hrSignatures_update" on "hrSignatures" for update using (public.has_perm('hr','write'));
create policy "hrSignatures_delete" on "hrSignatures" for delete using (public.has_perm('hr','delete'));

-- ---------------------------------------------------------------------------
-- ধাপ ৫ — users/settings: শুধু view delegate-যোগ্য, write/delete literal role-এ বাঁধা (উপরে
-- ব্যাখ্যা করা নিরাপত্তা সীমারেখা)। users_read broad-ই থাকছে (নাম/থিম দরকার UI-তে)। settings_read-ও
-- broad থাকছে (কোম্পানি ব্র্যান্ডিং সবাই দেখে) — শুধু write আগের মতোই literal role-bound।
-- ⚠️ এই ধাপে users_write/users_update-এর self-row-match exception অক্ষত রাখা হলো (রাউন্ড ১৭
-- হটফিক্স) — নাহলে লগইন আবার ভেঙে যাবে।
drop policy if exists "users_write" on users;
create policy "users_write" on users for insert with check (
  public.current_role() in ('admin','superadmin')
  or auth.uid()::text = (select id::text from profiles where username = users.username)
);
drop policy if exists "users_update" on users;
create policy "users_update" on users for update using (
  public.current_role() in ('admin','superadmin')
  or auth.uid()::text = (select id::text from profiles where username = users.username)
);
drop policy if exists "users_delete" on users;
create policy "users_delete" on users for delete using (public.current_role() in ('admin','superadmin'));
-- settings_write অপরিবর্তিত (v13 থেকেই superadmin-only, এখানে ছোঁয়া হয়নি)

-- ---------------------------------------------------------------------------
-- ধাপ ৬ — Payment RPC দুটোর ভেতরের role-চেক has_perm('accounts','write')-এ বদলানো
-- ---------------------------------------------------------------------------
create or replace function public.record_buyer_payment(
  p_pi_no text, p_amount numeric, p_method text, p_check_number text,
  p_remarks text, p_receipt_image text, p_date text
) returns json
language plpgsql security definer set search_path = public
as $$
declare
  v_row "accBuyer"%rowtype;
  v_total numeric; v_received numeric; v_new_received numeric; v_new_due numeric;
  v_new_status text; v_hist_id bigint; v_username text; v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or not (v_role = 'superadmin' or public.has_perm('accounts','write')) then
    raise exception 'অনুমতি নেই: আপনার Accounts মডিউলে Payment রেকর্ড করার অনুমতি নেই';
  end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Amount অবশ্যই ০-এর বেশি হতে হবে'; end if;
  if p_pi_no is null or length(trim(p_pi_no)) = 0 then raise exception 'PI No আবশ্যক'; end if;
  select * into v_row from "accBuyer" where "piNo" = p_pi_no for update;
  if not found then raise exception 'এই PI No খুঁজে পাওয়া যায়নি: %', p_pi_no; end if;
  v_total := coalesce(nullif(regexp_replace(coalesce(v_row.total, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_received := coalesce(nullif(regexp_replace(coalesce(v_row.received, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_new_received := v_received + p_amount;
  v_new_due := greatest(v_total - v_new_received, 0);
  v_new_status := case when v_new_due <= 0 then 'Paid' else 'Due' end;
  update "accBuyer" set
    received = '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    due = '$' || to_char(v_new_due, 'FM999,999,999,990.00'),
    status = v_new_status, lc = p_method
  where "piNo" = p_pi_no;
  insert into "buyerPaymentHistory" ("piNo", "buyer", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_pi_no, v_row.buyer, to_char(p_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;
  insert into "auditLog" (id, "timestamp", username, role, action, module, "recordId", "recordLabel")
  values ((select coalesce(max(id), 0) + 1 from "auditLog"),
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'buyerPaymentHistory', v_hist_id::text,
    p_pi_no || ' — $' || to_char(p_amount, 'FM999999999990.00'));
  return json_build_object('ok', true, 'historyId', v_hist_id,
    'received', '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    'due', '$' || to_char(v_new_due, 'FM999,999,999,990.00'), 'status', v_new_status);
end;
$$;

create or replace function public.record_supplier_payment(
  p_order_no text, p_amount numeric, p_method text, p_check_number text,
  p_remarks text, p_receipt_image text, p_date text
) returns json
language plpgsql security definer set search_path = public
as $$
declare
  v_row "accSupplier"%rowtype;
  v_total numeric; v_paid numeric; v_new_paid numeric; v_new_due numeric;
  v_hist_id bigint; v_username text; v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or not (v_role = 'superadmin' or public.has_perm('accounts','write')) then
    raise exception 'অনুমতি নেই: আপনার Accounts মডিউলে Payment রেকর্ড করার অনুমতি নেই';
  end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Amount অবশ্যই ০-এর বেশি হতে হবে'; end if;
  if p_order_no is null or length(trim(p_order_no)) = 0 then raise exception 'Order No আবশ্যক'; end if;
  select * into v_row from "accSupplier" where "orderNo" = p_order_no for update;
  if not found then raise exception 'এই Order No খুঁজে পাওয়া যায়নি: %', p_order_no; end if;
  v_total := coalesce(nullif(regexp_replace(coalesce(v_row.total, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_paid := coalesce(nullif(regexp_replace(coalesce(v_row.paid, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_new_paid := v_paid + p_amount;
  v_new_due := greatest(v_total - v_new_paid, 0);
  update "accSupplier" set
    paid = '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    due = '$' || to_char(v_new_due, 'FM999,999,999,990.00')
  where "orderNo" = p_order_no;
  insert into "supplierPaymentHistory" ("orderNo", "supplier", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_order_no, v_row.supplier, to_char(p_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;
  insert into "auditLog" (id, "timestamp", username, role, action, module, "recordId", "recordLabel")
  values ((select coalesce(max(id), 0) + 1 from "auditLog"),
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'supplierPaymentHistory', v_hist_id::text,
    p_order_no || ' — $' || to_char(p_amount, 'FM999999999990.00'));
  return json_build_object('ok', true, 'historyId', v_hist_id,
    'paid', '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    'due', '$' || to_char(v_new_due, 'FM999,999,999,990.00'));
end;
$$;

grant execute on function public.record_buyer_payment(text, numeric, text, text, text, text, text) to authenticated;
grant execute on function public.record_supplier_payment(text, numeric, text, text, text, text, text) to authenticated;
grant execute on function public.has_perm(text, text) to authenticated;
-- ============================================================================
-- AccoFlow ERP — রাউন্ড ২২: Online/Offline Mode সাপোর্ট (Conflict-Detection কলাম)
-- ============================================================================
-- Supabase Dashboard > SQL Editor-এ রান করুন (v13, v14, v15, v16, v18, v21 আগে থেকেই রান করা
-- থাকতে হবে)। idempotent — একাধিকবার রান করলেও সমস্যা নেই।
--
-- ⚠️ গুরুত্বপূর্ণ: এই মাইগ্রেশনটা দুই জায়গাতেই রান করতে হবে —
--   ১) আপনার আসল/অনলাইন (ক্লাউড) Supabase প্রজেক্টে
--   ২) আপনার Offline/Self-Hosted (Docker) Supabase ইনস্ট্যান্সে (দেখুন docker/README_SELF_HOST.md)
-- দুই ডাটাবেসের স্কিমা হুবহু না মিললে Online ⇄ Offline সিঙ্ক (js/offline-sync.js) ভুল আচরণ করতে
-- পারে।
--
-- == এই মাইগ্রেশন কী করছে এবং কেন ==
-- Offline Mode-এ (LAN-এ সেলফ-হোস্টেড Supabase) কাজ করার সময় কোনো রেকর্ড এডিট হলে, এবং একই সময়ে
-- অন্য কেউ Online (ক্লাউড) থেকেও সেই একই রেকর্ড এডিট করলে — যখন নেট ফিরে এসে দুই ডাটাবেস আবার
-- মেলানো (sync) হবে, তখন বোঝা দরকার কোনটা "নতুন" পরিবর্তন। এর জন্য প্রতিটা সিঙ্কযোগ্য টেবিলে একটা
-- সাধারণ (generic) "updatedAt" টাইমস্ট্যাম্প কলাম যোগ করা হলো — শুধু একটা নতুন, nullable কলাম,
-- বিদ্যমান কোনো কলাম/ডেটা/অ্যাপ লজিক স্পর্শ করা হয়নি। client (js/offline-sync.js) প্রতিটা সেভে
-- এই কলামে বর্তমান সময় বসায়; এখানে যোগ করা ট্রিগারটা একটা অতিরিক্ত নিরাপত্তা-স্তর — client কোনো
-- কারণে ভুলে গেলেও ডাটাবেস নিজে থেকে UPDATE-এর সময় এই কলাম রিফ্রেশ করে দেবে।
-- ============================================================================

-- ধাপ ১ — প্রতিটা সিঙ্কযোগ্য টেবিলে updatedAt কলাম (না থাকলে) যোগ করা
alter table "piList" add column if not exists "updatedAt" timestamptz default now();
alter table "masterData" add column if not exists "updatedAt" timestamptz default now();
alter table "receivedGoods" add column if not exists "updatedAt" timestamptz default now();
alter table "supplierOrders" add column if not exists "updatedAt" timestamptz default now();
alter table "deliveryPlan" add column if not exists "updatedAt" timestamptz default now();
alter table "deliveryExec" add column if not exists "updatedAt" timestamptz default now();
alter table "deliveryHist" add column if not exists "updatedAt" timestamptz default now();
alter table "qcList" add column if not exists "updatedAt" timestamptz default now();
alter table "accBuyer" add column if not exists "updatedAt" timestamptz default now();
alter table "accSupplier" add column if not exists "updatedAt" timestamptz default now();
alter table "buyerPaymentHistory" add column if not exists "updatedAt" timestamptz default now();
alter table "supplierPaymentHistory" add column if not exists "updatedAt" timestamptz default now();
alter table "expenseList" add column if not exists "updatedAt" timestamptz default now();
alter table vouchers add column if not exists "updatedAt" timestamptz default now();
alter table "hrEmployees" add column if not exists "updatedAt" timestamptz default now();
alter table "hrAttendance" add column if not exists "updatedAt" timestamptz default now();
alter table "hrLeaves" add column if not exists "updatedAt" timestamptz default now();
alter table "hrSalary" add column if not exists "updatedAt" timestamptz default now();
alter table "hrSignatures" add column if not exists "updatedAt" timestamptz default now();
alter table "hrDepartments" add column if not exists "updatedAt" timestamptz default now();
alter table "hrApprovals" add column if not exists "updatedAt" timestamptz default now();
alter table users add column if not exists "updatedAt" timestamptz default now();
alter table buyers add column if not exists "updatedAt" timestamptz default now();
alter table suppliers add column if not exists "updatedAt" timestamptz default now();

-- ধাপ ২ — generic ট্রিগার ফাংশন: যেকোনো UPDATE-এ updatedAt স্বয়ংক্রিয়ভাবে "এখন" বসিয়ে দেয়
-- (client যদি নিজে থেকে updatedAt না পাঠায়, বা সরাসরি SQL Editor থেকে কেউ রেকর্ড এডিট করে,
-- তখনও এই ট্রিগার সেটা ধরে ফেলবে — conflict-detection কখনো "স্টেল" (stale) তথ্যের উপর নির্ভর করবে না)
create or replace function public.set_offline_sync_updated_at()
returns trigger language plpgsql as $$
begin
  new."updatedAt" = now();
  return new;
end;
$$;

-- ধাপ ৩ — প্রতিটা টেবিলে ট্রিগার সংযুক্ত করা (idempotent: আগে থাকলে drop করে আবার তৈরি)
do $$
declare
  t text;
  tables text[] := array[
    'piList','masterData','receivedGoods','supplierOrders','deliveryPlan','deliveryExec',
    'deliveryHist','qcList','accBuyer','accSupplier','buyerPaymentHistory','supplierPaymentHistory',
    'expenseList','vouchers','hrEmployees','hrAttendance','hrLeaves','hrSalary','hrSignatures',
    'hrDepartments','hrApprovals','users','buyers','suppliers'
  ];
begin
  foreach t in array tables loop
    execute format('drop trigger if exists trg_set_updated_at on %I;', t);
    execute format(
      'create trigger trg_set_updated_at before update on %I for each row execute function public.set_offline_sync_updated_at();',
      t
    );
  end loop;
end $$;

-- ধাপ ৪ — প্রতিটা টেবিলে updatedAt-এর উপর ইনডেক্স (Offline Sync-এর সময় "id, updatedAt" হালকা
-- কোয়েরি দিয়ে দুই ডাটাবেস তুলনা করা হয় — বড় টেবিলে এই ইনডেক্স ছাড়া সেই কোয়েরি ধীর হতে পারে)
do $$
declare
  t text;
  tables text[] := array[
    'piList','masterData','receivedGoods','supplierOrders','deliveryPlan','deliveryExec',
    'deliveryHist','qcList','accBuyer','accSupplier','buyerPaymentHistory','supplierPaymentHistory',
    'expenseList','vouchers','hrEmployees','hrAttendance','hrLeaves','hrSalary','hrSignatures',
    'hrDepartments','hrApprovals','users','buyers','suppliers'
  ];
begin
  foreach t in array tables loop
    execute format('create index if not exists %I on %I ("updatedAt");', 'idx_' || lower(t) || '_updated_at', t);
  end loop;
end $$;
-- ============================================================================
-- AccoFlow ERP -- Round 23: fixes for issues found during the audit sessions
-- ============================================================================
-- Run in Supabase Dashboard > SQL Editor (v13, v15, v16, v18, v21, v22 must already
-- be applied -- this depends on public.current_role(), public.has_perm(), the payment
-- RPCs, and the profiles table). Idempotent -- safe to re-run.
--
-- This migration fixes:
--   1. record_buyer_payment / record_supplier_payment -- no upper bound on payment
--      amount, so a payment could exceed the outstanding due with no error.
--   2. auditLog.id was a plain bigint (not identity) -- two concurrent payments on
--      different PI/Order numbers could compute the same next id and collide.
--   3. users_write / users_update RLS -- a non-admin user could self-upsert their own
--      "role" column to 'superadmin' (RLS never validated the column's value, only
--      row ownership). This did not grant real database privileges (those all check
--      profiles.role, not users.role) but did unlock the client-side admin UI.
--   4. Online<->Offline dual-endpoint reconcile had no way to distinguish "record was
--      never synced" from "record was deleted on the other side" -- deleted records
--      could be silently resurrected. A lightweight tombstone table is added here;
--      the corresponding app.js/offline-sync.js changes are delivered alongside this
--      migration and are required for this fix to take effect.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Fix 1 -- overpayment validation in both payment RPCs
-- ---------------------------------------------------------------------------
create or replace function public.record_buyer_payment(
  p_pi_no text,
  p_amount numeric,
  p_method text,
  p_check_number text,
  p_remarks text,
  p_receipt_image text,
  p_date text
) returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row "accBuyer"%rowtype;
  v_total numeric;
  v_received numeric;
  v_new_received numeric;
  v_new_due numeric;
  v_new_status text;
  v_hist_id bigint;
  v_username text;
  v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or v_role not in ('admin', 'superadmin', 'accountant') then
    raise exception 'Not authorised: only admin/superadmin/accountant can record payments';
  end if;

  if p_amount is null or p_amount <= 0 then
    raise exception 'Amount must be greater than 0';
  end if;
  if p_pi_no is null or length(trim(p_pi_no)) = 0 then
    raise exception 'PI No is required';
  end if;

  select * into v_row from "accBuyer" where "piNo" = p_pi_no for update;
  if not found then
    raise exception 'PI No not found: %', p_pi_no;
  end if;

  v_total := coalesce(nullif(regexp_replace(coalesce(v_row.total, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_received := coalesce(nullif(regexp_replace(coalesce(v_row.received, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;

  -- Fix 1: reject a payment that would push received above the invoice total.
  if p_amount > (v_total - v_received) then
    raise exception 'Payment amount ($%) exceeds the outstanding due ($%) for %', p_amount, (v_total - v_received), p_pi_no;
  end if;

  v_new_received := v_received + p_amount;
  v_new_due := greatest(v_total - v_new_received, 0);
  v_new_status := case when v_new_due <= 0 then 'Paid' else 'Due' end;

  update "accBuyer" set
    received = '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    due = '$' || to_char(v_new_due, 'FM999,999,999,990.00'),
    status = v_new_status,
    lc = p_method
  where "piNo" = p_pi_no;

  insert into "buyerPaymentHistory" ("piNo", "buyer", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_pi_no, v_row.buyer, to_char(p_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;

  insert into "auditLog" ("timestamp", username, role, action, module, "recordId", "recordLabel")
  values (
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'buyerPaymentHistory', v_hist_id::text,
    p_pi_no || ' -- $' || to_char(p_amount, 'FM999999999990.00')
  );

  return json_build_object(
    'ok', true, 'historyId', v_hist_id,
    'received', '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    'due', '$' || to_char(v_new_due, 'FM999,999,999,990.00'),
    'status', v_new_status
  );
end;
$$;

create or replace function public.record_supplier_payment(
  p_order_no text,
  p_amount numeric,
  p_method text,
  p_check_number text,
  p_remarks text,
  p_receipt_image text,
  p_date text
) returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row "accSupplier"%rowtype;
  v_total numeric;
  v_paid numeric;
  v_new_paid numeric;
  v_new_due numeric;
  v_hist_id bigint;
  v_username text;
  v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or v_role not in ('admin', 'superadmin', 'accountant') then
    raise exception 'Not authorised: only admin/superadmin/accountant can record payments';
  end if;

  if p_amount is null or p_amount <= 0 then
    raise exception 'Amount must be greater than 0';
  end if;
  if p_order_no is null or length(trim(p_order_no)) = 0 then
    raise exception 'Order No is required';
  end if;

  select * into v_row from "accSupplier" where "orderNo" = p_order_no for update;
  if not found then
    raise exception 'Order No not found: %', p_order_no;
  end if;

  v_total := coalesce(nullif(regexp_replace(coalesce(v_row.total, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;
  v_paid := coalesce(nullif(regexp_replace(coalesce(v_row.paid, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric;

  -- Fix 1: reject a payment that would push paid above the order total.
  if p_amount > (v_total - v_paid) then
    raise exception 'Payment amount ($%) exceeds the outstanding due ($%) for %', p_amount, (v_total - v_paid), p_order_no;
  end if;

  v_new_paid := v_paid + p_amount;
  v_new_due := greatest(v_total - v_new_paid, 0);

  update "accSupplier" set
    paid = '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    due = '$' || to_char(v_new_due, 'FM999,999,999,990.00')
  where "orderNo" = p_order_no;

  insert into "supplierPaymentHistory" ("orderNo", "supplier", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_order_no, v_row.supplier, to_char(p_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;

  insert into "auditLog" ("timestamp", username, role, action, module, "recordId", "recordLabel")
  values (
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'supplierPaymentHistory', v_hist_id::text,
    p_order_no || ' -- $' || to_char(p_amount, 'FM999999999990.00')
  );

  return json_build_object(
    'ok', true, 'historyId', v_hist_id,
    'paid', '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    'due', '$' || to_char(v_new_due, 'FM999,999,999,990.00')
  );
end;
$$;

grant execute on function public.record_buyer_payment(text, numeric, text, text, text, text, text) to authenticated;
grant execute on function public.record_supplier_payment(text, numeric, text, text, text, text, text) to authenticated;

-- ---------------------------------------------------------------------------
-- Fix 2 -- auditLog.id -> identity column (idempotency-checked, learned from the
-- v16 bug where the same statement pattern was not safe to re-run)
-- ---------------------------------------------------------------------------
do $$
begin
  if not exists (
    select 1 from pg_attribute a join pg_class c on c.oid = a.attrelid
    where c.relname = 'auditLog' and a.attname = 'id' and a.attidentity <> ''
  ) then
    alter table "auditLog" alter column id add generated by default as identity;
    perform setval(
      pg_get_serial_sequence('"auditLog"', 'id'),
      coalesce((select max(id) from "auditLog"), 0) + 1,
      false
    );
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- Fix 3 -- users.role can no longer be self-escalated. A non-admin user updating
-- their own row (the lastLogin/theme-preference exception from v13/round-17) must
-- now keep "role" identical to their real profiles.role. Admins/superadmins are
-- unaffected (they can still set any role via the normal user-management flow).
-- ---------------------------------------------------------------------------
drop policy if exists "users_write" on users;
create policy "users_write" on users for insert with check (
  public.current_role() in ('admin','superadmin')
  or (
    auth.uid()::text = (select id::text from profiles where username = users.username)
    and role = (select role from profiles where username = users.username)
  )
);

drop policy if exists "users_update" on users;
create policy "users_update" on users for update using (
  public.current_role() in ('admin','superadmin')
  or auth.uid()::text = (select id::text from profiles where username = users.username)
) with check (
  public.current_role() in ('admin','superadmin')
  or (
    auth.uid()::text = (select id::text from profiles where username = users.username)
    and role = (select role from profiles where username = users.username)
  )
);

-- ---------------------------------------------------------------------------
-- Fix 4 -- delete tombstones for the Online<->Offline dual-endpoint reconcile.
-- A tiny, single shared table rather than a deletedAt column on every business
-- table -- lower risk, and the app only needs to check "was this id deleted
-- somewhere" during reconcile, not carry deleted rows around everywhere else.
-- ---------------------------------------------------------------------------
create table if not exists sync_tombstones (
  "tableName" text not null,
  "recordId" text not null,
  "deletedAt" timestamptz not null default now(),
  "deletedBy" text,
  primary key ("tableName", "recordId")
);

alter table sync_tombstones enable row level security;

drop policy if exists "sync_tombstones_read" on sync_tombstones;
create policy "sync_tombstones_read" on sync_tombstones for select using (public.is_active_user());

drop policy if exists "sync_tombstones_insert" on sync_tombstones;
create policy "sync_tombstones_insert" on sync_tombstones for insert with check (public.is_active_user());

-- No update/delete policy on purpose -- like auditLog, tombstones are append-only
-- from the app's point of view (a superadmin can still clean old ones up via
-- service_role/SQL Editor directly, e.g. a periodic purge of entries older than
-- 90 days, since IDs are rarely reused across that long a window).
-- ============================================================================
-- AccoFlow ERP -- Round 24: security hardening + direct ZKTeco -> Supabase push
-- ============================================================================
-- Run in Supabase Dashboard > SQL Editor AFTER accoflow_combined_schema_v23.sql
-- (or just run accoflow_combined_schema_v24.sql, which already contains v23 + this).
-- Idempotent -- safe to re-run.  Take a backup first.
--
-- What this migration does
--   1. is_active_user() no longer treats the new 'device' role (the ZKTeco bridge's
--      service account) as a normal user -> a bridge account can NOT read business data.
--   2. profiles_guard trigger: a plain 'admin' can no longer promote anybody (or
--      themselves) to superadmin, touch a superadmin's row, or change their own
--      role/permissions/status by writing to `profiles` directly through the API.
--   3. record_buyer_payment / record_supplier_payment: the Round-23 version had silently
--      replaced the has_perm('accounts','write') check (v21) with a hard-coded role list.
--      The permission check is restored, the overpayment guard is kept, and amounts are
--      now handled in whole cents (so 0.017-style fractions can never leave a stuck
--      "due 0.002" behind).
--   4. next_row_id(): collision-free ID allocation for tables whose ids are generated
--      in the browser (Math.max()+1 -> two users saving at the same moment overwrote each
--      other's record).  The app calls this RPC and falls back to the old behaviour if it
--      is not installed yet.
--   5. record_zk_attendance(): the ZKTeco bridge now pushes punches straight to Supabase
--      through this function (matching by "zkUserId"/NID exactly like the old browser
--      sync did).  The Telegram relay is gone.
--   6. Scrubs any Telegram bot token that an older version stored in settings.zktecoConfig.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. 'device' accounts are not "active users" for ordinary read policies
-- ---------------------------------------------------------------------------
create or replace function public.is_active_user()
returns boolean
language sql stable
security definer set search_path = public
as $$
  select exists (
    select 1 from profiles
    where id = auth.uid() and status = 'Active' and role <> 'device'
  );
$$;

-- ---------------------------------------------------------------------------
-- 2. profiles_guard -- stop admin -> superadmin escalation done directly on the table
-- ---------------------------------------------------------------------------
-- auth.uid() is NULL for service_role / SQL-editor / Edge-Function admin-client calls, so
-- the trusted server-side paths are not affected (the Edge Function has its own checks).
create or replace function public.profiles_guard()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_caller text;
begin
  if v_uid is null then
    return coalesce(new, old);
  end if;

  select role into v_caller from profiles where id = v_uid and status = 'Active';

  if v_caller = 'superadmin' then
    return coalesce(new, old);
  end if;

  if v_caller is distinct from 'admin' then
    raise exception 'Not authorised to modify profiles';
  end if;

  -- From here: caller is a plain admin
  if tg_op = 'INSERT' then
    if new.role in ('superadmin', 'device') then
      raise exception 'Only a superadmin can create a % account', new.role;
    end if;
  elsif tg_op = 'UPDATE' then
    if old.role in ('superadmin', 'device') or new.role in ('superadmin', 'device') then
      raise exception 'Only a superadmin can modify or create superadmin/device accounts';
    end if;
    if new.id is distinct from old.id then
      raise exception 'profiles.id cannot be changed';
    end if;
    if old.id = v_uid and (
         new.role is distinct from old.role
      or new.status is distinct from old.status
      or new.permissions is distinct from old.permissions
    ) then
      raise exception 'You cannot change your own role, status or permissions';
    end if;
  elsif tg_op = 'DELETE' then
    if old.role in ('superadmin', 'device') or old.id = v_uid then
      raise exception 'Only a superadmin can delete this account';
    end if;
  end if;

  return coalesce(new, old);
end;
$$;

drop trigger if exists trg_profiles_guard on profiles;
create trigger trg_profiles_guard
  before insert or update or delete on profiles
  for each row execute function public.profiles_guard();

-- ---------------------------------------------------------------------------
-- 3. Payment RPCs -- permission check restored (has_perm), whole-cent arithmetic
-- ---------------------------------------------------------------------------
create or replace function public.record_buyer_payment(
  p_pi_no text, p_amount numeric, p_method text, p_check_number text,
  p_remarks text, p_receipt_image text, p_date text
) returns json
language plpgsql security definer set search_path = public
as $$
declare
  v_row "accBuyer"%rowtype;
  v_total numeric; v_received numeric; v_amount numeric;
  v_new_received numeric; v_new_due numeric;
  v_new_status text; v_hist_id bigint; v_username text; v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or not (v_role = 'superadmin' or public.has_perm('accounts', 'write')) then
    raise exception 'Not authorised: you do not have permission to record payments (Accounts module)';
  end if;

  -- Money is handled in whole cents: anything finer than 0.01 is rounded, never carried
  v_amount := round(coalesce(p_amount, 0), 2);
  if v_amount <= 0 then raise exception 'Amount must be at least 0.01'; end if;
  if p_pi_no is null or length(trim(p_pi_no)) = 0 then raise exception 'PI No is required'; end if;

  select * into v_row from "accBuyer" where "piNo" = p_pi_no for update;
  if not found then raise exception 'PI No not found: %', p_pi_no; end if;

  v_total    := round(coalesce(nullif(regexp_replace(coalesce(v_row.total,    '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric, 2);
  v_received := round(coalesce(nullif(regexp_replace(coalesce(v_row.received, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric, 2);

  if v_amount > (v_total - v_received) then
    raise exception 'Payment amount ($%) exceeds the outstanding due ($%) for %',
      to_char(v_amount, 'FM999,999,999,990.00'), to_char(v_total - v_received, 'FM999,999,999,990.00'), p_pi_no;
  end if;

  v_new_received := v_received + v_amount;
  v_new_due      := greatest(v_total - v_new_received, 0);
  v_new_status   := case when v_new_due <= 0 then 'Paid' else 'Due' end;

  update "accBuyer" set
    received = '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    due      = '$' || to_char(v_new_due,      'FM999,999,999,990.00'),
    status   = v_new_status, lc = p_method
  where "piNo" = p_pi_no;

  insert into "buyerPaymentHistory" ("piNo", "buyer", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_pi_no, v_row.buyer, to_char(v_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;

  insert into "auditLog" ("timestamp", username, role, action, module, "recordId", "recordLabel")
  values (
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'buyerPaymentHistory', v_hist_id::text,
    p_pi_no || ' -- $' || to_char(v_amount, 'FM999999999990.00')
  );

  return json_build_object(
    'ok', true, 'historyId', v_hist_id,
    'received', '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    'due',      '$' || to_char(v_new_due,      'FM999,999,999,990.00'),
    'status', v_new_status
  );
end;
$$;

create or replace function public.record_supplier_payment(
  p_order_no text, p_amount numeric, p_method text, p_check_number text,
  p_remarks text, p_receipt_image text, p_date text
) returns json
language plpgsql security definer set search_path = public
as $$
declare
  v_row "accSupplier"%rowtype;
  v_total numeric; v_paid numeric; v_amount numeric;
  v_new_paid numeric; v_new_due numeric;
  v_hist_id bigint; v_username text; v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or not (v_role = 'superadmin' or public.has_perm('accounts', 'write')) then
    raise exception 'Not authorised: you do not have permission to record payments (Accounts module)';
  end if;

  v_amount := round(coalesce(p_amount, 0), 2);
  if v_amount <= 0 then raise exception 'Amount must be at least 0.01'; end if;
  if p_order_no is null or length(trim(p_order_no)) = 0 then raise exception 'Order No is required'; end if;

  select * into v_row from "accSupplier" where "orderNo" = p_order_no for update;
  if not found then raise exception 'Order No not found: %', p_order_no; end if;

  v_total := round(coalesce(nullif(regexp_replace(coalesce(v_row.total, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric, 2);
  v_paid  := round(coalesce(nullif(regexp_replace(coalesce(v_row.paid,  '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric, 2);

  if v_amount > (v_total - v_paid) then
    raise exception 'Payment amount ($%) exceeds the outstanding due ($%) for %',
      to_char(v_amount, 'FM999,999,999,990.00'), to_char(v_total - v_paid, 'FM999,999,999,990.00'), p_order_no;
  end if;

  v_new_paid := v_paid + v_amount;
  v_new_due  := greatest(v_total - v_new_paid, 0);

  update "accSupplier" set
    paid = '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    due  = '$' || to_char(v_new_due,  'FM999,999,999,990.00')
  where "orderNo" = p_order_no;

  insert into "supplierPaymentHistory" ("orderNo", "supplier", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_order_no, v_row.supplier, to_char(v_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;

  insert into "auditLog" ("timestamp", username, role, action, module, "recordId", "recordLabel")
  values (
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'supplierPaymentHistory', v_hist_id::text,
    p_order_no || ' -- $' || to_char(v_amount, 'FM999999999990.00')
  );

  return json_build_object(
    'ok', true, 'historyId', v_hist_id,
    'paid', '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    'due',  '$' || to_char(v_new_due,  'FM999,999,999,990.00')
  );
end;
$$;

grant execute on function public.record_buyer_payment(text, numeric, text, text, text, text, text) to authenticated;
grant execute on function public.record_supplier_payment(text, numeric, text, text, text, text, text) to authenticated;

-- ---------------------------------------------------------------------------
-- 4. Collision-free ID allocation (replaces browser-side Math.max()+1 race)
-- ---------------------------------------------------------------------------
create table if not exists id_counters (
  table_name text primary key,
  last_id    bigint not null default 0
);
alter table id_counters enable row level security;   -- no policies: only the functions below touch it
revoke all on id_counters from anon, authenticated;

-- internal allocator (no permission check) -- used by next_row_id() and record_zk_attendance()
create or replace function public._alloc_row_id(p_table text)
returns bigint
language plpgsql security definer set search_path = public
as $$
declare
  v_max bigint;
  v_id  bigint;
begin
  if p_table not in (
    'piList','masterData','receivedGoods','supplierOrders','deliveryPlan','deliveryExec','deliveryHist','qcList',
    'accBuyer','accSupplier','buyerPaymentHistory','supplierPaymentHistory','expenseList','vouchers',
    'hrEmployees','hrAttendance','hrLeaves','hrSalary','hrSignatures','hrDepartments','hrApprovals',
    'users','buyers','suppliers'
  ) then
    raise exception 'next_row_id: table not allowed: %', p_table;
  end if;

  execute format('select coalesce(max(id), 0) from %I', p_table) into v_max;

  insert into id_counters (table_name, last_id) values (p_table, v_max + 1)
  on conflict (table_name) do update
    set last_id = greatest(id_counters.last_id, v_max) + 1
  returning last_id into v_id;

  return v_id;
end;
$$;
revoke all on function public._alloc_row_id(text) from public, anon, authenticated;

create or replace function public.next_row_id(p_table text)
returns bigint
language plpgsql security definer set search_path = public
as $$
begin
  if not public.is_active_user() then
    raise exception 'Not authorised';
  end if;
  return public._alloc_row_id(p_table);
end;
$$;
grant execute on function public.next_row_id(text) to authenticated;

-- ---------------------------------------------------------------------------
-- 5. ZKTeco bridge -> Supabase (direct push, no Telegram)
-- ---------------------------------------------------------------------------
-- Permission: has_perm('zkbridge','push') -- true for superadmin, or for the dedicated
-- 'device' account created by scripts/create-bridge-user.mjs (permissions {"zkbridge":{"push":true}}).
-- That account cannot read any other table (see is_active_user() above).
--
-- p_punches: [{ "userId": "12", "time": "08:57", "type": "in"|"out", "timestamp": "<ISO>" }, ...]
--            (`time` = HH:MM in the bridge PC's local time; falls back to timestamp in Asia/Dhaka)
create or replace function public.record_zk_attendance(p_date text, p_punches jsonb)
returns json
language plpgsql security definer set search_path = public
as $$
declare
  v_open text;
  v_p jsonb;
  v_uid text; v_time text; v_type text;
  v_emp record;
  v_n int;
  v_row "hrAttendance"%rowtype;
  v_matched int := 0; v_added int := 0; v_updated int := 0;
  v_unmatched text[] := '{}'; v_conflicts text[] := '{}';
begin
  if not public.has_perm('zkbridge', 'push') then
    raise exception 'Not authorised: this account may not push ZKTeco attendance';
  end if;
  if p_date is null or p_date !~ '^\d{4}-\d{2}-\d{2}$' then
    raise exception 'p_date must be YYYY-MM-DD';
  end if;
  if p_punches is null or jsonb_typeof(p_punches) <> 'array' then
    raise exception 'p_punches must be a JSON array';
  end if;
  if jsonb_array_length(p_punches) > 5000 then
    raise exception 'Too many punches in one call (max 5000)';
  end if;

  perform pg_advisory_xact_lock(hashtext('record_zk_attendance'));

  select coalesce(nullif(value, ''), '09:00') into v_open from settings where key = 'officeOpenTime';
  v_open := coalesce(v_open, '09:00');

  for v_p in select * from jsonb_array_elements(p_punches) loop
    v_uid  := trim(coalesce(v_p->>'userId', ''));
    v_type := coalesce(v_p->>'type', 'in');
    v_time := nullif(trim(coalesce(v_p->>'time', '')), '');
    if v_time is null and nullif(v_p->>'timestamp', '') is not null then
      v_time := to_char((v_p->>'timestamp')::timestamptz at time zone 'Asia/Dhaka', 'HH24:MI');
    end if;
    if v_uid = '' or v_time is null or v_time !~ '^\d{2}:\d{2}$' then continue; end if;

    -- employee match: zkUserId first, NID as fallback (same rule the browser used)
    select count(*) into v_n from "hrEmployees"
      where coalesce("deletedAt", '') = ''
        and (trim(coalesce("zkUserId", '')) = v_uid or trim(coalesce(nid, '')) = v_uid);
    if v_n = 0 then
      if not (v_uid = any(v_unmatched)) then v_unmatched := v_unmatched || v_uid; end if;
      continue;
    elsif v_n > 1 then
      if not (v_uid = any(v_conflicts)) then v_conflicts := v_conflicts || v_uid; end if;
      continue;
    end if;
    select * into v_emp from "hrEmployees"
      where coalesce("deletedAt", '') = ''
        and (trim(coalesce("zkUserId", '')) = v_uid or trim(coalesce(nid, '')) = v_uid);
    v_matched := v_matched + 1;

    select * into v_row from "hrAttendance"
      where date = p_date and employee = v_emp.name and coalesce("deletedAt", '') = ''
      order by id limit 1;
    if not found then
      insert into "hrAttendance" (id, date, employee, "checkIn", "checkOut", status, "otHours")
      values (public._alloc_row_id('hrAttendance'), p_date, v_emp.name, '', '', 'Present', '0')
      returning * into v_row;
      v_added := v_added + 1;
    end if;

    if v_type = 'out' then
      if coalesce(v_row."checkOut", '') = '' or v_time > v_row."checkOut" then
        update "hrAttendance" set "checkOut" = v_time where id = v_row.id;
        v_updated := v_updated + 1;
      end if;
    else
      if coalesce(v_row."checkIn", '') = '' or v_time < v_row."checkIn" then
        update "hrAttendance"
          set "checkIn" = v_time, status = case when v_time > v_open then 'Late' else 'Present' end
          where id = v_row.id;
        v_updated := v_updated + 1;
      end if;
    end if;
  end loop;

  insert into settings (key, value) values (
    'zkBridgeLastPush',
    json_build_object('at', to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
                      'date', p_date, 'matched', v_matched, 'added', v_added,
                      'unmatched', v_unmatched, 'conflicts', v_conflicts)::text
  ) on conflict (key) do update set value = excluded.value;

  return json_build_object('ok', true, 'matched', v_matched, 'added', v_added, 'updated', v_updated,
                           'unmatched', v_unmatched, 'conflicts', v_conflicts);
end;
$$;
grant execute on function public.record_zk_attendance(text, jsonb) to authenticated;

-- ---------------------------------------------------------------------------
-- 6. Remove any Telegram secrets that older versions saved into settings
-- ---------------------------------------------------------------------------
do $$
begin
  update settings
     set value = ((value::jsonb) - 'telegramBotToken' - 'telegramChatId')::text
   where key = 'zktecoConfig';
exception when others then
  null;  -- value was not valid JSON; nothing to scrub
end $$;
