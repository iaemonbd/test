/** Default / offline fallback — empty until data is loaded from Google Sheets */
const CURRENCY_BDT = '\u09F3';

const DEFAULT_STATE = {
  piList: [],
  masterData: [],
  receivedGoods: [],
  deliveryPlan: [],
  deliveryExec: [],
  deliveryHist: [],
  qcList: [],
  accBuyer: [],
  accSupplier: [],
  expenseList: [],
  vouchers: [],
  hrEmployees: [],
  hrAttendance: [],
  hrLeaves: [],
  hrSalary: [],
  hrSignatures: [],
  hrDepartments: [],
  hrApprovals: [],
  users: [],
  buyers: [],
  suppliers: [],
  supplierOrders: [],
  buyerPaymentHistory: [],
  supplierPaymentHistory: [],
  auditLog: []
};

const DEFAULT_ORDERS = {};
