// List of tables that support the Recycle Bin (Soft Delete) -- exactly the tables
// confirmDelete() uses, so every deleted record can be restored
const SOFT_DELETE_TABLES = [
  'piList', 'masterData', 'receivedGoods', 'supplierOrders', 'deliveryPlan', 'deliveryHist',
  'qcList', 'accBuyer', 'accSupplier', 'expenseList', 'vouchers', 'hrEmployees', 'hrAttendance',
  'hrLeaves', 'hrSalary', 'hrSignatures', 'hrDepartments', 'users', 'buyers', 'suppliers'
];

// For ZKTeco sync, "today" means the browser's local calendar date (not UTC) -- important to
// keep matching AccoFlow ZKTeco Bridge v2.1+. Both sides used to calculate "today" with
// new Date().toISOString() (UTC), so a punch near midnight (between local midnight and 6am,
// because of Bangladesh's UTC+6 offset) could land on the wrong date -- this was a source of
// mismatch between the device data and the ERP.
function zkLocalDateStr(d) {
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

// ============================================================
// Global system-wide timezone and date-format configuration
// ------------------------------------------------------------
// Everywhere in the app -- "today", timestamps (deletedAt, audit log, last login) and the
// clock -- everything is calculated per Bangladesh Standard Time (BST, GMT+6), set in this one
// single place, no matter what the user's own browser/OS timezone setting is. To change the
// timezone in future, just changing APP_TIMEZONE's value is reflected across the whole app.
const APP_TIMEZONE = 'Asia/Dhaka'; // GMT+6, Bangladesh Standard Time
const APP_DATE_FORMAT = 'DD/MM/YYYY'; // Global date display format (tables/forms/views everywhere)

// Returns "today" as YYYY-MM-DD, always per the Asia/Dhaka timezone -- this is exactly the
// format needed for an <input type="date">'s value attribute (per the HTML standard; the
// display format is a separate matter). todayStr() used to use UTC time -- near midnight
// (BST local time between midnight and 6am, because of the UTC+6 offset) this could show the
// wrong "today".
function todayStr() {
  return new Date().toLocaleDateString('en-CA', { timeZone: APP_TIMEZONE }); // en-CA => YYYY-MM-DD
}

// Returns the current moment's timestamp as an ISO-like string with the Asia/Dhaka offset
// (+06:00) -- used for storing deletedAt, auditLog timestamps, etc., so that no matter what
// timezone the server/browser itself is in, the recorded time is always unambiguously in
// Bangladesh time.
function nowISO() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: APP_TIMEZONE, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
  }).formatToParts(new Date()).reduce((acc, p) => { acc[p.type] = p.value; return acc; }, {});
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}:${parts.second}+06:00`;
}

// Converts any stored date (ISO 'YYYY-MM-DD', a full timestamp, or a Date object) into the
// global display format DD/MM/YYYY -- this one function should be used everywhere a date is
// shown, in tables/forms/views, so a future format change only needs changing in one place.
function formatDate(input) {
  if (!input) return '';
  const d = (input instanceof Date) ? input : new Date(input);
  if (isNaN(d.getTime())) return String(input); // if it can't be parsed, return the original value (so data is never lost)
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: APP_TIMEZONE, year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(d).reduce((acc, p) => { acc[p.type] = p.value; return acc; }, {});
  return `${parts.day}/${parts.month}/${parts.year}`; // DD/MM/YYYY
}

// For showing date with time as well (Recycle Bin's Deleted At, Audit Log timestamp, Last
// Login, etc.) -- always per Asia/Dhaka time, format: DD/MM/YYYY, HH:MM:SS
function formatDateTime(input) {
  if (!input) return '';
  const d = (input instanceof Date) ? input : new Date(input);
  if (isNaN(d.getTime())) return String(input);
  const datePart = formatDate(d);
  const timePart = new Intl.DateTimeFormat('en-US', {
    timeZone: APP_TIMEZONE, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
  }).format(d);
  return `${datePart}, ${timePart}`;
}

// Converts the "YYYY-MM" value coming from the HR Salary module's "Salary Month"
// <input type="month"> into a human-readable "Jul 2026" format (used in the Salary table and
// filter dropdown)
function formatMonthLabel(ym) {
  if (!ym) return '';
  const [y, m] = String(ym).split('-').map(Number);
  if (!y || !m) return ym;
  const d = new Date(y, m - 1, 1);
  if (isNaN(d.getTime())) return ym;
  return new Intl.DateTimeFormat('en-US', { month: 'short', year: 'numeric' }).format(d);
}

const app = {
  role: 'admin',
  viewingPIId: null,
  companyLogo: localStorage.getItem('gp_logo') || null,
  dbConnected: false,
  chartInstances: {},
  zkteco: { enabled: false, ip: '', port: 4370, bridgeUrl: '', autoSyncMinutes: 0 },
  _zktecoTimer: null,
  trashItems: [], // soft-deleted records accumulate here ({ module, record, deletedAt, deletedBy })
  // Round 21: every user's granular permissions for the Roles page (from the profiles table)
  // -- kept outside this.state deliberately, since it is not part of the normal
  // loadAll()/persistSheet() pipeline, and is only fetched lazily via
  // loadProfilesForRolesPage() when the Roles page is opened
  profiles: [],
  currentUsername: '', // the logged-in user's username (for the audit log)
  settings: {
    companyName: '',
    tagline: '',
    address: '',
    phone: '',
    accName: '', accNo: '', bankName: '', swift: '', bin: '',
    superAdminUser: 'emon', superAdminPass: '7797',
    officeOpenTime: '09:00', officeCloseTime: '18:00',
    maxQcAllowedPct: 5, // configurable via QC Center > Settings -- default 5%
    theme: 'ocean', mode: 'dark'
  },
  state: JSON.parse(JSON.stringify(DEFAULT_STATE)),
  masterData: { orders: { ...DEFAULT_ORDERS } },

  async init() {
    // Settings saved in localStorage (including the Super Admin username/password) are loaded
    // first, so the user can log in immediately with their most recently changed credentials
    // even if the Google Sheets connection is slow/missing -- this was one cause of the old
    // "can't log in with the new password" bug.
    this.loadLocalSettings();
    this.loadZKTecoSettings();
    // ⚠️ Online/Offline Mode (Round 22): wraps SheetsDB's upsertRows()/deleteRow() and applies
    // the correct Supabase credentials per the saved mode (Online/Offline) -- this needs to
    // happen before everything else, so no subsequent SheetsDB call uses the wrong/stale
    // credentials.
    if (window.OfflineSync) { try { await OfflineSync.init(); } catch (e) { console.warn('OfflineSync init failed:', e); } }
    // ⚠️ Theme system redesign: there used to be three separate layers -- a Dark/Light Mode
    // toggle, 10 Accent Colours, and 5 Style Packs -- combined together these created countless
    // combinations that could not all be tested separately, leaving bugs like .btn-accent
    // buttons (Save/Process/Create New PI, etc.) in Light Mode becoming white text on a white
    // background and disappearing. Now there is just one "App Theme" -- Classic Glass (default,
    // the old dark theme, unchanged) and Aqua Dash (Round 14, below) -- each a fully
    // self-contained, verified palette (background+card+text+accent together), so no
    // combination can ever break contrast. The login screen always shows the neutral default
    // (Classic Glass) -- as soon as the user logs in, doLogin() applies their own saved theme.
    this.applyAppTheme('classic');
    this.showLoader(true);
    // ⚠️ Round 13 (RLS migration): the login function used to be made to wait for the data
    // load to finish via a dbReadyPromise here (so the password could be checked against a
    // fresh users table in the local state). Once RLS was enabled, no table (including
    // settings/users) can be read before authentication anyway, and password checking is now
    // done server-side by Supabase Auth itself -- so this whole mechanism is no longer needed.
    // loadFromDatabase() is now only called after a successful sign-in in login().
    const loaderSafetyTimer = setTimeout(() => this.showLoader(false), 8000);
    try {
      this.clock();
      setInterval(() => this.clock(), 1000);
      this.nav();
      this.initBgParticles();
      const piDateEl = document.getElementById('pi-modal-date');
      if (piDateEl) piDateEl.value = todayStr();
      this.applyUserPermissions('admin', {});
      this.addPIRow();
      const soDateEl = document.getElementById('so-date');
      if (soDateEl) { soDateEl.value = todayStr(); this.addSupplierOrderRow(); }
      this.syncSettingsToInputs();
      this.updateSupplierOrderHeader();
      if (this.companyLogo) this.updateLogoDisplay(this.companyLogo);

      const supaUrlInput = document.getElementById('set-supabase-url');
      const supaKeyInput = document.getElementById('set-supabase-key');
      if (supaUrlInput && !supaUrlInput.value.trim()) supaUrlInput.value = SheetsDB.url;
      if (supaKeyInput && !supaKeyInput.value.trim()) supaKeyInput.value = SheetsDB.anonKey;
      if (window.OfflineSync) {
        const offUrlInput = document.getElementById('set-supabase-url-offline');
        const offKeyInput = document.getElementById('set-supabase-key-offline');
        const offCreds = OfflineSync.getCredentials('offline');
        if (offUrlInput && !offUrlInput.value.trim()) offUrlInput.value = offCreds.url;
        if (offKeyInput && !offKeyInput.value.trim()) offKeyInput.value = offCreds.key;
        this.renderConnModeUI();
        this.refreshConnPendingBadge();
      }
    } catch (err) {
      console.error('App init error:', err);
      this.notify('Problem loading the app: ' + err.message, 'error');
    } finally {
      clearTimeout(loaderSafetyTimer);
      this.showLoader(false);
    }
  },

  showLoader(show) {
    const el = document.getElementById('app-loader');
    if (el) el.classList.toggle('show', show);
  },

  // Runs when the login page's "Reset Cache" link is clicked -- completely clears any
  // old/stale credentials sitting in localStorage and reloads the page, so completely fresh
  // data loads from Google Sheets
  // Clicking the eye icon next to the login form's password field toggles showing/hiding the password as text
  togglePasswordVisibility() {
    const input = document.getElementById('login-pass');
    const icon = document.getElementById('login-pass-toggle-icon');
    if (!input || !icon) return;
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    icon.className = isHidden ? 'bi bi-eye-slash-fill' : 'bi bi-eye-fill';
  },

  resetLoginCache() {
    try {
      localStorage.removeItem('gp_settings');
    } catch (e) { /* the reload still proceeds even without localStorage access */ }
    alert('Cache has been reset. The page will reload now and load the latest data from Google Sheets.');
    location.reload();
  },

  // ⚠️ Theme system redesign: selecting any one of four complete, self-contained themes
  // applies it across the whole software immediately and is saved per-user (in localStorage +
  // Supabase, see savePersonalThemePrefs()) -- so on the next login you'll see your own theme
  // again, unaffected by anyone else's theme change.
  setAppTheme(name) {
    this.applyAppTheme(name);
    this.savePersonalThemePrefs({ appTheme: name });
    this.notify('Theme changed');
  },

  applyAppTheme(name) {
    // ⚠️ Round 14: Clean Light/Enterprise Blue/Warm Earthy were removed. If a user's profile
    // has one of these old names already saved, it is reverted to Classic Glass here, so an
    // unmatched data-app-theme value never leaves things themeless/inconsistent.
    const REMOVED_THEMES = ['clean-light', 'enterprise-blue', 'warm-earthy', 'pine-sidebar', 'aurora-sidebar'];
    if (REMOVED_THEMES.includes(name)) name = 'classic';
    const t = (!name || name === 'classic') ? '' : name;
    if (t) document.body.setAttribute('data-app-theme', t);
    else document.body.removeAttribute('data-app-theme');
    document.querySelectorAll('.apptheme-option').forEach(el => {
      el.classList.toggle('active', el.dataset.apptheme === (name || 'classic'));
    });
    // The Dashboard chart's axis/legend/grid colours need to differ on a light-background theme (see charts())
    if (this.chartInstances && (this.chartInstances.attendance || this.chartInstances.pie)) {
      this.charts(true);
    }
  },

  // ⚠️ Feature (re-added at the user's request): Accent Colour -- a completely separate,
  // independent axis from App Theme. App Theme fixes the background/card/text colours
  // (Classic Glass/Aqua Dash -- Clean Light/Enterprise Blue/Warm Earthy removed in Round 14),
  // while Accent Colour only changes --accent/--accent-2 (buttons, active nav, chart
  // highlights, etc.) -- any Accent Colour can be mixed with any App Theme, because Accent
  // Colour never touches background/text colour (so there is no risk of the old contrast bug
  // returning). Default is 'ocean'.
  setTheme(name) {
    this.applyTheme(name);
    this.savePersonalThemePrefs({ theme: name });
    this.notify('Accent color changed');
  },

  applyTheme(name) {
    const theme = (!name || name === 'ocean') ? '' : name;
    if (theme) document.body.setAttribute('data-theme', theme);
    else document.body.removeAttribute('data-theme');
    document.querySelectorAll('.theme-option').forEach(el => {
      el.classList.toggle('active', el.dataset.theme === (name || 'ocean'));
    });
  },

  // Both App Theme and Accent Colour are saved per-user through this one function:
  // - for Super Admin, into settings.superAdminAppTheme/superAdminTheme (in the settings
  //   key/value table, no new column needed)
  // - for a regular user, into their own state.users record's appTheme/theme columns (both
  //   already exist)
  // This way, whenever a user logs in, only their own saved theme+accent combination loads
  // (see doLogin()). (The old stylePack column stays in the database but is no longer used --
  // Style Pack is now permanently just Classic Glass; not dropped deliberately, to avoid a
  // destructive migration.)
  async savePersonalThemePrefs(patch) {
    if (this.role === 'superadmin') {
      if (patch.appTheme !== undefined) this.settings.superAdminAppTheme = patch.appTheme;
      if (patch.theme !== undefined) this.settings.superAdminTheme = patch.theme;
      this.saveLocalSettings();
      if (SheetsDB.isConfigured()) {
        try {
          await SheetsDB.saveSettings({
            superAdminAppTheme: this.settings.superAdminAppTheme || 'classic',
            superAdminTheme: this.settings.superAdminTheme || 'ocean'
          });
        } catch (e) { /* will retry saving once the connection returns */ }
      }
      return;
    }
    const user = this.state.users.find(u => u.username === this.currentUsername);
    if (!user) return; // safety: if the user isn't found for any reason, stop quietly instead of crashing
    if (patch.appTheme !== undefined) user.appTheme = patch.appTheme;
    if (patch.theme !== undefined) user.theme = patch.theme;
    // ⚠️ Bug fix: this used to call persistSheet('users'), which upserted this.state.users'
    // *entire* array (every user's row) at once. But the "users" table's RLS policy only lets
    // a non-admin user write to *their own* row (matched via auth.uid()) -- so as soon as the
    // batch contained anyone else's row, the whole upsert failed with a "row-level security
    // policy violated" error, even though this user was really only changing their own theme.
    // Now only this one row (their own) is upserted.
    if (SheetsDB.isConfigured()) {
      try {
        await SheetsDB.upsert('users', user);
        this.dbConnected = true;
        this.updateSyncStatus();
      } catch (e) {
        this.dbConnected = false;
        this.updateSyncStatus();
        this.notify('Failed to save theme (kept locally, not saved to the cloud): ' + e.message, 'error');
      }
    }
  },

  loadLocalSettings() {
    try {
      const saved = localStorage.getItem('gp_settings');
      if (saved) Object.assign(this.settings, JSON.parse(saved));
    } catch (e) { /* if localStorage data is corrupt, the default settings are used quietly */ }
  },

  saveLocalSettings() {
    try { localStorage.setItem('gp_settings', JSON.stringify(this.settings)); } catch (e) { /* fine if storage is full, Sheets sync will still work if configured */ }
  },

  // Converts a password into a SHA-256 hash -- so an irreversible hash is stored in Google
  // Sheets or localStorage instead of the plaintext password. If the Web Crypto API isn't
  // available (very rare/old browsers) the plaintext is returned directly, so functionality
  // doesn't break.
  async sha256Hex(text) {
    if (!window.crypto || !window.crypto.subtle) return text; // fallback: when hashing isn't supported
    const buf = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return 'sha256:' + Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  },

  // The small topbar badge and the dashboard's compact pill (pulse-dot + one word) are both
  // updated together from here. The detailed message (when it was last checked, etc.) shows as
  // a tooltip on hovering the pill (title attribute) -- takes up little space in the main UI.
  updateSyncStatus() {
    const badge = document.getElementById('sync-status');
    const pill = document.getElementById('dash-db-status-strip');
    const pillText = document.getElementById('dash-db-status-text');
    const checkedAt = new Date().toLocaleTimeString('en-US', { timeZone: APP_TIMEZONE, hour12: true, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    // রাউন্ড ২২: Online/Offline Mode UI-তে প্রতিফলিত করার জন্য — badge/pill-এ এখন কোন মোডে (☁️/💻)
    // চলছে সেটাও দেখানো হয়, শুধু কানেক্টেড/ডিসকানেক্টেড না
    const modeIcon = (window.OfflineSync && OfflineSync.isOfflineMode()) ? '💻' : '☁️';

    if (!SheetsDB.isConfigured()) {
      if (badge) { badge.className = 'sync-badge offline'; badge.innerHTML = '<i class="bi bi-cloud-slash"></i> Offline (local)'; }
      if (pill) { pill.className = 'db-status-pill offline'; pill.title = 'Supabase কনফিগার করা নেই — অফলাইন/লোকাল মোডে চলছে'; }
      if (pillText) pillText.innerText = 'Offline';
      if (window.OfflineSync) this.renderConnModeUI();
      return;
    }
    if (badge) {
      badge.className = this.dbConnected ? 'sync-badge online' : 'sync-badge offline';
      badge.innerHTML = this.dbConnected ? `<i class="bi bi-cloud-check"></i> ${modeIcon} DB synced` : `<i class="bi bi-cloud-slash"></i> ${modeIcon} DB offline`;
    }
    if (pill) {
      pill.className = this.dbConnected ? 'db-status-pill online' : 'db-status-pill offline';
      pill.title = (this.dbConnected
        ? `${modeIcon} Database is connected -- ` + (modeIcon === '💻' ? 'real-time sync with Offline/Self-hosted Supabase' : 'real-time sync with Online Supabase') + ' is running'
        : 'Cannot reach the database -- working with local data') + ' | last checked: ' + checkedAt;
    }
    if (pillText) pillText.innerText = this.dbConnected ? 'Live' : 'Offline';
    if (window.OfflineSync) this.renderConnModeUI();
  },

  // ---------------------------------------------------------------------------
  // Round 22 -- Online ☁️ / Offline 💻 Mode: the Settings page's toggle/status UI and actions
  // ---------------------------------------------------------------------------
  async renderConnModeUI() {
    if (!window.OfflineSync) return;
    const mode = OfflineSync.getMode();
    const toggle = document.getElementById('conn-mode-toggle');
    const label = document.getElementById('conn-mode-label');
    const sub = document.getElementById('conn-mode-sub');
    const lastSyncEl = document.getElementById('conn-last-sync');
    if (toggle) toggle.setAttribute('data-mode', mode);
    if (label) label.innerText = mode === 'offline' ? '💻 Offline (Self-Hosted Supabase)' : '☁️ Online (Cloud Supabase)';
    if (sub) {
      sub.innerText = mode === 'offline'
        ? (this.dbConnected ? 'Currently connected to the Offline/Self-Hosted database' : 'Trying to connect to the Offline database / failed')
        : (this.dbConnected ? 'Currently connected to the cloud database' : 'Trying to connect to the cloud database / failed');
    }
    if (lastSyncEl) {
      const last = await OfflineSync.getLastSync();
      lastSyncEl.innerText = last ? formatDateTime(last) : '—';
    }
    this.refreshConnPendingBadge();
  },

  async refreshConnPendingBadge() {
    if (!window.OfflineSync) return;
    const pill = document.getElementById('conn-pending-pill');
    const text = document.getElementById('conn-pending-text');
    if (!pill || !text) return;
    const count = await OfflineSync.getPendingCount();
    if (count > 0) {
      pill.style.display = 'inline-flex';
      pill.classList.add('conn-pending-pulse');
      text.innerText = `${count} change(s) awaiting sync`;
    } else {
      pill.style.display = 'none';
      pill.classList.remove('conn-pending-pulse');
    }
  },

  // Runs when Settings > Online/Offline toggle is clicked. Changing mode means switching to a
  // different Supabase project (needs a separate Auth session), so it's confirmed explicitly
  // and the user is told a fresh login is needed after switching.
  async toggleConnectionMode() {
    if (!window.OfflineSync) return;
    const current = OfflineSync.getMode();
    const next = current === 'online' ? 'offline' : 'online';
    if (next === 'offline') {
      const creds = OfflineSync.getCredentials('offline');
      if (!creds.url || !creds.key) {
        this.notify('First save an Offline/Self-Hosted Supabase URL and Key below', 'warn');
        return;
      }
    }
    if (!confirm(`Switch to ${next === 'offline' ? '💻 Offline (Self-Hosted)' : '☁️ Online (Cloud)'} mode? This is a different database -- you will need to log in again after switching. Make sure your current work is already safely saved/synced.`)) return;
    OfflineSync.applyMode(next);
    this.notify(`Switched to ${next === 'offline' ? 'Offline' : 'Online'} mode -- please log in again`, 'warn');
    this.renderConnModeUI();
    setTimeout(() => location.reload(), 1200);
  },

  async saveOfflineSupabaseConfig() {
    if (!window.OfflineSync) return;
    const url = (document.getElementById('set-supabase-url-offline') || {}).value?.trim() || '';
    const key = (document.getElementById('set-supabase-key-offline') || {}).value?.trim() || '';
    OfflineSync.saveOfflineCredentials(url, key);
    this.notify('Offline Supabase configuration saved');
  },

  async testOfflineConnection() {
    if (!window.OfflineSync || !window.supabase) return;
    const url = (document.getElementById('set-supabase-url-offline') || {}).value?.trim() || '';
    const key = (document.getElementById('set-supabase-key-offline') || {}).value?.trim() || '';
    if (!url || !key) { this.notify('Enter the Offline Supabase URL and Key', 'warn'); return; }
    this.showLoader(true);
    try {
      const testClient = window.supabase.createClient(url, key, { auth: { persistSession: false } });
      const { error } = await testClient.from('settings').select('key').limit(1);
      if (error) throw new Error(error.message);
      OfflineSync.saveOfflineCredentials(url, key);
      this.notify('✅ Connected to Offline/Self-Hosted Supabase successfully');
    } catch (e) {
      this.notify('❌ Offline connection failed: ' + e.message, 'error');
    }
    this.showLoader(false);
  },

  // Called from both the "Sync Now" button and the browser's online event (when silent=true,
  // no success/failure toast is shown at all, it just tries in the background -- used for auto-retry)
  async manualSyncNow(silent) {
    if (!window.OfflineSync) return;
    if (!silent) this.showLoader(true);
    try {
      const res = await OfflineSync.syncNow(this);
      if (!silent) {
        if (!res.ok) {
          this.notify('Could not Sync -- Supabase is not configured', 'warn');
        } else {
          const parts = [];
          if (res.flushed.length) parts.push(`${res.flushed.length} table(s) sent`);
          if (res.deleted.length) parts.push(`${res.deleted.length} delete(s) sent`);
          if (res.reconciled.length) parts.push(`${res.reconciled.length} reconciled`);
          if (res.conflicts.length) parts.push(`⚠️ ${res.conflicts.length} conflict(s) resolved (the newer one was kept)`);
          this.notify(parts.length ? 'Sync complete: ' + parts.join(', ') : 'Everything was already in sync');
        }
      }
      await this.ensureDbConnection();
      this.renderConnModeUI();
    } catch (e) {
      if (!silent) this.notify('Sync failed: ' + e.message, 'error');
    }
    if (!silent) this.showLoader(false);
  },

  async loadFromDatabase() {
    if (!SheetsDB.isConfigured()) {
      this.dbConnected = false;
      return;
    }
    try {
      const data = await SheetsDB.loadAll();
      Object.keys(this.state).forEach(key => {
        if (Array.isArray(data[key])) this.state[key] = data[key];
      });
      // ⚠️ Important: a soft-deleted record (with deletedAt set) should never show up directly
      // in this.state[table] (i.e. the normal list/dashboard/dropdowns). So right after
      // loading, these are separated out into this.trashItems, so the rest of the app keeps
      // working normally as before (knowing nothing about deletedAt) -- much lower risk this way.
      this.trashItems = [];
      SOFT_DELETE_TABLES.forEach(table => {
        if (!Array.isArray(this.state[table])) return;
        const active = [], deleted = [];
        this.state[table].forEach(row => {
          if (row.deletedAt) deleted.push(row); else active.push(row);
        });
        this.state[table] = active;
        deleted.forEach(row => this.trashItems.push({ module: table, record: row, deletedAt: row.deletedAt, deletedBy: row.deletedBy || '' }));
      });
      this.purgeOldTrash();
      this.masterData.orders = {};
      if (Array.isArray(data.orders)) {
        data.orders.forEach(o => { if (o.orderNo) this.masterData.orders[o.orderNo] = o; });
      }
      // ⚠️ Data hygiene (legacy fix): an older installation's masterData.orders can be left
      // with entries whose original piList/supplierOrders record has already gone to the
      // Recycle Bin (deleting used to not clean up this shadow entry -- this was the cause of
      // the "still shows in the Order No dropdown after deleting" bug). These inconsistent
      // entries are pruned automatically every time data loads from the database, so an
      // already-deleted PI/Supplier Order never shows in the Order No dropdown again -- for a
      // newly-deleted record, confirmDelete() cleans this up immediately (see
      // removeOrderShadowEntry), this block is only for old/leftover data.
      this.dbConnected = true;
      const activePiNos = new Set(this.state.piList.map(p => p.piNo));
      const activeOrderNos = new Set(this.state.supplierOrders.map(o => o.orderNo));
      let ordersCleaned = false;
      Object.keys(this.masterData.orders).forEach(key => {
        const o = this.masterData.orders[key];
        if (o.type === 'PI' && !activePiNos.has(key)) { delete this.masterData.orders[key]; ordersCleaned = true; }
        else if (o.type === 'SO' && !activeOrderNos.has(key)) { delete this.masterData.orders[key]; ordersCleaned = true; }
      });
      // ⚠️ Data hygiene (bug fix backfill): BUYER used to always save as empty ('') when
      // saving a Supplier Order (a bug in saveSupplierOrder(), now fixed), so the BUYER field
      // in the Add Received Goods modal never auto-filled. New saves now work correctly, but
      // old, already-saved Supplier Orders' shadow entries still have an empty buyer -- so
      // every time data loads from the database, the Buyer name is looked up from piList via
      // piNo and filled in automatically (once only, then saved via persistOrders()).
      Object.keys(this.masterData.orders).forEach(key => {
        const o = this.masterData.orders[key];
        if (o.type === 'SO' && !o.buyer && o.pi) {
          const linkedPI = this.state.piList.find(p => p.piNo === o.pi);
          if (linkedPI && linkedPI.buyer) { o.buyer = linkedPI.buyer; ordersCleaned = true; }
        }
      });
      if (ordersCleaned) this.persistOrders();
      if (Array.isArray(data.settings) && data.settings.length) {
        data.settings.forEach(row => {
          if (row.key && row.value !== undefined) this.settings[row.key] = String(row.value);
        });
        this.saveLocalSettings();
        this.syncSettingsToInputs(true);
        this.loadZKTecoSettings();
      }
      // ⚠️ Round 22: if this browser already has any table marked "dirty" (not yet sent to
      // the server) -- the freshly-loaded (still-stale) copy from the server is replaced with
      // the IndexedDB-mirrored local version, so a page refresh/re-login never loses a pending
      // edit made offline. A sync is then attempted quietly once in the background.
      if (window.OfflineSync) {
        const restored = await OfflineSync.overlayDirtyOntoState(this);
        if (restored > 0) this.manualSyncNow(true);
      }
      this.notify('Data loaded from Supabase');
    } catch (e) {
      this.dbConnected = false;
      this.notify('Using local data — ' + e.message, 'warn');
    }
  },

  // Freshly verifies right before login whether the database connection is really alive --
  // internet/network conditions can change since the page loaded, so instead of just trusting
  // the old this.dbConnected value, a light "ping" is done at every login to confirm. Returns
  // { ok, reason } -- reason 'not-configured' means the Supabase URL/Key isn't set at all,
  // 'unreachable' means it is set but cannot be connected to (internet/server problem).
  async ensureDbConnection() {
    if (!SheetsDB.isConfigured()) {
      this.dbConnected = false;
      this.updateSyncStatus();
      return { ok: false, reason: 'not-configured' };
    }
    try {
      await SheetsDB.ping();
      this.dbConnected = true;
      this.updateSyncStatus();
      return { ok: true };
    } catch (e) {
      this.dbConnected = false;
      this.updateSyncStatus();
      return { ok: false, reason: 'unreachable', error: e.message };
    }
  },

  async persistSheet(sheetName) {
    if (!SheetsDB.isConfigured()) return;
    try {
      // ⚠️ রাউন্ড ১৩ ক্রিটিক্যাল ফিক্স: আগে এখানে SheetsDB.saveSheet() (পুরো টেবিল ডিফ-সিঙ্ক —
      // DB-তে থাকা কিন্তু this.state[sheetName]-এ নেই এমন রো ডিলিট করে দিত) ব্যবহার হতো। এটা
      // মাল্টি-ইউজার ডেটা-লস তৈরি করছিল: অন্য কোনো ইউজার নতুন রেকর্ড যোগ করার পর এই ব্রাউজার
      // রিফ্রেশ না করেই এই টেবিলে যেকোনো একটা এডিট সেভ করলে, সেই নতুন রেকর্ডটা "মিসিং" ধরে DB
      // থেকে স্থায়ীভাবে মুছে যেত — কোনো এরর ছাড়াই। এখন শুধু upsertRows() (কখনো ডিলিট করে না)
      // ব্যবহার করা হচ্ছে। এর ফলে soft-deleted ট্র্যাশ আইটেম এখানে সাময়িকভাবে ফিরিয়ে আনার আগের
      // workaround-টাও আর দরকার নেই (সেটা শুধু ভুলবশত ডিলিট-ডিফ এড়াতে করা হতো) — ট্র্যাশে থাকা
      // রেকর্ড DB-তে অস্পৃষ্ট থেকে যাবে, কারণ upsertRows() শুধু যা পাঠানো হয় তা-ই লেখে, বাকি কিছু
      // ছোঁয় না। প্রকৃত ডিলিট (soft বা hard) আগের মতোই সবসময় আলাদাভাবে deleteRow()/upsert()-এর
      // মাধ্যমে নির্দিষ্টভাবে হয় (দেখুন confirmDelete, updateDeliveryPlanStatus)।
      await SheetsDB.upsertRows(sheetName, this.state[sheetName]);
      this.dbConnected = true;
      this.updateSyncStatus();
    } catch (e) {
      // সেভ ব্যর্থ হলে সিঙ্ক ব্যাজেও তা প্রতিফলিত করা হচ্ছে, যাতে ইউজার বুঝতে পারেন এই পরিবর্তনটি
      // আসলে ক্লাউডে সংরক্ষিত হয়নি (আগে এখানে dbConnected আপডেট না হওয়ায় ব্যাজ ভুলভাবে "synced" দেখাত)
      this.dbConnected = false;
      this.updateSyncStatus();
      this.notify('Save failed (data kept locally, not saved to the cloud): ' + e.message, 'error');
    }
  },

  async persistOrders() {
    if (!SheetsDB.isConfigured() || !this.dbConnected) return;
    const rows = Object.keys(this.masterData.orders).map(k => ({ orderNo: k, ...this.masterData.orders[k] }));
    try {
      await SheetsDB.saveSheet('orders', rows);
    } catch (e) {
      this.notify('Orders save failed', 'error');
    }
  },

  // Core bug fix: saving a PI or Supplier Order used to never add it to masterData.orders,
  // so the Order No dropdown in "Add Received Goods", "Log Delivery", etc. always stayed
  // empty. This function creates an "order" entry as soon as a PI/Supplier Order is saved,
  // and immediately refreshes every dropdown everywhere.
  async registerOrder(orderNo, data) {
    if (!orderNo) return;
    this.masterData.orders[orderNo] = { orderNo, ...data };
    await this.persistOrders();
    this.populateOrderDropdown();
  },

  async testConnection() {
    const url = document.getElementById('set-supabase-url').value.trim();
    const key = document.getElementById('set-supabase-key').value.trim();
    // ⚠️ Round 13 fix: the client is not recreated unless the URL/Key genuinely changed
    // (otherwise the login session would be lost -- see the same fix's comment in
    // saveSettings()). If it genuinely changed, the client becomes new and loadFromDatabase()
    // shows empty data because of RLS (expected -- there's no session yet on the new project)
    // -- the user is told this explicitly in that case.
    const credentialsChanged = (url !== SheetsDB.url || key !== SheetsDB.anonKey);
    if (credentialsChanged) SheetsDB.setCredentials(url, key);
    this.showLoader(true);
    try {
      await SheetsDB.ping();
      await this.loadFromDatabase();
      this.renderAllTables();
      this.populateOrderDropdown();
      if (credentialsChanged) {
        this.notify('Connected to a new Supabase project -- log in again to view/save data', 'warn');
      } else {
        this.notify('Connected to Supabase successfully');
      }
    } catch (e) {
      this.dbConnected = false;
      this.notify('Connection failed: ' + e.message, 'error');
    }
    this.updateSyncStatus();
    this.showLoader(false);
  },

  renderAllTables() {
    ['renderPITable','renderMasterTable','renderReceivedGoodsTable','renderDeliveryPlan',
     'renderDeliveryHist','renderQCList','renderAccBuyer','renderAccSupplier','renderExpenseList',
     'renderHREmployees','renderHRAttendance','renderHRSalary','renderHRLeaves','renderUsers','renderBuyers','renderSuppliers',
     'renderSupplierOrderHistory','renderTrash','renderAuditLog','renderHRSettingsEmployees','renderHRSignaturesList',
     'renderHRDepartments','renderCompleteOrderList'
    ].forEach(fn => this[fn]());
    this.populateMerchandiserSignatureDropdowns();
    this.updateDashboard();
  },

  // ⚠️ Feature (A1): instead of a PI's "QC Status: Hold" (which was always static), this now
  // computes a genuine multi-stage Status -- cross-referencing supplierOrders, receivedGoods,
  // qcList and deliveryHist via piNo/orderNo to work out which stage of the process the PI is
  // actually at:
  // Order Pending → Order Placed → Received: Partial/Full → QC: Fail/Pending → Ready for Delivery
  // → Delivery: Partial → Delivery Complete
  computePIStatus(pi) {
    const orders = this.state.supplierOrders.filter(o => o.piNo === pi.piNo);
    if (!orders.length) return { label: 'Order Pending', cls: 'y' };
    const orderNos = orders.map(o => o.orderNo);

    const received = this.state.receivedGoods.filter(r => orderNos.includes(r.orderNo));
    if (!received.length) return { label: 'Order Placed', cls: 'b' };
    // ⚠️ Bug fix (A1 -- Partial Shipment double-counting): autofillReceivedGoods() saves each
    // Received Goods entry with the linked Supplier Order's full Order Qty auto-filled. So
    // when the same orderNo had multiple partial-shipment entries, summing r.orderQty used to
    // multiply Order Qty by the number of entries, leaving the status stuck at "Received:
    // Partial" forever. Now each orderNo's real Order Qty is counted only once -- first from
    // masterData.orders (the real source for a Supplier Order, the sum of items' qty), falling
    // back to max(orderQty) among that orderNo's entries if not found there. Received Qty is
    // correctly the sum of every entry (each entry is the real quantity actually received for
    // a separate challan, so summing is correct).
    const totalOrderQty = orderNos.reduce((sum, no) => {
      const fromMaster = Number(this.masterData.orders[no]?.qty || 0);
      if (fromMaster > 0) return sum + fromMaster;
      const entriesForOrder = received.filter(r => r.orderNo === no);
      const maxEntryQty = entriesForOrder.reduce((m, r) => Math.max(m, Number(r.orderQty || 0)), 0);
      return sum + maxEntryQty;
    }, 0);
    const totalReceivedQty = received.reduce((s, r) => s + Number(r.receivedQty || 0), 0);
    if (!(totalOrderQty > 0 && totalReceivedQty >= totalOrderQty)) return { label: 'Received: Partial', cls: 'y' };

    const qc = this.state.qcList.filter(q => orderNos.includes(q.orderNo));
    if (!qc.length) return { label: 'Received: Full (QC Pending)', cls: 'b' };
    if (qc.some(q => (q.result || '').toLowerCase() === 'fail')) return { label: 'QC: Fail', cls: 'r' };
    if (!qc.every(q => (q.result || '').toLowerCase() === 'pass')) return { label: 'QC: Pending', cls: 'y' };

    const delivered = this.state.deliveryHist.filter(d => orderNos.includes(d.orderNo));
    const deliveredQty = delivered.reduce((s, d) => s + Number(d.qty || 0), 0);
    if (deliveredQty <= 0) return { label: 'Ready for Delivery', cls: 'b' };
    if (deliveredQty >= totalReceivedQty) return { label: 'Delivery Complete', cls: 'g' };
    return { label: 'Delivery: Partial', cls: 'y' };
  },

  renderPITable() {
    const tbody = document.getElementById('inv-list-tbody');
    if (!tbody) return;
    // ⚠️ Bug fix: this datalist refresh used to happen only after the if-block below, so when
    // piList became empty (every PI deleted), an old/deleted PI No stayed suggested in the
    // datalist. It now always refreshes first (whether empty or not).
    const piDatalist = document.getElementById('so-pi-no-list');
    if (piDatalist) piDatalist.innerHTML = this.state.piList.map(p => `<option value="${this.escapeHtml(p.piNo)}">`).join('');
    // ⚠️ Feature: an archived PI (see Data Safety > Complete Order List) is hidden from this
    // regular list -- the data is not deleted, only filtered. It is still fully visible in the
    // Complete Order List.
    const activeRows = this.state.piList.filter(p => !p.archived);
    if (!activeRows.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:24px">No proforma invoices yet. Click Create New PI to add one.</td></tr>';
      return;
    }
    tbody.innerHTML = activeRows.map(row => {
      const st = this.computePIStatus(row);
      return `
      <tr><td>${formatDate(row.date)}</td><td class="f-mono f-accent">${this.escapeHtml(row.piNo)}</td><td>${this.escapeHtml(row.buyer)}</td><td>${this.escapeHtml(row.supplier)}</td>
      <td>${this.escapeHtml(row.items)}</td><td>${this.escapeHtml(row.totalValue)}</td>
      <td><span class="badge badge-${st.cls}">${st.label}</span></td>
      <td><button class="action-btn action-view" onclick="app.viewPI(${row.id})"><i class="bi bi-eye"></i> View</button>
      <button class="action-btn action-edit inventory-write" onclick="app.editPI(${row.id})"><i class="bi bi-pencil"></i> Edit</button>
      <button class="action-btn action-delete inventory-delete" onclick="app.confirmDelete('piList', ${row.id})"><i class="bi bi-trash"></i> Remove</button></td></tr>`;
    }).join('');
  },

  renderMasterTable() {
    const tbody = document.getElementById('inv-master-tbody');
    if (!tbody) return;
    // ⚠️ Bug fix: the datalist refresh used to happen after the if-block, so when masterData
    // became empty (every item deleted), old/deleted codes stayed suggested in the Item Code
    // datalist.
    this.populateItemCodeDatalist();
    if (!this.state.masterData.length) {
      tbody.innerHTML = '<tr><td colspan="13" style="text-align:center;color:var(--text-muted);padding:24px">No items yet. Click Add Item to create one.</td></tr>';
      return;
    }
    tbody.innerHTML = this.state.masterData.map(row => `
      <tr><td>${row.image && String(row.image).startsWith('data:image/') ? `<img src="${this.escapeHtml(row.image)}" alt="${this.escapeHtml(row.itemCode)}" style="width:36px;height:36px;object-fit:cover;border-radius:6px;border:1px solid var(--border)">` : `<span style="color:var(--text-dim)"><i class="bi bi-image"></i></span>`}</td>
      <td class="f-mono f-accent">${this.escapeHtml(row.itemCode)}</td><td>${this.escapeHtml(row.description)}</td><td>${this.escapeHtml(row.styleNo || '')}</td><td>${this.escapeHtml(row.brand || '')}</td>
      <td>${this.escapeHtml(row.hsCode || '')}</td><td>${this.escapeHtml(row.dept || '')}</td>
      <td>${row.sellingPrice ?? row.unitPrice ?? ''}</td><td>${row.buyingPrice ?? row.unitPrice ?? ''}</td>
      <td>${this.escapeHtml(row.size)}</td><td>${this.escapeHtml(row.unit)}</td><td><span class="badge badge-g">${this.escapeHtml(row.stock)}</span></td>
      <td><button class="action-btn action-edit inventory-write" onclick="app.editMasterItem(${row.id})"><i class="bi bi-pencil"></i> Edit</button>
      <button class="action-btn action-delete inventory-delete" onclick="app.confirmDelete('masterData', ${row.id})"><i class="bi bi-trash"></i> Delete</button></td></tr>`).join('');
  },

  // Populates a datalist with every Item Code from Master Data -- for showing auto-suggest while typing in the PI and QC forms
  populateItemCodeDatalist() {
    const dl = document.getElementById('pi-item-codes-list');
    if (!dl) return;
    dl.innerHTML = this.state.masterData.map(r => `<option value="${this.escapeHtml(r.itemCode)}">${this.escapeHtml(r.description)}</option>`).join('');
  },

  async handleItemImageUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { this.notify('Please upload an image file only', 'warn'); return; }
    try {
      const dataUrl = await this.resizeImageToDataURL(file, 200, 200, 0.7);
      document.getElementById('item-image-data').value = dataUrl;
      document.getElementById('item-image-preview-box').innerHTML = `<img src="${dataUrl}" alt="Preview">`;
    } catch (e) {
      this.notify('Problem processing the image', 'error');
    }
  },

  openAddItemModal() {
    document.getElementById('add-item-modal-title').innerText = 'Add New Item';
    document.getElementById('item-save-btn-text').innerText = 'Save';
    document.getElementById('item-edit-id').value = '';
    document.getElementById('item-image-data').value = '';
    document.getElementById('item-image-preview-box').innerHTML = '<i class="bi bi-image placeholder-icon"></i>';
    ['item-code','item-desc','item-size','item-stock','item-style-no','item-brand','item-hs-code','item-dept'].forEach(id => { document.getElementById(id).value = ''; });
    document.getElementById('item-selling-price').value = '';
    document.getElementById('item-buying-price').value = '';
    document.getElementById('item-unit').value = 'PCS';
    this.open('add-item-modal');
  },

  // For compatibility with old data, saveMasterItem() automatically sets unitPrice from sellingPrice/buyingPrice

  editMasterItem(id) {
    const item = this.state.masterData.find(r => r.id === id);
    if (!item) return;
    document.getElementById('add-item-modal-title').innerText = 'Edit Item';
    document.getElementById('item-save-btn-text').innerText = 'Update';
    document.getElementById('item-edit-id').value = id;
    document.getElementById('item-code').value = item.itemCode;
    document.getElementById('item-desc').value = item.description;
    document.getElementById('item-style-no').value = item.styleNo || '';
    document.getElementById('item-brand').value = item.brand || '';
    document.getElementById('item-hs-code').value = item.hsCode || '';
    document.getElementById('item-dept').value = item.dept || '';
    document.getElementById('item-selling-price').value = item.sellingPrice ?? item.unitPrice ?? '';
    document.getElementById('item-buying-price').value = item.buyingPrice ?? item.unitPrice ?? '';
    document.getElementById('item-size').value = item.size;
    document.getElementById('item-unit').value = item.unit;
    document.getElementById('item-stock').value = String(item.stock).replace(/,/g, '');
    document.getElementById('item-image-data').value = item.image || '';
    document.getElementById('item-image-preview-box').innerHTML = item.image ? `<img src="${this.escapeHtml(this.safeImageSrc(item.image))}" alt="Preview">` : '<i class="bi bi-image placeholder-icon"></i>';
    this.open('add-item-modal');
  },

  async saveMasterItem() {
    const editId = document.getElementById('item-edit-id').value;
    const sellingPrice = parseFloat(document.getElementById('item-selling-price').value) || 0;
    const buyingPrice = parseFloat(document.getElementById('item-buying-price').value) || 0;
    const record = {
      itemCode: document.getElementById('item-code').value.trim(),
      description: document.getElementById('item-desc').value.trim(),
      styleNo: document.getElementById('item-style-no').value.trim(),
      brand: document.getElementById('item-brand').value.trim(),
      hsCode: document.getElementById('item-hs-code').value.trim(),
      dept: document.getElementById('item-dept').value.trim(),
      sellingPrice, buyingPrice,
      unitPrice: sellingPrice || buyingPrice, // legacy field, kept in sync for any old code paths
      size: document.getElementById('item-size').value.trim(),
      unit: document.getElementById('item-unit').value,
      stock: String(parseInt(document.getElementById('item-stock').value) || 0),
      image: document.getElementById('item-image-data').value || ''
    };
    if (!record.itemCode || !record.description) { this.notify('Item Code and Description are required', 'warn'); return; }

    let recordId;
    if (editId) {
      const idx = this.state.masterData.findIndex(r => r.id == editId);
      if (idx !== -1) this.state.masterData[idx] = { id: parseInt(editId), ...record };
      recordId = editId;
      this.notify('Item Updated');
    } else {
      const newId = await this.allocId('masterData');
      this.state.masterData.push({ id: newId, ...record });
      recordId = newId;
      this.notify('Item Added');
    }
    this.logAudit(editId ? 'Update' : 'Create', 'masterData', recordId, record.itemCode);
    await this.persistSheet('masterData');
    this.close('add-item-modal');
    this.renderMasterTable();
    this.updateDashboard();
  },

  renderReceivedGoodsTable() {
    const tbody = document.getElementById('received-goods-tbody');
    if (!tbody) return;
    // ⚠️ Feature: an archived PI's Received Goods entries are hidden from this regular list
    // (fully visible in Data Safety > Complete Order List) -- the data is not deleted, only
    // filtered.
    tbody.innerHTML = this.state.receivedGoods.filter(row => !this.isArchivedByOrderNo(row.orderNo)).map(row => {
      const dueClass = row.dueQty > 0 ? 'rg-due-negative' : 'rg-due-positive';
      return `<tr class="${row.dueQty > 0 ? 'rg-highlight' : ''}">
        <td>${formatDate(row.date)}</td><td class="f-mono f-accent">${this.escapeHtml(row.orderNo)}</td><td>${this.escapeHtml(row.buyer)}</td><td>${this.escapeHtml(row.itemName)}</td>
        <td>${this.esc(row.styleNo)}</td><td>${Number(row.orderQty).toLocaleString()}</td><td>${Number(row.receivedQty).toLocaleString()}</td>
        <td>${this.esc(row.cnNo)}</td><td class="${dueClass}">${Number(row.dueQty).toLocaleString()}</td>
        <td><button class="action-btn action-view" onclick="app.viewReceivedGoods(${row.id})"><i class="bi bi-eye"></i> View</button>
        <button class="action-btn action-edit inventory-write" onclick="app.editReceivedGoods(${row.id})"><i class="bi bi-pencil"></i> Edit</button>
        <button class="action-btn action-delete inventory-delete" onclick="app.confirmDelete('receivedGoods', ${row.id})"><i class="bi bi-trash"></i> Delete</button></td></tr>`;
    }).join('');
    this.updateReceivedGoodsStats();
    // ⚠️ Bug fix: the QC form's Challan No datalist used to not refresh after
    // receivedGoods was deleted/added (only called from certain specific places) -- so a
    // deleted challan number stayed suggested too.
    this.populateQCChallanList();
  },

  updateReceivedGoodsStats() {
    const normalizeDate = dateStr => {
      if (!dateStr) return '';
      if (dateStr.includes('/')) {
        const [day, month, year] = dateStr.split('/');
        return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
      }
      return dateStr;
    };
    const total = this.state.receivedGoods.length;
    const today = todayStr();
    const todayReceived = this.state.receivedGoods.filter(r => normalizeDate(r.date) === today).reduce((s, r) => s + Number(r.receivedQty), 0);
    // ⚠️ Bug fix (A1 -- Partial Shipment double-counting): each Received Goods entry's
    // dueQty used to be summed directly. But each entry's dueQty = (the auto-filled full Order
    // Qty) − (that entry's Received Qty), so multiple partial entries for the same orderNo made
    // the sum show several times the real outstanding amount (even after 100% was received).
    // Due is now calculated once per order, grouped by orderNo: the real Order Qty (from
    // masterData.orders, falling back to the max among that orderNo's entries) minus the sum of
    // all that orderNo's receivedQty.
    const orderGroups = {};
    this.state.receivedGoods.forEach(r => {
      const g = orderGroups[r.orderNo] || (orderGroups[r.orderNo] = { receivedQty: 0, maxOrderQty: 0 });
      g.receivedQty += Number(r.receivedQty || 0);
      g.maxOrderQty = Math.max(g.maxOrderQty, Number(r.orderQty || 0));
    });
    const totalDue = Object.keys(orderGroups).reduce((s, orderNo) => {
      const g = orderGroups[orderNo];
      const trueOrderQty = Number(this.masterData.orders[orderNo]?.qty || 0) || g.maxOrderQty;
      return s + (trueOrderQty - g.receivedQty);
    }, 0);
    const activeOrders = new Set(this.state.receivedGoods.map(r => r.orderNo)).size;
    const map = { 'rg-stat-total': total, 'rg-stat-today': todayReceived.toLocaleString(), 'rg-stat-due': totalDue.toLocaleString(), 'rg-stat-orders': activeOrders };
    Object.entries(map).forEach(([id, val]) => { const el = document.getElementById(id); if (el) el.innerText = val; });
  },

  // ⚠️ Feature (UX): once the number of supplier orders grew large (500/1000+), scrolling a
  // long <select> dropdown to find the right order became very tedious. Now <input list="..."> +
  // <datalist> is used (the Item Code field already had the same pattern) -- as soon as the
  // user types a few letters of the order number, the browser suggests matching orders itself,
  // and clicking/entering puts that order number (just the code, without the
  // supplier/quantity label) into the input.
  populateOrderDropdown() {
    const dl = document.getElementById('rg-order-no-datalist');
    if (!dl) return;
    dl.innerHTML = '';
    Object.keys(this.masterData.orders).forEach(orderNo => {
      const o = this.masterData.orders[orderNo];
      if (o.type && o.type !== 'SO') return;
      dl.innerHTML += `<option value="${this.escapeHtml(orderNo)}">${this.escapeHtml(orderNo)} - ${this.esc(o.supplier || o.buyer || '')} (${Number(o.qty).toLocaleString()})</option>`;
    });
  },

  // Selecting an Order No fills the item-wise sheet automatically with the linked Supplier
  // Order's every item (Item Code, Style No, Qty) -- the user can still change Received Qty if
  // they want
  autofillReceivedGoods(orderNo) {
    const data = this.masterData.orders[orderNo];
    if (!data) {
      // ⚠️ If the typed order number didn't match the list, nothing used to happen quietly
      // (the previous autofilled data wrongly stayed) -- now the fields are explicitly cleared
      // and the user is told
      if (orderNo) this.notify('This order number was not found -- select from the list', 'warn');
      ['rg-pi-no', 'rg-style-no', 'rg-buyer', 'rg-item-name'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
      const tbody = document.getElementById('rg-items-tbody');
      if (tbody) tbody.innerHTML = '';
      return;
    }
    const fields = { 'rg-pi-no': data.pi, 'rg-style-no': data.styleNo, 'rg-buyer': data.buyer, 'rg-item-name': data.itemName };
    Object.entries(fields).forEach(([id, val]) => {
      const el = document.getElementById(id);
      if (el) { el.value = val || ''; el.classList.add('autofill-field'); setTimeout(() => el.classList.remove('autofill-field'), 1500); }
    });
    const tbody = document.getElementById('rg-items-tbody');
    tbody.innerHTML = '';
    const soItems = Array.isArray(data.items) && data.items.length ? data.items : (this.state.supplierOrders.find(o => o.orderNo === orderNo) ? JSON.parse(this.state.supplierOrders.find(o => o.orderNo === orderNo).items || '[]') : []);
    if (soItems.length) {
      soItems.forEach(it => this.addRGItemRow(it.itemCode, it.styleNo, it.qty));
    } else {
      this.addRGItemRow();
    }
    this.calcRGTotals();
    this.notify(`Auto-filled: ${orderNo}`);
  },

  addRGItemRow(itemCode = '', styleNo = '', orderQty = '') {
    const tbody = document.getElementById('rg-items-tbody');
    if (!tbody) return;
    const r = tbody.rows.length + 1;
    const row = document.createElement('tr');
    row.innerHTML = `<td>${r}</td>
      <td><input list="pi-item-codes-list" class="rg-f-item-code" value="${itemCode}" placeholder="Item Code"></td>
      <td><input class="rg-f-style-no" value="${styleNo}" placeholder="Style No"></td>
      <td><input type="number" class="rg-f-order-qty" value="${orderQty}" placeholder="0" min="0" oninput="app.calcRGTotals()" style="text-align:right"></td>
      <td><input type="number" class="rg-f-received-qty" value="0" placeholder="0" min="0" oninput="app.calcRGTotals()" style="text-align:right"></td>
      <td class="rg-due-cell" style="text-align:right">0</td>
      <td><input class="rg-f-refcn" placeholder="e.g. cn5579" title="Which challan this item actually came against (to track partial delivery)"></td>
      <td><input class="rg-f-remarks" placeholder="Remarks"></td>
      <td class="no-print"><button class="btn" style="padding:2px 5px;border:none;color:var(--red);background:transparent" onclick="this.closest('tr').remove();app.calcRGTotals()"><i class="bi bi-trash"></i></button></td>`;
    tbody.appendChild(row);
  },

  calcRGTotals() {
    let tOrder = 0, tRecv = 0, tDue = 0;
    document.querySelectorAll('#rg-items-tbody tr').forEach(r => {
      const oq = parseFloat(r.querySelector('.rg-f-order-qty')?.value) || 0;
      const rq = parseFloat(r.querySelector('.rg-f-received-qty')?.value) || 0;
      const due = oq - rq;
      r.querySelector('.rg-due-cell').innerText = due;
      r.querySelector('.rg-due-cell').style.color = due > 0 ? 'var(--red)' : 'var(--green)';
      tOrder += oq; tRecv += rq; tDue += due;
    });
    document.getElementById('rg-total-order-qty').innerText = tOrder.toLocaleString();
    document.getElementById('rg-total-received-qty').innerText = tRecv.toLocaleString();
    document.getElementById('rg-total-due-qty').innerText = tDue.toLocaleString();
    return { tOrder, tRecv, tDue };
  },

  getRGItems() {
    const items = [];
    document.querySelectorAll('#rg-items-tbody tr').forEach(r => {
      const orderQty = parseFloat(r.querySelector('.rg-f-order-qty')?.value) || 0;
      const receivedQty = parseFloat(r.querySelector('.rg-f-received-qty')?.value) || 0;
      items.push({
        itemCode: r.querySelector('.rg-f-item-code')?.value.trim() || '',
        styleNo: r.querySelector('.rg-f-style-no')?.value.trim() || '',
        orderQty, receivedQty, dueQty: orderQty - receivedQty,
        refCn: r.querySelector('.rg-f-refcn')?.value.trim() || '',
        remarks: r.querySelector('.rg-f-remarks')?.value.trim() || ''
      });
    });
    return items;
  },

  openReceivedGoodsModal() {
    document.getElementById('rg-modal-title').innerText = 'Add Received Goods';
    document.getElementById('rg-save-btn-text').innerText = 'Save';
    document.getElementById('rg-edit-id').value = '';
    ['rg-order-no','rg-pi-no','rg-style-no','rg-buyer','rg-item-name','rg-cn-no'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
    document.getElementById('rg-date').value = todayStr();
    document.getElementById('rg-items-tbody').innerHTML = '';
    this.addRGItemRow();
    this.calcRGTotals();
    this.open('received-goods-modal');
  },

  async saveReceivedGoods() {
    const id = document.getElementById('rg-edit-id').value;
    const items = this.getRGItems().filter(it => it.itemCode || it.orderQty || it.receivedQty);
    const totals = this.calcRGTotals();
    // If multiple Challan Nos are given comma-separated, each is trimmed separately and
    // rejoined cleanly with comma+space (e.g. "cn890,cn5579 ,cn89074245" → "cn890, cn5579, cn89074245")
    const cnNo = this.splitChallanList(document.getElementById('rg-cn-no').value).join(', ');
    const record = {
      date: document.getElementById('rg-date').value,
      orderNo: document.getElementById('rg-order-no').value,
      piNo: document.getElementById('rg-pi-no').value,
      styleNo: items.map(it => it.styleNo).filter(Boolean).join(', ') || document.getElementById('rg-style-no').value,
      buyer: document.getElementById('rg-buyer').value,
      itemName: document.getElementById('rg-item-name').value,
      items,
      orderQty: totals.tOrder,
      receivedQty: totals.tRecv,
      cnNo,
      dueQty: totals.tDue
    };
    if (!record.date || !record.orderNo || !record.cnNo || !items.length) { this.notify('Date, Order No, CN No and at least one item are required', 'warn'); return; }

    let recordId;
    if (id) {
      const idx = this.state.receivedGoods.findIndex(r => r.id == id);
      if (idx !== -1) this.state.receivedGoods[idx] = { id: parseInt(id), ...record };
      recordId = id;
      this.notify('Received Goods Updated');
    } else {
      const newId = await this.allocId('receivedGoods');
      this.state.receivedGoods.push({ id: newId, ...record });
      recordId = newId;
      this.notify('Received Goods Added');
    }
    this.logAudit(id ? 'Update' : 'Create', 'receivedGoods', recordId, record.orderNo);
    await this.persistSheet('receivedGoods');
    this.close('received-goods-modal');
    this.renderReceivedGoodsTable();
    this.updateDashboard();
  },

  viewReceivedGoods(id) {
    const item = this.state.receivedGoods.find(r => r.id === id);
    if (!item) return;
    const items = Array.isArray(item.items) ? item.items : [];
    const itemRows = items.length ? items.map(it => `
      <tr><td>${this.esc(it.itemCode || '')}</td><td>${this.esc(it.styleNo || '')}</td><td>${Number(it.orderQty || 0).toLocaleString()}</td>
      <td>${Number(it.receivedQty || 0).toLocaleString()}</td><td style="color:${(it.dueQty||0) > 0 ? 'var(--red)' : 'var(--green)'};font-weight:700">${Number(it.dueQty || 0).toLocaleString()}</td>
      <td>${this.escapeHtml(it.refCn || '')}</td><td>${this.escapeHtml(it.remarks || '')}</td></tr>`).join('') : '<tr><td colspan="7" style="text-align:center;color:var(--text-muted)">No item breakdown recorded</td></tr>';
    document.getElementById('view-rg-content').innerHTML = `
      <div style="display:grid;gap:12px">
        <div class="grid-2"><div class="fg"><label>Date</label><input value="${formatDate(item.date)}" readonly></div><div class="fg"><label>Order No</label><input value="${item.orderNo}" readonly></div></div>
        <div class="grid-2"><div class="fg"><label>PI No</label><input value="${this.esc(item.piNo)}" readonly></div><div class="fg"><label>CN No (Challan)</label><input value="${this.esc(item.cnNo)}" readonly></div></div>
        <div class="grid-3"><div class="fg"><label>Total Order Qty</label><input value="${Number(item.orderQty).toLocaleString()}" readonly></div>
        <div class="fg"><label>Total Received Qty</label><input value="${Number(item.receivedQty).toLocaleString()}" readonly></div>
        <div class="fg"><label>Total Due Qty</label><input value="${Number(item.dueQty).toLocaleString()}" readonly style="color:${item.dueQty > 0 ? 'var(--red)' : 'var(--green)'};font-weight:700"></div></div>
        <div class="table-wrap"><table><thead><tr><th>Item Code</th><th>Style No</th><th>Order Qty</th><th>Received Qty</th><th>Due Qty</th><th>Ref CN</th><th>Remarks</th></tr></thead><tbody>${itemRows}</tbody></table></div>
      </div>`;
    this.open('view-received-goods-modal');
  },

  editReceivedGoods(id) {
    const item = this.state.receivedGoods.find(r => r.id === id);
    if (!item) return;
    document.getElementById('rg-modal-title').innerText = 'Edit Received Goods';
    document.getElementById('rg-save-btn-text').innerText = 'Update';
    document.getElementById('rg-edit-id').value = id;
    document.getElementById('rg-date').value = item.date;
    document.getElementById('rg-order-no').value = item.orderNo;
    document.getElementById('rg-pi-no').value = item.piNo;
    document.getElementById('rg-style-no').value = item.styleNo;
    document.getElementById('rg-buyer').value = item.buyer;
    document.getElementById('rg-item-name').value = item.itemName;
    document.getElementById('rg-cn-no').value = item.cnNo;
    const tbody = document.getElementById('rg-items-tbody');
    tbody.innerHTML = '';
    const items = Array.isArray(item.items) && item.items.length ? item.items : [{ itemCode: item.itemName, styleNo: item.styleNo, orderQty: item.orderQty, receivedQty: item.receivedQty }];
    items.forEach(it => this.addRGItemRow(it.itemCode, it.styleNo, it.orderQty));
    // Old data's received qty, ref CN and remarks are also set into the inputs
    document.querySelectorAll('#rg-items-tbody tr').forEach((r, i) => {
      if (!items[i]) return;
      const rqEl = r.querySelector('.rg-f-received-qty');
      const refCnEl = r.querySelector('.rg-f-refcn');
      const remarksEl = r.querySelector('.rg-f-remarks');
      if (rqEl) rqEl.value = items[i].receivedQty || 0;
      if (refCnEl) refCnEl.value = items[i].refCn || '';
      if (remarksEl) remarksEl.value = items[i].remarks || '';
    });
    this.calcRGTotals();
    this.open('received-goods-modal');
  },

  // Works out a short, human-readable label for a record depending on its type (for showing
  // in the audit log and trash page) -- e.g. PI No, Voucher No, Username etc., from a
  // different field per table
  getRecordLabel(tableName, record) {
    const map = {
      piList: r => r.piNo, masterData: r => r.itemCode, receivedGoods: r => r.orderNo,
      supplierOrders: r => r.orderNo, deliveryPlan: r => r.orderNo, deliveryHist: r => r.challan,
      qcList: r => r.challan || r.orderNo, accBuyer: r => r.piNo, accSupplier: r => r.orderNo,
      expenseList: r => r.voucherNo, vouchers: r => r.voucherNo, hrEmployees: r => r.name,
      hrAttendance: r => `${r.employee} (${formatDate(r.date)})`, hrSalary: r => r.employee,
      hrLeaves: r => `${r.employee} (${formatDate(r.startDate)} - ${formatDate(r.endDate)})`,
      hrSignatures: r => `${r.name} (${r.designation || 'Merchandiser'})`, hrDepartments: r => r.name,
      users: r => r.username, buyers: r => r.name, suppliers: r => r.name
    };
    const fn = map[tableName];
    return (fn && fn(record)) || record.id;
  },

  // Adds an entry to the audit log -- added locally right away (this.state.auditLog), so the
  // Audit Log page shows it updated instantly, and inserted into the database in the
  // background (without await, so the main operation is never blocked)
  logAudit(action, module, recordId, recordLabel) {
    const entry = {
      id: Date.now() + Math.floor(Math.random() * 1000), // timestamp + random, to avoid collisions
      timestamp: nowISO(),
      username: this.currentUsername || this.role,
      role: this.role,
      action, module,
      recordId: String(recordId),
      recordLabel: String(recordLabel || '')
    };
    this.state.auditLog.unshift(entry);
    SheetsDB.insertAuditLog(entry); // deliberately not awaited -- the audit log should never slow down the main operation
    if (document.getElementById('audit-log-tbody')) this.renderAuditLog();
  },

  // A trash entry older than 30 days is automatically and permanently deleted (checked when
  // the app loads -- since there's no real server-side cron, this is "best-effort", and works
  // fine as long as the app is used regularly)
  async purgeOldTrash() {
    const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;
    const now = Date.now();
    const toPurge = this.trashItems.filter(t => (now - new Date(t.deletedAt).getTime()) > THIRTY_DAYS);
    if (!toPurge.length) return;
    for (const t of toPurge) {
      try { await SheetsDB.deleteRow(t.module, t.record.id); } catch (e) { /* will retry later */ }
      // ⚠️ Round 14: just like the manual permanentlyDeleteFromTrash(), the automatic 30-day
      // purge also needs to delete a 'users' record's Auth account -- otherwise the same
      // problem happens
      if (t.module === 'users' && t.record.username) {
        try { await SheetsDB.adminManageUser({ action: 'delete', username: t.record.username }); } catch (e) { /* will retry later */ }
      }
    }
    this.trashItems = this.trashItems.filter(t => !toPurge.includes(t));
  },

  // The Recycle Bin page shows every record in the trash (with a module filter), most
  // recently deleted at the top
  renderTrash() {
    const tbody = document.getElementById('trash-tbody');
    if (!tbody) return;
    const filterEl = document.getElementById('trash-module-filter');
    if (filterEl && filterEl.options.length <= 1) {
      const modules = [...new Set(this.trashItems.map(t => t.module))].sort();
      filterEl.innerHTML = '<option value="">All Modules</option>' + modules.map(m => `<option value="${m}">${m}</option>`).join('');
    }
    const filter = filterEl ? filterEl.value : '';
    const items = this.trashItems.filter(t => !filter || t.module === filter);

    this.updateDataSafetyTrashBadge();

    if (!items.length) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:24px">Recycle Bin is empty</td></tr>';
      return;
    }
    tbody.innerHTML = items.map(t => `
      <tr>
        <td><span class="badge badge-b">${this.escapeHtml(t.module)}</span></td>
        <td>${this.escapeHtml(this.getRecordLabel(t.module, t.record))}</td>
        <td>${formatDateTime(t.deletedAt)}</td>
        <td>${this.escapeHtml(t.deletedBy || '-')}</td>
        <td>
          <button class="action-btn action-edit admin-only" onclick="app.restoreFromTrash('${t.module}', ${t.record.id})"><i class="bi bi-arrow-counterclockwise"></i> Restore</button>
          <button class="action-btn action-delete superadmin-only" onclick="app.permanentlyDeleteFromTrash('${t.module}', ${t.record.id})"><i class="bi bi-trash3"></i> Permanent Delete</button>
        </td>
      </tr>`).join('');
  },

  renderDataSafetyTrash() { this.renderTrash(); },

  updateDataSafetyTrashBadge() {
    const badge = document.getElementById('nav-trash-badge');
    const dsBadge = document.getElementById('ds-trash-count');
    const count = this.trashItems.length;
    if (badge) { badge.style.display = count ? '' : 'none'; badge.innerText = count; }
    if (dsBadge) { dsBadge.style.display = count ? '' : 'none'; dsBadge.innerText = count; }
  },

  // ============================================================
  // DATA SAFETY -- Complete Order List (archival feature)
  // ============================================================
  // ⚠️ Feature: once a PI's Buyer Payment and every linked Supplier Order's Payment are
  // complete (and delivery is also complete), that PI can be "archived". An archived PI moves
  // out of the regular activity lists (PI List, Received Goods, Supplier Order history,
  // Delivery Challan, QC list, Buyer/Supplier Ledger) and is only visible collected together
  // in "Complete Order List" -- clicking any one shows a complete, detailed history of
  // everything that happened under that PI, together. This deliberately never truly
  // deletes/moves the data -- it only sets an "archived" flag on the piList record (reversible,
  // can be brought back any time via Unarchive), and every listing function checks that flag
  // to hide records linked to an archived PI. This carries no risk of losing data and never
  // breaks any report/ledger/audit log -- unlike actually moving the data, which would have
  // carried that risk.

  // Checks whether a PI is eligible for archiving: delivery complete + Buyer payment complete
  // + every Supplier Order's payment complete
  isPIEligibleForArchival(pi) {
    const status = this.computePIStatus(pi);
    if (status.label !== 'Delivery Complete') return false;
    const buyerRow = this.state.accBuyer.find(r => r.piNo === pi.piNo);
    if (!buyerRow || this.parseMoney(buyerRow.due) > 0) return false;
    const relatedOrderNos = this.state.supplierOrders.filter(o => o.piNo === pi.piNo).map(o => o.orderNo);
    if (!relatedOrderNos.length) return false;
    const supplierRows = this.state.accSupplier.filter(r => relatedOrderNos.includes(r.orderNo));
    if (!supplierRows.length || supplierRows.some(r => this.parseMoney(r.due) > 0)) return false;
    return true;
  },

  isArchivedByPiNo(piNo) {
    const pi = this.state.piList.find(p => p.piNo === piNo);
    return !!(pi && pi.archived);
  },

  // Looks up whether the PI linked to an orderNo is archived -- even when a table like
  // Received Goods/QC/Delivery/Supplier Ledger has no piNo directly, it can be worked out via
  // orderNo → supplierOrders → piNo
  isArchivedByOrderNo(orderNo) {
    const so = this.state.supplierOrders.find(o => o.orderNo === orderNo);
    if (!so || !so.piNo) return false;
    return this.isArchivedByPiNo(so.piNo);
  },

  // Renders the Data Safety > Complete Order List tab
  renderCompleteOrderList() {
    // Part 1: a suggestion list of PIs that are eligible to archive but haven't been yet --
    // instead of archiving fully automatically and quietly, the admin is shown and asked to
    // confirm (for safety)
    const suggestTbody = document.getElementById('ds-archive-suggest-tbody');
    const eligible = this.state.piList.filter(p => !p.archived && this.isPIEligibleForArchival(p));
    if (suggestTbody) {
      if (!eligible.length) {
        suggestTbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:16px">No new PI is currently ready to archive</td></tr>';
      } else {
        suggestTbody.innerHTML = eligible.map(pi => `
          <tr><td>${this.escapeHtml(pi.piNo)}</td><td>${this.escapeHtml(pi.buyer)}</td><td>${this.formatUSD(this.parseMoney(pi.totalValue))}</td>
          <td><button class="action-btn action-edit inventory-write" onclick="app.archivePI('${this.escapeJsAttr(pi.piNo)}')"><i class="bi bi-archive"></i> Archive</button></td></tr>`).join('');
      }
    }
    const suggestBadge = document.getElementById('ds-archive-suggest-count');
    if (suggestBadge) { suggestBadge.innerText = eligible.length; suggestBadge.style.display = eligible.length ? 'inline-block' : 'none'; }

    // Part 2: the already-archived list -- the real "Complete Order List"
    const tbody = document.getElementById('ds-complete-orders-tbody');
    if (!tbody) return;
    const archived = this.state.piList.filter(p => p.archived).sort((a, b) => (b.archivedAt || '').localeCompare(a.archivedAt || ''));
    if (!archived.length) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:24px">No PI has been archived yet</td></tr>';
      return;
    }
    tbody.innerHTML = archived.map(pi => `
      <tr style="cursor:pointer" onclick="app.openPIFullHistory('${this.escapeJsAttr(pi.piNo)}')">
      <td>${this.escapeHtml(pi.piNo)}</td><td>${this.escapeHtml(pi.buyer)}</td><td>${this.formatUSD(this.parseMoney(pi.totalValue))}</td><td>${formatDateTime(pi.archivedAt)}</td>
      <td><button class="action-btn action-view" onclick="event.stopPropagation();app.openPIFullHistory('${this.escapeJsAttr(pi.piNo)}')"><i class="bi bi-eye"></i> Details</button>
      <button class="action-btn action-edit inventory-delete" onclick="event.stopPropagation();app.unarchivePI('${this.escapeJsAttr(pi.piNo)}')"><i class="bi bi-arrow-counterclockwise"></i> Unarchive</button></td></tr>`).join('');
  },

  async archivePI(piNo) {
    if (!confirm(`Archive ${piNo} as complete? It will move out of the regular PI List, Received Goods, Supplier Order, Delivery, QC and Ledger lists and only show in Complete Order List (can be brought back any time via Unarchive, no data is lost).`)) return;
    const pi = this.state.piList.find(p => p.piNo === piNo);
    if (!pi) return;
    pi.archived = true;
    pi.archivedAt = nowISO();
    this.logAudit('Archive', 'piList', pi.id, piNo);
    await this.persistSheet('piList');
    this.notify(`${piNo} has been archived`);
    this.renderAllTables();
  },

  async unarchivePI(piNo) {
    if (this.role !== 'superadmin') { alert('Only Super Admin can Unarchive'); return; }
    if (!confirm(`Bring ${piNo} back to the active list?`)) return;
    const pi = this.state.piList.find(p => p.piNo === piNo);
    if (!pi) return;
    pi.archived = false;
    pi.archivedAt = null;
    this.logAudit('Unarchive', 'piList', pi.id, piNo);
    await this.persistSheet('piList');
    this.notify(`${piNo} is active again`);
    this.close('pi-full-history-modal');
    this.renderAllTables();
  },

  // Shows every activity that happened under an archived PI (Supplier Order, Received Goods,
  // QC, Delivery, Buyer/Supplier Ledger payments) together in a read-only drill-down view
  openPIFullHistory(piNo) {
    const pi = this.state.piList.find(p => p.piNo === piNo);
    if (!pi) return;
    const orders = this.state.supplierOrders.filter(o => o.piNo === piNo);
    const orderNos = orders.map(o => o.orderNo);
    const received = this.state.receivedGoods.filter(r => orderNos.includes(r.orderNo));
    const delivered = this.state.deliveryHist.filter(d => orderNos.includes(d.orderNo));
    const qc = this.state.qcList.filter(q => orderNos.includes(q.orderNo));
    const buyerPayments = this.state.buyerPaymentHistory.filter(h => h.piNo === piNo);
    const supplierPayments = this.state.supplierPaymentHistory.filter(h => orderNos.includes(h.orderNo));

    const section = (title, icon, count, rows) => `
      <div class="card mb-3"><div class="w-title mb-2"><i class="bi bi-${icon}"></i> ${title} (${count})</div>${rows}</div>`;
    const emptyMsg = '<p style="font-size:11px;color:var(--text-muted)">No records</p>';

    const html = `
      <div class="card mb-3"><div class="w-title mb-2"><i class="bi bi-file-earmark-text"></i> PI Details</div>
        <p style="font-size:11px;line-height:1.9;">
          <b>PI No:</b> ${this.escapeHtml(pi.piNo)} &nbsp;&nbsp; <b>Buyer:</b> ${this.escapeHtml(pi.buyer)} &nbsp;&nbsp;
          <b>Date:</b> ${this.escapeHtml(pi.date || '-')} &nbsp;&nbsp; <b>Total Value:</b> ${this.formatUSD(this.parseMoney(pi.totalValue))} &nbsp;&nbsp;
          <b>Archived On:</b> ${formatDateTime(pi.archivedAt)}
        </p>
      </div>
      ${section('Supplier Order Sheet', 'truck', orders.length, orders.length ? `<div class="table-wrap"><table><thead><tr><th>Order No</th><th>Supplier</th><th>Total Value</th></tr></thead><tbody>
        ${orders.map(o => `<tr><td>${this.escapeHtml(o.orderNo)}</td><td>${this.escapeHtml(o.supplier)}</td><td>${this.formatUSD(this.parseMoney(o.totalValue))}</td></tr>`).join('')}
      </tbody></table></div>` : emptyMsg)}
      ${section('Received Goods', 'box-seam', received.length, received.length ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Order No</th><th>Item</th><th>Received Qty</th><th>CN No</th></tr></thead><tbody>
        ${received.map(r => `<tr><td>${formatDate(r.date)}</td><td>${this.escapeHtml(r.orderNo)}</td><td>${this.escapeHtml(r.itemName || '-')}</td><td>${r.receivedQty}</td><td>${this.escapeHtml(r.cnNo || '-')}</td></tr>`).join('')}
      </tbody></table></div>` : emptyMsg)}
      ${section('QC Inspection Report', 'clipboard-check', qc.length, qc.length ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Order No</th><th>Result</th><th>Reject Qty</th></tr></thead><tbody>
        ${qc.map(q => `<tr><td>${formatDate(q.date)}</td><td>${this.escapeHtml(q.orderNo)}</td><td><span class="badge badge-${(q.result || '').toLowerCase() === 'pass' ? 'g' : 'r'}">${this.escapeHtml(q.result || '-')}</span></td><td>${q.rejectQty || 0}</td></tr>`).join('')}
      </tbody></table></div>` : emptyMsg)}
      ${section('Delivery Challan', 'truck-flatbed', delivered.length, delivered.length ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Order No</th><th>Qty</th><th>Challan</th></tr></thead><tbody>
        ${delivered.map(d => `<tr><td>${formatDate(d.date)}</td><td>${this.escapeHtml(d.orderNo)}</td><td>${d.qty}</td><td>${this.escapeHtml(d.challan || '-')}</td></tr>`).join('')}
      </tbody></table></div>` : emptyMsg)}
      <div class="grid-2">
        <div class="card"><div class="w-title mb-2"><i class="bi bi-cash-coin"></i> Buyer Ledger — Payments (${buyerPayments.length})</div>
          ${buyerPayments.length ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Amount</th></tr></thead><tbody>
            ${buyerPayments.map(h => `<tr><td>${formatDate(h.date)}</td><td>${this.formatUSD(this.parseMoney(h.amount))}</td></tr>`).join('')}
          </tbody></table></div>` : emptyMsg}
        </div>
        <div class="card"><div class="w-title mb-2"><i class="bi bi-cash-stack"></i> Supplier Ledger — Payments (${supplierPayments.length})</div>
          ${supplierPayments.length ? `<div class="table-wrap"><table><thead><tr><th>Date</th><th>Order No</th><th>Amount</th></tr></thead><tbody>
            ${supplierPayments.map(h => `<tr><td>${formatDate(h.date)}</td><td>${this.escapeHtml(h.orderNo)}</td><td>${this.formatUSD(this.parseMoney(h.amount))}</td></tr>`).join('')}
          </tbody></table></div>` : emptyMsg}
        </div>
      </div>`;
    document.getElementById('pi-full-history-body').innerHTML = html;
    document.getElementById('pi-full-history-title').innerText = `${piNo} -- Complete Activity History`;
    document.getElementById('pi-full-history-unarchive-btn').setAttribute('onclick', `app.unarchivePI('${piNo}')`);
    this.open('pi-full-history-modal');
  },

  renderAuditLog() {
    const tbody = document.getElementById('audit-log-tbody');
    if (!tbody) return;
    const filterEl = document.getElementById('audit-module-filter');
    if (filterEl && filterEl.options.length <= 1) {
      const modules = [...new Set(this.state.auditLog.map(a => a.module))].sort();
      filterEl.innerHTML = '<option value="">All Modules</option>' + modules.map(m => `<option value="${m}">${m}</option>`).join('');
    }
    const filter = filterEl ? filterEl.value : '';
    const items = this.state.auditLog.filter(a => !filter || a.module === filter);

    if (!items.length) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:24px">No audit log entries yet</td></tr>';
      return;
    }
    const actionColor = { Create: 'var(--green)', Update: 'var(--accent)', Delete: 'var(--red)', Restore: 'var(--yellow)', 'Permanent Delete': 'var(--red)' };
    tbody.innerHTML = items.slice(0, 500).map(a => `
      <tr>
        <td class="f-mono" style="font-size:10px;">${formatDateTime(a.timestamp)}</td>
        <td>${this.escapeHtml(a.username)}</td>
        <td><span class="badge badge-b">${this.escapeHtml(a.role)}</span></td>
        <td style="color:${actionColor[a.action] || 'var(--text-main)'};font-weight:600">${this.escapeHtml(a.action)}</td>
        <td>${this.escapeHtml(a.module)}</td>
        <td>${this.escapeHtml(a.recordLabel)}</td>
      </tr>`).join('');
  },

  renderDataSafetyAuditLog() {
    const tbody = document.getElementById('audit-log-tbody');
    if (!tbody) return;
    const filterEl = document.getElementById('audit-module-filter');
    const searchEl = document.getElementById('ds-audit-search');
    if (filterEl && filterEl.options.length <= 1) {
      const modules = [...new Set(this.state.auditLog.map(a => a.module))].sort();
      filterEl.innerHTML = '<option value="">All Modules</option>' + modules.map(m => `<option value="${m}">${m}</option>`).join('');
    }
    const filter = filterEl ? filterEl.value : '';
    const search = (searchEl ? searchEl.value : '').toLowerCase();
    let items = this.state.auditLog;
    if (filter) items = items.filter(a => a.module === filter);
    if (search) items = items.filter(a => `${a.username} ${a.role} ${a.action} ${a.module} ${a.recordLabel}`.toLowerCase().includes(search));

    if (!items.length) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:24px">No matching audit log entries</td></tr>';
      return;
    }
    const actionColor = { Create: 'var(--green)', Update: 'var(--accent)', Delete: 'var(--red)', Restore: 'var(--yellow)', 'Permanent Delete': 'var(--red)' };
    tbody.innerHTML = items.slice(0, 500).map(a => `
      <tr>
        <td class="f-mono" style="font-size:10px;">${formatDateTime(a.timestamp)}</td>
        <td>${this.escapeHtml(a.username)}</td>
        <td><span class="badge badge-b">${this.escapeHtml(a.role)}</span></td>
        <td style="color:${actionColor[a.action] || 'var(--text-main)'};font-weight:600">${this.escapeHtml(a.action)}</td>
        <td>${this.escapeHtml(a.module)}</td>
        <td>${this.escapeHtml(a.recordLabel)}</td>
      </tr>`).join('');
  },

  switchDataSafetyTab(el, targetId) {
    el.parentElement.querySelectorAll('.datasafety-tab').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    document.querySelectorAll('.datasafety-content').forEach(c => c.classList.remove('active'));
    const target = document.getElementById(targetId);
    if (target) target.classList.add('active');
    if (targetId === 'ds-audit') this.renderDataSafetyAuditLog();
    if (targetId === 'ds-recycle') { this.renderDataSafetyTrash(); this.updateDataSafetyTrashBadge(); }
    if (targetId === 'ds-complete-orders') this.renderCompleteOrderList();
  },

  toggleDashThemePicker() {
    const picker = document.getElementById('dash-theme-picker');
    const btn = document.querySelector('.dash-theme-btn');
    if (!picker || !btn) return;
    if (picker.classList.contains('show')) {
      picker.classList.remove('show');
      return;
    }
    // Calculates the button's position to place the fixed picker right below it
    const rect = btn.getBoundingClientRect();
    picker.style.top = (rect.bottom + 6) + 'px';
    picker.style.right = (window.innerWidth - rect.right) + 'px';
    picker.classList.add('show');
  },

  // ===== Duplicate Entry Validation (Soft Validation) =====
  // PI No, CN No, Order No, Challan No duplicate check -- shows a warning but does not block saving
  checkDuplicateEntry(field, value, excludeId) {
    if (!value || !value.trim()) return false;
    const val = value.trim().toLowerCase();
    const maps = {
      piNo: { table: 'piList', field: 'piNo', label: 'PI No' },
      cnNo: { table: 'receivedGoods', field: 'cnNo', label: 'CN No' },
      orderNo: { table: 'supplierOrders', field: 'orderNo', label: 'Order No' },
      challan: { table: 'qcList', field: 'challan', label: 'Challan No' }
    };
    const cfg = maps[field];
    if (!cfg) return false;
    const data = this.state[cfg.table] || [];
    const dup = data.find(r => {
      if (excludeId && r.id === excludeId) return false;
      const rVal = String(r[cfg.field] || '').trim().toLowerCase();
      // For CN No, check if the new value appears in any existing comma-separated CN list
      if (field === 'cnNo') {
        return rVal.split(',').map(c => c.trim()).some(c => c === val);
      }
      return rVal === val;
    });
    if (dup) {
      const existingVal = dup[cfg.field];
      this.showDuplicateWarning(cfg.label, existingVal);
      return true;
    }
    return false;
  },

  showDuplicateWarning(fieldName, existingValue) {
    const overlay = document.createElement('div');
    overlay.className = 'dup-warn-overlay';
    overlay.innerHTML = `
      <div class="dup-warn-box">
        <h3><i class="bi bi-exclamation-triangle-fill"></i> Duplicate ${this.escapeHtml(fieldName)}</h3>
        <p>A record with <strong>${this.escapeHtml(fieldName)}: "${this.escapeHtml(existingValue)}"</strong> already exists in the database.<br>You can still save, but please verify this is intentional.</p>
        <div class="dup-warn-actions">
          <button class="btn" id="dup-warn-cancel">Cancel</button>
          <button class="btn btn-accent" id="dup-warn-proceed">Save Anyway</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    return new Promise((resolve) => {
      document.getElementById('dup-warn-cancel').onclick = () => { document.body.removeChild(overlay); resolve(false); };
      document.getElementById('dup-warn-proceed').onclick = () => { document.body.removeChild(overlay); resolve(true); };
      overlay.onclick = (e) => { if (e.target === overlay) { document.body.removeChild(overlay); resolve(false); } };
    });
  },

  async checkDuplicateAsync(field, value, excludeId) {
    if (!this.checkDuplicateEntry(field, value, excludeId)) return true; // no duplicate, proceed
    // duplicate found — show warning and wait for user decision
    return await this.showDuplicateWarning(field, value);
  },

  // ===== One-Click Full Database Backup =====
  async fullDatabaseBackup() {
    if (typeof ExcelJS === 'undefined') { this.notify('Excel library not loaded — check internet connection', 'error'); return; }
    this.notify('Preparing full database backup...', 'info');
    const wb = new ExcelJS.Workbook();
    wb.creator = 'AccoFlow ERP v6.0';
    wb.created = new Date();

    const allTables = {
      'PI List': this.state.piList,
      'Master Data': this.state.masterData,
      'Received Goods': this.state.receivedGoods,
      'Supplier Orders': this.state.supplierOrders,
      'Delivery Plan': this.state.deliveryPlan,
      'Delivery History': this.state.deliveryHist,
      'QC List': this.state.qcList,
      'Buyer Ledger': this.state.accBuyer,
      'Supplier Ledger': this.state.accSupplier,
      'Buyer Payments': this.state.buyerPaymentHistory,
      'Supplier Payments': this.state.supplierPaymentHistory,
      'Expenses': this.state.expenseList,
      'Vouchers': this.state.vouchers,
      'Employees': this.state.hrEmployees,
      'Attendance': this.state.hrAttendance,
      'Salary': this.state.hrSalary,
      'Leave Requests': this.state.hrLeaves,
      'Users': this.state.users,
      'Buyers': this.state.buyers,
      'Suppliers': this.state.suppliers
    };

    for (const [sheetName, data] of Object.entries(allTables)) {
      const ws = wb.addWorksheet(sheetName.substring(0, 31), { views: [{ state: 'frozen', ySplit: 1 }] });
      if (!data || !data.length) continue;
      const keys = Object.keys(data[0]).filter(k => k !== 'deletedAt' && k !== 'deletedBy' && k !== 'photo' && k !== 'image' && k !== 'logo' && k !== 'receiptImage' && k !== 'formData' && k !== 'items' && k !== 'extraData');
      ws.columns = keys.map(k => ({ header: k, key: k, width: Math.max(k.length + 4, 14) }));
      const headerRow = ws.getRow(1);
      headerRow.height = 24;
      headerRow.eachCell(cell => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0A0F18' } };
        cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
        cell.border = { bottom: { style: 'medium', color: { argb: 'FF06B6D4' } } };
      });
      data.forEach((r, i) => {
        const row = ws.addRow(keys.reduce((obj, k) => { obj[k] = r[k] ?? ''; return obj; }, {}));
        row.eachCell(cell => {
          if (i % 2 === 1) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF3F6FA' } };
          cell.border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
        });
      });
    }

    const buf = await wb.xlsx.writeBuffer();
    const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AccoFlow_Full_Backup_${todayStr()}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    this.notify('Full database backup downloaded!');
  },

  // ⚠️ Bug fix: the real cause of "data still shows in autosuggest/dropdown after deleting" --
  // saving a PI or Supplier Order used to create an entry via registerOrder() in a separate
  // "shadow" cache called this.masterData.orders (not part of this.state, so the soft-delete
  // logic never touched it), used in Received Goods' "Select Supplier Order..." dropdown. But
  // deleting piList/supplierOrders never removed the entry from this shadow cache -- so a
  // deleted PI/Supplier Order (sent to the Recycle Bin) stayed in the Order No dropdown. This
  // helper function is called from confirmDelete() to remove the linked entry and refresh the
  // dropdown.
  removeOrderShadowEntry(tableName, record) {
    if (tableName === 'piList' && record.piNo && this.masterData.orders[record.piNo]) {
      delete this.masterData.orders[record.piNo];
    } else if (tableName === 'supplierOrders' && record.orderNo && this.masterData.orders[record.orderNo]) {
      delete this.masterData.orders[record.orderNo];
    } else {
      return; // this table has no relationship with masterData.orders
    }
    this.persistOrders();
    this.populateOrderDropdown();
  },

  // When a piList/supplierOrders record is made active again on Restore (see
  // restoreFromTrash below), its Order No is re-registered into the masterData.orders shadow
  // cache too -- following the exact same format registerOrder() is sent in
  // savePI()/saveSupplierOrder()
  reAddOrderShadowEntry(tableName, record) {
    if (tableName === 'piList' && record.piNo) {
      const lineItems = (record.formData && Array.isArray(record.formData.lineItems)) ? record.formData.lineItems : [];
      const totalQty = lineItems.reduce((s, it) => s + (parseFloat(it.qty) || 0), 0);
      this.masterData.orders[record.piNo] = {
        orderNo: record.piNo, buyer: record.buyer, supplier: record.supplier, qty: totalQty, pi: record.piNo,
        styleNo: lineItems.map(it => it.styleNo).filter(Boolean).join(', '),
        itemName: lineItems.map(it => it.description).filter(Boolean).join(', '),
        contact: '', address: '', type: 'PI'
      };
      this.persistOrders();
      this.populateOrderDropdown();
    } else if (tableName === 'supplierOrders' && record.orderNo) {
      let items = [];
      try { items = JSON.parse(record.items || '[]'); } catch (e) { items = []; }
      const totalQty = items.reduce((s, it) => s + (parseFloat(it.qty) || 0), 0);
      this.masterData.orders[record.orderNo] = {
        orderNo: record.orderNo, buyer: '', supplier: record.supplier, qty: totalQty, pi: record.piNo,
        styleNo: items.map(it => it.styleNo).filter(Boolean).join(', '),
        itemName: items.map(it => it.description).filter(Boolean).join(', '),
        contact: '', address: '', type: 'SO', items
      };
      this.persistOrders();
      this.populateOrderDropdown();
    }
  },

  async confirmDelete(tableName, id) {
    if (this.role !== 'superadmin') { alert('Only Super Admin can delete records'); return; }
    if (!confirm('Are you sure you want to delete this record? It will stay in the Recycle Bin for 30 days, and can be restored during that time if needed.')) return;
    const idx = this.state[tableName].findIndex(item => item.id === id);
    if (idx === -1) return;

    const [record] = this.state[tableName].splice(idx, 1);
    const label = this.getRecordLabel(tableName, record);
    this.removeOrderShadowEntry(tableName, record);

    // ⚠️ Recycle Bin: instead of permanently deleting the record, it is marked with
    // deletedAt/deletedBy and moved into this.trashItems, and the database is updated the same
    // way (as a soft-delete) -- no real DELETE query runs here
    if (SOFT_DELETE_TABLES.includes(tableName)) {
      record.deletedAt = nowISO();
      record.deletedBy = this.currentUsername || this.role;
      this.trashItems.unshift({ module: tableName, record, deletedAt: record.deletedAt, deletedBy: record.deletedBy });
      if (SheetsDB.isConfigured() && this.dbConnected) {
        try { await SheetsDB.upsert(tableName, record); } catch (e) { this.notify('Delete sync failed', 'error'); }
        // ⚠️ Round 13: when a 'users' table record is soft-deleted (deactivated), the linked
        // Supabase Auth account is also banned -- otherwise, even though the app's UI shows
        // them "deleted", they could still log in directly via Supabase Auth and access
        // RLS-authorised data
        if (tableName === 'users') {
          try { await SheetsDB.adminManageUser({ action: 'setStatus', username: record.username, status: 'Inactive' }); }
          catch (e) { this.notify('Problem deactivating the Auth account: ' + e.message, 'error'); }
        }
        // ⚠️ Round 14 fix (closing a known limitation): adding a Leave auto-creates an "On
        // Leave" entry in hrAttendance for every date in startDate-endDate (see saveLeave). But
        // deleting that Leave never used to remove these auto-created Attendance entries --
        // so cancelling/deleting a leave still wrongly showed "On Leave" in Attendance
        // reports/salary. Now deleting a Leave also removes those entries (whichever are still
        // "On Leave" -- excluding any a user has since manually corrected)
        // খুঁজে হার্ড-ডিলিট করা হয় (এগুলো স্বাধীন রেকর্ড না, Leave-এর পার্শ্ব-প্রতিক্রিয়া মাত্র)।
        if (tableName === 'hrLeaves' && record.employee && record.startDate && record.endDate) {
          const toRemove = this.state.hrAttendance.filter(a =>
            a.employee === record.employee && a.status === 'On Leave' &&
            a.date >= record.startDate && a.date <= record.endDate);
          if (toRemove.length) {
            this.state.hrAttendance = this.state.hrAttendance.filter(a => !toRemove.includes(a));
            for (const a of toRemove) {
              try { await SheetsDB.deleteRow('hrAttendance', a.id); } catch (e) { /* can be fixed manually later */ }
            }
            this.renderHRAttendance();
          }
        }
      }
    } else if (SheetsDB.isConfigured() && this.dbConnected) {
      try { await SheetsDB.deleteRow(tableName, id); } catch (e) { this.notify('Delete sync failed', 'error'); }
    }

    this.logAudit('Delete', tableName, id, label);
    this.notify('Record moved to Recycle Bin');
    this.renderAllTables();
    if (document.getElementById('trash-tbody')) this.renderTrash();
  },

  // Brings a record back from the Recycle Bin to where it was (deletedAt/deletedBy removed
  // and it's sent back into this.state[module], then synced via the normal persistSheet)
  //
  // ⚠️ Bug fix (the real reason Restore didn't work): `delete record.deletedAt` here used to
  // remove the key entirely. Deleting a key from a JavaScript object means it's completely
  // absent from the JSON payload sent when calling upsert() -- so the deletedAt column was
  // never SET at all in Supabase/PostgREST's generated "INSERT ... ON CONFLICT DO UPDATE"
  // query, and the old deletedAt timestamp stayed in the database. So even though the record
  // disappeared from Trash in the UI right away (optimistic local state), the next
  // refresh/reload's loadFromDatabase() found row.deletedAt truthy again and sent the record
  // straight back to Trash -- meaning Restore never actually persisted in the database at all.
  // Fix: instead of deleting the key, explicitly set it to `null`, so both deletedAt/deletedBy
  // are present in the upsert payload and correctly become null in the database too (data
  // safety stays intact throughout).
  async restoreFromTrash(module, id) {
    const idx = this.trashItems.findIndex(t => t.module === module && t.record.id === id);
    if (idx === -1) return;
    const [trashEntry] = this.trashItems.splice(idx, 1);
    const record = { ...trashEntry.record };
    record.deletedAt = null;
    record.deletedBy = null;
    this.state[module].push(record);
    this.reAddOrderShadowEntry(module, record);
    await this.persistSheet(module);
    // ⚠️ Round 13: when 'users' is restored, the linked Supabase Auth account is also
    // reactivated
    if (module === 'users' && SheetsDB.isConfigured() && this.dbConnected) {
      try { await SheetsDB.adminManageUser({ action: 'setStatus', username: record.username, status: 'Active' }); }
      catch (e) { this.notify('Problem reactivating the Auth account: ' + e.message, 'error'); }
    }
    this.logAudit('Restore', module, id, this.getRecordLabel(module, record));
    this.notify('Record restored successfully');
    this.renderAllTables();
    this.renderTrash();
    this.updateDataSafetyTrashBadge();
  },

  // Permanently deletes from the Recycle Bin (cannot be undone)
  async permanentlyDeleteFromTrash(module, id) {
    if (!confirm('Permanently delete this record? This cannot be undone.')) return;
    const idx = this.trashItems.findIndex(t => t.module === module && t.record.id === id);
    if (idx === -1) return;
    const [trashEntry] = this.trashItems.splice(idx, 1);
    if (SheetsDB.isConfigured() && this.dbConnected) {
      try { await SheetsDB.deleteRow(module, id); } catch (e) { this.notify('Permanent delete failed', 'error'); }
      // ⚠️ Round 14 fix: permanently deleting a 'users' record also deletes the linked
      // Supabase Auth account -- otherwise a new user could never be created again with that
      // same username/email ("already exists" error), even though the app's UI showed them as
      // fully deleted.
      if (module === 'users' && trashEntry.record.username) {
        try { await SheetsDB.adminManageUser({ action: 'delete', username: trashEntry.record.username }); }
        catch (e) { this.notify('Problem deleting the Auth account: ' + e.message, 'error'); }
      }
    }
    this.logAudit('Permanent Delete', module, id, this.getRecordLabel(module, trashEntry.record));
    this.notify('Record permanently deleted');
    this.renderTrash();
    this.updateDataSafetyTrashBadge();
  },

  updateDashboardWidget() {
    const today = todayStr();
    const todayItems = this.state.receivedGoods.filter(r => r.date === today);
    const todayTotal = todayItems.reduce((s, r) => s + Number(r.receivedQty), 0);
    const el = document.getElementById('dash-today-received');
    const elSub = document.getElementById('dash-today-received-sub');
    if (el) el.innerText = todayTotal.toLocaleString();
    if (elSub) elSub.innerText = `${todayItems.length} Order${todayItems.length !== 1 ? 's' : ''} today`;
  },

  renderDeliveryPlan() {
    const tbody = document.getElementById('del-plan-tbody');
    if (!tbody) return;
    if (!this.state.deliveryPlan.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:24px">No delivery plans yet.</td></tr>';
    } else {
      tbody.innerHTML = this.state.deliveryPlan.map(row => `
        <tr class="${row.status === 'Hold' ? 'del-plan-hold' : ''}"><td class="f-mono f-accent">${this.escapeHtml(row.orderNo)}</td><td>${this.escapeHtml(row.buyer)}</td><td>${this.escapeHtml(row.item)}</td><td>${this.escapeHtml(row.remainingQty)}</td>
        <td style="color:var(--red)">${this.escapeHtml(formatDate(row.expectedDate))}</td>
        <td><span class="badge badge-${row.priority === 'Urgent' ? 'r' : 'b'}">${this.escapeHtml(row.priority)}</span></td>
        <td>${row.challanData
          ? `<select onchange="app.updateDeliveryPlanStatus(${row.id}, this.value)" style="font-size:10px;padding:3px 6px;border-radius:6px;background:${row.status === 'Hold' ? 'rgba(239,68,68,0.12)' : 'rgba(6,182,212,0.12)'};color:${row.status === 'Hold' ? 'var(--red)' : 'var(--accent)'};border:1px solid var(--border)">
              <option value="Hold" ${row.status === 'Hold' ? 'selected' : ''}>Hold</option>
              <option value="Complete">Complete</option>
            </select>`
          : `<span class="badge badge-${row.status === 'Delayed' ? 'y' : 'b'}">${this.escapeHtml(row.status)}</span>`}</td>
        <td>${row.challanData ? `<button class="action-btn action-view" onclick="app.viewDeliveryPlanChallan(${row.id})"><i class="bi bi-eye"></i> View</button>
        <button class="action-btn action-edit delivery-write" onclick="app.editDeliveryPlanChallan(${row.id})"><i class="bi bi-pencil"></i> Edit</button>` : `<button class="action-btn action-view" onclick="app.notify('Viewing: ${this.escapeJsAttr(row.orderNo)}')"><i class="bi bi-eye"></i> View</button>`}
        <button class="action-btn action-delete delivery-delete" onclick="app.confirmDelete('deliveryPlan', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
    }
    this.updateDeliveryStats();
  },

  updateDeliveryStats() {
    const today = new Date();
    const overdue = this.state.deliveryPlan.filter(r => r.status === 'Delayed' || r.status === 'Overdue').length;
    const todayPlan = this.state.deliveryPlan.filter(r => r.expectedDate && r.expectedDate.includes(today.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', timeZone: APP_TIMEZONE }))).length;
    const overdueEl = document.getElementById('del-overdue-count');
    const todayEl = document.getElementById('del-today-count');
    if (overdueEl) overdueEl.innerText = overdue + ' Order' + (overdue !== 1 ? 's' : '');
    if (todayEl) todayEl.innerText = todayPlan + ' Order' + (todayPlan !== 1 ? 's' : '');
  },

  renderDeliveryHist() {
    const tbody = document.getElementById('del-hist-tbody');
    if (!tbody) return;
    // ⚠️ Feature: an archived PI's Delivery Challan entries are hidden from here (visible in Complete Order List)
    const rows = this.state.deliveryHist.filter(row => !this.isArchivedByOrderNo(row.orderNo));
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">No delivery history yet.</td></tr>';
      return;
    }
    tbody.innerHTML = rows.map(row => `
      <tr><td>${formatDate(row.date)}</td><td class="f-mono f-accent">${this.escapeHtml(row.orderNo)}</td><td>${this.escapeHtml(row.buyer)}</td><td>${this.escapeHtml(row.challan)}</td>
      <td>${this.escapeHtml(row.qty)}</td><td>${this.escapeHtml(row.deliveredBy)}</td>
      <td><button class="action-btn action-delete delivery-delete" onclick="app.confirmDelete('deliveryHist', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
  },

  renderQCList() {
    const tbody = document.getElementById('qc-list-tbody');
    if (!tbody) return;
    // ⚠️ Feature: an archived PI's QC reports are hidden from here (visible in Complete Order List)
    const rows = this.state.qcList.filter(row => !this.isArchivedByOrderNo(row.orderNo));
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px">No QC reports yet. Click Add QC Report to create one.</td></tr>';
      return;
    }
    tbody.innerHTML = rows.map(row => `
      <tr><td>${formatDate(row.date)}</td><td class="f-mono f-accent">${this.escapeHtml(row.challan || '')}</td><td class="f-mono f-accent">${this.escapeHtml(row.orderNo)}</td><td>${this.escapeHtml(row.itemCode || '')}</td><td>${this.escapeHtml(row.qcQty)}</td>
      <td>${this.escapeHtml(row.rejectQty)}</td><td>${this.escapeHtml(row.rejectPct)}</td>
      <td><span class="badge badge-${row.result === 'Pass' ? 'g' : 'r'}">${this.escapeHtml(row.result)}</span></td>
      <td><button class="action-btn action-view" onclick="app.viewQCReport(${row.id})"><i class="bi bi-printer"></i> View/Print</button>
      <button class="action-btn action-delete qc-delete" onclick="app.confirmDelete('qcList', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
  },

  renderAccBuyer() {
    const tbody = document.getElementById('acc-buyer-tbody');
    if (!tbody) return;
    // ⚠️ Feature: an archived PI's Buyer Ledger entries are hidden from here (visible in Complete Order List)
    const rows = this.state.accBuyer.filter(row => !this.isArchivedByPiNo(row.piNo));
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:24px">No buyer ledger records yet.</td></tr>';
    } else {
      tbody.innerHTML = rows.map(row => `
        <tr><td class="f-mono f-accent">${this.escapeHtml(row.piNo)}</td><td>${this.escapeHtml(row.buyer)}</td><td>${this.escapeHtml(row.lc)}</td><td>${this.escapeHtml(row.total)}</td>
        <td>${this.escapeHtml(row.received)}</td><td style="color:${this.parseMoney(row.due) > 0 ? 'var(--red)' : 'var(--green)'}">${this.escapeHtml(row.due)}</td>
        <td><span class="badge badge-${row.status === 'Paid' ? 'g' : 'y'}">${this.escapeHtml(row.status)}</span></td>
        <td><button class="action-btn action-edit payment-write" onclick="app.openAddPaymentModal('${this.escapeJsAttr(row.piNo)}')"><i class="bi bi-plus-lg"></i> Add</button>
        <button class="action-btn action-view" onclick="app.viewPaymentHistory('buyer', '${this.escapeJsAttr(row.piNo)}')"><i class="bi bi-clock-history"></i></button>
        <button class="action-btn action-delete accounts-delete" onclick="app.confirmDelete('accBuyer', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
    }
    this.updateAccountsStats();
  },

  updateAccountsStats() {
    // ⚠️ Feature: archived (completed) PIs are also excluded from this summary, so it shows a
    // true picture of only the currently active business
    const activeRows = this.state.accBuyer.filter(r => !this.isArchivedByPiNo(r.piNo));
    const invoiced = activeRows.reduce((s, r) => s + this.parseMoney(r.total), 0);
    const received = activeRows.reduce((s, r) => s + this.parseMoney(r.received), 0);
    const due = activeRows.reduce((s, r) => s + this.parseMoney(r.due), 0);
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = this.formatUSD(val); };
    set('acc-total-invoiced', invoiced);
    set('acc-total-received', received);
    set('acc-total-due', due);
  },

  renderAccSupplier() {
    const tbody = document.getElementById('acc-supp-tbody');
    if (!tbody) return;
    // ⚠️ Feature: an archived PI's linked Supplier Order Ledger entries are hidden from here
    const rows = this.state.accSupplier.filter(row => !this.isArchivedByOrderNo(row.orderNo));
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:24px">No supplier ledger records yet. Save a Supplier Order to auto-create one.</td></tr>';
    } else {
      tbody.innerHTML = rows.map(row => `
        <tr><td>${formatDate(row.date)}</td><td class="f-mono f-accent">${this.escapeHtml(row.orderNo || '-')}</td><td>${this.escapeHtml(row.supplier)}</td><td>${this.escapeHtml(row.total)}</td><td>${this.escapeHtml(row.paid)}</td>
        <td style="color:${this.parseMoney(row.due) > 0 ? 'var(--red)' : 'var(--green)'}">${this.escapeHtml(row.due)}</td>
        <td><span class="badge badge-${this.parseMoney(row.due) <= 0 ? 'g' : 'y'}">${this.parseMoney(row.due) <= 0 ? 'Paid' : 'Due'}</span></td>
        <td><button class="action-btn action-edit payment-write" onclick="app.openAddSupplierPaymentModal('${this.escapeJsAttr(row.orderNo || '')}')"><i class="bi bi-plus-lg"></i> Add</button>
        <button class="action-btn action-view" onclick="app.viewPaymentHistory('supplier', '${this.escapeJsAttr(row.orderNo || '')}')"><i class="bi bi-clock-history"></i></button>
        <button class="action-btn action-delete accounts-delete" onclick="app.confirmDelete('accSupplier', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
    }
    this.updateSupplierAccountsStats();
  },

  updateSupplierAccountsStats() {
    // ⚠️ Feature: an archived PI's linked Supplier Order is also excluded from this summary
    const activeRows = this.state.accSupplier.filter(r => !this.isArchivedByOrderNo(r.orderNo));
    const invoiced = activeRows.reduce((s, r) => s + this.parseMoney(r.total), 0);
    const paid = activeRows.reduce((s, r) => s + this.parseMoney(r.paid), 0);
    const due = activeRows.reduce((s, r) => s + this.parseMoney(r.due), 0);
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = this.formatUSD(val); };
    set('acc-supp-total-invoiced', invoiced);
    set('acc-supp-total-paid', paid);
    set('acc-supp-total-due', due);
  },

  renderExpenseList() {
    const tbody = document.getElementById('exp-list-tbody');
    if (!tbody) return;
    if (!this.state.expenseList.length) {
      tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px">No expenses recorded yet.</td></tr>';
    } else {
      tbody.innerHTML = this.state.expenseList.map(row => {
        const statusCls = row.status === 'Approved' ? 'g' : row.status === 'Rejected' ? 'r' : 'y';
        const isPending = row.status === 'Pending';
        return `
        <tr><td>${formatDate(row.date)}</td><td class="f-mono f-accent">${this.escapeHtml(row.voucherNo)}</td><td><span class="badge badge-b">${this.escapeHtml(row.category)}</span></td>
        <td>${this.escapeHtml(row.person)}</td><td>${this.escapeHtml(row.purpose)}</td><td>${this.esc(row.amount)}</td><td>${this.esc(row.ret)}</td>
        <td><span class="badge badge-${statusCls}" ${row.status === 'Rejected' && row.rejectNote ? `title="${this.escapeHtml(row.rejectNote)}"` : ''}>${this.esc(row.status)}</span></td>
        <td>
        <button class="action-btn action-view" onclick="app.viewExpenseVoucher(${row.id})"><i class="bi bi-eye"></i></button>
        ${isPending ? `<button class="action-btn action-edit expense-approver-only" onclick="app.approveExpenseVoucher(${row.id})"><i class="bi bi-check-lg"></i> Approve</button>
        <button class="action-btn action-delete expense-approver-only" onclick="app.openRejectExpenseModal(${row.id})"><i class="bi bi-x-lg"></i> Reject</button>` : ''}
        <button class="action-btn action-delete expense-delete" onclick="app.confirmDelete('expenseList', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`;
      }).join('');
    }
    this.updateExpenseStats();
  },

  // openAddExpenseModal()/saveExpense() removed -- "+ Add Voucher" is now used instead of "+
  // Add Expense", which goes to the Voucher Entry form (see saveVoucherEntry()), saving
  // straight into Expense List as Pending and going through the Approval workflow.

  // C1: "Basic Expense" = the sum of every expense outside the voucher category (every basic
  // office expense other than Salary) -- only Approved-status entries are counted, so a
  // Pending/Rejected voucher never gets added into the total expense by mistake
  updateExpenseStats() {
    const approved = this.state.expenseList.filter(r => r.status === 'Approved');
    const sumByCategory = (catPred) => approved
      .filter(r => r.category && catPred(r.category.toLowerCase()))
      .reduce((s, r) => s + this.parseMoney(r.amount), 0);
    const basicExpense = approved
      .filter(r => !(r.category && r.category.toLowerCase().includes('voucher')))
      .reduce((s, r) => s + this.parseMoney(r.amount), 0);
    const salary = sumByCategory(cat => cat.includes('salary'));
    const total = approved.reduce((s, r) => s + this.parseMoney(r.amount), 0);
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = CURRENCY_BDT + val.toLocaleString('en-IN'); };
    set('exp-cat-vouchers', basicExpense);
    set('exp-cat-salary', salary);
    set('exp-cat-total', total);
  },

  parseMoney(val) {
    if (val === null || val === undefined || val === '') return 0;
    return parseFloat(String(val).replace(/[^\d.-]/g, '')) || 0;
  },

  // ⚠️ Round 24 -- small amounts (e.g. a unit price of $0.017). Rules used everywhere now:
  //  * a UNIT PRICE may have up to 6 decimals and is kept/printed exactly as typed (0.017 stays 0.017);
  //  * every LINE TOTAL (qty x unit price) is rounded to whole cents (2 decimals) -- the same way
  //    a printed invoice works -- and the grand total is the sum of those rounded lines, so the
  //    lines on a PI/Supplier Order always add up to the printed total;
  //  * ledger/payment amounts are whole cents too (the payment functions in the database round
  //    to 2 decimals), so a stray "$0.002 due" can never be left behind.
  // roundMoney() rounds half-up on the decimal value (1.005 -> 1.01, not 1.00 as plain
  // floating-point arithmetic would give) and removes float noise such as 0.1*3 = 0.30000000000000004.
  roundMoney(n) {
    const v = Number(n);
    if (!Number.isFinite(v)) return 0;
    const sign = v < 0 ? -1 : 1;
    return sign * Math.round(parseFloat((Math.abs(v) * 100).toPrecision(15))) / 100;
  },
  // "$1,234.50" -- always exactly 2 decimals (never "20.978")
  fmtMoney2(n) {
    return '$' + this.roundMoney(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  // ⚠️ Important bug fix: amount >= 1000 used to display abbreviated as "$1.2K", and that
  // abbreviated string was stored directly in the accBuyer/accSupplier ledger. At the next
  // payment, parsing "$1.2K" again with parseMoney() returned 1.2 (not 1234) -- so the ledger's
  // Received/Due/Paid was silently corrupted on every payment ≥$1000. From now on formatUSD
  // always shows the full number (with commas, e.g. "$1,234"), so parsing it again with
  // parseMoney() always returns exactly the original number -- i.e. the format → store → parse
  // cycle is now completely safe (lossless).
  formatUSD(amount) {
    // ⚠️ Bug fix: maximumFractionDigits: 0 used to round away the cents part (e.g. $1,234.99 →
    // "$1,235", then parseMoney("$1,235") → 1235 -- the 99 cents lost forever). Now 2 decimals
    // are always shown, so no money/cents is ever silently lost in the format → store →
    // parseMoney cycle.
    amount = this.roundMoney(Number(amount) || 0);
    return '$' + amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  // Only for showing nicely on the Dashboard's KPI cards (a visual/display-only spot) -- this
  // value is never stored in the database or parsed again with parseMoney later, so
  // abbreviating it is safe
  formatUSDCompact(amount) {
    amount = Number(amount) || 0;
    const sign = amount < 0 ? '-' : '';
    const abs = Math.abs(amount);
    if (abs >= 1000000) return sign + '$' + (abs / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    if (abs >= 1000) return sign + '$' + (abs / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    return sign + '$' + abs.toLocaleString('en-US', { maximumFractionDigits: 0 });
  },

  formatBDT(amount) {
    return CURRENCY_BDT + amount.toLocaleString('en-IN', { maximumFractionDigits: 0 });
  },

  // The Dashboard's KPI numbers now count up when shown -- instead of a plain innerText set,
  // so the software feels more lively and engaging
  animateCounter(id, endValue, formatter) {
    const el = document.getElementById(id);
    if (!el) return;
    const end = Number(endValue) || 0;
    const start = Number(el.dataset.rawValue) || 0;
    if (Math.abs(end - start) < 0.5 && !formatter) { el.innerText = formatter ? formatter(end) : Math.round(end).toLocaleString(); el.dataset.rawValue = end; return; }
    const duration = 550;
    const t0 = performance.now();
    const step = (now) => {
      const progress = Math.min((now - t0) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = start + (end - start) * eased;
      el.innerText = formatter ? formatter(current) : Math.round(current).toLocaleString();
      if (progress < 1) requestAnimationFrame(step);
      else { el.dataset.rawValue = end; el.innerText = formatter ? formatter(end) : Math.round(end).toLocaleString(); }
    };
    requestAnimationFrame(step);
  },

  updateDashboard() {
    this.updateDashboardWidget();
    const today = todayStr();
    const todayDeliveries = this.state.deliveryHist.filter(r => {
      const d = new Date(r.date);
      return !isNaN(d) && d.toISOString().split('T')[0] === today;
    }).length + this.state.deliveryExec.filter(r => r.date === today || String(r.date).includes(today)).length;
    const overdue = this.state.deliveryPlan.filter(r => r.status === 'Delayed' || r.status === 'Overdue').length;
    const pending = this.state.deliveryPlan.filter(r => r.status === 'Planned' || r.status === 'Pending').length;
    const threshold = 500;
    const lowStock = this.state.masterData.filter(r => this.parseMoney(r.stock) < threshold).length;
    const buyerDue = this.state.accBuyer.reduce((s, r) => s + this.parseMoney(r.due), 0);
    const supplierDue = this.state.accSupplier.reduce((s, r) => s + this.parseMoney(r.due), 0);
    const month = new Date().getMonth();
    const year = new Date().getFullYear();
    const monthlySales = this.state.piList.reduce((s, r) => {
      const d = new Date(r.date);
      // ⚠️ Bug fix: even with an invalid/empty date, that PI's value used to get added into
      // this month's sales anyway (the line below mistakenly had "+ this.parseMoney(...)") --
      // it is now correctly excluded.
      if (isNaN(d)) return s;
      if (d.getMonth() === month && d.getFullYear() === year) return s + this.parseMoney(r.totalValue);
      return s;
    }, 0);
    const monthlyExpense = this.state.expenseList.reduce((s, r) => {
      const d = new Date(r.date);
      if (!isNaN(d) && d.getMonth() === month && d.getFullYear() === year) return s + this.parseMoney(r.amount);
      return s;
    }, 0);

    // ===== Total Profit (This Month) =====
    // Profit = this month's PI Sales − this month's Supplier Order Cost (both tracked in USD,
    // so subtracting directly is safe). Office Expense is tracked separately in ৳, so it's
    // deliberately not added into this figure to avoid a wrong currency conversion -- it's
    // shown separately in the "Monthly Expense" widget.
    const monthlySupplierCost = (this.state.supplierOrders || []).reduce((s, r) => {
      const d = new Date(r.date);
      if (!isNaN(d) && d.getMonth() === month && d.getFullYear() === year) return s + this.parseMoney(r.totalValue);
      return s;
    }, 0);
    const monthlyProfit = monthlySales - monthlySupplierCost;
    const profitMargin = monthlySales > 0 ? (monthlyProfit / monthlySales) * 100 : 0;

    // Comparison with last month (smart trend indicator)
    const lastMonthDate = new Date(year, month - 1, 1);
    const lastMonthSales = this.state.piList.reduce((s, r) => {
      const d = new Date(r.date);
      if (!isNaN(d) && d.getMonth() === lastMonthDate.getMonth() && d.getFullYear() === lastMonthDate.getFullYear()) return s + this.parseMoney(r.totalValue);
      return s;
    }, 0);
    const lastMonthCost = (this.state.supplierOrders || []).reduce((s, r) => {
      const d = new Date(r.date);
      if (!isNaN(d) && d.getMonth() === lastMonthDate.getMonth() && d.getFullYear() === lastMonthDate.getFullYear()) return s + this.parseMoney(r.totalValue);
      return s;
    }, 0);
    const lastMonthProfit = lastMonthSales - lastMonthCost;

    const setText = (id, text) => { const el = document.getElementById(id); if (el) el.innerText = text; };
    this.animateCounter('dash-today-deliveries', todayDeliveries);
    setText('dash-today-deliveries-sub', todayDeliveries ? `${todayDeliveries} logged today` : 'No deliveries today');
    this.animateCounter('dash-overdue', overdue);
    this.animateCounter('dash-pending', pending);
    setText('dash-pending-sub', pending ? `${pending} in plan` : 'None pending');
    this.animateCounter('dash-low-stock', lowStock);
    this.animateCounter('dash-total-due', buyerDue, v => this.formatUSDCompact(v));
    this.animateCounter('dash-supplier-due', supplierDue, v => this.formatUSDCompact(v));
    this.animateCounter('dash-monthly-sales', monthlySales, v => this.formatUSDCompact(v));
    this.animateCounter('dash-monthly-expense', monthlyExpense, v => this.formatBDT(v));
    this.animateCounter('dash-monthly-profit', monthlyProfit, v => this.formatUSDCompact(v));
    const profitEl = document.getElementById('dash-monthly-profit');
    if (profitEl) profitEl.style.color = monthlyProfit >= 0 ? 'var(--green)' : 'var(--red)';
    const profitSubEl = document.getElementById('dash-monthly-profit-sub');
    if (profitSubEl) {
      let trendTxt = '';
      if (lastMonthProfit !== 0) {
        const change = ((monthlyProfit - lastMonthProfit) / Math.abs(lastMonthProfit)) * 100;
        trendTxt = ` <span style="color:${change >= 0 ? 'var(--green)' : 'var(--red)'}"><i class="bi bi-arrow-${change >= 0 ? 'up' : 'down'}-short"></i>${Math.abs(change).toFixed(0)}% vs last month</span>`;
      }
      profitSubEl.innerHTML = `${profitMargin.toFixed(1)}% margin${trendTxt}`;
    }
    const marginBadge = document.getElementById('dash-profit-margin-badge');
    if (marginBadge) {
      marginBadge.innerText = `${profitMargin.toFixed(0)}% Margin`;
      marginBadge.className = `badge ${monthlyProfit >= 0 ? 'badge-g' : 'badge-r'}`;
    }

    const piBadge = document.getElementById('nav-pi-badge');
    const expBadge = document.getElementById('nav-expense-badge');
    const piCount = this.state.piList.length;
    const expCount = this.state.expenseList.length;
    if (piBadge) { piBadge.innerText = piCount; piBadge.style.display = piCount ? '' : 'none'; }
    if (expBadge) { expBadge.innerText = expCount; expBadge.style.display = expCount ? '' : 'none'; }

    this.updateDeliveryStats();
    this.updateExpenseStats();
    this.updateAccountsStats();
  },

  // ⚠️ Feature (D2 replacement): there used to be an Automated 5-star Rating here (calculated
  // from Punctuality + Overtime). At the user's request, the Star Rating was removed entirely
  // and replaced with a professional "Attendance Summary" (Present/Late/In Leave/Absent),
  // which resets automatically on the 1st of every month (since it's only calculated from the
  // current calendar month's records).
  //
  // "Absent" (unauthorised absence) is never stored as an explicit status in hrAttendance --
  // any day with no entry at all (Check-In/Leave) is treated as absence. So the total days from
  // the start of the month (or the employee's Join Date, whichever is later) to today are
  // counted, and Present+Late+On Leave are subtracted from that. There is no weekly-off/holiday
  // calendar configured in this app, so this is a simple approximation -- if excluding a
  // specific weekly off day is needed, a "Weekly Off Day" setting like Office Hours could be
  // added in future to make this more accurate.
  computeEmployeeMonthlySummary(employeeName, employeeJoinDate) {
    const ym = todayStr().slice(0, 7); // "YYYY-MM" -- the current month
    const records = this.state.hrAttendance.filter(r => r.employee === employeeName && (r.date || '').startsWith(ym));
    const present = records.filter(r => r.status === 'Present').length;
    const late = records.filter(r => r.status === 'Late').length;
    const leave = records.filter(r => r.status === 'On Leave').length;

    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    let countFrom = monthStart;
    if (employeeJoinDate) {
      const jd = new Date(employeeJoinDate + 'T00:00:00');
      if (!isNaN(jd) && jd > monthStart) countFrom = jd;
    }
    const elapsedDays = Math.max(0, Math.floor((now - countFrom) / (1000 * 60 * 60 * 24)) + 1);
    const absent = Math.max(0, elapsedDays - present - late - leave);

    return { present, late, leave, absent };
  },

  // Runs when the calendar icon in the Employees list's "History" column is clicked -- shows
  // that employee's complete past attendance record (Historical Attendance Log) in a modal,
  // with the current month's summary (Present/Late/In Leave/Absent) shown above as cards
  viewEmployeeAttendanceHistory(employeeId) {
    const emp = this.state.hrEmployees.find(e => e.id === employeeId);
    if (!emp) return;
    document.getElementById('emp-att-modal-title').innerText = `${emp.name} — Attendance History`;
    const records = [...this.state.hrAttendance]
      .filter(r => r.employee === emp.name)
      .sort((a, b) => (b.date || '').localeCompare(a.date || ''));
    const summary = this.computeEmployeeMonthlySummary(emp.name, emp.joinDate);
    document.getElementById('emp-att-summary-cards').innerHTML = `
      <div class="card" style="padding:10px;text-align:center;border-left:3px solid var(--green)"><div class="w-title">Present</div><div class="w-value" style="font-size:18px;color:var(--green)">${summary.present}</div></div>
      <div class="card" style="padding:10px;text-align:center;border-left:3px solid var(--yellow)"><div class="w-title">Late</div><div class="w-value" style="font-size:18px;color:var(--yellow)">${summary.late}</div></div>
      <div class="card" style="padding:10px;text-align:center;border-left:3px solid var(--accent)"><div class="w-title">In Leave</div><div class="w-value" style="font-size:18px;color:var(--accent)">${summary.leave}</div></div>
      <div class="card" style="padding:10px;text-align:center;border-left:3px solid var(--red)"><div class="w-title">Absent</div><div class="w-value" style="font-size:18px;color:var(--red)">${summary.absent}</div></div>`;
    const tbody = document.getElementById('emp-att-history-tbody');
    if (!records.length) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:20px">No attendance record yet</td></tr>';
    } else {
      tbody.innerHTML = records.map(r => `
        <tr><td>${formatDate(r.date)}</td><td>${this.esc(r.checkIn || '-')}</td><td>${this.esc(r.checkOut || '-')}</td>
        <td><span class="badge badge-${r.status === 'Present' ? 'g' : r.status === 'Late' ? 'y' : r.status === 'Absent' ? 'r' : 'b'}">${this.escapeHtml(r.status)}</span></td>
        <td>${r.otHours ? r.otHours + ' hrs' : '-'}</td></tr>`).join('');
    }
    this.open('view-employee-attendance-modal');
  },

  // ⚠️ Feature: a search (name/Designation/NID) and status filter were added above the
  // Employees list -- as the number of employees grows, this helps find someone specific
  // quickly. An "Active/Inactive" toggle button was also added (there used to be nowhere at
  // all to change this status -- the only way to make a resigned/dismissed employee Inactive
  // was Delete, which risked losing their history/linked Attendance-Salary records too).
  renderHREmployees() {
    const tbody = document.getElementById('hr-list-tbody');
    if (!tbody) return;
    if (!this.state.hrEmployees.length) {
      tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px">No employees yet. Add one from HR Settings.</td></tr>';
      return;
    }
    const searchEl = document.getElementById('hr-emp-search');
    const statusEl = document.getElementById('hr-emp-status-filter');
    const q = searchEl ? searchEl.value.trim().toLowerCase() : '';
    const statusFilter = statusEl ? statusEl.value : '';
    let rows = this.state.hrEmployees;
    if (q) {
      rows = rows.filter(r => [r.name, r.designation, r.nid].some(v => (v || '').toLowerCase().includes(q)));
    }
    if (statusFilter) rows = rows.filter(r => (r.status || 'Active') === statusFilter);

    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px">No employee matches the search</td></tr>';
      return;
    }
    // ⚠️ Feature: Add/Edit/Activate-Deactivate/Delete can now only be done from HR Settings (at
    // the user's request) -- this list is now view-only, keeping just the "History" button (for
    // viewing Attendance).
    tbody.innerHTML = rows.map(row => {
      const s = this.computeEmployeeMonthlySummary(row.name, row.joinDate);
      const isActive = (row.status || 'Active') === 'Active';
      return `
      <tr><td>${row.photo ? `<img src="${this.escapeHtml(this.safeImageSrc(row.photo))}" alt="${this.escapeHtml(row.name)}" style="width:32px;height:32px;object-fit:cover;border-radius:50%;border:1px solid var(--border)">` : `<span style="color:var(--text-dim)"><i class="bi bi-person-circle"></i></span>`}</td>
      <td>${this.escapeHtml(row.name)}</td><td>${this.escapeHtml(row.designation)}</td><td>${this.escapeHtml(row.nid || '-')}</td><td>${this.escapeHtml(row.contact)}</td><td>${formatDate(row.joinDate)}</td>
      <td><div style="display:flex;gap:4px;flex-wrap:wrap;">
        <span class="badge badge-g" title="Present">P: ${s.present}</span>
        <span class="badge badge-y" title="Late">L: ${s.late}</span>
        <span class="badge badge-b" title="In Leave (approved leave)">Lv: ${s.leave}</span>
        <span class="badge badge-r" title="Absent (unauthorised absence)">Ab: ${s.absent}</span>
      </div></td>
      <td style="text-align:center"><button class="action-btn action-view" onclick="app.viewEmployeeAttendanceHistory(${row.id})" title="View full attendance history"><i class="bi bi-calendar3"></i></button></td>
      <td><span class="badge badge-${isActive ? 'g' : 'r'}">${this.esc(row.status || 'Active')}</span></td></tr>`;
    }).join('');
  },

  // ⚠️ Feature: HR Settings modal's own Employees panel -- Add/Edit/Activate-Deactivate/Delete
  // are done here (the main HR Module > Employees tab is now view-only, see renderHREmployees()
  // above)
  renderHRSettingsEmployees() {
    const tbody = document.getElementById('hrset-employees-tbody');
    if (!tbody) return;
    if (!this.state.hrEmployees.length) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:24px">No employees yet. Click Add Employee to create one.</td></tr>';
      return;
    }
    tbody.innerHTML = this.state.hrEmployees.map(row => {
      const isActive = (row.status || 'Active') === 'Active';
      return `
      <tr><td>${this.escapeHtml(row.name)}</td><td>${this.escapeHtml(row.designation)}</td><td>${this.escapeHtml(row.department || '-')}</td>
      <td>${this.escapeHtml(row.salaryAccountNo || '-')}</td>
      <td><span class="badge badge-${isActive ? 'g' : 'r'}">${this.esc(row.status || 'Active')}</span></td>
      <td><button class="action-btn action-edit hr-write" onclick="app.editEmployee(${row.id})"><i class="bi bi-pencil"></i> Edit</button>
      <button class="action-btn ${isActive ? 'action-delete' : 'action-edit'} admin-only" onclick="app.toggleEmployeeStatus(${row.id})" title="${isActive ? 'Make Inactive if the employee has left/been dismissed' : 'Make active again'}"><i class="bi bi-${isActive ? 'person-dash' : 'person-check'}"></i> ${isActive ? 'Deactivate' : 'Activate'}</button>
      <button class="action-btn action-delete hr-delete" onclick="app.confirmDelete('hrEmployees', ${row.id})"><i class="bi bi-trash"></i> Delete</button></td></tr>`;
    }).join('');
  },

  // Opens the HR Settings modal + refreshes every tab's data
  openHRSettingsModal() {
    this.renderHRSettingsEmployees();
    this.renderHRSignaturesList();
    this.renderHRDepartments();
    this.populateEmployeeDepartmentDropdown();
    this.loadOTSettingsToForm();
    this.renderSignaturePreviews();
    this.open('hr-settings-modal');
  },

  // Toggles an Employee Active ⇄ Inactive (without deleting) -- this keeps old
  // Attendance/Salary/PI references (like "Delivered By") intact, they just get left out of
  // dropdowns for new Check-In/Leave/Salary (wherever applicable). ⚠️ Now goes through the HR
  // Settings approval workflow -- deactivating/activating from the 'admin' role needs Super
  // Admin confirmation.
  async toggleEmployeeStatus(id) {
    const emp = this.state.hrEmployees.find(r => r.id === id);
    if (!emp) return;
    const current = emp.status || 'Active';
    const newStatus = current === 'Active' ? 'Inactive' : 'Active';
    if (newStatus === 'Inactive' && !confirm(`Make ${emp.name} Inactive? They will no longer show in lists for new Check-In/Leave/User Account, but every old record (Attendance/Salary) stays intact and they can be made Active again any time if needed.`)) return;
    await this.submitHRChange('employee_status', `${emp.name} → ${newStatus}`, { id, name: emp.name, newStatus });
  },

  // ⚠️ Feature: the Attendance Log shows only the selected single day's (default: today)
  // report by default -- it used to mix every date's records together, which grew longer every
  // day and hurt usability. Any specific day can be chosen from the "att-log-filter-date" input
  // above, or clicking "Show All" clears the filter to see the full history again (the old
  // behaviour, kept deliberately as an option).
  renderHRAttendance() {
    const tbody = document.getElementById('hr-attendance-tbody');
    if (!tbody) return;
    const filterEl = document.getElementById('att-log-filter-date');
    // If the filter input is empty the first time, "today" is set as the default (per the request to stay on a single day's report)
    if (filterEl && !filterEl.value && !filterEl.dataset.cleared) filterEl.value = todayStr();
    const filterDate = filterEl ? filterEl.value : '';
    // ⚠️ Feature: the Attendance Log can now be filtered by a specific employee as well as by
    // date -- with many employees, this makes finding someone's history (across several days)
    // easier
    const empFilterEl = document.getElementById('att-log-filter-employee');
    const filterEmployee = empFilterEl ? empFilterEl.value : '';

    if (!this.state.hrAttendance.length) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">No attendance records yet.</td></tr>';
      return;
    }
    // Sorted with the most recent date first, then filtered by the selected date/employee if needed
    let sorted = [...this.state.hrAttendance].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
    if (filterDate) sorted = sorted.filter(r => r.date === filterDate);
    if (filterEmployee) sorted = sorted.filter(r => r.employee === filterEmployee);

    if (!sorted.length) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">${filterDate || filterEmployee ? 'No attendance record matches the selected filter' : 'No attendance records yet.'}</td></tr>`;
      return;
    }
    tbody.innerHTML = sorted.map(row => `
      <tr><td>${formatDate(row.date)}</td><td>${this.escapeHtml(row.employee)}</td><td>${this.esc(row.checkIn || '-')}</td><td>${this.esc(row.checkOut || '-')}</td>
      <td><span class="badge badge-${row.status === 'Present' ? 'g' : row.status === 'Late' ? 'y' : row.status === 'Absent' ? 'r' : 'b'}">${this.esc(row.status)}</span></td>
      <td>${row.otHours ? row.otHours + ' hrs' : '-'}</td>
      <td>${!row.checkOut && row.checkIn ? `<button class="action-btn action-edit hr-write" onclick="app.openCheckOutModal(${row.id})"><i class="bi bi-box-arrow-right"></i> Check Out</button>` : ''}
      <button class="action-btn action-delete hr-delete" onclick="app.confirmDelete('hrAttendance', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
  },

  // Clicking "Show All" clears both the date and employee filters, showing the full history again
  resetAttendanceLogFilter() {
    const filterEl = document.getElementById('att-log-filter-date');
    if (filterEl) { filterEl.value = ''; filterEl.dataset.cleared = '1'; }
    const empFilterEl = document.getElementById('att-log-filter-employee');
    if (empFilterEl) empFilterEl.value = '';
    this.renderHRAttendance();
  },

  // ⚠️ Feature: the Salary table now shows a "Month" column (most recent first), and the
  // "sal-filter-month" dropdown above lets a specific month's Salary records be filtered and
  // viewed separately (same pattern as Attendance Log, to make finding things easier in a
  // growing list).
  renderHRSalary() {
    const tbody = document.getElementById('hr-salary-tbody');
    if (!tbody) return;
    const monthFilterEl = document.getElementById('sal-filter-month');
    if (monthFilterEl) {
      const months = [...new Set(this.state.hrSalary.map(r => r.month).filter(Boolean))].sort().reverse();
      const currentFilter = monthFilterEl.value;
      monthFilterEl.innerHTML = '<option value="">All months</option>' + months.map(m => `<option value="${m}">${formatMonthLabel(m)}</option>`).join('');
      if (currentFilter) monthFilterEl.value = currentFilter;
    }
    if (!this.state.hrSalary.length) {
      tbody.innerHTML = '<tr><td colspan="10" style="text-align:center;color:var(--text-muted);padding:24px">No salary records yet. Click Process Salary to create one.</td></tr>';
      return;
    }
    const filterMonth = monthFilterEl ? monthFilterEl.value : '';
    let rows = [...this.state.hrSalary].sort((a, b) => (b.month || '').localeCompare(a.month || '') || (a.employee || '').localeCompare(b.employee || ''));
    if (filterMonth) rows = rows.filter(r => r.month === filterMonth);
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="10" style="text-align:center;color:var(--text-muted);padding:24px">No Salary record for the selected month</td></tr>';
      return;
    }
    tbody.innerHTML = rows.map(row => `
      <tr><td>${this.escapeHtml(row.employee)}</td><td>${row.month ? formatMonthLabel(row.month) : '-'}</td><td>${this.escapeHtml(row.designation || '-')}</td><td>${this.esc(row.basic)}</td><td>${this.esc(row.otHours || 0)}</td><td>${this.esc(row.ot)}</td><td>${this.esc(row.deduction)}</td><td>${this.esc(row.net)}</td>
      <td><span class="badge badge-${row.status === 'Paid' ? 'g' : 'y'}">${this.esc(row.status)}</span></td>
      <td><button class="action-btn action-edit hr-write" onclick="app.toggleSalaryStatus(${row.id})">${row.status === 'Paid' ? 'Mark Pending' : 'Mark Paid'}</button>
      <button class="action-btn action-delete hr-delete" onclick="app.confirmDelete('hrSalary', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
  },

  openProcessSalaryModal() {
    const select = document.getElementById('sal-employee');
    // ⚠️ Inactive employees are also shown here (but labelled) -- because a final month's
    // settlement may still need processing even after they've left/been dismissed
    select.innerHTML = '<option value="">Select Employee...</option>' +
      this.state.hrEmployees.map(e => `<option value="${this.escapeHtml(e.name)}" data-designation="${this.escapeHtml(e.designation || '')}" data-basic="${e.basicSalary || 0}">${this.escapeHtml(e.name)}${(e.status || 'Active') === 'Inactive' ? ' (Inactive)' : ''}</option>`).join('');
    ['sal-designation', 'sal-basic', 'sal-ot-hours', 'sal-ot-rate', 'sal-ot-pay', 'sal-deduction', 'sal-net'].forEach(id => { document.getElementById(id).value = ''; });
    // The current month is set as the default -- the user can still process an earlier month if they want
    document.getElementById('sal-month').value = todayStr().slice(0, 7);
    this.open('process-salary-modal');
  },

  // Selecting an employee auto-fills their Designation and Basic Salary, and calculates OT
  // Hours for the selected Salary Month
  // ⚠️ Feature (new OT Rate system in HR Settings): OT Rate (৳/hour) used to need typing in by
  // hand here every time. It's now set automatically from HR Settings' Standard Working Hours
  // and OT Multiplier (%), based on the employee's own Basic Salary (see
  // computeStandardOTRate()) -- the user can still change it manually for an exceptional
  // case.
  autofillSalaryEmployee() {
    const select = document.getElementById('sal-employee');
    const opt = select.options[select.selectedIndex];
    if (!opt || !opt.value) return;
    document.getElementById('sal-designation').value = opt.dataset.designation || '';
    document.getElementById('sal-basic').value = opt.dataset.basic || 0;
    document.getElementById('sal-ot-rate').value = this.computeStandardOTRate(Number(opt.dataset.basic) || 0).toFixed(2);
    this.recalcSalaryOtHours();
  },

  // ⚠️ Bug fix (HR Module -- wrong OT Hours calculation): this function used to sum every OT
  // Hour from an employee's entire Attendance history (across every month), so each month's
  // Salary Process kept re-adding earlier months' (already-paid) OT Hours too -- Net Salary
  // kept incorrectly growing every month. OT Hours is now calculated only from the selected
  // "Salary Month"'s Attendance records, so each month's OT is separate and correct.
  recalcSalaryOtHours() {
    const employee = document.getElementById('sal-employee').value;
    const month = document.getElementById('sal-month').value;
    if (!employee) return;
    const totalOtHours = this.state.hrAttendance
      .filter(r => r.employee === employee && month && (r.date || '').startsWith(month))
      .reduce((s, r) => s + (parseFloat(r.otHours) || 0), 0);
    document.getElementById('sal-ot-hours').value = totalOtHours.toFixed(2);
    this.calcSalaryNet();
  },

  // OT Hours × OT Rate = OT Pay, then Basic + OT Pay - Deduction = Net Salary -- everything calculated automatically
  calcSalaryNet() {
    const basic = parseFloat(document.getElementById('sal-basic').value) || 0;
    const otHours = parseFloat(document.getElementById('sal-ot-hours').value) || 0;
    const otRate = parseFloat(document.getElementById('sal-ot-rate').value) || 0;
    const deduction = parseFloat(document.getElementById('sal-deduction').value) || 0;
    const otPay = otHours * otRate;
    const net = basic + otPay - deduction;
    document.getElementById('sal-ot-pay').value = otPay.toFixed(2);
    document.getElementById('sal-net').value = net.toFixed(2);
  },

  async saveSalary() {
    const employee = document.getElementById('sal-employee').value;
    const month = document.getElementById('sal-month').value;
    const designation = document.getElementById('sal-designation').value;
    const basic = parseFloat(document.getElementById('sal-basic').value) || 0;
    const otHours = parseFloat(document.getElementById('sal-ot-hours').value) || 0;
    const otPay = parseFloat(document.getElementById('sal-ot-pay').value) || 0;
    const deduction = parseFloat(document.getElementById('sal-deduction').value) || 0;
    const net = parseFloat(document.getElementById('sal-net').value) || 0;
    if (!employee) { this.notify('Select an Employee', 'warn'); return; }
    if (!month) { this.notify('Select a Salary Month', 'warn'); return; }

    // ⚠️ Feature: warns if the same employee's Salary for the same month is already
    // processed -- this stops an accidental duplicate entry (there's no way to edit a Salary
    // record, so if a correction is needed the user is advised to Delete the old one and
    // Process again correctly)
    const dup = this.state.hrSalary.find(r => r.employee === employee && r.month === month);
    if (dup && !confirm(`${employee}'s Salary for ${formatMonthLabel(month)} has already been processed (Status: ${dup.status}). Processing again will create a duplicate entry. Continue anyway?`)) return;

    const newId = await this.allocId('hrSalary');
    this.state.hrSalary.push({ id: newId, employee, month, designation, basic, otHours, ot: otPay, deduction, net, status: 'Pending' });
    this.logAudit('Create', 'hrSalary', newId, `${employee} — ${formatMonthLabel(month)}`);
    await this.persistSheet('hrSalary');
    this.notify('Salary Processed');
    this.renderHRSalary();
    this.close('process-salary-modal');
  },

  renderUsers() {
    const tbody = document.getElementById('users-tbody');
    if (!tbody) return;
    if (!this.state.users.length) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">No users created yet.</td></tr>';
      return;
    }
    // Round 21: the Permissions column now shows a short summary of "which modules have what
    // access" from profiles.permissions, instead of a legacy text tag
    const MOD_LABELS = { dashboard: 'Dashboard', inventory: 'Inventory', delivery: 'Delivery', qc: 'QC', accounts: 'Accounts', expense: 'Expense', hr: 'HR', bsinfo: 'B&S Info', datasafety: 'Data Safety', users: 'Users', settings: 'Settings' };
    const summarizePerms = (username, role) => {
      if (role === 'superadmin') return '<span class="badge badge-g">Everything (Super Admin)</span>';
      const profile = this.profiles.find(p => p.username === username);
      const perms = (profile && profile.permissions) || {};
      const parts = Object.keys(MOD_LABELS).filter(m => perms[m] && perms[m].view).map(m => {
        const p = perms[m];
        const tags = ['write','delete','approve','export'].filter(a => p[a]);
        return this.escapeHtml(MOD_LABELS[m]) + (tags.length ? `<small style="opacity:.6"> (${tags.join('/')})</small>` : '');
      });
      return parts.length ? parts.join(', ') : '<span style="color:var(--text-dim)">No module access</span>';
    };
    tbody.innerHTML = this.state.users.map(row => `
      <tr><td>${this.esc(row.username || '')}</td><td>${this.esc(row.name || '')}</td><td>${this.esc(row.role || '')}</td><td style="font-size:10.5px;max-width:280px;">${summarizePerms(row.username, row.role)}</td><td>${this.esc(row.lastLogin || '')}</td>
      <td><span class="badge badge-${row.status === 'Active' ? 'g' : 'y'}">${this.esc(row.status || 'Inactive')}</span></td>
      <td><button class="action-btn action-edit superadmin-only" onclick="app.editUser(${row.id})"><i class="bi bi-pencil"></i></button>
      <button class="action-btn action-delete superadmin-only" onclick="app.confirmDelete('users', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
  },

  renderBuyers() {
    const tbody = document.getElementById('bs-buyer-tbody');
    if (!tbody) return;
    // ⚠️ Bug fix: the datalist refresh used to happen after the if-block, so when buyers
    // became empty (every buyer deleted), old/deleted names stayed suggested in the PI form and
    // Delivery Challan's Buyer Name datalist.
    this.populatePIBuyerList();
    const challanDl = document.getElementById('challan-buyer-list');
    if (challanDl) challanDl.innerHTML = this.state.buyers.map(b => `<option value="${this.escapeHtml(b.name)}">`).join('');
    if (!this.state.buyers.length) {
      tbody.innerHTML = '<tr><td colspan="16" style="text-align:center;color:var(--text-muted);padding:24px">No buyers yet.</td></tr>';
      return;
    }
    tbody.innerHTML = this.state.buyers.map(row => `
      <tr><td>${row.logo ? `<img src="${this.escapeHtml(this.safeImageSrc(row.logo))}" alt="${this.escapeHtml(row.name)}" style="width:32px;height:32px;object-fit:cover;border-radius:6px;border:1px solid var(--border)">` : `<span style="color:var(--text-dim)"><i class="bi bi-building"></i></span>`}</td>
      <td>${this.escapeHtml(row.name)}</td><td>${this.escapeHtml(row.contactPerson || '-')}</td><td>${this.escapeHtml(row.address)}</td><td>${this.esc(row.mobile)}</td><td>${this.esc(row.email)}</td><td>${this.esc(row.country)}</td>
      <td>${this.esc(row.bankAccount || '-')}</td><td>${this.escapeHtml(row.bankName || '-')}</td><td>${this.escapeHtml(row.bankBranch || '-')}</td><td>${this.esc(row.bin || '-')}</td><td>${this.esc(row.swift || '-')}</td><td>${this.esc(row.outsideMerchandiser || '-')}</td>
      <td>${this.esc(row.orders)}</td><td><span class="badge badge-g">${this.esc(row.status)}</span></td>
      <td><button class="action-btn action-delete bsinfo-delete" onclick="app.confirmDelete('buyers', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
  },

  // Typing/selecting a Buyer Name in Delivery Center > Challan Generator auto-fills Contact
  // Person and Address from the Buyer Directory (still editable if needed)
  autofillChallanBuyer(name) {
    const buyer = (this.state.buyers || []).find(b => (b.name || '').toLowerCase() === name.trim().toLowerCase());
    if (!buyer) return;
    const set = (id, val) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.value = val || '';
      el.classList.add('autofill-field');
      setTimeout(() => el.classList.remove('autofill-field'), 1500);
    };
    set('challan-contact', buyer.contactPerson || '');
    set('challan-address', buyer.address || '');
    this.notify(`Auto-filled: ${buyer.name}`);
  },

  renderSuppliers() {
    const tbody = document.getElementById('bs-supplier-tbody');
    if (!tbody) return;
    // A datalist for auto-suggest on the Supplier Order Sheet's Supplier field -- learning
    // from the earlier bug, this line is deliberately kept before the if-block so it still
    // works even when the list becomes empty
    const soSupplierDl = document.getElementById('so-supplier-list');
    if (soSupplierDl) soSupplierDl.innerHTML = this.state.suppliers.map(s => `<option value="${this.escapeHtml(s.name)}">`).join('');
    if (!this.state.suppliers.length) {
      tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;color:var(--text-muted);padding:24px">No suppliers yet.</td></tr>';
      return;
    }
    tbody.innerHTML = this.state.suppliers.map(row => `
      <tr><td>${row.logo ? `<img src="${this.escapeHtml(this.safeImageSrc(row.logo))}" alt="${this.escapeHtml(row.name)}" style="width:32px;height:32px;object-fit:cover;border-radius:6px;border:1px solid var(--border)">` : `<span style="color:var(--text-dim)"><i class="bi bi-building"></i></span>`}</td>
      <td>${this.escapeHtml(row.name)}</td><td>${this.escapeHtml(row.contactPerson || '-')}</td><td>${this.escapeHtml(row.address)}</td><td>${this.esc(row.mobile)}</td><td>${this.esc(row.bin || '-')}</td><td>${this.esc(row.bankAcc)}</td><td>${this.esc(row.bank)}</td>
      <td>${this.esc(row.supply)}</td><td><span class="badge badge-${row.status === 'Active' ? 'g' : 'y'}">${this.esc(row.status)}</span></td>
      <td><button class="action-btn action-delete bsinfo-delete" onclick="app.confirmDelete('suppliers', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
  },

  async handleBuyerLogoUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { this.notify('Please upload an image file only', 'warn'); return; }
    try {
      const dataUrl = await this.resizeImageToDataURL(file, 150, 150, 0.7);
      document.getElementById('buyer-logo-data').value = dataUrl;
      document.getElementById('buyer-logo-preview').innerHTML = `<img src="${dataUrl}" alt="Preview">`;
    } catch (e) {
      this.notify('Problem processing the logo', 'error');
    }
  },

  async handleSupplierLogoUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { this.notify('Please upload an image file only', 'warn'); return; }
    try {
      const dataUrl = await this.resizeImageToDataURL(file, 150, 150, 0.7);
      document.getElementById('supplier-logo-data').value = dataUrl;
      document.getElementById('supplier-logo-preview').innerHTML = `<img src="${dataUrl}" alt="Preview">`;
    } catch (e) {
      this.notify('Problem processing the logo', 'error');
    }
  },

  handleLogoUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    if (!['image/png','image/jpeg','image/jpg','image/svg+xml','image/gif'].includes(file.type)) { this.notify('Invalid format', 'warn'); return; }
    if (file.size > 2 * 1024 * 1024) { this.notify('Max 2MB', 'warn'); return; }
    const reader = new FileReader();
    reader.onload = (e) => {
      this.companyLogo = e.target.result;
      localStorage.setItem('gp_logo', e.target.result);
      this.updateLogoDisplay(e.target.result);
      this.notify('Logo uploaded');
    };
    reader.readAsDataURL(file);
  },

  loadLogoFromURL(url) {
    if (!url) return;
    const img = new Image();
    img.onload = () => { this.companyLogo = url; localStorage.setItem('gp_logo', url); this.updateLogoDisplay(url); this.notify('Logo loaded'); };
    img.onerror = () => this.notify('Failed to load logo', 'error');
    img.src = url;
  },

  updateLogoDisplay(src) {
    if (!src) return;
    document.getElementById('sidebar-logo-icon').innerHTML = `<img src="${src}" alt="Logo">`;
    document.getElementById('logo-preview-box').innerHTML = `<img src="${src}" alt="Preview">`;
    const piLogo = document.getElementById('pi-logo-img');
    if (piLogo) { piLogo.src = src; piLogo.style.display = 'block'; }
    const challanLogo = document.getElementById('challan-logo-img');
    if (challanLogo) { challanLogo.src = src; challanLogo.style.display = 'block'; }
  },

  // Converts an uploaded image/signature file into a small JPEG thumbnail -- because a single
  // Google Sheets cell holds around 50,000 characters at most, so saving a large image directly
  // as base64 would fail Sheets sync. This function resizes the image within maxW x maxH and
  // lowers the JPEG quality to produce a safely small data URL.
  resizeImageToDataURL(file, maxW, maxH, quality) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          let w = img.width, h = img.height;
          const ratio = Math.min(maxW / w, maxH / h, 1);
          w = Math.round(w * ratio); h = Math.round(h * ratio);
          const canvas = document.createElement('canvas');
          canvas.width = w; canvas.height = h;
          const ctx = canvas.getContext('2d');
          ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h); // fills transparency with white for JPEG
          ctx.drawImage(img, 0, 0, w, h);
          resolve(canvas.toDataURL('image/jpeg', quality || 0.7));
        };
        img.onerror = () => reject(new Error('Could not load the image'));
        img.src = e.target.result;
      };
      reader.onerror = () => reject(new Error('Could not read the file'));
      reader.readAsDataURL(file);
    });
  },

  initBgParticles() {
    const canvas = document.getElementById('bg-canvas');
    const ctx = canvas.getContext('2d');
    let particles = [];
    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize(); window.addEventListener('resize', resize);
    for (let i = 0; i < 50; i++) particles.push({ x: Math.random() * canvas.width, y: Math.random() * canvas.height, vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.3, s: Math.random() * 1.5 + 0.5, o: Math.random() * 0.2 + 0.05 });
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(6, 182, 212, ${p.o})`; ctx.fill();
      });
      requestAnimationFrame(animate);
    };
    animate();
  },

  async login() {
    const btn = document.getElementById('login-btn');
    const originalBtnHtml = btn ? btn.innerHTML : '';
    const username = document.getElementById('login-user').value.trim();
    const pass = document.getElementById('login-pass').value;
    if (!username || !pass) { alert('Enter Username and Password'); return; }

    if (!SheetsDB.isConfigured()) {
      alert('Supabase is not configured -- add the Supabase URL/Key from Settings.');
      return;
    }

    // Verifies the database connection is genuinely alive before logging in -- just for an
    // informational warning (to show a clear network error instead of "Wrong password" when
    // there's no internet), the real blocking check is done by signInWithPassword() itself
    // below.
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="bi bi-arrow-clockwise" style="animation:spin 0.8s linear infinite"></i> Checking connection...'; }
    const conn = await this.ensureDbConnection();
    if (!conn.ok && conn.reason === 'unreachable') {
      if (btn) { btn.disabled = false; btn.innerHTML = originalBtnHtml; }
      this.notify('⚠️ Could not connect to the database (' + conn.error + ') -- check your internet connection. Logging in without a connection is not possible while RLS is enabled.', 'error');
      return;
    }

    // ⚠️ Round 13 (RLS + Supabase Auth migration): password verification is now done entirely
    // server-side by Supabase Auth -- no longer comparing a SHA-256 hash in the local
    // this.state.users array like before. The username is mapped to a synthetic email
    // (username@accoflow.internal) -- this is never sent to a real email address, it's only to
    // match the format Supabase Auth needs.
    if (btn) { btn.innerHTML = '<i class="bi bi-arrow-clockwise" style="animation:spin 0.8s linear infinite"></i> Verifying...'; }
    const { data: authData, error: authErr } = await SheetsDB.client.auth.signInWithPassword({
      email: `${username.toLowerCase()}@accoflow.internal`,
      password: pass,
    });
    if (authErr || !authData || !authData.user) {
      if (btn) { btn.disabled = false; btn.innerHTML = originalBtnHtml; }
      alert('Wrong username or password!');
      return;
    }

    // ⚠️ Round 21 -- custom permission system: this user's own granular permissions
    // (profiles.permissions JSONB) are loaded regardless of role, sent to doLogin()
    const myPerms = await SheetsDB.getMyPermissions(authData.user.id);

    // Authentication succeeded -- now (and only now, because of RLS), the full dataset is loaded
    if (btn) { btn.innerHTML = '<i class="bi bi-arrow-clockwise" style="animation:spin 0.8s linear infinite"></i> Loading data...'; }
    try {
      await this.loadFromDatabase();
      this.applyAppTheme('classic');
      this.renderAllTables();
      this.populateOrderDropdown();
      this.populateAttendanceEmployees();
      this.charts(true);
      this.updateSyncStatus();
    } catch (e) {
      if (btn) { btn.disabled = false; btn.innerHTML = originalBtnHtml; }
      this.notify('Login succeeded but there was a problem loading data: ' + e.message, 'error');
      await SheetsDB.client.auth.signOut();
      return;
    }
    if (btn) { btn.disabled = false; btn.innerHTML = originalBtnHtml; }

    // Super Admin (settings.superAdminUser) -- this isn't a row in the "users" table, so it's checked separately
    const saUser = String(this.settings.superAdminUser || 'emon');
    if (username === saUser) {
      this.doLogin('superadmin', 'Super Admin', null, saUser, { appTheme: this.settings.superAdminAppTheme || 'classic', theme: this.settings.superAdminTheme || 'ocean' }, myPerms);
      return;
    }

    const user = this.state.users.find(u => u.username === username && u.status === 'Active');
    if (!user) {
      // Auth succeeded but there's no matching (Active) profile in the app's users table --
      // e.g. someone exists in Supabase Auth but has been made Inactive/deleted here
      alert('This user\'s profile could not be found or is inactive -- contact your admin.');
      await SheetsDB.client.auth.signOut();
      return;
    }
    user.lastLogin = formatDateTime(new Date());
    // ⚠️ Same bug fix (see savePersonalThemePrefs() for the detailed explanation): the login
    // flow used to call persistSheet('users') -- upserting this.state.users' *entire* array,
    // which clashed with RLS's self-row-match policy and failed (throwing "row-level security
    // policy violated" on login for merchandiser/storekeeper/accountant, or any role). Now only
    // this user's own row is upserted. Login is not blocked even if this save fails (lastLogin
    // is a non-critical stat, it's wrong to keep the user from logging in over it) -- it's just
    // logged to the console.
    if (SheetsDB.isConfigured()) {
      try {
        await SheetsDB.upsert('users', user);
      } catch (e) {
        console.warn('Failed to update lastLogin (login proceeding anyway):', e.message);
      }
    }
    // Looks up the HR Module > Employees entry matching this user's name, so their real
    // photo can be shown at the bottom of the sidebar after logging in
    const employee = (this.state.hrEmployees || []).find(e => (e.name || '').trim().toLowerCase() === (user.name || '').trim().toLowerCase());
    // ⚠️ Per-user theme: this user's own saved theme/stylePack (or the default Ocean/Classic
    // if none) is sent to doLogin(), so their own theme loads only when this specific user
    // logs in
    this.doLogin(user.role, user.name || user.username, employee ? employee.photo : null, user.username, { appTheme: user.appTheme || 'classic', theme: user.theme || 'ocean' }, myPerms);
  },

  doLogin(role, displayName, photoUrl, username, themePrefs, permissions) {
    document.getElementById('login-screen').style.display = 'none';
    this.role = role;
    // ⚠️ Round 21: role is now just a label/preset -- real permission comes from this permissions object
    // (superadmin is the exception, always bypassing everything -- see applyUserPermissions())
    this.userPerms = permissions || {};
    // The current username is stored so the audit log can correctly record who did each action
    this.currentUsername = username || role;
    document.getElementById('u-name').innerText = displayName;
    // If a matching employee's photo is found for the logged-in user, it's shown at the
    // bottom of the sidebar (avatar), otherwise the first two letters of the name are shown as
    // before
    const avatarEl = document.getElementById('u-avatar');
    if (avatarEl) {
      if (photoUrl) {
        avatarEl.innerHTML = `<img src="${this.escapeHtml(photoUrl)}" alt="${this.escapeHtml(displayName)}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
      } else {
        avatarEl.innerText = displayName.substring(0, 2).toUpperCase();
      }
    }
    // ⚠️ Round 13: this field (superAdminPass) is no longer used for actual password
    // verification (Supabase Auth does that now) -- but if it's still the default value
    // ('7797') before the bootstrap script has run, that's a signal this installation is still
    // in an old/insecure state or the migration isn't complete -- so the warning is kept.
    if (role === 'superadmin' && String(this.settings.superAdminPass || '') === '7797') {
      this.notify('⚠️ Security warning: Super Admin is still using the default password ("7797") -- change it from Settings immediately!', 'error');
    }
    // ⚠️ Per-user App Theme + Accent Colour feature: each user's own saved theme+accent is
    // loaded and applied right here -- this combination only shows up when this specific user
    // logs in, and never affects any other user's session.
    const themePrefsSafe = themePrefs || {};
    this.applyAppTheme(themePrefsSafe.appTheme || 'classic');
    this.applyTheme(themePrefsSafe.theme || 'ocean');
    this.notify('Logged in as ' + role);
    this.applyUserPermissions(role, this.userPerms);
    this.charts(true);
  },

  logout() {
    // ⚠️ Round 13: also signs out of the Supabase Auth session (this used to be only a
    // UI-level logout, there wasn't really any session before). With persistSession:false the
    // session wouldn't survive a refresh anyway, but if someone logs in again later in this
    // same tab, calling signOut() is needed to make sure the old session isn't still active.
    if (SheetsDB.isConfigured() && SheetsDB.client) { SheetsDB.client.auth.signOut(); }
    document.getElementById('login-screen').style.display = 'flex';
    document.getElementById('login-user').value = '';
    this.notify('Logged Out');
    // After logout, so the previous user's personal theme+accent never shows on the login
    // screen (so it never accidentally "leaks" to the next user), it's reset back to the
    // neutral default
    this.applyAppTheme('classic');
    this.applyTheme('ocean');
  },

  // Topbar live clock -- Bangladesh Standard Time (Asia/Dhaka), 12-hour format (with AM/PM),
  // e.g. 03:35:04 PM (used to show in 24-hour format like 15:35:04)
  clock() {
    const el = document.getElementById('clock');
    if (el) el.innerText = new Date().toLocaleTimeString('en-US', { timeZone: APP_TIMEZONE, hour12: true, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  },

  toggleSidebar() { document.getElementById('sidebar').classList.toggle('active'); },

  nav() {
    document.querySelectorAll('.nav-item').forEach(el => {
      el.onclick = () => {
        document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
        el.classList.add('active');
        this.go(el.dataset.page);
        if (window.innerWidth <= 768) document.getElementById('sidebar').classList.remove('active');
      };
    });
  },

  go(id) {
    if (id === 'settings' && !this.canView('settings')) { this.notify('You do not have permission to view Settings', 'warn'); return; }
    document.querySelectorAll('.page-view').forEach(p => p.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    const titles = { dash: 'Dashboard', inventory: 'Inventory & PI', delivery: 'Delivery Center', qc: 'QC Center', accounts: 'Accounts', expense: 'Office Expense', bsinfo: 'B&S Info', hr: 'HR Module', users: 'Roles', settings: 'Settings', datasafety: 'Data Safety' };
    document.getElementById('p-title').innerText = titles[id] || id;
    document.getElementById('p-sub').innerText = `AccoFlow / ${titles[id] || id}`;
    if (id === 'dash') { this.updateDashboard(); this.charts(true); }
    if (id === 'settings') this.syncSettingsToInputs(true);
    if (id === 'datasafety') {
      const isAdminOrSuper = this.role === 'admin' || this.role === 'superadmin';
      // ⚠️ Feature: Reports & BI now lives on the Data Safety > Backup & Excel Export tab.
      // The Audit Log/Recycle Bin/Complete Order List tabs are for admin/superadmin only
      // (sensitive data), so a role like accountant/merchandiser landing here is taken straight
      // to the Backup & Excel Export (including Reports) tab -- so they never accidentally see
      // the default Audit Log tab's sensitive data.
      if (!isAdminOrSuper) {
        const backupTab = document.getElementById('ds-backup-tab');
        if (backupTab) this.switchDataSafetyTab(backupTab, 'ds-backup');
      } else {
        this.renderDataSafetyAuditLog();
        this.renderDataSafetyTrash();
        this.updateDataSafetyTrashBadge();
      }
    }
    if (id === 'inventory' || id === 'delivery') { this.refreshPIForm(); if (id === 'delivery') this.syncChallanDetails(); }
    if (id === 'inventory') this.updateReceivedGoodsStats();
    if (id === 'hr') { this.populateEmployeeDepartmentDropdown(); }
    if (id === 'users') { this.loadProfilesForRolesPage(); }
    // ⚠️ Office Expense is now the 3rd tab on the Accounts page -- a user with only the
    // "Expense" permission (no "Accounts") should not see the Buyer/Supplier Ledger tabs, and
    // one with only "Accounts" (no "Expense") should not see the Office Expense tab -- that
    // granular permission-based visibility is applied here
    if (id === 'accounts') {
      const hasAcc = this.canView('accounts');
      const hasExp = this.canView('expense');
      const outerTabs = document.querySelectorAll('#accounts > .tabs > .tab');
      const buyerTab = outerTabs[0], suppTab = outerTabs[1], expTab = outerTabs[2];
      if (buyerTab) buyerTab.style.display = hasAcc ? '' : 'none';
      if (suppTab) suppTab.style.display = hasAcc ? '' : 'none';
      if (expTab) expTab.style.display = hasExp ? '' : 'none';
      const activeIsHiddenBuyer = !hasAcc && document.getElementById('acc-buyer').style.display !== 'none';
      const activeIsHiddenSupp = !hasAcc && document.getElementById('acc-supp').style.display !== 'none';
      if ((activeIsHiddenBuyer || activeIsHiddenSupp) && hasExp && expTab) {
        this.switchTab(expTab, 'acc-expense');
      } else if (!hasExp && document.getElementById('acc-expense').style.display !== 'none' && hasAcc && buyerTab) {
        this.switchTab(buyerTab, 'acc-buyer');
      }
    }
  },

  switchTab(el, targetId) {
    el.parentElement.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    const parent = el.closest('.card') || el.closest('.page-view');
    if (!parent) return;
    Array.from(parent.children).forEach(div => {
      // The tab bar itself (class="tabs") should never be hidden -- otherwise the user gets stuck and cannot get back to another tab
      if (div.classList && div.classList.contains('tabs')) return;
      if (div.id && div.id !== targetId) div.style.display = 'none';
    });
    const targetEl = document.getElementById(targetId);
    if (targetEl) { targetEl.style.display = 'block'; targetEl.style.animation = 'fadeUp 0.3s ease'; }
    // del-challan is no longer a tab, it opens as a full-screen modal (see openChallanFullscreen)
    if (targetId === 'inv-received') this.updateReceivedGoodsStats();
    if (targetId === 'hr-attendance') { this.populateAttendanceEmployees(); this.renderHRAttendance(); }
    if (targetId === 'hr-leaves') this.renderHRLeaves();
    if (targetId === 'hr-salary') this.renderHRSalary();
    if (targetId === 'inv-supplier-order') this.updateSupplierOrderHeader();
    if (targetId === 'exp-voucher-entry') this.refreshVoucherForm();
  },

  // ⚠️ Feature: Office Expense is now the Accounts & Finance page's 3rd tab (Office Expense)
  // instead of a separate sidebar page -- this helper goes straight from anywhere (Quick
  // Action modal, etc.) to the Accounts page, into the Office Expense tab, and then the
  // Voucher Entry sub-tab.
  goToVoucherEntry() {
    this.go('accounts');
    const expTab = document.querySelector('#accounts > .tabs > .tab:nth-child(3)');
    if (expTab) this.switchTab(expTab, 'acc-expense');
    const voucherTab = document.querySelector('#acc-expense .tabs .tab:nth-child(2)');
    if (voucherTab) this.switchTab(voucherTab, 'exp-voucher-entry');
  },

  open(id) {
    const modal = document.getElementById(id);
    if (modal) {
      modal.classList.add('show');
      if (id === 'pi-modal') this.refreshPIForm();
    }
  },

  // Instead of hiding a Modal instantly when closing it, a smooth fade + scale-out transition
  // runs first (css: .modal-ov.closing), and the real .show class is removed once the
  // animation finishes.
  close(id) {
    const modal = document.getElementById(id);
    if (!modal || !modal.classList.contains('show')) return;
    modal.classList.add('closing');
    const finish = () => { modal.classList.remove('show', 'closing'); };
    // A fallback timeout is also kept so the modal never gets stuck even if the
    // animation-end event is missed (e.g. the duration is near-zero with prefers-reduced-motion
    // on)
    let done = false;
    const onEnd = () => { if (done) return; done = true; finish(); };
    modal.addEventListener('animationend', onEnd, { once: true });
    setTimeout(onEnd, 220);
  },

  handleSearch(query) {
    const activeView = document.querySelector('.page-view.active');
    if (!activeView) return;
    activeView.querySelectorAll('table tbody tr').forEach(row => {
      row.style.display = row.innerText.toLowerCase().includes(query.toLowerCase()) ? '' : 'none';
    });
  },

  // ⚠️ Round 21: the old "soft mode" userHasPerm() (comma-separated tags, could only narrow
  // down within a role, never grant beyond it) has been removed -- fully replaced with
  // canView/canWrite/canDelete/canApprove/canExport (below), which read from
  // profiles.permissions JSONB and can grant permission beyond the role too.

  // Maps each page (data-page) in the navigation sidebar to its permissions module
  NAV_PAGE_MODULE_MAP: {
    dash: 'dashboard', inventory: 'inventory', delivery: 'delivery', qc: 'qc',
    accounts: 'accounts', hr: 'hr',
    bsinfo: 'bsinfo', datasafety: 'datasafety', settings: 'settings', users: 'users'
  },

  // ⚠️ Round 21 -- custom per-user permission system: before (applyRolePermissions), role
  // alone decided who could do what -- 5 fixed "packages". Now role is just a label/quick
  // preset, and real permission comes from this user's own permissions object (set by
  // Admin/Superadmin from the Roles page, stored in the DB as profiles.permissions JSONB) --
  // so someone with more than one responsibility can be given the module access they need
  // beyond their role. Only superadmin always bypasses everything (whatever permissions say).
  // This must be kept exactly matching the DB's has_perm() function (see
  // migration_v21_custom_permissions.sql) -- the client side only shows/hides UI, real
  // security is enforced by RLS.
  canView(module) { return this.role === 'superadmin' || !!(this.userPerms && this.userPerms[module] && this.userPerms[module].view); },
  canWrite(module) { return this.role === 'superadmin' || !!(this.userPerms && this.userPerms[module] && this.userPerms[module].write); },
  canDelete(module) { return this.role === 'superadmin' || !!(this.userPerms && this.userPerms[module] && this.userPerms[module].delete); },
  canApprove(module) { return this.role === 'superadmin' || !!(this.userPerms && this.userPerms[module] && this.userPerms[module].approve); },
  canExport(module) { return this.role === 'superadmin' || !!(this.userPerms && this.userPerms[module] && this.userPerms[module].export); },

  applyUserPermissions(role, permissions) {
    this.role = role;
    this.userPerms = permissions || {};
    document.querySelectorAll('.nav-item').forEach(item => {
      const page = item.dataset.page;
      const module = this.NAV_PAGE_MODULE_MAP[page];
      // Office Expense is now just a tab on the Accounts page (no separate nav item), so the
      // "Accounts" nav item is shown if either accounts or expense has view permission
      const visible = module ? (this.canView(module) || (page === 'accounts' && this.canView('expense'))) : true;
      item.classList.toggle('hidden', !visible);
    });
    // ⚠️ The .admin-only/.superadmin-only classes deliberately still check the literal role
    // (cannot be delegated via permissions) -- only for the most destructive/sensitive actions:
    // account management (Users create/edit/delete), writing company-wide Settings, and things
    // like "Clear All Data". Reason: giving anyone the ability to edit permissions would let
    // them effectively make themselves/anyone else a superadmin at will (self-escalation) --
    // explained in detail in migration_v21's comments.
    const isAdminOrSuper = role === 'admin' || role === 'superadmin';
    document.querySelectorAll('.admin-only').forEach(el => {
      el.style.display = isAdminOrSuper ? '' : 'none';
      el.style.pointerEvents = isAdminOrSuper ? '' : 'none';
    });
    document.querySelectorAll('.superadmin-only').forEach(el => {
      const show = role === 'superadmin';
      el.style.display = show ? '' : 'none';
      el.style.pointerEvents = show ? '' : 'none';
    });
    // Everything else (business modules) now comes entirely from this user's own
    // permissions -- regardless of role (except superadmin, which is always true)
    const toggleClass = (cls, allowed) => {
      document.querySelectorAll('.' + cls).forEach(el => {
        el.style.display = allowed ? '' : 'none';
        el.style.pointerEvents = allowed ? '' : 'none';
      });
    };
    toggleClass('inventory-write', this.canWrite('inventory'));
    toggleClass('inventory-delete', this.canDelete('inventory'));
    toggleClass('delivery-write', this.canWrite('delivery'));
    toggleClass('delivery-delete', this.canDelete('delivery'));
    toggleClass('qc-write', this.canWrite('qc'));
    toggleClass('qc-delete', this.canDelete('qc'));
    toggleClass('payment-write', this.canWrite('accounts'));
    toggleClass('accounts-delete', this.canDelete('accounts'));
    toggleClass('expense-write', this.canWrite('expense'));
    toggleClass('expense-delete', this.canDelete('expense'));
    toggleClass('hr-write', this.canWrite('hr'));
    toggleClass('hr-delete', this.canDelete('hr'));
    toggleClass('bsinfo-write', this.canWrite('bsinfo'));
    toggleClass('bsinfo-delete', this.canDelete('bsinfo'));
    // Office Expense's voucher Approve/Reject
    const canApproveExpense = this.canApprove('expense');
    document.querySelectorAll('.expense-approver-only').forEach(el => {
      el.style.display = canApproveExpense ? '' : 'none';
      el.style.pointerEvents = canApproveExpense ? '' : 'none';
    });
    // Data Safety > "Backup & Excel Export" sub-tab
    const dsBackupTab = document.getElementById('ds-backup-tab');
    if (dsBackupTab) dsBackupTab.style.display = this.canExport('datasafety') ? '' : 'none';
    this.renderAllTables();
  },

  syncSettingsToInputs(fromLoad) {
    const fields = {
      'set-company-name': 'companyName', 'set-company-tagline': 'tagline', 'set-address': 'address',
      'set-phone-email': 'phone', 'set-acc-name': 'accName', 'set-acc-no': 'accNo',
      'set-bank-name': 'bankName', 'set-swift': 'swift', 'set-bin': 'bin',
      'set-office-open': 'officeOpenTime', 'set-office-close': 'officeCloseTime'
    };
    Object.entries(fields).forEach(([id, key]) => {
      const el = document.getElementById(id);
      if (!el) return;
      if (fromLoad) el.value = this.settings[key] || '';
      else this.settings[key] = el.value || '';
    });
    const nameEl = document.getElementById('company-name');
    if (nameEl) nameEl.innerText = this.settings.companyName.split(' ')[0] || 'AccoFlow';
    if (fromLoad) {
      const saUserEl = document.getElementById('sa-new-username');
      if (saUserEl) saUserEl.value = this.settings.superAdminUser || 'superadmin';
    }
  },

  // Bug fix: the Expense Voucher's header used to have hardcoded "AccoFlow" text where the
  // company name should be. It's now set dynamically from the companyName/tagline saved in
  // Settings (same as the PI form).
  refreshVoucherForm() {
    const nameEl = document.getElementById('voucher-company-name');
    if (nameEl) nameEl.innerText = this.settings.companyName || 'AccoFlow';
    const subEl = document.getElementById('voucher-company-subtitle');
    if (subEl) subEl.innerText = this.settings.tagline || 'ERP ENTERPRISE';
  },

  // Bug fix/redesign: the QC Inspection Report's header banner now dynamically sets the
  // companyName saved in Settings (it wasn't there before, needed once the new design added
  // the "COMPANY NAME" banner)
  refreshQCForm() {
    const nameEl = document.getElementById('qc-company-name');
    if (nameEl) nameEl.innerText = this.settings.companyName || 'AccoFlow';
  },

  refreshPIForm() {
    this.syncSettingsToInputs(true);
    document.getElementById('pi-company-name-display').innerText = this.settings.companyName;
    document.getElementById('pi-company-address-display').innerText = `${this.settings.address} | ${this.settings.phone}`;
    const piLogo = document.getElementById('pi-logo-img');
    if (this.companyLogo && piLogo) { piLogo.src = this.companyLogo; piLogo.style.display = 'block'; }
    document.getElementById('pi-bank-content').innerHTML = [
      ['Account Name', this.settings.accName], ['Account No', this.settings.accNo],
      ['Bank Name', this.settings.bankName], ['Swift Code', this.settings.swift], ['BIN No', this.settings.bin]
    ].map(([l, v]) => `<div><b>${l}:</b> ${v || '______________'}</div>`).join('');
    this.applySignaturesToPrintouts();
  },

  // A signature uploaded in Settings (Chairman, Managing Director) is placed automatically in
  // the right spot on the PI and Supplier Order Sheet. Merchandiser signatures can now be
  // multiple (hrSignatures), so not here -- that's placed separately via
  // applyMerchSignatureToSO() when selected from the dropdown.
  applySignaturesToPrintouts() {
    const map = [
      ['pi-sign-chairman-img', this.settings.signChairman],
      ['pi-sign-md-img', this.settings.signMD],
      ['so-sign-md-img', this.settings.signMD]
    ];
    map.forEach(([id, src]) => {
      const el = document.getElementById(id);
      if (!el) return;
      if (src) { el.src = src; el.style.display = 'block'; } else { el.style.display = 'none'; }
    });
  },

  async handleSignatureUpload(settingsKey, event) {
    const file = event.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { this.notify('Please upload an image file only', 'warn'); return; }
    try {
      const dataUrl = await this.resizeImageToDataURL(file, 300, 120, 0.75);
      this.settings[settingsKey] = dataUrl;
      this.saveLocalSettings();
      this.renderSignaturePreviews();
      this.applySignaturesToPrintouts();

      if (SheetsDB.isConfigured()) {
        try { await SheetsDB.saveSettings(this.settings); this.notify('Signature uploaded and saved to Supabase'); }
        catch (e) { this.notify('Signature saved locally -- Sheets sync failed', 'warn'); }
      } else {
        this.notify('Signature saved (local)');
      }
    } catch (e) {
      this.notify('Problem processing the signature', 'error');
    }
  },

  // When the HR Settings > Signatures tab opens, or after an upload/delete, every preview box
  // and its "Remove" button next to it is updated per the saved settings
  renderSignaturePreviews() {
    const map = {
      signChairman: { preview: 'sign-chairman-preview', del: 'sign-chairman-delete' },
      signMD: { preview: 'sign-md-preview', del: 'sign-md-delete' }
    };
    Object.entries(map).forEach(([key, ids]) => {
      const previewBox = document.getElementById(ids.preview);
      const delBtn = document.getElementById(ids.del);
      const dataUrl = this.settings[key];
      if (previewBox) {
        previewBox.innerHTML = dataUrl ? `<img src="${dataUrl}" alt="Signature">` : `<i class="bi bi-pen placeholder-icon"></i>`;
      }
      if (delBtn) delBtn.style.display = dataUrl ? 'flex' : 'none';
    });
  },

  // Removing a signature drops it from settings and it also disappears automatically from
  // the PI/Supplier Order Sheet printouts
  async removeSignature(settingsKey) {
    const labels = { signChairman: 'Chairman', signMD: 'Managing Director' };
    if (!confirm(`Remove the ${labels[settingsKey] || 'this'} signature?`)) return;
    this.settings[settingsKey] = '';
    this.saveLocalSettings();
    this.renderSignaturePreviews();
    this.applySignaturesToPrintouts();
    const fileInput = document.getElementById({ signChairman: 'sign-chairman-file', signMD: 'sign-md-file' }[settingsKey]);
    if (fileInput) fileInput.value = '';
    if (SheetsDB.isConfigured()) {
      try { await SheetsDB.saveSettings(this.settings); this.notify('Signature removed'); }
      catch (e) { this.notify('Signature removed locally -- Sheets sync failed', 'warn'); }
    } else {
      this.notify('Signature removed (local)');
    }
  },


  updateSupplierOrderHeader() {
    const nameEl = document.getElementById('so-company-name');
    const tagEl = document.getElementById('so-company-tagline');
    const addrEl = document.getElementById('so-company-address');
    if (nameEl) nameEl.innerText = this.settings.companyName || 'AccoFlow Enterprise';
    if (tagEl) tagEl.innerText = this.settings.tagline || '';
    if (addrEl) addrEl.innerText = `${this.settings.address || ''}${this.settings.phone ? ' | ' + this.settings.phone : ''}`;
    this.applySignaturesToPrintouts();
    const piDatalist = document.getElementById('so-pi-no-list');
    if (piDatalist) piDatalist.innerHTML = this.state.piList.map(p => `<option value="${this.escapeHtml(p.piNo)}">`).join('');
  },

  openNewPIModal() {
    this.resetPIForm();
    document.getElementById('pi-modal-title').innerHTML = '<i class="bi bi-file-earmark-text" style="color:var(--accent)"></i> Create Proforma Invoice';
    document.getElementById('pi-save-btn-text').innerText = 'Save to DB';
    document.getElementById('pi-edit-id').value = '';
    document.getElementById('pi-modal-date').value = todayStr();
    const nextId = this.state.piList.length ? Math.max(...this.state.piList.map(r => r.id)) + 1 : 1;
    document.getElementById('pi-invoice-no').value = 'PI-' + nextId;
    this.open('pi-modal');
  },

  // These default values are set automatically when creating a new PI, though the user can change them any time
  PI_DEFAULTS: {
    'pi-destination': 'BANGLADESH',
    'pi-terms': '90 DAYS',
    'pi-validity': '15 DAYS',
    'pi-port': 'BANGLADESH',
    'pi-shipment': 'BY COVER VAN FROM OUR FACTORY',
    'pi-packing': 'STANDARD EXPORT PACKING',
    'pi-origin': 'MADE IN BANGLADESH'
  },

  resetPIForm() {
    ['pi-consignee', 'pi-attention', 'pi-notify-party', 'pi-buyer-other', 'pi-buyer-address', 'pi-buyer-bank-ac', 'pi-buyer-search', 'pi-carton'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = '';
    });
    Object.entries(this.PI_DEFAULTS).forEach(([id, val]) => {
      const el = document.getElementById(id);
      if (el) el.value = val;
    });
    this.populatePIBuyerList();
    document.getElementById('pi-full-tbody').innerHTML = '';
    this.addPIRow();
    this.calcFullPI();
  },

  // A datalist is built from the Buyer Directory (B&S Info > Buyer Directory), so the PI form
  // can auto-suggest as soon as the first few letters of the buyer's name are typed
  populatePIBuyerList() {
    const dl = document.getElementById('pi-buyer-list');
    if (!dl) return;
    dl.innerHTML = (this.state.buyers || []).map(b => `<option value="${this.escapeHtml(b.name)}">`).join('');
  },

  // Selecting/typing a name from the Buyer Directory auto-fills Consignee, Buyer Address,
  // Attention, Notify Party (the user can still edit them afterwards)
  autofillPIBuyer(name) {
    const buyer = (this.state.buyers || []).find(b => (b.name || '').toLowerCase() === name.trim().toLowerCase());
    if (!buyer) return;
    const set = (id, val) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.value = val || '';
      el.classList.add('autofill-field');
      setTimeout(() => el.classList.remove('autofill-field'), 1500);
    };
    // CONSIGNEE / BUYER: only the buyer's name goes here (used to set name + address both,
    // but since there's a separate "BUYER ADDRESS" field right next to it, just the name goes
    // here without duplicating)
    set('pi-consignee', buyer.name || '');
    set('pi-buyer-address', buyer.address || '');
    set('pi-attention', [buyer.contactPerson, buyer.mobile].filter(Boolean).join('\n'));
    // NOTIFY PARTY: the buyer's bank name and branch go here instead of the buyer's own
    // address -- in LC/export documentation, Notify Party usually means the buyer's bank
    set('pi-notify-party', [buyer.bankName, buyer.bankBranch].filter(Boolean).join('\n'));
    // A newly-added field in a spot that used to sit empty -- the buyer's bank account number
    set('pi-buyer-bank-ac', buyer.bankAccount || '');
    set('pi-buyer-other', buyer.name || '');
    this.notify(`Auto-filled: ${buyer.name}`);
  },

  getPIFormData() {
    const lineItems = [];
    document.querySelectorAll('#pi-full-tbody tr').forEach(r => {
      const inputs = r.querySelectorAll('input');
      lineItems.push({
        buyerRef: inputs[0]?.value || '', hsCode: inputs[1]?.value || '', dept: inputs[2]?.value || '',
        poNo: inputs[3]?.value || '', styleNo: inputs[4]?.value || '', itemCode: inputs[5]?.value || '',
        description: inputs[6]?.value || '', qty: inputs[7]?.value || '0', unitPrice: inputs[8]?.value || '0',
        total: r.cells[10]?.innerText || '$0.00'
      });
    });
    const consignee = document.getElementById('pi-consignee')?.value.trim() || '';
    const buyerOther = document.getElementById('pi-buyer-other')?.value.trim() || '';
    return {
      consignee, attention: document.getElementById('pi-attention')?.value || '',
      notifyParty: document.getElementById('pi-notify-party')?.value || '',
      destination: document.getElementById('pi-destination')?.value || '',
      buyerAddress: document.getElementById('pi-buyer-address')?.value || '',
      buyerBankAc: document.getElementById('pi-buyer-bank-ac')?.value || '',
      carton: document.getElementById('pi-carton')?.value || '',
      terms: document.getElementById('pi-terms')?.value || '',
      validity: document.getElementById('pi-validity')?.value || '',
      port: document.getElementById('pi-port')?.value || '',
      shipment: document.getElementById('pi-shipment')?.value || '',
      packing: document.getElementById('pi-packing')?.value || '',
      origin: document.getElementById('pi-origin')?.value || '',
      buyerOther, invoiceDate: document.getElementById('pi-modal-date')?.value || '',
      invoiceNo: document.getElementById('pi-invoice-no')?.value.trim() || '',
      buyer: buyerOther || consignee.split('\n')[0] || 'Unknown Buyer',
      supplier: consignee.split('\n')[1]?.trim() || 'Supplier',
      lineItems, totalQty: document.getElementById('pi-full-tqty')?.innerText || '0',
      grandTotal: document.getElementById('pi-full-gtotal')?.innerText || '$0.00',
      inWords: document.getElementById('pi-in-words')?.innerText || ''
    };
  },

  setPIFormData(data) {
    if (!data) return;
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ''; };
    set('pi-consignee', data.consignee);
    set('pi-attention', data.attention);
    set('pi-notify-party', data.notifyParty);
    set('pi-destination', data.destination || this.PI_DEFAULTS['pi-destination']);
    set('pi-buyer-address', data.buyerAddress || '');
    set('pi-buyer-bank-ac', data.buyerBankAc || '');
    set('pi-carton', data.carton || '');
    set('pi-terms', data.terms || this.PI_DEFAULTS['pi-terms']);
    set('pi-validity', data.validity || this.PI_DEFAULTS['pi-validity']);
    set('pi-port', data.port || this.PI_DEFAULTS['pi-port']);
    set('pi-shipment', data.shipment || this.PI_DEFAULTS['pi-shipment']);
    set('pi-packing', data.packing || this.PI_DEFAULTS['pi-packing']);
    set('pi-origin', data.origin || this.PI_DEFAULTS['pi-origin']);
    set('pi-buyer-other', data.buyerOther);
    set('pi-modal-date', data.invoiceDate);
    set('pi-invoice-no', data.invoiceNo);
    const tbody = document.getElementById('pi-full-tbody');
    tbody.innerHTML = '';
    const items = data.lineItems && data.lineItems.length ? data.lineItems : [{}];
    items.forEach((item, i) => {
      this.addPIRow();
      const row = tbody.rows[i];
      if (!row) return;
      const inputs = row.querySelectorAll('input');
      const vals = [item.buyerRef, item.hsCode, item.dept, item.poNo, item.styleNo, item.itemCode, item.description, item.qty, item.unitPrice];
      vals.forEach((v, idx) => { if (inputs[idx]) inputs[idx].value = v || (idx >= 7 ? '0' : ''); });
    });
    this.calcFullPI();
  },

  // ⚠️ Fix (A9): this used to show only Date/PI No/Buyer/Supplier/Items count/Total/QC Status
  // and Consignee -- every other field (Buyer Address, Attention, Notify Party, Destination,
  // Buyer If Other, Bank A/C, Invoice No, Carton, Shipping/Packing/Terms/Validity/Origin) and,
  // most importantly, the entire line-item table itself (SL/Buyer Ref/HS Code/Dept/PO No/Style
  // No/Item Code/Description/Qty/Unit Price/Total) was completely left out -- now everything
  // that's on the Create/Edit form is shown here too (read-only), so exactly what makes up the
  // PI is fully visible.
  viewPI(id) {
    const item = this.state.piList.find(r => r.id === id);
    if (!item) return;
    this.viewingPIId = id;
    const form = item.formData || {};
    const bankRows = [
      ['Account Name', this.settings.accName], ['Account No', this.settings.accNo],
      ['Bank Name', this.settings.bankName], ['Swift Code', this.settings.swift], ['BIN No', this.settings.bin]
    ].map(([l, v]) => `<div class="fg"><label>${l}</label><input value="${v || '—'}" readonly></div>`).join('');
    const ro = (label, val) => `<div class="fg"><label>${label}</label><input value="${this.escapeHtml(val || '—')}" readonly></div>`;
    const roTA = (label, val) => `<div class="fg"><label>${label}</label><textarea readonly>${this.escapeHtml(val || '—')}</textarea></div>`;
    const lineItems = (form.lineItems && form.lineItems.length) ? form.lineItems : [];
    const itemRows = lineItems.length ? lineItems.map((li, i) => `
      <tr><td>${i + 1}</td><td>${this.escapeHtml(li.buyerRef || '')}</td><td>${this.escapeHtml(li.hsCode || '')}</td><td>${this.escapeHtml(li.dept || '')}</td>
      <td>${this.escapeHtml(li.poNo || '')}</td><td>${this.escapeHtml(li.styleNo || '')}</td><td class="f-mono f-accent">${this.escapeHtml(li.itemCode || '')}</td>
      <td>${this.escapeHtml(li.description || '')}</td><td>${this.escapeHtml(li.qty || '0')}</td><td>${this.escapeHtml(li.unitPrice || '0')}</td><td>${this.escapeHtml(li.total || '$0.00')}</td></tr>`).join('')
      : '<tr><td colspan="11" style="text-align:center;color:var(--text-muted);padding:14px">No line items found</td></tr>';
    const st = this.computePIStatus(item);
    document.getElementById('view-pi-content').innerHTML = `
      <div style="display:grid;gap:12px">
        <div class="grid-3">${ro('Date', formatDate(item.date))}${ro('PI No', item.piNo)}<div class="fg"><label>Status</label><input value="${st.label}" readonly></div></div>
        <div class="grid-2">${ro('Invoice Date', formatDate(form.invoiceDate))}${ro('Invoice No', form.invoiceNo)}</div>
        <div style="border-top:1px solid var(--border);padding-top:12px"><div class="w-title mb-3">Buyer / Consignee</div>
          <div class="grid-2">${ro('Consignee / Buyer', form.consignee || item.buyer)}${roTA('Buyer Address', form.buyerAddress)}</div>
          <div class="grid-2">${roTA('Attention / Merchandiser', form.attention)}${roTA('Notify Party (Bank Name & Branch)', form.notifyParty)}</div>
          <div class="grid-3">${ro('Country of Final Destination', form.destination)}${ro('Buyer (If Other)', form.buyerOther)}${ro("Buyer's Bank A/C No", form.buyerBankAc)}</div>
        </div>
        <div style="border-top:1px solid var(--border);padding-top:12px"><div class="w-title mb-3">Shipping & Terms</div>
          <div class="grid-3">${ro('Port of Loading', form.port)}${ro('Shipment', form.shipment)}${ro('No. of Carton', form.carton)}</div>
          <div class="grid-3">${ro('Packing', form.packing)}${ro('Country of Origin', form.origin)}${ro('Terms of Delivery & Payment', form.terms)}</div>
          <div class="grid-2">${ro('L/C Validity', form.validity)}${ro('Supplier', item.supplier)}</div>
        </div>
        <div style="border-top:1px solid var(--border);padding-top:12px"><div class="w-title mb-3">Line Items (${lineItems.length})</div>
          <div class="table-wrap"><table style="font-size:11px"><thead><tr><th>SL</th><th>Buyer Ref</th><th>HS Code</th><th>Dept</th><th>PO No</th><th>Style No</th><th>Item Code</th><th>Description</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead>
          <tbody>${itemRows}</tbody></table></div>
        </div>
        <div class="grid-3">${ro('Total Qty', form.totalQty)}${ro('Grand Total', form.grandTotal || item.totalValue)}${ro('Amount in Words', form.inWords)}</div>
        <div style="border-top:1px solid var(--border);padding-top:12px"><div class="w-title mb-3">Bank Details (from System Settings)</div>${bankRows}</div>
      </div>`;
    this.open('view-pi-modal');
  },

  editPI(id) {
    const item = this.state.piList.find(r => r.id === id);
    if (!item) return;
    document.getElementById('pi-modal-title').innerHTML = '<i class="bi bi-file-earmark-text" style="color:var(--accent)"></i> Edit Proforma Invoice';
    document.getElementById('pi-save-btn-text').innerText = 'Update PI';
    document.getElementById('pi-edit-id').value = id;
    this.resetPIForm();
    if (item.formData) {
      this.setPIFormData(item.formData);
    } else {
      document.getElementById('pi-modal-date').value = item.date;
      document.getElementById('pi-invoice-no').value = item.piNo;
      document.getElementById('pi-consignee').value = item.buyer;
      document.getElementById('pi-buyer-other').value = item.buyer;
    }
    this.open('pi-modal');
  },

  syncChallanDetails() {
    this.syncSettingsToInputs(true);
    const printName = document.getElementById('print-company-name');
    const printTag = document.getElementById('print-company-tagline');
    const printAddress = document.getElementById('print-company-address');
    if (printName) printName.innerText = this.settings.companyName;
    if (printTag) printTag.innerText = this.settings.tagline;
    if (printAddress) printAddress.innerText = this.settings.address ? `${this.settings.address} | ${this.settings.phone}` : 'Company address';
    const challanLogo = document.getElementById('challan-logo-img');
    if (this.companyLogo && challanLogo) { challanLogo.src = this.companyLogo; challanLogo.style.display = 'block'; }
  },

  async saveOfficeHours() {
    this.settings.officeOpenTime = document.getElementById('set-office-open').value || '09:00';
    this.settings.officeCloseTime = document.getElementById('set-office-close').value || '18:00';
    this.saveLocalSettings();
    if (SheetsDB.isConfigured()) {
      try { await SheetsDB.saveSettings(this.settings); this.notify('Office Hours saved'); }
      catch (e) { this.notify('Saved locally -- Sheets sync failed', 'warn'); }
    } else {
      this.notify('Office Hours saved (local)');
    }
  },

  // ⚠️ Feature: QC Center > Settings -- a modal to configure Max QC Allowed % (how high a
  // Reject % can still be treated as a "Pass"). Same pattern as saveOfficeHours(): the input is
  // pre-filled with the previously saved value (openQCSettingsModal), and Save updates
  // this.settings, saved both locally and to Supabase.
  openQCSettingsModal() {
    const input = document.getElementById('set-qc-max-reject-pct');
    if (input) input.value = this.QC_MAX_REJECT_PCT;
    this.open('qc-settings-modal');
  },

  async saveQCSettings() {
    const input = document.getElementById('set-qc-max-reject-pct');
    const val = parseFloat(input ? input.value : NaN);
    if (!Number.isFinite(val) || val < 0 || val > 100) {
      this.notify('Enter a valid percentage (0-100)', 'warn');
      return;
    }
    this.settings.maxQcAllowedPct = val;
    this.saveLocalSettings();
    if (SheetsDB.isConfigured()) {
      try { await SheetsDB.saveSettings({ maxQcAllowedPct: val }); this.notify('Max QC Allowed % saved'); }
      catch (e) { this.notify('Saved locally -- Sheets sync failed', 'warn'); }
    } else {
      this.notify('Max QC Allowed % saved (local)');
    }
    this.close('qc-settings-modal');
  },

  async saveSettings() {
    this.syncSettingsToInputs(false);
    this.saveLocalSettings();
    const supaUrl = document.getElementById('set-supabase-url').value.trim();
    const supaKey = document.getElementById('set-supabase-key').value.trim();
    // ⚠️ Round 13 fix: setCredentials() used to always be called here, even when the URL/Key
    // hadn't changed at all. setCredentials() creates a new Supabase client -- after the
    // RLS/Auth migration this wiped the logged-in session (auth.uid()), so the very next
    // saveSettings() call got blocked by RLS ("Settings saved locally -- sync failed"). Now the
    // client is only recreated when the URL/Key genuinely changed -- a normal save leaves the
    // session intact.
    if (supaUrl !== SheetsDB.url || supaKey !== SheetsDB.anonKey) {
      SheetsDB.setCredentials(supaUrl, supaKey);
    }
    if (SheetsDB.isConfigured()) {
      try {
        await SheetsDB.saveSettings(this.settings);
        this.dbConnected = true;
        this.notify('Settings saved to Supabase');
      } catch (e) {
        this.notify('Settings saved locally — sync failed', 'warn');
      }
    } else {
      this.notify('Settings saved locally');
    }
    this.updateSyncStatus();
    this.refreshPIForm();
    this.updateSupplierOrderHeader();
    this.syncChallanDetails();
    this.refreshVoucherForm();
    this.refreshQCForm();
  },

  async saveSuperAdminCredentials() {
    if (this.role !== 'superadmin') { this.notify('Only Super Admin can change this information', 'warn'); return; }
    const newUser = document.getElementById('sa-new-username').value.trim();
    const newPass = document.getElementById('sa-new-pass').value;
    const confirmPass = document.getElementById('sa-confirm-pass').value;

    // ⚠️ Round 13: the "current password" is not separately verified here -- reaching this
    // screen already requires a valid Supabase Auth session (role === 'superadmin'), which is
    // treated as sufficient authorisation (no other admin action in the app asks for a
    // separate re-auth either).
    if (!newUser) { this.notify('Enter a new username', 'warn'); return; }
    // ⚠️ Changing the username is not supported -- Supabase Auth identifies the account via
    // a username→email mapping (saveUser() has the same limitation, see that function's
    // comment)
    if (newUser !== (this.settings.superAdminUser || 'emon')) {
      this.notify('Changing the Super Admin username is not supported at this time -- only change the password.', 'warn');
      return;
    }
    if (!newPass) { this.notify('Enter a new password', 'warn'); return; }
    if (newPass.length < 6) { this.notify('Password must be at least 6 characters', 'warn'); return; }
    if (newPass !== confirmPass) { this.notify('New password and confirm password do not match', 'error'); return; }

    try {
      await SheetsDB.adminManageUser({ action: 'update', username: newUser, password: newPass });
    } catch (e) {
      this.notify('Failed to change password: ' + e.message, 'error');
      return;
    }

    // ⚠️ This field is no longer the real password -- it's kept only as a neutral marker for
    // the "is the default password still unchanged" warning (see doLogin())
    this.settings.superAdminPass = 'changed-via-supabase-auth';
    this.saveLocalSettings();
    if (SheetsDB.isConfigured()) {
      try { await SheetsDB.saveSettings(this.settings); } catch (e) { /* will retry later */ }
    }
    this.notify('Super Admin password changed successfully');

    document.getElementById('sa-new-pass').value = '';
    document.getElementById('sa-confirm-pass').value = '';
    document.getElementById('sa-new-username').value = this.settings.superAdminUser;
  },

  openAddPaymentModal(piNo) {
    const select = document.getElementById('pay-pi-no');
    if (select) {
      select.innerHTML = '<option value="">Select PI...</option>' +
        this.state.accBuyer.map(r => `<option value="${this.escapeHtml(r.piNo)}">${this.escapeHtml(r.piNo)} - ${this.escapeHtml(r.buyer)}</option>`).join('');
      if (piNo) select.value = piNo;
    }
    ['pay-amount', 'pay-check-number', 'pay-remarks'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
    document.getElementById('pay-method').value = 'LC';
    document.getElementById('pay-check-number-wrap').style.display = 'none';
    document.getElementById('pay-receipt-image-data').value = '';
    document.getElementById('pay-receipt-preview').innerHTML = '<i class="bi bi-image placeholder-icon"></i>';
    const dateEl = document.getElementById('pay-date');
    if (dateEl) dateEl.value = todayStr();
    this.open('add-payment-modal');
  },

  // The Check Number field only shows when "Check" is selected in the Payment Method dropdown, hidden for any other method
  togglePayCheckField(selectId, wrapId) {
    const method = document.getElementById(selectId).value;
    const wrap = document.getElementById(wrapId);
    if (wrap) wrap.style.display = method === 'Check' ? 'block' : 'none';
  },

  // Handler for uploading a Check/money receipt image -- compressed via resizeImageToDataURL and set into a hidden input
  async handlePaymentReceiptUpload(event, hiddenInputId, previewBoxId) {
    const file = event.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { this.notify('Please upload an image file only', 'warn'); return; }
    try {
      const dataUrl = await this.resizeImageToDataURL(file, 400, 400, 0.7);
      document.getElementById(hiddenInputId).value = dataUrl;
      document.getElementById(previewBoxId).innerHTML = `<img src="${dataUrl}" alt="Receipt">`;
    } catch (e) {
      this.notify('Problem processing the image', 'error');
    }
  },

  async saveBuyerPayment() {
    const piNo = document.getElementById('pay-pi-no').value;
    const rawAmount = parseFloat(document.getElementById('pay-amount').value) || 0;
    const amount = this.roundMoney(rawAmount);
    if (rawAmount > 0 && Math.abs(rawAmount - amount) > 1e-9 && amount > 0) this.notify(`Amount rounded to $${amount.toFixed(2)} (payments are recorded in whole cents)`, 'warn');
    const method = document.getElementById('pay-method').value;
    const checkNumber = method === 'Check' ? document.getElementById('pay-check-number').value.trim() : '';
    const remarks = document.getElementById('pay-remarks').value.trim();
    const receiptImage = document.getElementById('pay-receipt-image-data').value || '';
    const date = document.getElementById('pay-date').value || todayStr();
    if (!piNo || amount <= 0) { this.notify('PI No is required and Amount must be greater than 0', 'warn'); return; }

    const row = this.state.accBuyer.find(r => r.piNo === piNo);
    if (!row) { this.notify('This PI No was not found', 'error'); return; }

    // ⚠️ Round 16: when Supabase is configured, the whole operation (validate + row-lock +
    // ledger update + history insert + audit log) now happens in one atomic DB transaction
    // (RPC) -- if two users pay the same PI at the same time, the second one can no longer
    // overwrite the first (this used to be two separate persistSheet() calls, and a failure in
    // between could leave the ledger/history mismatched). When Supabase isn't configured
    // (local/offline mode), the old client-side calculation is still used.
    if (SheetsDB.isConfigured()) {
      try {
        const result = await SheetsDB.recordBuyerPayment({ piNo, amount, method, checkNumber, remarks, receiptImage, date });
        row.received = result.received;
        row.due = result.due;
        row.status = result.status;
        row.lc = method;
        this.state.buyerPaymentHistory.push({
          id: result.historyId, piNo, buyer: row.buyer, amount: amount.toFixed(2), method, checkNumber, date, remarks, receiptImage
        });
        this.dbConnected = true;
        this.updateSyncStatus();
        this.notify('Payment recorded');
        this.renderAccBuyer();
        this.close('add-payment-modal');
      } catch (e) {
        this.dbConnected = false;
        this.updateSyncStatus();
        this.notify('Failed to save payment: ' + e.message, 'error');
      }
      return;
    }

    const total = this.parseMoney(row.total);
    const receivedSoFar = this.parseMoney(row.received);
    const newReceived = receivedSoFar + amount;
    const newDue = Math.max(total - newReceived, 0);

    row.received = this.formatUSD(newReceived);
    row.due = this.formatUSD(newDue);
    row.status = newDue <= 0 ? 'Paid' : 'Due';
    row.lc = method; // shows the most recent payment method in the LC/RTGS/Check column

    // This payment is also recorded separately in Buyer Payment History, so it can be seen later from "View History"
    const newHistId = await this.allocId('buyerPaymentHistory');
    this.state.buyerPaymentHistory.push({
      id: newHistId, piNo, buyer: row.buyer, amount: amount.toFixed(2), method, checkNumber, date, remarks, receiptImage
    });

    this.logAudit('Create', 'buyerPaymentHistory', newHistId, `${piNo} — $${amount.toFixed(2)}`);
    this.notify('Payment recorded (local mode)');
    this.renderAccBuyer();
    this.close('add-payment-modal');
  },

  openAddSupplierPaymentModal(orderNo) {
    const select = document.getElementById('supp-pay-order-no');
    if (select) {
      select.innerHTML = '<option value="">Select Order...</option>' +
        this.state.accSupplier.map(r => `<option value="${this.escapeHtml(r.orderNo)}">${this.escapeHtml(r.orderNo)} - ${this.escapeHtml(r.supplier)}</option>`).join('');
      if (orderNo) select.value = orderNo;
    }
    ['supp-pay-amount', 'supp-pay-check-number', 'supp-pay-remarks'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
    document.getElementById('supp-pay-method').value = 'LC';
    document.getElementById('supp-pay-check-number-wrap').style.display = 'none';
    document.getElementById('supp-pay-receipt-image-data').value = '';
    document.getElementById('supp-pay-receipt-preview').innerHTML = '<i class="bi bi-image placeholder-icon"></i>';
    const dateEl = document.getElementById('supp-pay-date');
    if (dateEl) dateEl.value = todayStr();
    this.open('add-supplier-payment-modal');
  },

  async saveSupplierPaymentEntry() {
    const orderNo = document.getElementById('supp-pay-order-no').value;
    const rawAmount = parseFloat(document.getElementById('supp-pay-amount').value) || 0;
    const amount = this.roundMoney(rawAmount);
    if (rawAmount > 0 && Math.abs(rawAmount - amount) > 1e-9 && amount > 0) this.notify(`Amount rounded to $${amount.toFixed(2)} (payments are recorded in whole cents)`, 'warn');
    const method = document.getElementById('supp-pay-method').value;
    const checkNumber = method === 'Check' ? document.getElementById('supp-pay-check-number').value.trim() : '';
    const remarks = document.getElementById('supp-pay-remarks').value.trim();
    const receiptImage = document.getElementById('supp-pay-receipt-image-data').value || '';
    const date = document.getElementById('supp-pay-date').value || todayStr();
    if (!orderNo || amount <= 0) { this.notify('Order No is required and Amount must be greater than 0', 'warn'); return; }

    const row = this.state.accSupplier.find(r => r.orderNo === orderNo);
    if (!row) { this.notify('This Order No was not found', 'error'); return; }

    // ⚠️ Round 16: same as saveBuyerPayment() -- an atomic RPC is used when Supabase is configured
    if (SheetsDB.isConfigured()) {
      try {
        const result = await SheetsDB.recordSupplierPayment({ orderNo, amount, method, checkNumber, remarks, receiptImage, date });
        row.paid = result.paid;
        row.due = result.due;
        this.state.supplierPaymentHistory.push({
          id: result.historyId, orderNo, supplier: row.supplier, amount: amount.toFixed(2), method, checkNumber, date, remarks, receiptImage
        });
        this.dbConnected = true;
        this.updateSyncStatus();
        this.notify('Payment recorded');
        this.renderAccSupplier();
        this.close('add-supplier-payment-modal');
      } catch (e) {
        this.dbConnected = false;
        this.updateSyncStatus();
        this.notify('Failed to save payment: ' + e.message, 'error');
      }
      return;
    }

    const total = this.parseMoney(row.total);
    const paidSoFar = this.parseMoney(row.paid);
    const newPaid = paidSoFar + amount;
    const newDue = Math.max(total - newPaid, 0);

    row.paid = this.formatUSD(newPaid);
    row.due = this.formatUSD(newDue);

    const newHistId = await this.allocId('supplierPaymentHistory');
    this.state.supplierPaymentHistory.push({
      id: newHistId, orderNo, supplier: row.supplier, amount: amount.toFixed(2), method, checkNumber, date, remarks, receiptImage
    });

    this.logAudit('Create', 'supplierPaymentHistory', newHistId, `${orderNo} — $${amount.toFixed(2)}`);
    this.notify('Payment recorded (local mode)');
    this.renderAccSupplier();
    this.close('add-supplier-payment-modal');
  },

  // Clicking the Buyer or Supplier Ledger's "View History" button shows that specific
  // PI/Order's payment history (date, amount, payment method, check number, remarks, receipt
  // image)
  viewPaymentHistory(type, key) {
    const isBuyer = type === 'buyer';
    const records = isBuyer
      ? this.state.buyerPaymentHistory.filter(r => r.piNo === key)
      : this.state.supplierPaymentHistory.filter(r => r.orderNo === key);
    document.getElementById('payment-history-title').innerText = `Payment History — ${key}`;
    const container = document.getElementById('payment-history-content');
    if (!records.length) {
      container.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:20px">No payment record yet.</p>';
    } else {
      container.innerHTML = records.map(r => `
        <div class="card" style="padding:12px;margin-bottom:10px;">
          <div class="flex-between"><b style="color:var(--accent)">${this.formatUSD(this.parseMoney(r.amount))}</b><span style="font-size:10px;color:var(--text-muted)">${formatDate(r.date)}</span></div>
          <div style="font-size:11px;margin-top:6px;"><b>Method:</b> ${this.escapeHtml(r.method)}${r.checkNumber ? ` (Check No: ${this.escapeHtml(r.checkNumber)})` : ''}</div>
          ${r.remarks ? `<div style="font-size:11px;margin-top:4px;color:var(--text-muted)"><b>Remarks:</b> ${this.escapeHtml(r.remarks)}</div>` : ''}
          ${this.safeImageSrc(r.receiptImage) ? `<img src="${this.escapeHtml(this.safeImageSrc(r.receiptImage))}" style="max-width:100px;max-height:100px;border-radius:6px;margin-top:8px;border:1px solid var(--border);cursor:pointer" onclick="window.open(this.src)">` : ''}
          <div class="no-print" style="margin-top:8px;text-align:right;"><button class="action-btn action-delete accounts-delete" onclick="app.deletePaymentHistoryRecord('${this.escapeJsAttr(type)}', ${Number(r.id)}, '${this.escapeJsAttr(key)}')"><i class="bi bi-trash"></i> Delete</button></div>
        </div>`).join('');
    }
    this.open('payment-history-modal');
  },

  // For permanently deleting a specific Payment History entry that was added by mistake
  async deletePaymentHistoryRecord(type, id, key) {
    if (this.role !== 'superadmin') { this.notify('Only Super Admin can delete this', 'warn'); return; }
    if (!confirm('Permanently delete this payment record?')) return;
    const isBuyer = type === 'buyer';
    const stateKey = isBuyer ? 'buyerPaymentHistory' : 'supplierPaymentHistory';
    const idx = this.state[stateKey].findIndex(r => r.id === id);
    if (idx === -1) return;
    this.state[stateKey].splice(idx, 1);
    if (SheetsDB.isConfigured() && this.dbConnected) {
      try { await SheetsDB.deleteRow(stateKey, id); } catch (e) { this.notify('Delete sync failed', 'error'); }
    }
    this.notify('Payment record deleted');
    this.viewPaymentHistory(type, key);
  },

  openAddBuyerModal() {
    document.querySelectorAll('#add-buyer-modal input').forEach(i => i.value = '');
    document.getElementById('buyer-logo-preview').innerHTML = '<i class="bi bi-building placeholder-icon"></i>';
    this.open('add-buyer-modal');
  },

  openAddSupplierModal() {
    document.querySelectorAll('#add-supplier-modal input').forEach(i => i.value = '');
    document.getElementById('supplier-logo-preview').innerHTML = '<i class="bi bi-building placeholder-icon"></i>';
    this.open('add-supplier-modal');
  },

  async saveBuyer() {
    const name = document.getElementById('buyer-name').value.trim();
    const contactPerson = document.getElementById('buyer-contact-person').value.trim();
    const address = document.getElementById('buyer-address').value.trim();
    const mobile = document.getElementById('buyer-mobile').value.trim();
    const email = document.getElementById('buyer-email').value.trim();
    const country = document.getElementById('buyer-country').value.trim();
    const bankAccount = document.getElementById('buyer-bank-account').value.trim();
    const bankName = document.getElementById('buyer-bank-name').value.trim();
    const bankBranch = document.getElementById('buyer-bank-branch').value.trim();
    const bin = document.getElementById('buyer-bin').value.trim();
    const swift = document.getElementById('buyer-swift').value.trim();
    const outsideMerchandiser = document.getElementById('buyer-outside-merchandiser').value.trim();
    const logo = document.getElementById('buyer-logo-data').value || '';
    if (!name) { this.notify('Buyer Name is required', 'warn'); return; }

    const newId = await this.allocId('buyers');
    this.state.buyers.push({ id: newId, name, contactPerson, address, mobile, email, country, bankAccount, bankName, bankBranch, bin, swift, outsideMerchandiser, logo, orders: 0, status: 'Active' });
    await this.persistSheet('buyers');
    this.notify('Buyer added');
    this.renderBuyers();
    this.close('add-buyer-modal');
    document.querySelectorAll('#add-buyer-modal input').forEach(i => i.value = '');
    document.getElementById('buyer-logo-data').value = '';
    document.getElementById('buyer-logo-preview').innerHTML = '<i class="bi bi-building placeholder-icon"></i>';
  },

  async saveSupplier() {
    const name = document.getElementById('supplier-name').value.trim();
    const contactPerson = document.getElementById('supplier-contact-person').value.trim();
    const address = document.getElementById('supplier-address').value.trim();
    const mobile = document.getElementById('supplier-mobile').value.trim();
    const bin = document.getElementById('supplier-bin').value.trim();
    const bankAcc = document.getElementById('supplier-bankacc').value.trim();
    const bank = document.getElementById('supplier-bank').value.trim();
    const logo = document.getElementById('supplier-logo-data').value || '';
    if (!name) { this.notify('Supplier Name is required', 'warn'); return; }

    const newId = await this.allocId('suppliers');
    this.state.suppliers.push({ id: newId, name, contactPerson, address, mobile, bin, bankAcc, bank, logo, supply: 0, status: 'Active' });
    await this.persistSheet('suppliers');
    this.notify('Supplier added');
    this.renderSuppliers();
    this.close('add-supplier-modal');
    document.querySelectorAll('#add-supplier-modal input').forEach(i => i.value = '');
    document.getElementById('supplier-logo-data').value = '';
    document.getElementById('supplier-logo-preview').innerHTML = '<i class="bi bi-building placeholder-icon"></i>';
  },

  async clearAllData() {
    if (this.role !== 'superadmin') { alert('Only Super Admin can clear all data'); return; }
    if (!confirm('Delete ALL records from the app and Supabase? This cannot be undone.')) return;
    this.state = JSON.parse(JSON.stringify(DEFAULT_STATE));
    this.masterData.orders = {};
    this.showLoader(true);
    if (SheetsDB.isConfigured()) {
      try {
        await SheetsDB.clearAllSheets();
        this.dbConnected = true;
        this.notify('All data cleared from Supabase');
      } catch (e) {
        this.notify('Local data cleared — Sheets sync failed: ' + e.message, 'warn');
      }
    } else {
      this.notify('All local data cleared');
    }
    this.renderAllTables();
    this.populateOrderDropdown();
    this.charts(true);
    this.updateSyncStatus();
    this.showLoader(false);
  },

  async refreshData() {
    const icon = document.getElementById('refresh-icon');
    const btn = document.getElementById('refresh-btn');
    if (icon) icon.classList.add('spin-icon');
    if (btn) btn.disabled = true;

    if (!SheetsDB.isConfigured()) {
      this.notify('Supabase URL/Key is not configured -- add it from Settings', 'warn');
      if (icon) icon.classList.remove('spin-icon');
      if (btn) btn.disabled = false;
      return;
    }

    try {
      await this.loadFromDatabase();
      this.renderAllTables();
      this.populateOrderDropdown();
      this.populateAttendanceEmployees();
      this.charts(true);
    } catch (e) {
      this.notify('Refresh failed: ' + e.message, 'error');
    }
    this.updateSyncStatus();
    if (icon) icon.classList.remove('spin-icon');
    if (btn) btn.disabled = false;
  },

  async syncAllToSheets() {
    if (!SheetsDB.isConfigured()) { this.notify('Configure Supabase URL/Key first', 'warn'); return; }
    this.showLoader(true);
    try {
      await SheetsDB.bulkSave(this.state);
      await SheetsDB.saveSettings(this.settings);
      const rows = Object.keys(this.masterData.orders).map(k => ({ orderNo: k, ...this.masterData.orders[k] }));
      await SheetsDB.saveSheet('orders', rows);
      this.dbConnected = true;
      this.notify('All data synced to Supabase');
    } catch (e) {
      this.notify('Sync failed: ' + e.message, 'error');
    }
    this.updateSyncStatus();
    this.showLoader(false);
  },

  populateAttendanceEmployees() {
    const select = document.getElementById('att-employee');
    if (!select) return;
    const current = select.value;
    // ⚠️ There's no way to create a new Check-In entry for an Inactive
    // (resigned/dismissed) employee -- only Active employees are shown in the list
    const activeEmployees = this.state.hrEmployees.filter(e => (e.status || 'Active') !== 'Inactive');
    select.innerHTML = '<option value="">Select Employee...</option>' +
      activeEmployees.map(e => `<option value="${this.escapeHtml(e.name)}">${this.escapeHtml(e.name)}</option>`).join('');
    if (current) select.value = current;
    const dateEl = document.getElementById('att-date');
    if (dateEl && !dateEl.value) dateEl.value = todayStr();
    const timeEl = document.getElementById('att-checkin-time');
    if (timeEl && !timeEl.value) timeEl.value = new Date().toTimeString().slice(0, 5);

    // The Attendance Log's Employee filter dropdown -- everyone (Active+Inactive) is shown
    // here, so a former employee's old history can still be filtered and viewed if needed
    const logFilterSelect = document.getElementById('att-log-filter-employee');
    if (logFilterSelect) {
      const currentFilter = logFilterSelect.value;
      logFilterSelect.innerHTML = '<option value="">All employees</option>' +
        this.state.hrEmployees.map(e => `<option value="${this.escapeHtml(e.name)}">${this.escapeHtml(e.name)}</option>`).join('');
      if (currentFilter) logFilterSelect.value = currentFilter;
    }
  },

  // Compared against Office Open Time, a late Check-In Time is marked "Late", otherwise "Present"
  async checkInAttendance() {
    const emp = document.getElementById('att-employee').value;
    const date = document.getElementById('att-date').value || todayStr();
    const checkIn = document.getElementById('att-checkin-time').value;
    if (!emp || !checkIn) { this.notify('Employee and Check-In Time are required', 'warn'); return; }

    const officeOpen = this.settings.officeOpenTime || '09:00';
    const status = checkIn > officeOpen ? 'Late' : 'Present';

    // If an "On Leave" placeholder entry already exists for this date (leave was planned but
    // they actually came in to the office), it's updated with the real Check-In -- the new
    // entry is not blocked. But if a real Check-In (non-leave) already exists, a duplicate
    // entry is still prevented, as before.
    const existing = this.state.hrAttendance.find(r => r.employee === emp && r.date === date);
    if (existing && existing.status !== 'On Leave') {
      this.notify('This employee already has today\'s entry', 'warn');
      return;
    }
    if (existing) {
      existing.checkIn = checkIn; existing.status = status;
    } else {
      const newId = await this.allocId('hrAttendance');
      this.state.hrAttendance.push({ id: newId, date, employee: emp, checkIn, checkOut: '', status, otHours: 0 });
    }
    await this.persistSheet('hrAttendance');
    this.notify(`${emp} - ${status}`);
    this.renderHRAttendance();
    document.getElementById('att-employee').value = '';
  },

  // Opens the Leave Application modal (D1) -- populates the employee dropdown (only Active
  // employees, since there's no need to create a new leave application for an
  // Inactive/former employee)
  openAddLeaveModal() {
    const select = document.getElementById('leave-employee');
    const activeEmployees = this.state.hrEmployees.filter(e => (e.status || 'Active') !== 'Inactive');
    select.innerHTML = '<option value="">Select Employee...</option>' +
      activeEmployees.map(e => `<option value="${this.escapeHtml(e.name)}">${this.escapeHtml(e.name)}</option>`).join('');
    document.getElementById('leave-start-date').value = todayStr();
    document.getElementById('leave-end-date').value = todayStr();
    document.getElementById('leave-doc-data').value = '';
    document.getElementById('leave-doc-preview').innerHTML = '<i class="bi bi-file-earmark-text placeholder-icon"></i>';
    this.open('add-leave-modal');
  },

  // Saves the leave application + auto-creates a status="On Leave" entry in hrAttendance for
  // every date in the Start-End Date range (excluding any date that already has a Check-In
  // entry, so real attendance data is never overwritten)
  async saveLeaveRequest() {
    const employee = document.getElementById('leave-employee').value;
    const startDate = document.getElementById('leave-start-date').value;
    const endDate = document.getElementById('leave-end-date').value;
    const document_ = document.getElementById('leave-doc-data').value || '';
    if (!employee || !startDate || !endDate) { this.notify('Employee, Start Date and End Date are required', 'warn'); return; }
    if (endDate < startDate) { this.notify('End Date cannot be before Start Date', 'warn'); return; }

    const newId = await this.allocId('hrLeaves');
    // Total leave days (inclusive) -- calculated and stored once, for showing in the Leaves list and Leave Report
    const days = Math.round((new Date(endDate + 'T00:00:00') - new Date(startDate + 'T00:00:00')) / 86400000) + 1;
    this.state.hrLeaves.push({ id: newId, employee, startDate, endDate, days, document: document_, createdAt: nowISO() });
    await this.persistSheet('hrLeaves');

    // Creates an On Leave entry for every date from startDate through endDate
    let added = 0;
    const cur = new Date(startDate + 'T00:00:00');
    const end = new Date(endDate + 'T00:00:00');
    while (cur <= end) {
      const dateStr = zkLocalDateStr(cur);
      if (!this.state.hrAttendance.some(r => r.employee === employee && r.date === dateStr)) {
        const attId = await this.allocId('hrAttendance');
        this.state.hrAttendance.push({ id: attId, date: dateStr, employee, checkIn: '', checkOut: '', status: 'On Leave', otHours: 0 });
        added++;
      }
      cur.setDate(cur.getDate() + 1);
    }
    if (added) await this.persistSheet('hrAttendance');

    this.logAudit('Create', 'hrLeaves', newId, employee);
    this.notify(`${employee}'s leave saved -- "On Leave" status added for ${added} date(s)`);
    this.renderHRAttendance();
    this.renderHRLeaves();
    this.close('add-leave-modal');
  },

  // ⚠️ Feature (HR Module improvement): a leave application (hrLeaves) used to save
  // correctly, but there was no list at all to view/delete it -- the Attendance Log only
  // showed its result (an "On Leave" entry) as separate individual days, while the actual
  // application (from-to, how many days, document) stayed invisible. A separate "Leaves" tab
  // has now been added to the HR Module, listing every leave application.
  renderHRLeaves() {
    const tbody = document.getElementById('hr-leaves-tbody');
    if (!tbody) return;
    if (!this.state.hrLeaves.length) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:24px">No leave applications yet. Add one from the "Leave of Absence" button on the Attendance tab.</td></tr>';
      return;
    }
    const sorted = [...this.state.hrLeaves].sort((a, b) => (b.startDate || '').localeCompare(a.startDate || ''));
    tbody.innerHTML = sorted.map(row => {
      const days = row.days || (Math.round((new Date(row.endDate + 'T00:00:00') - new Date(row.startDate + 'T00:00:00')) / 86400000) + 1);
      return `
      <tr><td>${this.escapeHtml(row.employee)}</td><td>${formatDate(row.startDate)}</td><td>${formatDate(row.endDate)}</td>
      <td><span class="badge badge-b">${days} day(s)</span></td>
      <td>${row.document ? `<button class="action-btn action-view" onclick="app.viewLeaveDocument(${row.id})" title="View attached document"><i class="bi bi-file-earmark-image"></i> View</button>` : '-'}</td>
      <td><button class="action-btn action-delete hr-delete" onclick="app.confirmDelete('hrLeaves', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`;
    }).join('');
  },

  // Shows the document (medical certificate, etc.) uploaded with a leave application, opened in a new tab
  viewLeaveDocument(id) {
    const row = this.state.hrLeaves.find(r => r.id === id);
    if (!row || !row.document) return;
    const w = window.open('');
    if (w) w.document.write(`<title>${this.escapeHtml(row.employee)} — Leave Document</title><body style="margin:0;background:#111;display:flex;align-items:center;justify-content:center;min-height:100vh;"><img src="${this.escapeHtml(row.document)}" style="max-width:100%;max-height:100vh;"></body>`);
  },

  // Opens the Check-Out modal -- a native time picker is used (not prompt()), so the user can pick a time easily
  openCheckOutModal(id) {
    document.getElementById('checkout-attendance-id').value = id;
    document.getElementById('checkout-time').value = new Date().toTimeString().slice(0, 5);
    this.open('checkout-modal');
  },

  // If time worked at Check-Out goes past Office Close Time, that extra time is calculated
  // and saved automatically as Overtime Hours
  async checkOutAttendance() {
    const id = parseInt(document.getElementById('checkout-attendance-id').value);
    const checkOut = document.getElementById('checkout-time').value;
    const row = this.state.hrAttendance.find(r => r.id === id);
    if (!row || !checkOut) return;

    row.checkOut = checkOut;
    const officeClose = this.settings.officeCloseTime || '18:00';
    if (checkOut > officeClose) {
      const [outH, outM] = checkOut.split(':').map(Number);
      const [closeH, closeM] = officeClose.split(':').map(Number);
      const otMinutes = (outH * 60 + outM) - (closeH * 60 + closeM);
      row.otHours = Math.round((otMinutes / 60) * 100) / 100;
    } else {
      row.otHours = 0;
    }
    await this.persistSheet('hrAttendance');
    this.notify(`Check-Out recorded${row.otHours > 0 ? ' -- OT: ' + row.otHours + ' hrs' : ''}`);
    this.renderHRAttendance();
    this.close('checkout-modal');
  },

  addPIRow() {
    const tbody = document.getElementById('pi-full-tbody');
    const r = tbody.rows.length + 1;
    const row = document.createElement('tr');
    row.innerHTML = `<td>${r}</td><td><input></td><td><input></td><td><input></td><td><input></td><td><input></td>
      <td><input list="pi-item-codes-list" placeholder="Item Code" onchange="app.autofillPIItemRow(this)"></td>
      <td><input placeholder="Description"></td>
      <td><input type="number" step="any" value="0" oninput="app.calcFullPI()" style="text-align:right"></td>
      <td><input type="number" step="any" value="0.00" oninput="app.calcFullPI()" style="text-align:right"></td>
      <td class="total-cell" style="text-align:right">$0.00</td>
      <td class="no-print"><button class="btn" style="padding:2px 5px;border:none;color:var(--red);background:transparent" onclick="this.closest('tr').remove();app.calcFullPI()"><i class="bi bi-trash"></i></button></td>`;
    tbody.appendChild(row);
  },

  // After typing/selecting in a PI's Item Code cell, if it matches Master Data, Style No,
  // HS Code, Dept, Description and Unit Price -- every linked field is auto-filled (each input
  // below stays a normal editable <input>, so the user can still manually change the value on
  // any line even after autofill). The user is warned if it doesn't match Master Data, since
  // only an item code that's in Master Data is meant to be used.
  autofillPIItemRow(el) {
    const code = el.value.trim();
    const row = el.closest('tr');
    if (!row) return;
    const hsCodeInput = row.cells[2].querySelector('input');
    const deptInput = row.cells[3].querySelector('input');
    const styleNoInput = row.cells[5].querySelector('input');
    const descInput = row.cells[7].querySelector('input');
    const priceInput = row.cells[9].querySelector('input');
    const item = this.state.masterData.find(m => m.itemCode.toLowerCase() === code.toLowerCase());
    if (item) {
      el.value = item.itemCode;
      el.style.outline = '';
      if (descInput) descInput.value = item.description;
      if (priceInput) priceInput.value = item.sellingPrice ?? item.unitPrice ?? 0;
      if (styleNoInput) styleNoInput.value = item.styleNo || '';
      if (hsCodeInput) hsCodeInput.value = item.hsCode || '';
      if (deptInput) deptInput.value = item.dept || '';
      this.calcFullPI();
    } else if (code) {
      el.style.outline = '2px solid var(--red)';
      this.notify('This Item Code was not found in Master Data. Select a valid code from the list, or add it to Master Data first.', 'warn');
    } else {
      el.style.outline = '';
    }
  },

  calcFullPI() {
    let total = 0, qty = 0;
    document.querySelectorAll('#pi-full-tbody tr').forEach(r => {
      const q = parseFloat(r.cells[8].querySelector('input').value) || 0;
      const p = parseFloat(r.cells[9].querySelector('input').value) || 0;
      const t = this.roundMoney(q * p); total = this.roundMoney(total + t); qty += q;
      r.cells[10].innerText = this.fmtMoney2(t);
    });
    document.getElementById('pi-full-tqty').innerText = qty.toLocaleString(undefined, { maximumFractionDigits: 3 });
    document.getElementById('pi-full-gtotal').innerText = this.fmtMoney2(total);
    document.getElementById('pi-in-words').innerText = 'IN WORDS: USD ' + this.amountInWords(total) + ' ONLY.';
  },

  // Splits a dollar amount into whole-dollar and cent parts and writes both out in words,
  // so amounts like $1,234.56 read "...THIRTY FOUR AND FIFTY SIX CENTS ONLY" instead of
  // silently dropping the .56 (the previous Math.round(total) call lost the cents entirely).
  amountInWords(total) {
    // work in whole cents so 20.995 -> 21.00 can never produce "ONE HUNDRED CENTS"
    const totalCents = Math.round(this.roundMoney(Math.abs(total)) * 100);
    const whole = Math.floor(totalCents / 100);
    const cents = totalCents % 100;
    let out = this.numberToWords(whole);
    if (cents > 0) out += ' AND ' + this.numberToWords(cents) + ' CENTS';
    return out;
  },

  numberToWords(n) {
    // ⚠️ Bug fix: with no "CRORE" tier for numbers above 1 crore (10,000,000), the output used
    // to be wrong (e.g. "ONE HUNDRED LAKH" where it should say "ONE CRORE") -- print-out
    // invoices had a wrong amount-in-words. Both negative numbers and the Crore tier are
    // handled correctly now.
    if (n < 0) return 'MINUS ' + this.numberToWords(Math.abs(n));
    if (n === 0) return 'ZERO';
    const ones = ['','ONE','TWO','THREE','FOUR','FIVE','SIX','SEVEN','EIGHT','NINE','TEN','ELEVEN','TWELVE','THIRTEEN','FOURTEEN','FIFTEEN','SIXTEEN','SEVENTEEN','EIGHTEEN','NINETEEN'];
    const tens = ['','','TWENTY','THIRTY','FORTY','FIFTY','SIXTY','SEVENTY','EIGHTY','NINETY'];
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : '');
    if (n < 1000) return ones[Math.floor(n / 100)] + ' HUNDRED' + (n % 100 ? ' AND ' + this.numberToWords(n % 100) : '');
    if (n < 100000) return this.numberToWords(Math.floor(n / 1000)) + ' THOUSAND' + (n % 1000 ? ' ' + this.numberToWords(n % 1000) : '');
    if (n < 10000000) return this.numberToWords(Math.floor(n / 100000)) + ' LAKH' + (n % 100000 ? ' ' + this.numberToWords(n % 100000) : '');
    return this.numberToWords(Math.floor(n / 10000000)) + ' CRORE' + (n % 10000000 ? ' ' + this.numberToWords(n % 10000000) : '');
  },

  async savePI() {
    const editId = document.getElementById('pi-edit-id').value;
    const formData = this.getPIFormData();
    if (!formData.invoiceNo) { this.notify('Please enter Invoice No', 'warn'); return; }
    const record = {
      date: formData.invoiceDate || new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', timeZone: APP_TIMEZONE }),
      piNo: formData.invoiceNo,
      buyer: formData.buyer,
      supplier: formData.supplier,
      items: formData.lineItems.length,
      totalValue: formData.grandTotal,
      qcStatus: 'Hold',
      formData
    };

    let recordId;
    if (editId) {
      const idx = this.state.piList.findIndex(r => r.id == editId);
      if (idx !== -1) this.state.piList[idx] = { id: parseInt(editId), ...record };
      recordId = editId;
      this.notify('PI Updated');
    } else {
      const newId = await this.allocId('piList');
      this.state.piList.unshift({ id: newId, ...record });
      recordId = newId;
      this.notify('PI Saved');
    }
    this.logAudit(editId ? 'Update' : 'Create', 'piList', recordId, record.piNo);
    await this.persistSheet('piList');

    // The PI is also registered as an "Order" (treating PI No as the Order No), so it can be
    // selected in the Order No dropdown on the Received Goods, Delivery, QC, etc. forms
    const totalQtySum = formData.lineItems.reduce((s, it) => s + (parseFloat(it.qty) || 0), 0);
    await this.registerOrder(formData.invoiceNo, {
      buyer: record.buyer,
      supplier: record.supplier,
      qty: totalQtySum,
      pi: formData.invoiceNo,
      styleNo: formData.lineItems.map(it => it.styleNo).filter(Boolean).join(', '),
      itemName: formData.lineItems.map(it => it.description).filter(Boolean).join(', '),
      contact: '', address: '', type: 'PI'
    });

    // An entry is also automatically created/updated in the Buyer Ledger (accBuyer) for this PI
    this.syncAccBuyerFromPI(record);

    this.renderPITable();
    this.updateDashboard();
    this.close('pi-modal');
  },

  // Saving a PI automatically creates or updates an entry for that PI No in the Buyer Ledger
  // (Accounts & Finance > Buyer Due) -- Total comes from here, the previous Received/Due stays
  // intact
  async syncAccBuyerFromPI(piRecord) {
    const total = this.parseMoney(piRecord.totalValue);
    let row = this.state.accBuyer.find(r => r.piNo === piRecord.piNo);
    if (row) {
      row.buyer = piRecord.buyer;
      row.total = this.formatUSD(total);
      const received = this.parseMoney(row.received);
      const due = Math.max(total - received, 0);
      row.due = this.formatUSD(due);
      row.status = due <= 0 ? 'Paid' : 'Due';
    } else {
      const newId = await this.allocId('accBuyer');
      this.state.accBuyer.push({
        id: newId, piNo: piRecord.piNo, buyer: piRecord.buyer, lc: '',
        total: this.formatUSD(total), received: this.formatUSD(0), due: this.formatUSD(total), status: 'Due'
      });
    }
    await this.persistSheet('accBuyer');
    this.renderAccBuyer();
  },

  // B1: Challan Generator now opens as a full-screen modal (used to be a separate tab)
  openChallanFullscreen() {
    document.getElementById('challan-edit-id').value = '';
    this.syncChallanDetails();
    ['challan-no', 'challan-buyer', 'challan-contact', 'challan-address', 'challan-pi'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
    document.getElementById('challan-date').value = todayStr();
    document.getElementById('challan-grand-total').innerText = '______';
    document.getElementById('challan-tbody').innerHTML =
      '<tr><td contenteditable="true">1</td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td class="no-print row-action-cell" style="text-align:center;"><button type="button" class="action-btn action-delete" onclick="app.removeChallanRow(this)" title="Delete this row"><i class="bi bi-trash"></i></button></td></tr>' +
      '<tr><td contenteditable="true">2</td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td class="no-print row-action-cell" style="text-align:center;"><button type="button" class="action-btn action-delete" onclick="app.removeChallanRow(this)" title="Delete this row"><i class="bi bi-trash"></i></button></td></tr>';
    const goodsEntryInput = document.getElementById('challan-goods-entry-input');
    if (goodsEntryInput) goodsEntryInput.value = '';
    // B5: The Delivered By dropdown is populated from HR Module > Employees
    const dbSelect = document.getElementById('challan-delivered-by');
    if (dbSelect) {
      dbSelect.innerHTML = '<option value="">Select</option>' +
        this.state.hrEmployees.map(e => `<option value="${this.escapeHtml(e.name)}">${this.escapeHtml(e.name)}</option>`).join('');
    }
    document.getElementById('challan-delivered-by-print').innerText = '';
    const box = document.getElementById('challan-fullscreen-box');
    if (box) box.classList.remove('minimized');
    document.getElementById('challan-fs-icon').className = 'bi bi-arrows-angle-contract';
    document.getElementById('challan-fs-text').innerText = 'Minimize';
    this.open('challan-fullscreen-modal');
  },

  // Minimize/Maximize toggle
  toggleChallanFullscreen() {
    const box = document.getElementById('challan-fullscreen-box');
    if (!box) return;
    const isMin = box.classList.toggle('minimized');
    document.getElementById('challan-fs-icon').className = isMin ? 'bi bi-arrows-angle-expand' : 'bi bi-arrows-angle-contract';
    document.getElementById('challan-fs-text').innerText = isMin ? 'Maximize' : 'Minimize';
  },

  // B3: saves the challan to the database -- a new entry is added to "Planning & Overdue"
  // with status "Hold" (the previous status is kept in edit mode). The full challan detail
  // (item rows, address, etc.) is stored in challanData so the complete data can be retrieved
  // again when viewing/editing.
  async saveChallanToDB() {
    const editId = document.getElementById('challan-edit-id').value;
    const challanNo = document.getElementById('challan-no').value.trim();
    const buyer = document.getElementById('challan-buyer').value.trim();
    const contact = document.getElementById('challan-contact').value.trim();
    const date = document.getElementById('challan-date').value;
    const address = document.getElementById('challan-address').value.trim();
    const piNo = document.getElementById('challan-pi').value.trim();
    const deliveredBy = document.getElementById('challan-delivered-by').value;
    const grandTotal = document.getElementById('challan-grand-total').innerText.trim();
    if (!challanNo || !buyer || !date) { this.notify('Challan No, Buyer Name and Date are required', 'warn'); return; }

    const rows = Array.from(document.querySelectorAll('#challan-tbody tr')).map(tr => {
      const c = tr.querySelectorAll('td');
      return { sl: c[0]?.innerText.trim(), poNo: c[1]?.innerText.trim(), styleNo: c[2]?.innerText.trim(), itemCode: c[3]?.innerText.trim(),
        item: c[4]?.innerText.trim(), orderQty: c[5]?.innerText.trim(), deliveryQty: c[6]?.innerText.trim(), brand: c[7]?.innerText.trim(),
        color: c[8]?.innerText.trim(), shortExcess: c[9]?.innerText.trim(), remarks: c[10]?.innerText.trim() };
    }).filter(r => r.item || r.itemCode);
    const remainingQty = rows.reduce((s, r) => s + (parseFloat(r.deliveryQty) || 0), 0);
    const itemSummary = rows.length ? (rows.length > 2 ? `${rows[0].item || rows[0].itemCode}, +${rows.length - 1} more` : rows.map(r => r.item || r.itemCode).join(', ')) : '';
    const challanData = { challanNo, buyer, contact, date, address, piNo, deliveredBy, grandTotal, rows };

    if (editId) {
      const idx = this.state.deliveryPlan.findIndex(r => r.id == editId);
      if (idx !== -1) {
        this.state.deliveryPlan[idx] = { ...this.state.deliveryPlan[idx], orderNo: challanNo, buyer, item: itemSummary, remainingQty, expectedDate: date, challanData };
        this.notify('Challan updated');
      }
    } else {
      const newId = await this.allocId('deliveryPlan');
      this.state.deliveryPlan.push({ id: newId, orderNo: challanNo, buyer, item: itemSummary, remainingQty, expectedDate: date, priority: 'Normal', status: 'Hold', challanData });
      this.notify('Challan saved -- added to "Planning & Overdue"');
    }
    await this.persistSheet('deliveryPlan');
    this.renderDeliveryPlan();
    this.close('challan-fullscreen-modal');
    const tab = document.querySelector('#delivery .tabs .tab:nth-child(1)');
    if (tab) this.switchTab(tab, 'del-plan');
  },

  // Planning & Overdue's "Edit" button -- loads a saved challan's full data back into the Challan Generator
  editDeliveryPlanChallan(id) {
    const row = this.state.deliveryPlan.find(r => r.id === id);
    if (!row || !row.challanData) { this.notify('No challan data was found for this entry', 'warn'); return; }
    const cd = row.challanData;
    this.openChallanFullscreen();
    document.getElementById('challan-edit-id').value = id;
    document.getElementById('challan-no').value = cd.challanNo || '';
    document.getElementById('challan-buyer').value = cd.buyer || '';
    document.getElementById('challan-contact').value = cd.contact || '';
    document.getElementById('challan-date').value = cd.date || '';
    document.getElementById('challan-address').value = cd.address || '';
    document.getElementById('challan-pi').value = cd.piNo || '';
    document.getElementById('challan-delivered-by').value = cd.deliveredBy || '';
    document.getElementById('challan-delivered-by-print').innerText = cd.deliveredBy || '';
    document.getElementById('challan-grand-total').innerText = cd.grandTotal || '______';
    if (cd.rows && cd.rows.length) {
      document.getElementById('challan-tbody').innerHTML = cd.rows.map(r => `
        <tr><td contenteditable="true">${this.escapeHtml(r.sl)}</td><td contenteditable="true">${this.escapeHtml(r.poNo)}</td><td contenteditable="true">${this.escapeHtml(r.styleNo)}</td>
        <td contenteditable="true">${this.escapeHtml(r.itemCode)}</td><td contenteditable="true">${this.escapeHtml(r.item)}</td><td contenteditable="true">${this.escapeHtml(r.orderQty)}</td>
        <td contenteditable="true">${this.escapeHtml(r.deliveryQty)}</td><td contenteditable="true">${this.escapeHtml(r.brand)}</td><td contenteditable="true">${this.escapeHtml(r.color)}</td>
        <td contenteditable="true">${this.escapeHtml(r.shortExcess)}</td><td contenteditable="true">${this.escapeHtml(r.remarks)}</td>
        <td class="no-print row-action-cell" style="text-align:center;"><button type="button" class="action-btn action-delete" onclick="app.removeChallanRow(this)" title="Delete this row"><i class="bi bi-trash"></i></button></td></tr>`).join('');
    }
  },

  // Planning & Overdue's "View" বাটন — সংরক্ষিত চালান পড়ার জন্য (রিড-অনলি)
  viewDeliveryPlanChallan(id) {
    const row = this.state.deliveryPlan.find(r => r.id === id);
    if (!row) return;
    const cd = row.challanData || {};
    const rowsHtml = (cd.rows && cd.rows.length) ? cd.rows.map(r => `
      <tr><td>${this.escapeHtml(r.sl)}</td><td>${this.escapeHtml(r.poNo)}</td><td>${this.escapeHtml(r.styleNo)}</td><td>${this.escapeHtml(r.itemCode)}</td>
      <td>${this.escapeHtml(r.item)}</td><td>${this.escapeHtml(r.orderQty)}</td><td>${this.escapeHtml(r.deliveryQty)}</td><td>${this.escapeHtml(r.brand)}</td>
      <td>${this.escapeHtml(r.color)}</td><td>${this.escapeHtml(r.shortExcess)}</td><td>${this.escapeHtml(r.remarks)}</td></tr>`).join('')
      : '<tr><td colspan="11" style="text-align:center;color:var(--text-muted)">No items found</td></tr>';
    document.getElementById('view-pi-content').innerHTML = `
      <div style="display:grid;gap:12px">
        <div class="grid-3"><div class="fg"><label>Challan No</label><input value="${this.escapeHtml(cd.challanNo || row.orderNo)}" readonly></div><div class="fg"><label>Date</label><input value="${formatDate(cd.date || row.expectedDate)}" readonly></div><div class="fg"><label>Status</label><input value="${this.esc(row.status)}" readonly></div></div>
        <div class="grid-2"><div class="fg"><label>Buyer</label><input value="${this.escapeHtml(cd.buyer || row.buyer)}" readonly></div><div class="fg"><label>Contact Person</label><input value="${this.escapeHtml(cd.contact || '')}" readonly></div></div>
        <div class="grid-2"><div class="fg"><label>Address</label><input value="${this.escapeHtml(cd.address || '')}" readonly></div><div class="fg"><label>PI No</label><input value="${this.escapeHtml(cd.piNo || '')}" readonly></div></div>
        <div class="table-wrap"><table style="font-size:11px"><thead><tr><th>SL</th><th>PO No</th><th>Style No</th><th>Item Code</th><th>Item</th><th>Order Qty</th><th>Delivery Qty</th><th>Brand</th><th>Color</th><th>Short/Excess</th><th>Remarks</th></tr></thead><tbody>${rowsHtml}</tbody></table></div>
        <div class="grid-2"><div class="fg"><label>Grand Total</label><input value="${this.escapeHtml(cd.grandTotal || '')}" readonly></div><div class="fg"><label>Delivered By</label><input value="${this.escapeHtml(cd.deliveredBy || '')}" readonly></div></div>
      </div>`;
    this.open('view-pi-modal');
  },

  // B3: Status dropdown -- Complete moves it to the History Timeline, Hold keeps it here (highlighted red)
  async updateDeliveryPlanStatus(id, newStatus) {
    const idx = this.state.deliveryPlan.findIndex(r => r.id === id);
    if (idx === -1) return;
    const row = this.state.deliveryPlan[idx];
    if (newStatus === 'Complete') {
      const cd = row.challanData || {};
      const newHistId = await this.allocId('deliveryHist');
      this.state.deliveryHist.unshift({
        id: newHistId, date: cd.date || row.expectedDate, orderNo: row.orderNo, buyer: row.buyer,
        challan: cd.challanNo || row.orderNo, qty: row.remainingQty, deliveredBy: cd.deliveredBy || ''
      });
      this.state.deliveryPlan.splice(idx, 1);
      await this.persistSheet('deliveryHist');
      // ⚠️ Round 13: persistSheet('deliveryPlan') used to rely on diff-sync to delete this
      // now-completed record from the DB (that won't work any more since upsertRows() no
      // longer deletes) -- so deleteRow() is now called directly
      if (SheetsDB.isConfigured() && this.dbConnected) {
        try { await SheetsDB.deleteRow('deliveryPlan', id); } catch (e) { this.notify('Delivery Plan DB sync failed: ' + e.message, 'error'); }
      }
      this.notify('Challan complete -- added to History Timeline');
      this.renderDeliveryHist();
    } else {
      row.status = 'Hold';
      await this.persistSheet('deliveryPlan');
      this.notify('Status: Hold');
    }
    this.renderDeliveryPlan();
  },

  addVoucherRow() {
    document.getElementById('voucher-transport-rows').insertAdjacentHTML('beforeend', '<tr><td><input type="text" placeholder="Origin" style="background:transparent;border:none;color:#000;width:100%"></td><td><input type="text" placeholder="Dest" style="background:transparent;border:none;color:#000;width:100%"></td><td><input type="text" placeholder="Mode" style="background:transparent;border:none;color:#000;width:100%"></td><td><input type="number" placeholder="0" style="background:transparent;border:none;color:#000;width:100%" oninput="app.calcVoucherDue()"></td></tr>');
  },

  removeVoucherRow() {
    const tbody = document.getElementById('voucher-transport-rows');
    if (tbody.rows.length > 1) tbody.deleteRow(tbody.rows.length - 1);
    this.calcVoucherDue();
  },

  // Bug fix: Due Amount used to be calculated as Received − Return, never accounting for the
  // Voucher Details table's (transport rows) expense total. The correct calculation:
  // Received = expense (transportTotal) + Return + Due, so Due = Received − transportTotal −
  // Return. A negative result (meaning more expense+return was entered than received) is not
  // hidden -- it's highlighted red instead, to flag that a data entry error has been caught.
  calcVoucherDue() {
    const receivedEl = document.getElementById('voucher-entry-received');
    const returnEl = document.getElementById('voucher-entry-return');
    const dueEl = document.getElementById('voucher-entry-due');
    const received = receivedEl ? parseFloat(receivedEl.value) || 0 : 0;
    const ret = returnEl ? parseFloat(returnEl.value) || 0 : 0;
    const transportTotal = Array.from(document.querySelectorAll('#voucher-transport-rows tr')).reduce((sum, tr) => {
      const amountInput = tr.querySelectorAll('input')[3];
      return sum + (parseFloat(amountInput && amountInput.value) || 0);
    }, 0);
    const due = received - transportTotal - ret;
    if (dueEl) {
      dueEl.value = due.toFixed(2);
      dueEl.style.color = due < 0 ? 'var(--red)' : 'var(--accent)';
    }
  },

  // ⚠️ Redesign (C4): this used to save into a separate "vouchers" table, and a copy was only
  // created in Expense List once Approved -- it now saves straight into Expense List (status:
  // Pending), so an authorised person (Super Admin/Admin/Accountant) can Approve/Reject
  // directly from Expense List itself. The transport rows' detail (voucherDetails) is stored
  // so the full voucher can be seen on "View".
  async saveVoucherEntry() {
    const editId = document.getElementById('voucher-entry-edit-id').value;
    const voucherNo = document.getElementById('voucher-entry-no').value.trim();
    const date = document.getElementById('voucher-entry-date').value;
    const claimant = document.getElementById('voucher-entry-claimant').value.trim();
    const purpose = document.getElementById('voucher-entry-purpose').value.trim();
    const received = parseFloat(document.getElementById('voucher-entry-received').value) || 0;
    const ret = parseFloat(document.getElementById('voucher-entry-return').value) || 0;
    if (!voucherNo || !date || !claimant || !purpose) { this.notify('Complete voucher details', 'warn'); return; }
    const transportRows = Array.from(document.querySelectorAll('#voucher-transport-rows tr')).map(tr => {
      const ins = tr.querySelectorAll('input');
      return { from: ins[0]?.value || '', to: ins[1]?.value || '', vehicle: ins[2]?.value || '', amount: parseFloat(ins[3]?.value) || 0 };
    });
    const transportTotal = transportRows.reduce((s, r) => s + r.amount, 0);
    // Bug fix: Due Amount used to be calculated as just (Received - Return), never
    // accounting for the Voucher Details table's expense (transportTotal). Now: Due = Received
    // - transportTotal - Return -- i.e. whatever remains/is outstanding after subtracting the
    // real expense and the return from the amount received is the Due.
    const due = received - transportTotal - ret;
    const voucherDetails = { transportRows, received: received.toFixed(2), transportTotal: transportTotal.toFixed(2) };
    const record = { date, voucherNo, category: purpose, person: claimant, purpose, amount: due.toFixed(2), ret: ret.toFixed(2), voucherDetails };

    let recordId;
    if (editId) {
      const idx = this.state.expenseList.findIndex(r => r.id == editId);
      if (idx !== -1) {
        this.state.expenseList[idx] = { ...this.state.expenseList[idx], ...record };
        this.notify('Voucher updated');
      }
      recordId = editId;
    } else {
      const newId = await this.allocId('expenseList');
      this.state.expenseList.unshift({ id: newId, ...record, status: 'Pending', rejectNote: '' });
      recordId = newId;
      this.notify('Voucher saved -- added to Expense List as Pending, awaiting approval');
    }
    this.logAudit(editId ? 'Update' : 'Create', 'expenseList', recordId, voucherNo);
    await this.persistSheet('expenseList');
    this.renderExpenseList();
    document.getElementById('voucher-entry-edit-id').value = '';
    document.getElementById('voucher-entry-no').value = '';
    document.getElementById('voucher-entry-date').value = '';
    document.getElementById('voucher-entry-claimant').value = '';
    document.getElementById('voucher-entry-purpose').value = '';
    document.getElementById('voucher-entry-received').value = '';
    document.getElementById('voucher-entry-return').value = '';
    document.getElementById('voucher-entry-due').value = '';
    document.getElementById('voucher-transport-rows').innerHTML = '<tr><td><input type="text" placeholder="Origin" style="background:transparent;border:none;color:#000;width:100%"></td><td><input type="text" placeholder="Destination" style="background:transparent;border:none;color:#000;width:100%"></td><td><input type="text" placeholder="Mode" style="background:transparent;border:none;color:#000;width:100%"></td><td><input type="number" placeholder="0" style="background:transparent;border:none;color:#000;width:100%"></td></tr>';
    const tab = document.querySelector('#acc-expense .tabs .tab:nth-child(1)');
    if (tab) this.switchTab(tab, 'exp-list');
  },

  // The "View" button on a Pending voucher row in Expense List shows the full voucher
  // (transport rows, Received/Due, and the note too if it was Rejected)
  viewExpenseVoucher(id) {
    const row = this.state.expenseList.find(r => r.id === id);
    if (!row) return;
    const vd = row.voucherDetails || {};
    const rowsHtml = (vd.transportRows && vd.transportRows.length)
      ? vd.transportRows.map(r => `<tr><td>${this.escapeHtml(r.from)}</td><td>${this.escapeHtml(r.to)}</td><td>${this.escapeHtml(r.vehicle)}</td><td>${Number(r.amount).toFixed(2)}</td></tr>`).join('')
      : '<tr><td colspan="4" style="text-align:center;color:var(--text-muted)">No transport details</td></tr>';
    document.getElementById('view-voucher-content').innerHTML = `
      <div class="grid-2"><div class="fg"><label>Voucher No</label><input value="${this.escapeHtml(row.voucherNo)}" readonly></div><div class="fg"><label>Date</label><input value="${formatDate(row.date)}" readonly></div></div>
      <div class="grid-2"><div class="fg"><label>Claimant</label><input value="${this.escapeHtml(row.person)}" readonly></div><div class="fg"><label>Purpose / Category</label><input value="${this.escapeHtml(row.purpose)}" readonly></div></div>
      <div class="table-wrap"><table style="font-size:11px"><thead><tr><th>From</th><th>To</th><th>Vehicle</th><th>Amount</th></tr></thead><tbody>${rowsHtml}</tbody></table></div>
      <div class="grid-3"><div class="fg"><label>Received</label><input value="${this.esc(vd.received || '0.00')}" readonly></div><div class="fg"><label>Return</label><input value="${this.esc(row.ret || '0.00')}" readonly></div><div class="fg"><label>Amount (Due)</label><input value="${this.esc(row.amount || '0.00')}" readonly></div></div>
      <div class="fg"><label>Status</label><input value="${this.esc(row.status)}" readonly></div>
      ${row.status === 'Rejected' && row.rejectNote ? `<div class="fg"><label>Reject Note</label><textarea readonly style="color:var(--red)">${this.escapeHtml(row.rejectNote)}</textarea></div>` : ''}`;
    document.getElementById('view-voucher-id').value = id;
    const actionsEl = document.getElementById('view-voucher-actions');
    if (actionsEl) actionsEl.style.display = row.status === 'Pending' ? '' : 'none';
    this.open('view-voucher-modal');
  },

  // Approve/Reject is now controlled entirely by canApprove('expense') (Round 21 -- not role,
  // permissions.expense.approve; superadmin always bypasses) -- this check is kept inside the
  // function too, not just in hiding the button
  async approveExpenseVoucher(id) {
    if (!this.canApprove('expense')) { this.notify('You do not have permission to Approve Expense vouchers', 'warn'); return; }
    const idx = this.state.expenseList.findIndex(r => r.id === id);
    if (idx === -1) return;
    this.state.expenseList[idx].status = 'Approved';
    this.state.expenseList[idx].rejectNote = '';
    await this.persistSheet('expenseList');
    this.renderExpenseList();
    this.notify('Voucher approved');
    this.close('view-voucher-modal');
  },

  // Writing a short note is mandatory when Rejecting, to explain why it was rejected
  openRejectExpenseModal(id) {
    if (!this.canApprove('expense')) { this.notify('You do not have permission to Reject Expense vouchers', 'warn'); return; }
    document.getElementById('reject-expense-id').value = id;
    document.getElementById('reject-expense-note').value = '';
    this.open('reject-expense-modal');
  },

  async confirmRejectExpense() {
    const id = parseInt(document.getElementById('reject-expense-id').value);
    const note = document.getElementById('reject-expense-note').value.trim();
    if (!note) { this.notify('A reason for rejecting is required', 'warn'); return; }
    const idx = this.state.expenseList.findIndex(r => r.id === id);
    if (idx === -1) return;
    this.state.expenseList[idx].status = 'Rejected';
    this.state.expenseList[idx].rejectNote = note;
    await this.persistSheet('expenseList');
    this.renderExpenseList();
    this.notify('Voucher rejected');
    this.close('reject-expense-modal');
    this.close('view-voucher-modal');
  },

  editVoucher(id) {
    const row = this.state.expenseList.find(r => r.id === id);
    if (!row) return;
    const vd = row.voucherDetails || {};
    document.getElementById('voucher-entry-edit-id').value = id;
    document.getElementById('voucher-entry-no').value = row.voucherNo;
    document.getElementById('voucher-entry-date').value = row.date;
    document.getElementById('voucher-entry-claimant').value = row.person;
    document.getElementById('voucher-entry-purpose').value = row.purpose;
    document.getElementById('voucher-entry-received').value = vd.received || '0';
    document.getElementById('voucher-entry-return').value = row.ret || '0';
    document.getElementById('voucher-entry-due').value = row.amount || '0';
    if (vd.transportRows && vd.transportRows.length) {
      document.getElementById('voucher-transport-rows').innerHTML = vd.transportRows.map(r => `<tr><td><input type="text" value="${this.escapeHtml(r.from)}" style="background:transparent;border:none;color:#000;width:100%"></td><td><input type="text" value="${this.escapeHtml(r.to)}" style="background:transparent;border:none;color:#000;width:100%"></td><td><input type="text" value="${this.escapeHtml(r.vehicle)}" style="background:transparent;border:none;color:#000;width:100%"></td><td><input type="number" value="${r.amount}" style="background:transparent;border:none;color:#000;width:100%" oninput="app.calcVoucherDue()"></td></tr>`).join('');
    }
    this.calcVoucherDue();
    this.notify('Voucher details loaded into the Voucher Entry form -- make changes and Save');
    const tab = document.querySelector('#acc-expense .tabs .tab:nth-child(2)');
    if (tab) this.switchTab(tab, 'exp-voucher-entry');
  },

  async toggleSalaryStatus(id) {
    const idx = this.state.hrSalary.findIndex(r => r.id === id);
    if (idx === -1) return;
    const current = this.state.hrSalary[idx].status || 'Pending';
    const newStatus = current === 'Paid' ? 'Pending' : 'Paid';
    this.state.hrSalary[idx].status = newStatus;
    await this.persistSheet('hrSalary');

    // When Salary is marked "Paid", an entry is also created automatically in Office Expense List
    if (newStatus === 'Paid') {
      const salary = this.state.hrSalary[idx];
      const newExpId = await this.allocId('expenseList');
      this.state.expenseList.push({
        id: newExpId, date: todayStr(), voucherNo: '', category: 'Salary',
        person: salary.employee, purpose: `Salary payment - ${salary.designation || ''}`, amount: salary.net, ret: '0.00', status: 'Approved'
      });
      await this.persistSheet('expenseList');
      this.renderExpenseList();
    }

    this.renderHRSalary();
    this.notify(`Salary marked ${newStatus}`);
  },

  // ============================================================
  // HR SETTINGS -- approval workflow engine
  // ============================================================
  // ⚠️ New feature: only the 'admin' and 'superadmin' roles can enter the HR Module (see
  // applyRolePermissions()). Until now, anyone with the 'admin' role could directly
  // add/edit/activate-deactivate employees, change departments/signatures/OT rate -- with no
  // second set of eyes on it. From now on, when someone with the 'admin' role makes a change in
  // HR Settings, it doesn't apply directly -- it sits as "Pending Approval"; only once Super
  // Admin confirms does it actually take effect. A change made by Super Admin themselves takes
  // effect immediately (no need to make them wait for their own approval). Deleting a record
  // was already Super Admin's jurisdiction alone (see confirmDelete() -- it's blocked right at
  // the start of the function if role !== 'superadmin'), so this approval layer isn't needed
  // for a delete action -- it applies to Create/Update only.
  // ⚠️ Round 13: this function used to go down one of two paths depending on role --
  // superadmin applied directly, otherwise it sat in hrApprovals as "pending" waiting for Super
  // Admin's Approve/Reject (the Pending Approvals tab). This workflow was removed at the user's
  // request -- on this installation Super Admin makes every HR Settings change themselves, so
  // in practice the queue always sat empty. Now every role's change applies directly.
  async submitHRChange(type, summary, payload) {
    const applied = await this.applyApprovedHRChange(type, payload);
    if (applied) this.notify('Change applied');
    return applied;
  },

  // Applies the real change depending on type -- called directly from submitHRChange()
  async applyApprovedHRChange(type, payload) {
    // ⚠️ Round 13 fix (caught from an "ON CONFLICT DO UPDATE command cannot affect row a
    // second time" error): newId = Math.max(...existingIds)+1 is calculated client-side, with
    // no server-side locking. Clicking "Add" twice quickly (or a second click on a slow
    // network) could let both calls compute the same "next" id before the first save
    // finished, creating two records with the same id and throwing the error above on the next
    // save. Running the same kind of (add) operation twice at once is now blocked -- the
    // second is ignored until the first finishes.
    const ADD_TYPES = ['employee_add', 'signature_add', 'department_add'];
    if (ADD_TYPES.includes(type)) {
      this._hrAddLocks = this._hrAddLocks || new Set();
      if (this._hrAddLocks.has(type)) {
        this.notify('The previous request is still processing, please wait a moment', 'warn');
        return false;
      }
      this._hrAddLocks.add(type);
      try {
        await this._applyApprovedHRChangeInner(type, payload);
      } finally {
        this._hrAddLocks.delete(type);
      }
      return true;
    }
    await this._applyApprovedHRChangeInner(type, payload);
    return true;
  },

  async _applyApprovedHRChangeInner(type, payload) {
    if (type === 'employee_add') {
      const newId = await this.allocId('hrEmployees');
      this.state.hrEmployees.push({ ...payload, id: newId, status: 'Active' });
      this.logAudit('Create', 'hrEmployees', newId, payload.name);
      await this.persistSheet('hrEmployees');
      this.populateAttendanceEmployees();
    } else if (type === 'employee_edit') {
      const idx = this.state.hrEmployees.findIndex(r => r.id === payload.id);
      if (idx !== -1) this.state.hrEmployees[idx] = { ...this.state.hrEmployees[idx], ...payload.fields };
      this.logAudit('Update', 'hrEmployees', payload.id, payload.fields.name);
      await this.persistSheet('hrEmployees');
      this.populateAttendanceEmployees();
    } else if (type === 'employee_status') {
      const emp = this.state.hrEmployees.find(r => r.id === payload.id);
      if (emp) emp.status = payload.newStatus;
      this.logAudit('Update', 'hrEmployees', payload.id, `${payload.name} → ${payload.newStatus}`);
      await this.persistSheet('hrEmployees');
      this.populateAttendanceEmployees();
    } else if (type === 'signature_add') {
      const newId = await this.allocId('hrSignatures');
      this.state.hrSignatures.push({ ...payload, id: newId, createdAt: nowISO() });
      this.logAudit('Create', 'hrSignatures', newId, payload.name);
      await this.persistSheet('hrSignatures');
      this.populateMerchandiserSignatureDropdowns();
    } else if (type === 'department_add') {
      const newId = await this.allocId('hrDepartments');
      this.state.hrDepartments.push({ ...payload, id: newId, createdAt: nowISO() });
      this.logAudit('Create', 'hrDepartments', newId, payload.name);
      await this.persistSheet('hrDepartments');
      this.populateEmployeeDepartmentDropdown();
    } else if (type === 'department_head') {
      const dept = this.state.hrDepartments.find(r => r.id === payload.id);
      if (dept) dept.headEmployeeId = payload.headEmployeeId;
      this.logAudit('Update', 'hrDepartments', payload.id, `Head → ${payload.headName || 'None'}`);
      await this.persistSheet('hrDepartments');
    } else if (type === 'ot_settings') {
      this.settings.otStandardHours = payload.otStandardHours;
      this.settings.otMultiplier = payload.otMultiplier;
      this.saveLocalSettings();
      if (SheetsDB.isConfigured()) { try { await SheetsDB.saveSettings({ otStandardHours: payload.otStandardHours, otMultiplier: payload.otMultiplier }); } catch (e) { /* পরে আবার চেষ্টা হবে */ } }
    }
    this.renderHREmployees();
    this.renderHRSignaturesList();
    this.renderHRDepartments();
  },

  // ============================================================
  // HR SETTINGS -- Signatures (multi-merchandiser)
  // ============================================================
  // ⚠️ Feature: "Merchandiser Signature" used to be a single slot (settings.signMerchandiser)
  // -- there was no way to keep more than one merchandiser's signature at once. Now several
  // merchandisers' names + signature images can be added separately (the hrSignatures table),
  // and a dropdown in places like the Supplier Order Sheet lets the right merchandiser be
  // chosen for each order.
  async handleNewSignatureUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { this.notify('Please upload an image file only', 'warn'); return; }
    try {
      const dataUrl = await this.resizeImageToDataURL(file, 300, 120, 0.75);
      document.getElementById('hrsig-image-data').value = dataUrl;
      document.getElementById('hrsig-image-preview').innerHTML = `<img src="${dataUrl}" alt="Signature">`;
    } catch (e) {
      this.notify('Problem processing the signature', 'error');
    }
  },

  async addHRSignature() {
    const name = document.getElementById('hrsig-name').value.trim();
    const designation = document.getElementById('hrsig-designation').value.trim();
    const image = document.getElementById('hrsig-image-data').value;
    if (!name || !image) { this.notify('Enter both a name and a signature image', 'warn'); return; }
    await this.submitHRChange('signature_add', `New merchandiser signature: ${name}`, { name, designation, signatureImage: image });
    document.getElementById('hrsig-name').value = '';
    document.getElementById('hrsig-designation').value = '';
    document.getElementById('hrsig-image-data').value = '';
    document.getElementById('hrsig-image-preview').innerHTML = '<i class="bi bi-pen placeholder-icon"></i>';
    document.getElementById('hrsig-file').value = '';
  },

  renderHRSignaturesList() {
    const tbody = document.getElementById('hrset-signatures-tbody');
    if (!tbody) return;
    if (!this.state.hrSignatures.length) {
      tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:24px">No merchandiser signature has been added yet</td></tr>';
      return;
    }
    tbody.innerHTML = this.state.hrSignatures.map(row => `
      <tr><td><img src="${this.escapeHtml(this.safeImageSrc(row.signatureImage))}" style="max-height:36px;max-width:100px;"></td><td>${this.escapeHtml(row.name)}</td><td>${this.escapeHtml(row.designation || '-')}</td>
      <td><button class="action-btn action-delete hr-delete" onclick="app.confirmDelete('hrSignatures', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
  },

  // Any <select> given class="merch-signature-select" on any page is automatically populated
  // with every merchandiser signature -- if a future document needs a merchandiser signature,
  // just adding a <select> with this class is enough, no new code is needed.
  populateMerchandiserSignatureDropdowns() {
    document.querySelectorAll('.merch-signature-select').forEach(select => {
      const current = select.value;
      select.innerHTML = '<option value="">-- Select Merchandiser --</option>' +
        this.state.hrSignatures.map(s => `<option value="${s.id}">${this.escapeHtml(s.name)}${s.designation ? ' - ' + this.escapeHtml(s.designation) : ''}</option>`).join('');
      if (current) select.value = current;
    });
  },

  // Selecting a merchandiser from the dropdown places their signature+name on the Supplier
  // Order Sheet's printout, and the selection is also saved on the linked Supplier Order
  // record (so opening it again later still shows the same merchandiser's signature)
  applyMerchSignatureToSO(signatureId) {
    const sig = this.state.hrSignatures.find(s => String(s.id) === String(signatureId));
    const img = document.getElementById('so-sign-merch-img');
    const nameEl = document.getElementById('so-sign-merch-name');
    if (sig) {
      if (img) { img.src = sig.signatureImage; img.style.display = 'block'; }
      if (nameEl) nameEl.innerText = sig.name;
    } else {
      if (img) img.style.display = 'none';
      if (nameEl) nameEl.innerText = 'Merchandiser';
    }
  },

  // ============================================================
  // HR SETTINGS — Departments
  // ============================================================
  async addHRDepartment() {
    const name = document.getElementById('hrdept-name').value.trim();
    if (!name) { this.notify('Enter a Department name', 'warn'); return; }
    const dup = this.state.hrDepartments.find(d => d.name.toLowerCase() === name.toLowerCase());
    if (dup) { this.notify('A Department with this name already exists', 'warn'); return; }
    await this.submitHRChange('department_add', `New Department: ${name}`, { name, headEmployeeId: null });
    document.getElementById('hrdept-name').value = '';
  },

  async setHRDepartmentHead(deptId, employeeId) {
    const dept = this.state.hrDepartments.find(d => d.id === deptId);
    if (!dept) return;
    const emp = employeeId ? this.state.hrEmployees.find(e => e.id === Number(employeeId)) : null;
    await this.submitHRChange('department_head', `${dept.name}'s Department Head -> ${emp ? emp.name : 'None'}`, { id: deptId, headEmployeeId: employeeId ? Number(employeeId) : null, headName: emp ? emp.name : '' });
  },

  renderHRDepartments() {
    const tbody = document.getElementById('hrset-departments-tbody');
    if (!tbody) return;
    if (!this.state.hrDepartments.length) {
      tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:var(--text-muted);padding:24px">এখনো কোনো Department তৈরি করা হয়নি</td></tr>';
      return;
    }
    const activeEmployees = this.state.hrEmployees.filter(e => (e.status || 'Active') !== 'Inactive');
    tbody.innerHTML = this.state.hrDepartments.map(row => `
      <tr><td>${this.escapeHtml(row.name)}</td>
      <td><select class="table-select" onchange="app.setHRDepartmentHead(${row.id}, this.value)"><option value="">-- None --</option>${activeEmployees.map(e => `<option value="${e.id}" ${row.headEmployeeId === e.id ? 'selected' : ''}>${this.escapeHtml(e.name)}</option>`).join('')}</select></td>
      <td><button class="action-btn action-delete hr-delete" onclick="app.confirmDelete('hrDepartments', ${row.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
  },

  // Populates the Department dropdown on the Add/Edit Employee form
  populateEmployeeDepartmentDropdown() {
    const select = document.getElementById('employee-department');
    if (!select) return;
    const current = select.value;
    select.innerHTML = '<option value="">-- Select Department --</option>' + this.state.hrDepartments.map(d => `<option value="${this.escapeHtml(d.name)}">${this.escapeHtml(d.name)}</option>`).join('');
    if (current) select.value = current;
  },

  // ============================================================
  // HR SETTINGS -- OT Rate (percentage + fixed working-hours based)
  // ============================================================
  // 💡 Design note: OT Rate (৳/hour) used to need typing by hand every time Process Salary ran
  // -- different for each employee, inconsistent, and easy to get wrong. Under the common
  // convention in Bangladesh's Labour Act 2006, OT Rate is usually double (200%) the normal
  // hourly rate, and the hourly rate comes from Basic Salary divided by monthly Standard
  // Working Hours. So just two settings are kept here:
  //   1. Standard Working Hours (monthly) -- default 208 hours (26 working days × 8 hours)
  //   2. OT Multiplier (%) -- default 200%
  // Every employee's OT Rate is worked out automatically: (Basic Salary ÷ Standard Hours) ×
  // (Multiplier ÷ 100). A higher-paid employee's OT Rate is fairly higher too, with no need to
  // type it in every month -- though it can still be manually overridden in the Process Salary
  // modal for an exceptional case.
  loadOTSettingsToForm() {
    const hoursEl = document.getElementById('hrset-ot-hours');
    const multEl = document.getElementById('hrset-ot-multiplier');
    if (hoursEl) hoursEl.value = this.settings.otStandardHours || 208;
    if (multEl) multEl.value = this.settings.otMultiplier || 200;
  },

  async saveOTSettings() {
    const otStandardHours = parseFloat(document.getElementById('hrset-ot-hours').value) || 208;
    const otMultiplier = parseFloat(document.getElementById('hrset-ot-multiplier').value) || 200;
    await this.submitHRChange('ot_settings', `OT Rate settings: ${otStandardHours} hrs/month, ${otMultiplier}%`, { otStandardHours, otMultiplier });
  },

  // Calculates OT Rate (৳/hour) from an employee's Basic Salary -- used in the Process Salary modal
  computeStandardOTRate(basicSalary) {
    const hours = Number(this.settings.otStandardHours) || 208;
    const multiplier = Number(this.settings.otMultiplier) || 200;
    if (!basicSalary || !hours) return 0;
    return (basicSalary / hours) * (multiplier / 100);
  },

  openAddEmployeeModal() {
    document.getElementById('employee-modal-title').innerText = 'Add Employee';
    document.getElementById('employee-save-btn-text').innerText = 'Save';
    document.getElementById('employee-edit-id').value = '';
    document.getElementById('employee-photo-data').value = '';
    document.getElementById('employee-photo-preview').innerHTML = '<i class="bi bi-person placeholder-icon"></i>';
    ['employee-name', 'employee-designation', 'employee-nid', 'employee-basic-salary', 'employee-contact', 'employee-join-date', 'employee-zk-userid', 'employee-department', 'employee-salary-account'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
    this.populateEmployeeDepartmentDropdown();
    this.open('add-employee-modal');
  },

  editEmployee(id) {
    const emp = this.state.hrEmployees.find(r => r.id === id);
    if (!emp) return;
    document.getElementById('employee-modal-title').innerText = 'Edit Employee';
    document.getElementById('employee-save-btn-text').innerText = 'Update';
    document.getElementById('employee-edit-id').value = id;
    document.getElementById('employee-name').value = emp.name || '';
    document.getElementById('employee-designation').value = emp.designation || '';
    document.getElementById('employee-nid').value = emp.nid || '';
    document.getElementById('employee-basic-salary').value = emp.basicSalary || '';
    document.getElementById('employee-contact').value = emp.contact || '';
    document.getElementById('employee-join-date').value = emp.joinDate || '';
    document.getElementById('employee-zk-userid').value = emp.zkUserId || '';
    document.getElementById('employee-photo-data').value = emp.photo || '';
    document.getElementById('employee-photo-preview').innerHTML = emp.photo ? `<img src="${this.escapeHtml(this.safeImageSrc(emp.photo))}" alt="Preview">` : '<i class="bi bi-person placeholder-icon"></i>';
    this.populateEmployeeDepartmentDropdown();
    document.getElementById('employee-department').value = emp.department || '';
    // ⚠️ Feature: Salary Account Number -- a new field, for storing a bank/mobile banking account number
    document.getElementById('employee-salary-account').value = emp.salaryAccountNo || '';
    this.open('add-employee-modal');
  },

  async handleEmployeePhotoUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { this.notify('Please upload an image file only', 'warn'); return; }
    try {
      const dataUrl = await this.resizeImageToDataURL(file, 200, 200, 0.7);
      document.getElementById('employee-photo-data').value = dataUrl;
      document.getElementById('employee-photo-preview').innerHTML = `<img src="${dataUrl}" alt="Preview">`;
    } catch (e) {
      this.notify('Problem processing the image', 'error');
    }
  },

  // ⚠️ Feature: Add/Edit Employee is now only accessible from the HR Settings modal (the main
  // HR Module > Employees tab is now view-only). Saving applies directly via submitHRChange()
  // (since Round 13 -- 'admin' role changes used to sit in Pending Approval, no longer).
  async saveEmployee() {
    const editId = document.getElementById('employee-edit-id').value;
    const name = document.getElementById('employee-name').value.trim();
    const designation = document.getElementById('employee-designation').value.trim();
    const nid = document.getElementById('employee-nid').value.trim();
    const basicSalary = parseFloat(document.getElementById('employee-basic-salary').value) || 0;
    const contact = document.getElementById('employee-contact').value.trim();
    const joinDate = document.getElementById('employee-join-date').value;
    const zkUserId = document.getElementById('employee-zk-userid').value.trim();
    const photo = document.getElementById('employee-photo-data').value || '';
    const department = document.getElementById('employee-department').value || '';
    const salaryAccountNo = document.getElementById('employee-salary-account').value.trim();
    if (!name || !designation || !contact || !joinDate) { this.notify('Complete employee information', 'warn'); return; }

    // ⚠️ ZKTeco data-integrity check: if the same Device User ID is set in two employees'
    // profiles, a device punch could get added to the wrong person's attendance -- so this is
    // blocked before saving.
    if (zkUserId) {
      const clash = (this.state.hrEmployees || []).find(e =>
        String(e.id) !== String(editId) && e.zkUserId && String(e.zkUserId).trim() === zkUserId
      );
      if (clash) {
        this.notify(`This "ZKTeco Device User ID" (${zkUserId}) is already in use on "${clash.name}"'s profile -- an ID can only be linked to one employee`, 'error');
        return;
      }
    }

    const fields = { name, designation, nid, basicSalary, contact, joinDate, zkUserId, photo, department, salaryAccountNo };
    if (editId) {
      await this.submitHRChange('employee_edit', `Employee information changed: ${name}`, { id: Number(editId), fields });
    } else {
      await this.submitHRChange('employee_add', `New employee: ${name}`, fields);
    }
    this.close('add-employee-modal');
  },

  // Opening the Roles page loads every user's granular permissions (the profiles table) --
  // only admin/superadmin can see every row under this RLS policy (v13's profiles_read)
  async loadProfilesForRolesPage() {
    this.profiles = await SheetsDB.loadAllProfiles();
    this.renderUsers();
  },

  // ⚠️ Round 21: these presets are kept exactly matching migration_v21_custom_permissions.sql's
  // backfill defaults -- used only as a quick-start on the "Add User" form, and can be changed
  // however you like after saving (role itself no longer carries any permission)
  PERM_PRESETS: {
    admin: {
      dashboard: { view: true }, inventory: { view: true, write: true, delete: false },
      delivery: { view: true, write: true, delete: false }, qc: { view: true, write: true, delete: false },
      accounts: { view: true, write: true, delete: false }, expense: { view: true, write: true, delete: true, approve: true },
      hr: { view: true, write: true, delete: false }, bsinfo: { view: true, write: true, delete: false },
      datasafety: { view: true, export: true }, users: { view: true }, settings: { view: false }
    },
    accountant: {
      dashboard: { view: true }, inventory: { view: false, write: false, delete: false },
      delivery: { view: false, write: false, delete: false }, qc: { view: false, write: false, delete: false },
      accounts: { view: true, write: true, delete: false }, expense: { view: true, write: true, delete: false, approve: true },
      hr: { view: false, write: false, delete: false }, bsinfo: { view: true, write: false, delete: false },
      datasafety: { view: true, export: true }, users: { view: false }, settings: { view: false }
    },
    merchandiser: {
      dashboard: { view: true }, inventory: { view: true, write: true, delete: false },
      delivery: { view: true, write: false, delete: false }, qc: { view: true, write: false, delete: false },
      accounts: { view: false, write: false, delete: false }, expense: { view: false, write: false, delete: false, approve: false },
      hr: { view: false, write: false, delete: false }, bsinfo: { view: true, write: false, delete: false },
      datasafety: { view: true, export: false }, users: { view: false }, settings: { view: false }
    },
    storekeeper: {
      dashboard: { view: true }, inventory: { view: false, write: false, delete: false },
      delivery: { view: true, write: true, delete: false }, qc: { view: true, write: true, delete: false },
      accounts: { view: false, write: false, delete: false }, expense: { view: false, write: false, delete: false, approve: false },
      hr: { view: false, write: false, delete: false }, bsinfo: { view: false, write: false, delete: false },
      datasafety: { view: false, export: false }, users: { view: false }, settings: { view: false }
    }
  },

  // Clicking a preset button sets the grid's checkboxes to match that preset ('clear' unchecks everything)
  applyPermPreset(name) {
    const preset = name === 'clear' ? {} : (this.PERM_PRESETS[name] || {});
    this.populatePermissionsGrid(preset);
    if (name !== 'clear') document.getElementById('user-role').value = name;
  },

  // Builds the permissions JSON object from the grid's current checkbox state
  collectPermissionsFromGrid() {
    const result = {};
    document.querySelectorAll('#user-permissions-grid .perm-grid-row[data-module]').forEach(row => {
      const mod = row.dataset.module;
      const actions = {};
      row.querySelectorAll('input[type="checkbox"]').forEach(cb => { actions[cb.dataset.action] = cb.checked; });
      result[mod] = actions;
    });
    return result;
  },

  // Sets the grid's checkboxes from a permissions object (used on Edit User or applying a Preset)
  populatePermissionsGrid(perms) {
    perms = perms || {};
    document.querySelectorAll('#user-permissions-grid .perm-grid-row[data-module]').forEach(row => {
      const mod = row.dataset.module;
      const modPerms = perms[mod] || {};
      row.querySelectorAll('input[type="checkbox"]').forEach(cb => { cb.checked = !!modPerms[cb.dataset.action]; });
    });
  },

  openAddUserModal() {
    document.getElementById('user-modal-title').innerText = 'Add User';
    document.getElementById('user-edit-id').value = '';
    document.getElementById('user-username').value = '';
    document.getElementById('user-name').value = '';
    document.getElementById('user-role').value = 'admin';
    document.getElementById('user-status').value = 'Active';
    document.getElementById('user-password').value = '';
    document.getElementById('user-password').placeholder = 'Password';
    this.populatePermissionsGrid({}); // starts with an empty grid -- Admin deliberately picks a preset or ticks it themselves
    this.hideEmployeeSuggestions();
    this.open('add-user-modal');
  },

  // ===== Roles > Add User: an auto-suggest feature to enforce the rule that only an
  // employee already in HR Module > Employees can be added as a user. Typing 2-3 letters
  // suggests matching employees, showing their name, photo and designation. =====
  suggestEmployeeNames(query) {
    const box = document.getElementById('user-name-suggest');
    if (!box) return;
    const q = (query || '').trim().toLowerCase();
    const employees = (this.state.hrEmployees || []).filter(e => e.status !== 'Inactive');
    const matches = q.length >= 2
      ? employees.filter(e => (e.name || '').toLowerCase().includes(q))
      : employees; // even with fewer than 2 letters, focusing shows the full list of active employees

    if (!matches.length) {
      box.innerHTML = `<div class="autosuggest-empty">${q ? 'No employee found -- add them to HR Module > Employees first' : 'There are no employees in HR Module > Employees yet'}</div>`;
    } else {
      box.innerHTML = matches.slice(0, 8).map(e => {
        const safeName = (e.name || '').replace(/'/g, "\\'");
        const avatarHtml = e.photo
          ? `<img src="${this.escapeHtml(e.photo)}" alt="">`
          : `<div class="avatar-fallback">${this.escapeHtml((e.name || '?').substring(0, 2).toUpperCase())}</div>`;
        return `<div class="autosuggest-item" onmousedown="app.selectSuggestedEmployeeName('${safeName}')">${avatarHtml}<span>${this.escapeHtml(e.name || '')}</span><small>${this.escapeHtml(e.designation || '')}</small></div>`;
      }).join('');
    }
    box.classList.add('show');
  },

  selectSuggestedEmployeeName(name) {
    const input = document.getElementById('user-name');
    if (input) input.value = name;
    this.hideEmployeeSuggestions();
  },

  hideEmployeeSuggestions() {
    const box = document.getElementById('user-name-suggest');
    if (box) box.classList.remove('show');
  },

  async saveUser() {
    const editId = document.getElementById('user-edit-id').value;
    const username = document.getElementById('user-username').value.trim();
    const name = document.getElementById('user-name').value.trim();
    const role = document.getElementById('user-role').value;
    const status = document.getElementById('user-status').value;
    const passwordInput = document.getElementById('user-password').value;
    // ⚠️ Security: the Super Admin role is reserved for the software's real owner -- only an
    // existing Super Admin can make anyone else a Super Admin. A regular Admin cannot (this
    // option is also hidden for Admin in the dropdown -- see index.html's superadmin-only class
    // -- but the check is kept separately here too, so it cannot be bypassed via DOM
    // manipulation either)
    if (role === 'superadmin' && this.role !== 'superadmin') {
      this.notify('Only Super Admin can make someone else a Super Admin', 'error');
      return;
    }
    // ⚠️ Round 21: instead of the old flat comma-tag permissions, a granular (view/write/
    // delete/approve/export per module) object is now collected from the grid -- this is what
    // gets stored in profiles.permissions and works directly matching RLS's has_perm()
    const permsObj = this.collectPermissionsFromGrid();
    // Leaving the password blank while editing keeps the previous password unchanged -- a
    // password is only required when creating a new user
    if (!username || !name || (!editId && !passwordInput)) { this.notify('Username, name and password are required', 'warn'); return; }

    const existing = editId ? this.state.users.find(r => r.id == editId) : null;
    // ⚠️ Round 13: changing the username is not supported at this time -- because the account
    // is identified in Supabase Auth via a username→email mapping (username@accoflow.internal);
    // to change a username for now this user needs to be deleted and re-created with the new
    // username.
    if (existing && existing.username !== username) {
      this.notify('Changing the username is not supported at this time -- keep the username unchanged while updating name/role/status, or delete this user and create a new one with the new username.', 'warn');
      return;
    }

    // Rule: only an employee already in HR Module > Employees (and Active) can be added as a
    // user -- this stops an account from being created with a misspelled or non-existent
    // person's name
    const matchedEmployee = (this.state.hrEmployees || []).find(e => (e.name || '').trim().toLowerCase() === name.toLowerCase());
    if (!matchedEmployee) {
      this.notify('No active employee with this name was found in HR Module > Employees. Add the employee from HR Module first, then select their name from the suggestions here.', 'warn');
      return;
    }

    // ⚠️ Round 13: the password is no longer SHA-256 hashed and kept in this.state.users -- it
    // goes straight to Supabase Auth (server-side, via the Edge Function, using the
    // service_role key). If the Auth sync fails, the local users table is not touched, so the
    // two never go out of sync.
    try {
      if (!editId) {
        await SheetsDB.adminManageUser({ action: 'create', username, role, status, password: passwordInput });
      } else {
        const payload = { action: 'update', username, role, status };
        if (passwordInput) payload.password = passwordInput;
        await SheetsDB.adminManageUser(payload);
      }
    } catch (e) {
      this.notify('Auth account sync failed (users table not updated): ' + e.message, 'error');
      return;
    }

    let recordId;
    if (editId) {
      const idx = this.state.users.findIndex(r => r.id == editId);
      if (idx !== -1) {
        // ⚠️ Bug prevention: the whole user object used to be rebuilt from scratch here, so
        // the user's own saved appTheme/theme fields got lost as soon as "Edit User" saved
        // (showing the default Classic Glass/Ocean again on the next login). The existing
        // values are now kept.
        this.state.users[idx] = {
          id: parseInt(editId),
          username,
          name,
          role,
          permissions: '', // Round 21: this legacy field is no longer used, real permission now lives in profiles.permissions
          password: 'managed-by-supabase-auth',
          lastLogin: existing.lastLogin || '',
          status,
          appTheme: existing.appTheme || 'classic',
          theme: existing.theme || 'ocean'
        };
        this.notify('User updated');
      }
      recordId = editId;
    } else {
      const newId = await this.allocId('users');
      // Default theme for a new user (Ocean accent + Classic Glass full theme) -- after
      // logging in, this user can change it themselves from the Theme Picker, saved only to
      // their own profile.
      this.state.users.push({ id: newId, username, name, role, permissions: '', password: 'managed-by-supabase-auth', lastLogin: '', status, theme: 'ocean', stylePack: 'classic' });
      recordId = newId;
      this.notify('User added');
    }
    // For security, the password is never kept in the audit log, only the username
    this.logAudit(editId ? 'Update' : 'Create', 'users', recordId, username);
    await this.persistSheet('users');
    // ⚠️ Round 21: granular permissions are saved separately in the profiles table (a
    // different table from users, a different RLS policy) -- this is attempted after the
    // Auth account/users row succeeds, so even if this fails there's still a guarantee that
    // the user account itself was created/updated
    try {
      await SheetsDB.saveUserPermissions(username, permsObj);
      // Updates the local cache (this.profiles) -- so the new permission shows immediately in the Active Users table
      const pIdx = this.profiles.findIndex(p => p.username === username);
      if (pIdx !== -1) this.profiles[pIdx].permissions = permsObj;
      else this.profiles.push({ username, role, status, permissions: permsObj });
      // If the currently logged-in user is editing their own permissions (e.g. an admin), it
      // is applied immediately so the new access takes effect without a refresh
      if (username === this.currentUsername) {
        this.userPerms = permsObj;
        this.applyUserPermissions(this.role, permsObj);
      }
    } catch (e) {
      this.notify('User saved, but there was a problem saving permissions: ' + e.message, 'error');
    }
    this.renderUsers();
    document.getElementById('user-edit-id').value = '';
    this.close('add-user-modal');
  },

  editUser(id) {
    const user = this.state.users.find(r => r.id === id);
    if (!user) return;
    document.getElementById('user-modal-title').innerText = 'Edit User';
    document.getElementById('user-edit-id').value = id;
    document.getElementById('user-username').value = user.username || '';
    document.getElementById('user-name').value = user.name || '';
    document.getElementById('user-role').value = user.role || 'admin';
    document.getElementById('user-status').value = user.status || 'Active';
    document.getElementById('user-password').value = '';
    document.getElementById('user-password').placeholder = 'Leave blank to keep current password';
    // Round 21: this user's current granular permissions are looked up from this.profiles
    // (loaded when the Roles page is opened) and set into the grid -- if not found (e.g.
    // profiles hasn't loaded yet), an empty grid is shown, which Admin can fill in manually or
    // with a preset
    const profile = this.profiles.find(p => p.username === user.username);
    this.populatePermissionsGrid(profile ? profile.permissions : {});
    this.hideEmployeeSuggestions();
    this.open('add-user-modal');
  },

  addChallanRow() {
    const tbody = document.getElementById('challan-tbody');
    const r = tbody.rows.length + 1;
    const newRow = tbody.insertRow();
    newRow.innerHTML = Array(11).fill('<td contenteditable="true"></td>').join('') +
      '<td class="no-print row-action-cell" style="text-align:center;"><button type="button" class="action-btn action-delete" onclick="app.removeChallanRow(this)" title="Delete this row"><i class="bi bi-trash"></i></button></td>';
    newRow.cells[0].innerText = r;
  },

  // ⚠️ Feature: the trash button next to every row of the Challan Generator table -- the same
  // pattern as the QC modal's removeQCRow(), at least one row must always remain
  removeChallanRow(btn) {
    const tbody = document.getElementById('challan-tbody');
    if (!tbody) return;
    if (tbody.querySelectorAll('tr').length <= 1) { this.notify('At least one row must remain', 'warn'); return; }
    btn.closest('tr').remove();
    Array.from(tbody.querySelectorAll('tr')).forEach((tr, i) => { tr.cells[0].innerText = i + 1; });
  },

  // ⚠️ Feature: Challan Goods Entry -- given several Challan Nos together (comma-separated)
  // from the temporary box, each one is checked for (a) whether it has a Received Goods entry
  // and (b) whether that challan's QC is complete -- only if both hold true are that challan's
  // items added to the table. If either condition isn't met, that challan is skipped and
  // notified with the reason (the whole process doesn't get blocked).
  addGoodsFromChallanEntry() {
    const input = document.getElementById('challan-goods-entry-input');
    if (!input) return;
    const challanNos = this.splitChallanList(input.value);
    if (!challanNos.length) { this.notify('Enter at least one Challan No', 'warn'); return; }

    const tbody = document.getElementById('challan-tbody');
    if (!tbody) return;
    // Still completely empty (unused) starting rows are removed before new data is added
    Array.from(tbody.querySelectorAll('tr')).forEach(tr => {
      const cells = Array.from(tr.querySelectorAll('td:not(.row-action-cell)'));
      const isEmpty = cells.slice(1).every(td => !td.innerText.trim());
      if (isEmpty) tr.remove();
    });

    let addedCount = 0;
    const skipped = [];
    challanNos.forEach(no => {
      const rg = this.findReceivedGoodsByChallan(no);
      if (!rg) { skipped.push(`${no} (not found in Received Goods)`); return; }
      const qcDone = this.state.qcList.some(q => this.splitChallanList(q.challan).some(c => c.toLowerCase() === no.toLowerCase()));
      if (!qcDone) { skipped.push(`${no} (QC not complete)`); return; }

      const buyerEl = document.getElementById('challan-buyer');
      if (buyerEl && !buyerEl.value) { buyerEl.value = rg.buyer || ''; this.autofillChallanBuyer(rg.buyer || ''); }
      const piEl = document.getElementById('challan-pi');
      if (piEl && !piEl.value) piEl.value = rg.piNo || '';

      const items = Array.isArray(rg.items) && rg.items.length ? rg.items : [{ itemCode: rg.itemName, styleNo: rg.styleNo, orderQty: rg.orderQty, receivedQty: rg.receivedQty }];
      items.forEach(it => {
        const md = this.state.masterData.find(m => m.itemCode === it.itemCode);
        const sl = tbody.querySelectorAll('tr').length + 1;
        const row = tbody.insertRow();
        row.innerHTML = `
          <td contenteditable="true">${sl}</td>
          <td contenteditable="true">${this.escapeHtml(rg.orderNo || '')}</td>
          <td contenteditable="true">${this.escapeHtml(it.styleNo || '')}</td>
          <td contenteditable="true">${this.escapeHtml(it.itemCode || '')}</td>
          <td contenteditable="true">${this.escapeHtml((md && md.description) || it.itemCode || '')}</td>
          <td contenteditable="true">${this.escapeHtml(it.orderQty || '')}</td>
          <td contenteditable="true">${this.escapeHtml(it.receivedQty || '')}</td>
          <td contenteditable="true">${this.escapeHtml((md && md.brand) || '')}</td>
          <td contenteditable="true"></td>
          <td contenteditable="true"></td>
          <td contenteditable="true">Challan: ${this.escapeHtml(no)}</td>
          <td class="no-print row-action-cell" style="text-align:center;"><button type="button" class="action-btn action-delete" onclick="app.removeChallanRow(this)" title="Delete this row"><i class="bi bi-trash"></i></button></td>`;
      });
      addedCount++;
    });

    if (addedCount) this.notify(`Goods from ${addedCount} Challan(s) added to the table`);
    if (skipped.length) this.notify('Skipped -- ' + skipped.join(', '), 'warn');
    if (!addedCount && !skipped.length) this.notify('Nothing could be added', 'warn');
    if (addedCount) input.value = '';
  },

  // ============ SUPPLIER ORDER SHEET ============
  // The form is kept minimized by default, so there's no need to scroll to see the "Previous
  // Supplier Orders" list. Clicking "Maximize" shows/edits the full form again if needed.
  toggleSupplierOrderForm() {
    const box = document.getElementById('print-area-supplier-order');
    const icon = document.getElementById('so-toggle-icon');
    const text = document.getElementById('so-toggle-text');
    if (!box) return;
    const isHidden = box.style.display === 'none';
    box.style.display = isHidden ? '' : 'none';
    if (icon) icon.className = isHidden ? 'bi bi-arrows-angle-contract' : 'bi bi-arrows-angle-expand';
    if (text) text.innerText = isHidden ? 'Minimize' : 'Maximize';
  },

  addSupplierOrderRow() {
    const tbody = document.getElementById('so-items-tbody');
    if (!tbody) return;
    const r = tbody.rows.length + 1;
    const row = document.createElement('tr');
    row.innerHTML = `<td>${r}</td>
      <td><input list="pi-item-codes-list" placeholder="Item Code" onchange="app.autofillSupplierOrderRow(this)"></td>
      <td><input placeholder="Description"></td>
      <td><input placeholder="Style No"></td>
      <td><input placeholder="Brand"></td>
      <td><input type="number" step="any" value="0" oninput="app.calcSupplierOrderTotal()" style="text-align:right"></td>
      <td><input type="number" step="any" value="0.00" oninput="app.calcSupplierOrderTotal()" style="text-align:right"></td>
      <td class="so-total-cell" style="text-align:right">$0.00</td>
      <td><input placeholder="Remarks"></td>`;
    tbody.appendChild(row);
  },

  autofillSupplierOrderRow(el) {
    const code = el.value.trim();
    const row = el.closest('tr');
    if (!row) return;
    const item = this.state.masterData.find(m => m.itemCode.toLowerCase() === code.toLowerCase());
    if (item) {
      el.value = item.itemCode; el.style.outline = '';
      row.cells[2].querySelector('input').value = item.description;
      row.cells[6].querySelector('input').value = item.buyingPrice ?? item.unitPrice ?? 0;
      this.calcSupplierOrderTotal();
    } else if (code) {
      el.style.outline = '2px solid var(--red)';
      this.notify('This Item Code was not found in Master Data', 'warn');
    }
  },

  // Giving a PI No automatically creates the Supplier Order Sheet's table rows from that PI's
  // every Item Code/Description/Style No/Qty (Brand and Buying Unit Price are cross-referenced
  // from Master Data -- a PI's line item has no Brand, and a PI's Unit Price is the selling
  // price to the buyer, which isn't right to use on a Supplier Order -- Master Data's Buying
  // Price is used here instead, exactly as it is for a single Item Code's autofill too, above
  // in autofillSupplierOrderRow)
  autofillSupplierOrderFromPI(piNoValue) {
    const piNo = (piNoValue || '').trim();
    if (!piNo) return;
    const pi = (this.state.piList || []).find(p => (p.piNo || '').toLowerCase() === piNo.toLowerCase());
    if (!pi) { this.notify('This PI No was not found', 'warn'); return; }
    const lineItems = (pi.formData && Array.isArray(pi.formData.lineItems)) ? pi.formData.lineItems : [];
    if (!lineItems.length) { this.notify('No items were found on this PI', 'warn'); return; }

    // If the Supplier field is empty (the user hasn't typed anything themselves), the supplier linked to the PI is also auto-filled
    const supplierEl = document.getElementById('so-supplier');
    if (supplierEl && !supplierEl.value.trim() && pi.supplier) supplierEl.value = pi.supplier;

    const tbody = document.getElementById('so-items-tbody');
    tbody.innerHTML = '';
    lineItems.forEach(li => {
      this.addSupplierOrderRow();
      const row = tbody.lastElementChild;
      const master = this.state.masterData.find(m => (m.itemCode || '').toLowerCase() === (li.itemCode || '').toLowerCase());
      row.cells[1].querySelector('input').value = li.itemCode || '';
      row.cells[2].querySelector('input').value = li.description || (master ? master.description : '') || '';
      row.cells[3].querySelector('input').value = li.styleNo || (master ? master.styleNo : '') || '';
      row.cells[4].querySelector('input').value = master ? (master.brand || '') : '';
      row.cells[5].querySelector('input').value = li.qty || 0;
      row.cells[6].querySelector('input').value = master ? (master.buyingPrice ?? master.unitPrice ?? 0) : (li.unitPrice || 0);
    });
    this.calcSupplierOrderTotal();
    this.notify(`${lineItems.length} item(s) loaded from PI ${pi.piNo}`);
  },

  calcSupplierOrderTotal() {
    let total = 0;
    document.querySelectorAll('#so-items-tbody tr').forEach(r => {
      const q = parseFloat(r.cells[5].querySelector('input').value) || 0;
      const p = parseFloat(r.cells[6].querySelector('input').value) || 0;
      const t = this.roundMoney(q * p); total = this.roundMoney(total + t);
      r.cells[7].innerText = this.fmtMoney2(t);
    });
    const gt = document.getElementById('so-grand-total');
    if (gt) gt.innerText = this.fmtMoney2(total);
    return total;
  },

  resetSupplierOrderForm() {
    const box = document.getElementById('print-area-supplier-order');
    if (box) box.style.display = '';
    const icon = document.getElementById('so-toggle-icon');
    const text = document.getElementById('so-toggle-text');
    if (icon) icon.className = 'bi bi-arrows-angle-contract';
    if (text) text.innerText = 'Minimize';
    document.getElementById('so-order-no').value = '';
    document.getElementById('so-pi-no').value = '';
    document.getElementById('so-merchandiser').value = '';
    document.getElementById('so-supplier').value = '';
    document.getElementById('so-expected-delivery').value = '';
    document.getElementById('so-edit-id').value = '';
    document.getElementById('so-date').value = todayStr();
    document.getElementById('so-items-tbody').innerHTML = '';
    this.addSupplierOrderRow();
    this.calcSupplierOrderTotal();
  },

  async saveSupplierOrder() {
    const editId = document.getElementById('so-edit-id').value;
    const orderNo = document.getElementById('so-order-no').value.trim();
    const piNo = document.getElementById('so-pi-no').value.trim();
    const supplier = document.getElementById('so-supplier').value.trim();
    if (!orderNo || !supplier) { this.notify('Order No and Supplier are required', 'warn'); return; }

    const items = [];
    document.querySelectorAll('#so-items-tbody tr').forEach(r => {
      const inputs = r.querySelectorAll('input');
      items.push({
        itemCode: inputs[0].value, description: inputs[1].value, styleNo: inputs[2].value,
        brand: inputs[3].value, qty: inputs[4].value, unitPrice: inputs[5].value, remarks: inputs[6].value
      });
    });
    const totalValue = this.calcSupplierOrderTotal();
    const totalQty = items.reduce((s, it) => s + (parseFloat(it.qty) || 0), 0);

    const record = {
      date: document.getElementById('so-date').value || todayStr(),
      orderNo, piNo, merchandiser: document.getElementById('so-merchandiser').value.trim(), supplier,
      expectedDelivery: document.getElementById('so-expected-delivery').value,
      items: JSON.stringify(items), totalValue,
      signMerchandiserId: document.querySelector('.merch-signature-select')?.value || ''
    };

    // ⚠️ Bug fix: editing via "View" and Save used to always create another record with a new
    // ID (a duplicate row with the same orderNo). Now, just like savePI(), so-edit-id is
    // checked -- the existing record is updated in edit mode, otherwise a new record is
    // created.
    let recordId;
    if (editId) {
      const idx = this.state.supplierOrders.findIndex(r => r.id == editId);
      if (idx !== -1) this.state.supplierOrders[idx] = { id: parseInt(editId), ...record };
      recordId = editId;
    } else {
      const newId = await this.allocId('supplierOrders');
      this.state.supplierOrders.unshift({ id: newId, ...record });
      recordId = newId;
    }
    this.logAudit(editId ? 'Update' : 'Create', 'supplierOrders', recordId, orderNo);
    await this.persistSheet('supplierOrders');

    // This Supplier Order is also registered as an "Order", so it shows up in the Order No
    // dropdown for Received Goods, Delivery, QC, etc.
    // ⚠️ Bug fix: selecting an Order No in the Add Received Goods modal never used to
    // auto-fill the BUYER field, because buyer was always hardcoded here as an empty string
    // (''). The real Buyer name is now looked up from piList via the linked PI No (piNo) (stays
    // empty if there's no linked piNo).
    const linkedPI = piNo ? this.state.piList.find(p => p.piNo === piNo) : null;
    await this.registerOrder(orderNo, {
      buyer: linkedPI ? linkedPI.buyer : '', supplier, qty: totalQty, pi: piNo,
      styleNo: items.map(it => it.styleNo).filter(Boolean).join(', '),
      itemName: items.map(it => it.description).filter(Boolean).join(', '),
      contact: '', address: '', type: 'SO', items
    });

    // An entry is also automatically created/updated in the Supplier Ledger (accSupplier) for this Order No
    await this.syncAccSupplierFromOrder(orderNo, supplier, totalValue);

    this.notify(editId ? 'Supplier Order updated' : 'Supplier Order saved');
    this.renderSupplierOrderHistory();
  },

  // Saving a Supplier Order automatically creates/updates an entry for that Order No in the
  // Supplier Ledger (Accounts & Finance > Supplier Due) -- Total comes from here, the previous
  // Paid/Due stays intact
  async syncAccSupplierFromOrder(orderNo, supplier, totalValue) {
    const total = this.parseMoney(totalValue);
    let row = this.state.accSupplier.find(r => r.orderNo === orderNo);
    if (row) {
      row.supplier = supplier;
      row.total = this.formatUSD(total);
      const paid = this.parseMoney(row.paid);
      row.due = this.formatUSD(Math.max(total - paid, 0));
    } else {
      const newId = await this.allocId('accSupplier');
      this.state.accSupplier.push({
        id: newId, date: todayStr(), orderNo, supplier,
        total: this.formatUSD(total), paid: this.formatUSD(0), due: this.formatUSD(total)
      });
    }
    await this.persistSheet('accSupplier');
    this.renderAccSupplier();
  },

  renderSupplierOrderHistory() {
    const tbody = document.getElementById('so-history-tbody');
    if (!tbody) return;
    // ⚠️ ফিচার: আর্কাইভ করা PI-এর Supplier Order এখান থেকে লুকানো থাকে (Complete Order List-এ দেখা যাবে)
    const rows = this.state.supplierOrders.filter(r => !this.isArchivedByPiNo(r.piNo));
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:20px">No supplier orders yet.</td></tr>';
      return;
    }
    tbody.innerHTML = rows.map(r => `
      <tr><td>${formatDate(r.date)}</td><td class="f-mono f-accent">${this.escapeHtml(r.orderNo)}</td><td>${this.escapeHtml(r.supplier)}</td><td>${this.escapeHtml(r.merchandiser || '')}</td>
      <td>${this.fmtMoney2(parseFloat(r.totalValue) || 0)}</td>
      <td><button class="action-btn action-view" onclick="app.loadSupplierOrder(${r.id})"><i class="bi bi-eye"></i> View</button>
      <button class="action-btn action-delete inventory-delete" onclick="app.confirmDelete('supplierOrders', ${r.id})"><i class="bi bi-trash"></i></button></td></tr>`).join('');
  },

  loadSupplierOrder(id) {
    const rec = this.state.supplierOrders.find(r => r.id === id);
    if (!rec) return;
    const box = document.getElementById('print-area-supplier-order');
    if (box) box.style.display = '';
    const icon = document.getElementById('so-toggle-icon');
    const text = document.getElementById('so-toggle-text');
    if (icon) icon.className = 'bi bi-arrows-angle-contract';
    if (text) text.innerText = 'Minimize';
    document.getElementById('so-edit-id').value = rec.id;
    document.getElementById('so-date').value = rec.date || '';
    document.getElementById('so-order-no').value = rec.orderNo || '';
    document.getElementById('so-pi-no').value = rec.piNo || '';
    document.getElementById('so-merchandiser').value = rec.merchandiser || '';
    document.getElementById('so-supplier').value = rec.supplier || '';
    document.getElementById('so-expected-delivery').value = rec.expectedDelivery || '';
    const tbody = document.getElementById('so-items-tbody');
    tbody.innerHTML = '';
    let items = [];
    try { items = JSON.parse(rec.items || '[]'); } catch (e) { items = []; }
    if (!items.length) { this.addSupplierOrderRow(); }
    items.forEach(it => {
      this.addSupplierOrderRow();
      const row = tbody.lastElementChild;
      const inputs = row.querySelectorAll('input');
      inputs[0].value = it.itemCode || ''; inputs[1].value = it.description || ''; inputs[2].value = it.styleNo || '';
      inputs[3].value = it.brand || ''; inputs[4].value = it.qty || ''; inputs[5].value = it.unitPrice || ''; inputs[6].value = it.remarks || '';
    });
    this.calcSupplierOrderTotal();
    // ⚠️ ফিচার: এই অর্ডারে আগে যে মার্চেন্ডাইজার সিলেক্ট করা হয়েছিল তার সিগনেচারও পুনরায় বসিয়ে দেওয়া হয়
    const merchSelect = document.querySelector('.merch-signature-select');
    if (merchSelect) { merchSelect.value = rec.signMerchandiserId || ''; this.applyMerchSignatureToSO(rec.signMerchandiserId || ''); }
    this.notify('Supplier Order লোড করা হয়েছে — প্রয়োজনে এডিট করে আবার Save করুন');
  },

  // ⚠️ ফিচার: QC Center > Settings বাটন থেকে কনফিগারযোগ্য (আগে হার্ডকোড করা 5% ছিল, এখন
  // this.settings.maxQcAllowedPct থেকে পড়া হয় — ডিফল্ট এখনো 5%)। getter হওয়ায় কোডের বাকি সব
  // জায়গা (calcQCReject, saveQC ইত্যাদি) অপরিবর্তিত থেকেও স্বয়ংক্রিয়ভাবে নতুন মান ব্যবহার করবে।
  get QC_MAX_REJECT_PCT() {
    const v = Number(this.settings.maxQcAllowedPct);
    return Number.isFinite(v) && v > 0 ? v : 5;
  },

  // ===== ZKTeco Access Control Device Integration (optional feature, toggled from Settings) =====
  // v24: the ZKTeco Bridge now pushes punches STRAIGHT INTO SUPABASE (HR > Attendance) through
  // the record_zk_attendance() database function -- there is no Telegram relay any more. A
  // browser cannot open a raw TCP socket to the device (port 4370), so a small bridge program
  // still has to run on a PC near the device; but this app no longer needs to reach that PC.
  // "Sync Now" / auto-sync therefore (1) optionally asks the bridge to push immediately (only if a
  // Bridge URL is set and reachable) and then (2) reloads HR > Attendance from Supabase.
  // Employee matching (ZKTeco Device User ID, else NID), Late/Present status and the
  // "same ID on two employees -> skipped" safety rule all run inside the database now.
  _zkBridgeKey() { try { return localStorage.getItem('gp_zk_bridge_key') || ''; } catch (e) { return ''; } },

  loadZKTecoSettings() {
    const defaults = { enabled: false, ip: '', port: 4370, bridgeUrl: '', autoSyncMinutes: 0 };
    try {
      const saved = this.settings.zktecoConfig ? JSON.parse(this.settings.zktecoConfig) : null;
      this.zkteco = Object.assign(defaults, saved || {});
    } catch (e) {
      this.zkteco = defaults;
    }
    // Secrets/options from older (Telegram) versions are dropped on load and never saved again
    delete this.zkteco.telegramBotToken;
    delete this.zkteco.telegramChatId;
    delete this.zkteco.syncMethod;
    this.syncZKTecoUIFromState();
    this.applyZKTecoAutoSync();
  },

  syncZKTecoUIFromState() {
    const enabledSwitch = document.getElementById('zkteco-enabled-switch');
    const fieldsBox = document.getElementById('zkteco-settings-fields');
    const ipEl = document.getElementById('zkteco-ip');
    const portEl = document.getElementById('zkteco-port');
    const bridgeEl = document.getElementById('zkteco-bridge-url');
    const keyEl = document.getElementById('zkteco-bridge-key');
    const autoEl = document.getElementById('zkteco-auto-sync');
    if (enabledSwitch) enabledSwitch.checked = !!this.zkteco.enabled;
    if (fieldsBox) fieldsBox.style.display = this.zkteco.enabled ? 'block' : 'none';
    if (ipEl) ipEl.value = this.zkteco.ip || '';
    if (portEl) portEl.value = this.zkteco.port || 4370;
    if (bridgeEl) bridgeEl.value = this.zkteco.bridgeUrl || '';
    if (keyEl) keyEl.value = this._zkBridgeKey();
    if (autoEl) autoEl.value = String(this.zkteco.autoSyncMinutes || 0);
    document.querySelectorAll('.zkteco-only').forEach(el => { el.style.display = this.zkteco.enabled ? '' : 'none'; });
  },

  toggleZKTeco(checked) {
    this.zkteco.enabled = checked;
    this.syncZKTecoUIFromState();
    this.persistZKTecoSettings();
    this.applyZKTecoAutoSync();
  },

  async saveZKTecoSettings() {
    this.zkteco.ip = (document.getElementById('zkteco-ip').value || '').trim();
    this.zkteco.port = parseInt(document.getElementById('zkteco-port').value) || 4370;
    this.zkteco.bridgeUrl = (document.getElementById('zkteco-bridge-url').value || '').trim().replace(/\/+$/, '');
    this.zkteco.autoSyncMinutes = parseInt(document.getElementById('zkteco-auto-sync').value) || 0;
    // The bridge API key is stored only in THIS browser (localStorage), never in the shared
    // database, because every logged-in user can read the settings table.
    const keyEl = document.getElementById('zkteco-bridge-key');
    try { localStorage.setItem('gp_zk_bridge_key', keyEl ? keyEl.value.trim() : ''); } catch (e) { /* private mode -- ignore */ }
    await this.persistZKTecoSettings();
    this.applyZKTecoAutoSync();
    this.notify('ZKTeco settings saved');
  },

  async persistZKTecoSettings() {
    this.settings.zktecoConfig = JSON.stringify(this.zkteco);
    this.saveLocalSettings();
    if (SheetsDB.isConfigured()) {
      try { await SheetsDB.saveSettings({ zktecoConfig: this.settings.zktecoConfig }); } catch (e) { /* will sync later */ }
    }
  },

  // Auto-sync only needs the feature switched on and an interval -- even with no Bridge URL
  // it simply re-reads HR > Attendance from Supabase (where the bridge keeps pushing).
  applyZKTecoAutoSync() {
    if (this._zktecoTimer) { clearInterval(this._zktecoTimer); this._zktecoTimer = null; }
    if (this.zkteco.enabled && this.zkteco.autoSyncMinutes > 0) {
      this._zktecoTimer = setInterval(() => this.syncZKTecoAttendance(true), this.zkteco.autoSyncMinutes * 60 * 1000);
    }
  },

  // Calls the bridge (fetch with a timeout). Returns { ok, status, json }.
  async _zkBridgeFetch(path, method, timeoutMs, baseUrl, key) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), timeoutMs || 15000);
    try {
      const headers = {};
      if (key) headers['x-api-key'] = key;
      const res = await fetch((baseUrl || this.zkteco.bridgeUrl) + path, { method: method || 'GET', headers, signal: ctl.signal });
      let json = null;
      try { json = await res.json(); } catch (e) { /* not JSON */ }
      return { ok: res.ok, status: res.status, json };
    } finally {
      clearTimeout(timer);
    }
  },

  // The bridge records every push in settings.zkBridgeLastPush (written by the database
  // function) -- read it fresh so the user can see whether the bridge is alive.
  async fetchZkBridgeLastPush() {
    if (!SheetsDB.isConfigured() || !SheetsDB.client) return null;
    const { data, error } = await SheetsDB.client.from('settings').select('value').eq('key', 'zkBridgeLastPush').maybeSingle();
    if (error || !data || !data.value) return null;
    try { return JSON.parse(data.value); } catch (e) { return null; }
  },

  _zkDescribeLastPush(last) {
    if (!last || !last.at) return 'Supabase-এ ব্রিজের কোনো পুশ এখনো পাওয়া যায়নি (ব্রিজ চালু আছে কিনা এবং config.json ঠিক আছে কিনা দেখুন)';
    const ageMin = Math.max(0, Math.round((Date.now() - new Date(last.at).getTime()) / 60000));
    const stale = ageMin > 30 ? ' ⚠️ অনেকক্ষণ কোনো পুশ আসেনি — ব্রিজ প্রোগ্রাম চালু আছে কিনা দেখুন' : '';
    return `ব্রিজ সর্বশেষ ${ageMin} মিনিট আগে ডেটা পাঠিয়েছে${stale}`;
  },

  // Reloads HR > Attendance from Supabase (where the bridge writes). Rows still waiting to be
  // sent from this browser (Offline mode) are never overwritten.
  async refreshAttendanceFromDB() {
    if (!SheetsDB.isConfigured() || !SheetsDB.client) throw new Error('Supabase is not configured');
    if (window.OfflineSync) {
      const dirty = await OfflineSync.getDirtyTables();
      if (Array.isArray(dirty) && dirty.includes('hrAttendance')) return false;
    }
    const { data, error } = await SheetsDB.client.from('hrAttendance').select('*');
    if (error) throw new Error(error.message);
    const rows = data || [];
    this.state.hrAttendance = rows.filter(r => !r.deletedAt);
    this.trashItems = this.trashItems.filter(t => t.module !== 'hrAttendance');
    rows.filter(r => r.deletedAt).forEach(r => this.trashItems.push({ module: 'hrAttendance', record: r, deletedAt: r.deletedAt, deletedBy: r.deletedBy || '' }));
    if (window.OfflineSync) OfflineSync.mirrorTable('hrAttendance', this.state.hrAttendance);
    return true;
  },

  async testZKTecoConnection() {
    const statusEl = document.getElementById('zkteco-status');
    const bridgeUrl = (document.getElementById('zkteco-bridge-url').value || '').trim().replace(/\/+$/, '');
    const keyEl = document.getElementById('zkteco-bridge-key');
    const key = keyEl ? keyEl.value.trim() : '';
    if (statusEl) statusEl.innerText = 'Testing...';
    const stamp = () => new Date().toLocaleTimeString('en-US', { timeZone: APP_TIMEZONE, hour12: true, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const parts = [];
    let bad = false;

    if (bridgeUrl) {
      try {
        const ping = await this._zkBridgeFetch('/ping', 'GET', 8000, bridgeUrl, '');
        if (!ping.ok) throw new Error('HTTP ' + ping.status);
        const st = await this._zkBridgeFetch('/sync-status', 'GET', 8000, bridgeUrl, key);
        if (st.status === 401) { parts.push('✗ ব্রিজ পাওয়া গেছে কিন্তু API key ভুল/নেই'); bad = true; }
        else if (st.ok && st.json) {
          if (!st.json.enabled) { parts.push('⚠️ ব্রিজ চালু, কিন্তু Supabase push কনফিগার করা নেই (ব্রিজের config.json দেখুন)'); bad = true; }
          else if (st.json.lastError) { parts.push('⚠️ ব্রিজ চালু, শেষ পুশে সমস্যা: ' + st.json.lastError); bad = true; }
          else parts.push('✓ ব্রিজ সংযুক্ত এবং Supabase push চালু');
        } else parts.push('✓ ব্রিজ সংযুক্ত');
      } catch (e) {
        parts.push('⚠️ ব্রিজে সরাসরি পৌঁছানো যায়নি (' + (e.message || e) + ') — HTTPS-এ হোস্ট করা অ্যাপ থেকে http:// ব্রিজে সংযোগ ব্লক হতে পারে, তাতে সমস্যা নেই: ব্রিজ নিজেই Supabase-এ ডেটা পাঠায়');
      }
    }
    try {
      const last = await this.fetchZkBridgeLastPush();
      parts.push(this._zkDescribeLastPush(last));
      if (!last || (Date.now() - new Date(last.at).getTime()) > 30 * 60000) bad = true;
    } catch (e) {
      parts.push('Supabase থেকে ব্রিজের শেষ পুশ পড়া যায়নি: ' + (e.message || e));
      bad = true;
    }
    const text = parts.join(' | ') + ' — শেষ পরীক্ষা: ' + stamp();
    if (statusEl) statusEl.innerText = text;
    this.notify(bad ? 'ZKTeco: কিছু বিষয় যাচাই করুন (নিচের স্ট্যাটাস দেখুন)' : 'ZKTeco ব্রিজ ঠিকভাবে কাজ করছে', bad ? 'warn' : undefined);
  },

  // "Sync Now" / auto-sync: ask the bridge to push right now (if reachable), then reload
  // HR > Attendance from Supabase. Unmatched / conflicting Device User IDs come back from the
  // database function and are reported exactly like before.
  async syncZKTecoAttendance(silent) {
    if (!this.zkteco.enabled) {
      if (!silent) this.notify('Settings থেকে আগে ZKTeco চালু করুন', 'warn');
      return;
    }
    let summary = null, bridgeNote = '';
    if (this.zkteco.bridgeUrl) {
      try {
        const r = await this._zkBridgeFetch('/sync-now', 'POST', 40000, this.zkteco.bridgeUrl, this._zkBridgeKey());
        if (r.status === 401) bridgeNote = ' (ব্রিজের API key ভুল — Settings-এ ঠিক করুন)';
        else if (r.json && r.json.ok) summary = r.json;
        else if (r.json && r.json.error) bridgeNote = ' (ব্রিজ: ' + r.json.error + ')';
      } catch (e) {
        bridgeNote = ''; // bridge not reachable from this browser -- fine, it pushes on its own schedule
      }
    }
    try {
      const refreshed = await this.refreshAttendanceFromDB();
      this.renderHRAttendance();

      let unmatched = [], conflicts = [], msg;
      let last = null;
      if (summary) {
        unmatched = summary.unmatched || [];
        conflicts = summary.conflicts || [];
        msg = `ZKTeco Sync সম্পন্ন — ${summary.matched || 0}টি লগ মেলানো হয়েছে, ${summary.added || 0}টি নতুন এন্ট্রি যোগ হয়েছে`;
      } else {
        last = await this.fetchZkBridgeLastPush();
        if (last) { unmatched = last.unmatched || []; conflicts = last.conflicts || []; }
        msg = 'HR > Attendance Supabase থেকে হালনাগাদ হয়েছে — ' + this._zkDescribeLastPush(last) + bridgeNote;
      }
      if (!refreshed) msg += ' (এই ব্রাউজারে অসিঙ্কড অফলাইন পরিবর্তন আছে, তাই আগে Sync করুন)';
      if (unmatched.length) msg += ` — ⚠️ কোনো কর্মচারীর সাথে মেলেনি এমন Device User ID: ${unmatched.join(', ')} (HR > Employees-এ "ZKTeco Device User ID" ফিল্ড চেক করুন)`;
      if (conflicts.length) msg += ` — ⚠️ একাধিক কর্মচারীর সাথে যুক্ত Device User ID (তাই স্কিপ করা হয়েছে): ${conflicts.join(', ')}`;
      const hasIssues = unmatched.length || conflicts.length;
      // Auto-sync would repeat the same warning every few minutes -- show a given issue set only once
      const sig = hasIssues ? unmatched.join(',') + '|' + conflicts.join(',') : '';
      if (!silent || (hasIssues && sig !== this._zkLastIssueSig)) this.notify(msg, hasIssues ? 'warn' : undefined);
      this._zkLastIssueSig = sig;
    } catch (e) {
      if (!silent) this.notify('ZKTeco Sync failed: ' + e.message, 'error');
    }
  },

  // ===== লেজার মেরামত টুল (Settings > Data Management) =====
  // formatUSD-এর পুরনো বাগের কারণে accBuyer/accSupplier-এ Total/Received/Paid/Due ভুল হয়ে
  // গিয়ে থাকতে পারে। এই ফাংশনটি প্রতিটি রেকর্ডের আসল/নির্ভরযোগ্য উৎস থেকে পুনরায় হিসাব করে:
  //  - Total → piList.totalValue / supplierOrders.totalValue (এগুলো কখনো formatUSD দিয়ে
  //    সংরক্ষিত হয়নি, তাই এখনো নির্ভুল)
  //  - Received/Paid → buyerPaymentHistory/supplierPaymentHistory-এর amount-এর যোগফল (এই
  //    কলামটিও কখনো formatUSD দিয়ে সংরক্ষিত হয়নি, শুধু .toFixed(2) দিয়ে, তাই নির্ভরযোগ্য)
  // এভাবে পুরনো ভুল সম্পূর্ণ বাদ দিয়ে শূন্য থেকে সঠিক মান পুনর্গঠন করা হয়।
  async repairLedgerData() {
    if (!confirm('এটি Buyer ও Supplier লেজারের Total/Received/Paid/Due মান PI, Supplier Order ও Payment History থেকে পুনরায় সঠিকভাবে হিসাব করে সংরক্ষণ করবে (formatUSD বাগে ভুল হয়ে যাওয়া পুরনো ডেটা ঠিক করার জন্য)। এগিয়ে যেতে চান?')) return;

    let buyerFixed = 0, supplierFixed = 0;

    this.state.accBuyer.forEach(row => {
      const pi = this.state.piList.find(p => p.piNo === row.piNo);
      const total = pi ? this.parseMoney(pi.totalValue) : this.parseMoney(row.total);
      const received = this.state.buyerPaymentHistory
        .filter(h => h.piNo === row.piNo)
        .reduce((s, h) => s + this.parseMoney(h.amount), 0);
      const due = Math.max(total - received, 0);
      const newTotal = this.formatUSD(total), newReceived = this.formatUSD(received), newDue = this.formatUSD(due);
      if (row.total !== newTotal || row.received !== newReceived || row.due !== newDue) buyerFixed++;
      row.total = newTotal; row.received = newReceived; row.due = newDue;
      row.status = due <= 0 ? 'Paid' : 'Due';
    });

    this.state.accSupplier.forEach(row => {
      const so = this.state.supplierOrders.find(s => s.orderNo === row.orderNo);
      const total = so ? this.parseMoney(so.totalValue) : this.parseMoney(row.total);
      const paid = this.state.supplierPaymentHistory
        .filter(h => h.orderNo === row.orderNo)
        .reduce((s, h) => s + this.parseMoney(h.amount), 0);
      const due = Math.max(total - paid, 0);
      const newTotal = this.formatUSD(total), newPaid = this.formatUSD(paid), newDue = this.formatUSD(due);
      if (row.total !== newTotal || row.paid !== newPaid || row.due !== newDue) supplierFixed++;
      row.total = newTotal; row.paid = newPaid; row.due = newDue;
    });

    await this.persistSheet('accBuyer');
    await this.persistSheet('accSupplier');
    this.renderAccBuyer();
    this.renderAccSupplier();
    this.notify(`লেজার মেরামত সম্পন্ন — Buyer: ${buyerFixed}টি, Supplier: ${supplierFixed}টি রেকর্ড সংশোধন করা হয়েছে`);
  },

  // ===== Excel (.xlsx) এক্সপোর্ট ফিচার =====
  // ExcelJS লাইব্রেরি দিয়ে প্রফেশনাল-লুকিং এক্সেল ফাইল তৈরি করা হয়: বোল্ড/রঙিন হেডার রো, উপযুক্ত
  // কলাম প্রস্থ, জেব্রা-স্ট্রাইপ সারি, ফ্রোজেন হেডার (স্ক্রল করলেও হেডার সবসময় দেখা যায়), এবং সংখ্যা
  // কলামে থাউজেন্ড-সেপারেটর ফরম্যাট। এই একটি জেনেরিক ফাংশনই নিচের ৫টি নির্দিষ্ট এক্সপোর্টে ব্যবহৃত হয়।
  async exportToExcel(sheetTitle, columns, rows, fileName) {
    if (typeof ExcelJS === 'undefined') { this.notify('Excel export library did not load -- check your internet connection', 'error'); return; }
    if (!rows.length) { this.notify('এক্সপোর্ট করার মতো কোনো ডেটা নেই', 'warn'); return; }

    const wb = new ExcelJS.Workbook();
    wb.creator = 'AccoFlow ERP';
    wb.created = new Date();
    // এক্সেল শিটের নাম সর্বোচ্চ ৩১ অক্ষর হতে পারে, তাই প্রয়োজনে ছেঁটে দেওয়া হচ্ছে
    const ws = wb.addWorksheet(sheetTitle.substring(0, 31), { views: [{ state: 'frozen', ySplit: 1 }] });
    ws.columns = columns.map(c => ({ header: c.header, key: c.key, width: c.width || 16 }));

    const headerRow = ws.getRow(1);
    headerRow.height = 24;
    headerRow.eachCell(cell => {
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0A0F18' } };
      cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
      cell.border = { bottom: { style: 'medium', color: { argb: 'FF06B6D4' } } };
    });

    rows.forEach((r, i) => {
      const row = ws.addRow(r);
      row.eachCell(cell => {
        // এক সারি পর পর হালকা ধূসর ব্যাকগ্রাউন্ড (zebra stripe) — পড়তে সুবিধার জন্য
        if (i % 2 === 1) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF3F6FA' } };
        cell.border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
        cell.alignment = { vertical: 'middle', wrapText: false };
      });
    });

    columns.forEach((c, idx) => { if (c.numFmt) ws.getColumn(idx + 1).numFmt = c.numFmt; });

    const buf = await wb.xlsx.writeBuffer();
    const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileName}_${todayStr()}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    this.notify('Downloading Excel file...');
  },

  exportPIToExcel() {
    const columns = [
      { header: 'Date', key: 'date', width: 14 },
      { header: 'PI No', key: 'piNo', width: 16 },
      { header: 'Buyer', key: 'buyer', width: 22 },
      { header: 'Supplier', key: 'supplier', width: 22 },
      { header: 'Items', key: 'items', width: 30 },
      { header: 'Total Value ($)', key: 'totalValue', width: 16, numFmt: '#,##0.00' },
      { header: 'Status', key: 'qcStatus', width: 22 }
    ];
    const rows = this.state.piList.map(r => ({
      date: formatDate(r.date), piNo: r.piNo, buyer: r.buyer, supplier: r.supplier,
      items: r.items, totalValue: this.parseMoney(r.totalValue), qcStatus: this.computePIStatus(r).label
    }));
    this.exportToExcel('PI List', columns, rows, 'AccoFlow_PI_List');
  },

  exportReceivedGoodsToExcel() {
    const columns = [
      { header: 'Date', key: 'date', width: 14 },
      { header: 'Order No', key: 'orderNo', width: 16 },
      { header: 'PI No', key: 'piNo', width: 14 },
      { header: 'Buyer', key: 'buyer', width: 20 },
      { header: 'Item Name', key: 'itemName', width: 22 },
      { header: 'Style No', key: 'styleNo', width: 16 },
      { header: 'CN No (Challan)', key: 'cnNo', width: 26 },
      { header: 'Order Qty', key: 'orderQty', width: 12, numFmt: '#,##0' },
      { header: 'Received Qty', key: 'receivedQty', width: 14, numFmt: '#,##0' },
      { header: 'Due Qty', key: 'dueQty', width: 12, numFmt: '#,##0' }
    ];
    const rows = this.state.receivedGoods.map(r => ({
      date: formatDate(r.date), orderNo: r.orderNo, piNo: r.piNo, buyer: r.buyer, itemName: r.itemName, styleNo: r.styleNo,
      cnNo: r.cnNo, orderQty: this.parseMoney(r.orderQty), receivedQty: this.parseMoney(r.receivedQty), dueQty: this.parseMoney(r.dueQty)
    }));
    this.exportToExcel('Received Goods', columns, rows, 'AccoFlow_Received_Goods');
  },

  // বর্তমানে খোলা (active) Supplier Order Sheet-টিকে আলাদা Excel ফাইল হিসেবে এক্সপোর্ট করে —
  // নিচের exportSupplierOrdersToExcel() পূর্বের সব অর্ডারের তালিকা এক্সপোর্ট করে, আর এটা শুধু
  // বর্তমানে কাজ করা একটি অর্ডারকে এক্সপোর্ট করে (PI মডিউলের মতোই)
  async exportSupplierOrderDocToExcel() {
    if (typeof ExcelJS === 'undefined') { this.notify('Excel library did not load -- check your internet connection', 'error'); return; }

    const wb = new ExcelJS.Workbook();
    wb.creator = 'AccoFlow ERP';
    wb.created = new Date();
    const ws = wb.addWorksheet('Supplier Order');

    ws.columns = [
      { width: 6 }, { width: 16 }, { width: 22 }, { width: 14 },
      { width: 14 }, { width: 10 }, { width: 12 }, { width: 12 }, { width: 18 }
    ];

    const getVal = id => (document.getElementById(id)?.value || '');
    const companyName = this.settings.companyName || 'AccoFlow Enterprise';
    const companyAddr = this.settings.address || '';

    const styleTitle = (cell, text, fontSize) => {
      cell.value = text;
      cell.font = { bold: true, size: fontSize || 14 };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
    };
    const styleLabel = (cell, text) => {
      cell.value = text;
      cell.font = { bold: true, size: 10, color: { argb: 'FF334155' } };
    };
    const darkHeader = (row) => {
      row.eachCell(cell => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 10 };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0A0F18' } };
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
        cell.border = { bottom: { style: 'medium', color: { argb: 'FF06B6D4' } } };
      });
    };

    let r = 1;
    ws.mergeCells(r, 1, r, 9);
    styleTitle(ws.getCell(r, 1), companyName, 16);
    r++;
    if (companyAddr) {
      ws.mergeCells(r, 1, r, 9);
      const addrCell = ws.getCell(r, 1);
      addrCell.value = companyAddr;
      addrCell.font = { size: 10, color: { argb: 'FF64748B' } };
      addrCell.alignment = { horizontal: 'center' };
      r++;
    }
    ws.mergeCells(r, 1, r, 9);
    styleTitle(ws.getCell(r, 1), 'SUPPLIER ORDER SHEET', 14);
    ws.getCell(r, 1).font = { bold: true, size: 14, color: { argb: 'FF000000' } };
    r += 2;

    const infoRows = [
      ['Date:', getVal('so-date'), 'Order No:', getVal('so-order-no')],
      ['PI No:', getVal('so-pi-no'), 'Merchandiser:', getVal('so-merchandiser')],
      ['Supplier:', getVal('so-supplier'), 'Expected Delivery:', getVal('so-expected-delivery')],
    ];
    infoRows.forEach(([l1, v1, l2, v2]) => {
      styleLabel(ws.getCell(r, 1), l1);
      ws.getCell(r, 2).value = v1;
      if (l2) {
        styleLabel(ws.getCell(r, 5), l2);
        ws.getCell(r, 6).value = v2;
      }
      r++;
    });
    r++;

    const itemHeaders = ['SL', 'ITEM CODE', 'DESCRIPTION', 'STYLE NO', 'BRAND', 'QTY', 'UNIT PRICE ($)', 'TOTAL ($)', 'REMARKS'];
    const headerRow = ws.getRow(r);
    itemHeaders.forEach((h, i) => { headerRow.getCell(i + 1).value = h; });
    darkHeader(headerRow);
    r++;

    const soRows = Array.from(document.querySelectorAll('#so-items-tbody tr'));
    soRows.forEach((tr, i) => {
      const cells = Array.from(tr.querySelectorAll('td')).map(td => {
        const input = td.querySelector('input');
        return input ? input.value : td.innerText.trim();
      });
      const row = ws.getRow(r);
      cells.forEach((val, ci) => { if (ci < 9) row.getCell(ci + 1).value = val; });
      row.eachCell(cell => {
        if (i % 2 === 1) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF3F6FA' } };
        cell.border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
        cell.alignment = { vertical: 'middle' };
      });
      r++;
    });

    r++;
    ws.mergeCells(r, 1, r, 7);
    styleLabel(ws.getCell(r, 1), 'GRAND TOTAL:');
    ws.getCell(r, 1).alignment = { horizontal: 'right' };
    const totalVal = document.getElementById('so-grand-total')?.innerText || '$0.00';
    ws.getCell(r, 8).value = totalVal;
    ws.getCell(r, 8).font = { bold: true, size: 12 };

    const buf = await wb.xlsx.writeBuffer();
    const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const orderNo = (getVal('so-order-no') || 'draft').replace(/[^a-zA-Z0-9_-]/g, '');
    a.download = `SupplierOrder_${orderNo}_${todayStr()}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    this.notify('Supplier Order Excel ফাইল ডাউনলোড হচ্ছে...');
  },

  exportSupplierOrdersToExcel() {
    const columns = [
      { header: 'Date', key: 'date', width: 14 },
      { header: 'Order No', key: 'orderNo', width: 16 },
      { header: 'PI No', key: 'piNo', width: 14 },
      { header: 'Merchandiser', key: 'merchandiser', width: 18 },
      { header: 'Supplier', key: 'supplier', width: 22 },
      { header: 'Expected Delivery', key: 'expectedDelivery', width: 16 },
      { header: 'Items', key: 'items', width: 32 },
      { header: 'Total Value ($)', key: 'totalValue', width: 16, numFmt: '#,##0.00' }
    ];
    const rows = this.state.supplierOrders.map(r => ({
      date: formatDate(r.date), orderNo: r.orderNo, piNo: r.piNo, merchandiser: r.merchandiser, supplier: r.supplier,
      expectedDelivery: formatDate(r.expectedDelivery), items: r.items, totalValue: this.parseMoney(r.totalValue)
    }));
    this.exportToExcel('Supplier Orders', columns, rows, 'AccoFlow_Supplier_Orders');
  },

  // "Delivery Challan" এক্সপোর্ট Delivery History (deliveryHist) থেকে নেওয়া হচ্ছে, কারণ এটাই প্রতিটি
  // সম্পন্ন হওয়া ডেলিভারির প্রকৃত চালান নম্বর সংরক্ষিত রেকর্ড (Delivery Center > Delivery History ট্যাব)।
  // Challan Generator (প্রিন্ট টেমপ্লেট) কোনো ডেটাবেসে সংরক্ষিত হয় না, তাই সেখান থেকে এক্সপোর্ট সম্ভব না।
  exportDeliveryHistToExcel() {
    const columns = [
      { header: 'Date', key: 'date', width: 14 },
      { header: 'Order No', key: 'orderNo', width: 16 },
      { header: 'Buyer', key: 'buyer', width: 20 },
      { header: 'Challan No', key: 'challan', width: 18 },
      { header: 'Qty', key: 'qty', width: 12, numFmt: '#,##0' },
      { header: 'Delivered By', key: 'deliveredBy', width: 18 },
      { header: 'Status', key: 'status', width: 14 }
    ];
    const rows = this.state.deliveryHist.map(r => ({
      date: formatDate(r.date), orderNo: r.orderNo, buyer: r.buyer, challan: r.challan,
      qty: this.parseMoney(r.qty), deliveredBy: r.deliveredBy, status: r.status
    }));
    this.exportToExcel('Delivery Challan History', columns, rows, 'AccoFlow_Delivery_Challan');
  },

  exportQCToExcel() {
    const columns = [
      { header: 'Date', key: 'date', width: 14 },
      { header: 'Challan No', key: 'challan', width: 16 },
      { header: 'Order No', key: 'orderNo', width: 16 },
      { header: 'PI', key: 'piNo', width: 14 },
      { header: 'Style No', key: 'styleNo', width: 14 },
      { header: 'Item Code', key: 'itemCode', width: 18 },
      { header: 'Supplier', key: 'supplier', width: 18 },
      { header: 'Buyer', key: 'buyer', width: 18 },
      { header: 'Qty', key: 'qty', width: 10, numFmt: '#,##0' },
      { header: 'QC Qty', key: 'qcQty', width: 10, numFmt: '#,##0' },
      { header: 'Reject Qty', key: 'rejectQty', width: 12, numFmt: '#,##0' },
      { header: 'Reject %', key: 'rejectPct', width: 10 },
      { header: 'Result', key: 'result', width: 10 },
      { header: 'Action', key: 'action', width: 32 }
    ];
    const rows = this.state.qcList.map(r => ({
      date: formatDate(r.date), challan: r.challan, orderNo: r.orderNo, piNo: r.piNo || '', styleNo: r.styleNo || '', itemCode: r.itemCode, supplier: r.supplier, buyer: r.buyer,
      qty: this.parseMoney(r.qty), qcQty: this.parseMoney(r.qcQty), rejectQty: this.parseMoney(r.rejectQty),
      rejectPct: r.rejectPct, result: r.result, action: r.action
    }));
    this.exportToExcel('QC Report', columns, rows, 'AccoFlow_QC_Report');
  },

  // ===== Challan Generator (Delivery Center > Challan Generator) থেকে সরাসরি Excel এক্সপোর্ট =====
  // এই টেবিলটি ডাটাবেসে সংরক্ষিত হয় না (শুধু প্রিন্টের জন্য contenteditable ড্রাফট), তাই এখানে
  // স্ক্রিনে বর্তমানে যা টাইপ করা আছে (চালান নম্বর, বায়ার, তারিখ ও টেবিলের সব সারি) সরাসরি DOM থেকে
  // পড়ে Excel-এ রূপান্তর করা হয় — এটাই প্রকৃত "DELIVERY CHALLAN" ডকুমেন্টের এক্সপোর্ট।
  async exportChallanToExcel() {
    if (typeof ExcelJS === 'undefined') { this.notify('Excel export library did not load -- check your internet connection', 'error'); return; }

    // ⚠️ ফিচার: প্রতিটি সারির শেষে এখন একটা ডিলিট বাটনের সেল আছে (row-action-cell ক্লাস) — Excel
    // এক্সপোর্টে এই বাটন কলামটা যেন না যায়, তাই সেটা বাদ দিয়ে বাকি ১১টা আসল ডেটা সেল পড়া হচ্ছে
    const dataRows = Array.from(document.querySelectorAll('#challan-tbody tr'))
      .map(tr => Array.from(tr.querySelectorAll('td:not(.row-action-cell)')).map(td => td.innerText.trim()))
      .filter(cells => cells.slice(1).some(c => c)); // SL নম্বর ছাড়া বাকি অন্তত একটা ঘরে কিছু লেখা থাকলেই রাখা হচ্ছে

    if (!dataRows.length) { this.notify('Challan টেবিলে এক্সপোর্ট করার মতো কোনো ডেটা নেই — আগে টেবিলটি পূরণ করুন', 'warn'); return; }

    const headers = ['SL NO', 'PO NO', 'STYLE NO', 'ITEM CODE', 'ITEM', 'ORDER QTY', 'DELIVERY QTY', 'BRAND', 'COLOR', 'SHORT/EXCESS', 'REMARKS'];
    const colWidths = [6, 14, 14, 16, 18, 12, 12, 12, 12, 14, 22];

    const wb = new ExcelJS.Workbook();
    wb.creator = 'AccoFlow ERP';
    wb.created = new Date();
    const ws = wb.addWorksheet('Delivery Challan');
    ws.columns = colWidths.map(w => ({ width: w }));

    // === শিরোনাম ===
    ws.mergeCells(1, 1, 1, headers.length);
    const titleCell = ws.getCell(1, 1);
    titleCell.value = (this.settings.companyName || 'AccoFlow ERP') + ' — DELIVERY CHALLAN';
    titleCell.font = { bold: true, size: 14 };
    titleCell.alignment = { horizontal: 'center' };
    ws.getRow(1).height = 24;

    // === চালানের তথ্য (Challan No/Buyer/Date/PI No ইত্যাদি) ===
    const getVal = id => (document.getElementById(id)?.value || '-');
    const infoPairs = [
      ['Challan No:', getVal('challan-no'), 'Date:', getVal('challan-date')],
      ['Buyer:', getVal('challan-buyer'), 'PI No:', getVal('challan-pi')],
      ['Contact Person:', getVal('challan-contact'), 'Address:', getVal('challan-address')]
    ];
    let r = 2;
    infoPairs.forEach(([l1, v1, l2, v2]) => {
      const row = ws.getRow(r);
      row.getCell(1).value = l1; row.getCell(1).font = { bold: true };
      row.getCell(2).value = v1;
      row.getCell(6).value = l2; row.getCell(6).font = { bold: true };
      row.getCell(7).value = v2;
      r++;
    });
    r++; // একটা ফাঁকা সারি রাখা হচ্ছে টেবিলের আগে

    // === টেবিলের হেডার রো ===
    const headerRow = ws.getRow(r);
    headers.forEach((h, i) => { headerRow.getCell(i + 1).value = h; });
    headerRow.eachCell(cell => {
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0A0F18' } };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
      cell.border = { bottom: { style: 'medium', color: { argb: 'FF06B6D4' } } };
    });
    headerRow.height = 22;
    r++;

    dataRows.forEach((cells, i) => {
      const row = ws.getRow(r);
      cells.forEach((val, ci) => { row.getCell(ci + 1).value = val; });
      row.eachCell(cell => {
        if (i % 2 === 1) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF3F6FA' } };
        cell.border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
        cell.alignment = { vertical: 'middle' };
      });
      r++;
    });

    const buf = await wb.xlsx.writeBuffer();
    const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const safeChallanNo = (getVal('challan-no') || 'draft').replace(/[^a-zA-Z0-9_-]/g, '');
    a.href = url;
    a.download = `AccoFlow_Delivery_Challan_${safeChallanNo}_${todayStr()}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    this.notify('Downloading Excel file...');
  },

  // ===== PI Document (Proforma Invoice) থেকে Excel এক্সপোর্ট =====
  // PI মডালে যা দেখা যাচ্ছে (হেডার তথ্য + আইটেম টেবিল) তা সম্পূর্ণ Excel-এ রূপান্তর করে।
  async exportPIDocToExcel() {
    if (typeof ExcelJS === 'undefined') { this.notify('Excel library did not load -- check your internet connection', 'error'); return; }

    const wb = new ExcelJS.Workbook();
    wb.creator = 'AccoFlow ERP';
    wb.created = new Date();
    const ws = wb.addWorksheet('Proforma Invoice');

    // Column widths
    ws.columns = [
      { width: 5 }, { width: 18 }, { width: 18 }, { width: 18 },
      { width: 12 }, { width: 12 }, { width: 12 }, { width: 12 }, { width: 12 }, { width: 12 }
    ];

    const getVal = id => (document.getElementById(id)?.value || '');
    const companyName = this.settings.companyName || 'COMPANY NAME';
    const companyAddr = this.settings.companyAddress || 'COMPANY ADDRESS';

    // Helper: style a merged title cell
    const styleTitle = (cell, text, fontSize) => {
      cell.value = text;
      cell.font = { bold: true, size: fontSize || 14 };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
    };
    const styleLabel = (cell, text) => {
      cell.value = text;
      cell.font = { bold: true, size: 10, color: { argb: 'FF334155' } };
    };
    const darkHeader = (row) => {
      row.eachCell(cell => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 10 };
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0A0F18' } };
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
        cell.border = { bottom: { style: 'medium', color: { argb: 'FF06B6D4' } } };
      });
    };

    let r = 1;
    // Company header
    ws.mergeCells(r, 1, r, 10);
    styleTitle(ws.getCell(r, 1), companyName, 16);
    r++;
    ws.mergeCells(r, 1, r, 10);
    const addrCell = ws.getCell(r, 1);
    addrCell.value = companyAddr;
    addrCell.font = { size: 10, color: { argb: 'FF64748B' } };
    addrCell.alignment = { horizontal: 'center' };
    r++;
    ws.mergeCells(r, 1, r, 10);
    styleTitle(ws.getCell(r, 1), 'PROFORMA INVOICE', 14);
    ws.getCell(r, 1).font = { bold: true, size: 14, color: { argb: 'FF000000' } };
    r += 2;

    // Buyer info section
    const buyerInfo = [
      ['Consignee / Buyer:', getVal('pi-consignee'), 'Invoice Date:', getVal('pi-modal-date')],
      ['Buyer Address:', getVal('pi-buyer-address'), 'Invoice No:', getVal('pi-invoice-no')],
      ['Attention / Merchandiser:', getVal('pi-attention'), 'No. of Carton:', getVal('pi-carton')],
      ['Notify Party:', getVal('pi-notify-party'), 'Terms:', getVal('pi-terms')],
      ['Country of Destination:', getVal('pi-destination'), 'L/C Validity:', getVal('pi-validity')],
      ['Buyer (If Other):', getVal('pi-buyer-other'), '', ''],
    ];
    buyerInfo.forEach(([l1, v1, l2, v2]) => {
      styleLabel(ws.getCell(r, 1), l1);
      ws.getCell(r, 2).value = v1;
      if (l2) {
        styleLabel(ws.getCell(r, 6), l2);
        ws.getCell(r, 7).value = v2;
      }
      r++;
    });
    r++;

    // Port/Shipment info
    const shipInfo = [
      ['Port of Loading:', getVal('pi-port')],
      ['Shipment:', getVal('pi-shipment')],
      ['Packing:', getVal('pi-packing')],
      ['Country of Origin:', getVal('pi-origin')]
    ];
    shipInfo.forEach(([l, v]) => {
      styleLabel(ws.getCell(r, 1), l);
      ws.getCell(r, 2).value = v;
      r++;
    });
    r++;

    // Item table header
    const itemHeaders = ['SL', 'BUYER REF', 'HS CODE', 'ITEM DESCRIPTION', 'STYLE NO', 'SIZE', 'QTY (PCS)', 'UNIT PRICE ($)', 'TOTAL ($)', 'REMARKS'];
    const headerRow = ws.getRow(r);
    itemHeaders.forEach((h, i) => { headerRow.getCell(i + 1).value = h; });
    darkHeader(headerRow);
    r++;

    // Item rows from PI table
    const piRows = Array.from(document.querySelectorAll('#pi-full-tbody tr'));
    piRows.forEach((tr, i) => {
      const cells = Array.from(tr.querySelectorAll('td')).map(td => td.innerText.trim());
      const row = ws.getRow(r);
      cells.forEach((val, ci) => {
        if (ci < 10) row.getCell(ci + 1).value = val;
      });
      row.eachCell(cell => {
        if (i % 2 === 1) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF3F6FA' } };
        cell.border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
        cell.alignment = { vertical: 'middle' };
      });
      r++;
    });

    // Grand total row
    r++;
    ws.mergeCells(r, 1, r, 8);
    styleLabel(ws.getCell(r, 1), 'GRAND TOTAL:');
    ws.getCell(r, 1).alignment = { horizontal: 'right' };
    const totalVal = document.getElementById('pi-full-gtotal')?.innerText || '$0.00';
    ws.getCell(r, 9).value = totalVal;
    ws.getCell(r, 9).font = { bold: true, size: 12 };
    r += 2;

    // In words
    const inWords = document.getElementById('pi-in-words')?.innerText || '';
    if (inWords) {
      ws.mergeCells(r, 1, r, 10);
      ws.getCell(r, 1).value = inWords;
      ws.getCell(r, 1).font = { italic: true, bold: true, size: 10 };
      ws.getCell(r, 1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF1F5F9' } };
    }

    const buf = await wb.xlsx.writeBuffer();
    const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const piNo = (getVal('pi-invoice-no') || 'draft').replace(/[^a-zA-Z0-9_-]/g, '');
    a.download = `PI_${piNo}_${todayStr()}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    this.notify('PI Excel ফাইল ডাউনলোড হচ্ছে...');
  },

  // ===== QC Sheet (QC Report মডালের বর্তমান ডেটা) থেকে Excel এক্সপোর্ট =====
  // মডালে যতগুলো QC সারি আছে সবগুলো একসাথে একটি Excel ফাইলে রপ্তানি হবে।
  async exportQCSheetToExcel() {
    if (typeof ExcelJS === 'undefined') { this.notify('Excel library did not load -- check your internet connection', 'error'); return; }

    const header = {
      date: document.getElementById('qc-h-date').value || '',
      challan: document.getElementById('qc-h-challan').value || '',
      orderNo: document.getElementById('qc-h-order-no').value || '',
      supplier: document.getElementById('qc-h-supplier').value || '',
      buyer: document.getElementById('qc-h-buyer').value || ''
    };

    const dataRows = Array.from(document.querySelectorAll('#qc-tbody .qc-row')).map(tr => ({
      piNo: tr.querySelector('.qc-f-pi')?.value || '',
      styleNo: tr.querySelector('.qc-f-style-no')?.value || '',
      itemCode: tr.querySelector('.qc-f-item-code')?.value || '',
      qty: tr.querySelector('.qc-f-order-qty')?.value || '',
      qcQty: tr.querySelector('.qc-f-qty')?.value || '',
      rejectQty: tr.querySelector('.qc-f-reject-qty')?.value || '',
      rejectPct: tr.querySelector('.qc-f-reject-pct')?.textContent || '',
      result: tr.querySelector('.qc-f-result')?.textContent || '',
      action: tr.querySelector('.qc-f-action')?.value || ''
    })).filter(r => r.itemCode || r.qcQty || r.piNo || r.styleNo);

    if (!dataRows.length) { this.notify('QC টেবিলে এক্সপোর্ট করার মতো কোনো ডেটা নেই', 'warn'); return; }

    const wb = new ExcelJS.Workbook();
    wb.creator = 'AccoFlow ERP';
    wb.created = new Date();
    const ws = wb.addWorksheet('QC Report');

    const columns = [
      { header: 'PI', key: 'piNo', width: 14 },
      { header: 'Style No', key: 'styleNo', width: 14 },
      { header: 'Item Code', key: 'itemCode', width: 16 },
      { header: 'Quantity', key: 'qty', width: 12 },
      { header: 'QC Qty', key: 'qcQty', width: 12 },
      { header: 'Reject Qty', key: 'rejectQty', width: 12 },
      { header: 'Reject %', key: 'rejectPct', width: 10 },
      { header: 'Result', key: 'result', width: 10 },
      { header: 'Action', key: 'action', width: 30 }
    ];
    ws.columns = columns;

    // Company name (title) row
    ws.mergeCells(1, 1, 1, columns.length);
    const titleCell = ws.getCell(1, 1);
    titleCell.value = this.settings.companyName || 'AccoFlow ERP';
    titleCell.font = { bold: true, size: 16 };
    titleCell.alignment = { horizontal: 'center' };
    ws.getRow(1).height = 26;

    // "QC INSPECTION REPORT" subtitle row
    ws.mergeCells(2, 1, 2, columns.length);
    const subCell = ws.getCell(2, 1);
    subCell.value = 'QC INSPECTION REPORT';
    subCell.font = { bold: true, size: 12 };
    subCell.alignment = { horizontal: 'center' };
    subCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9D9D9' } };

    // Header info block (Order No / Challan No / Supplier / Buyer / Date)
    const infoPairs = [
      ['Order No', header.orderNo], ['Challan No', header.challan], ['Supplier', header.supplier],
      ['Buyer', header.buyer], ['Date', header.date ? formatDate(header.date) : '']
    ];
    let r = 4;
    infoPairs.forEach(([label, val]) => {
      const labelCell = ws.getCell(r, 1);
      labelCell.value = label;
      labelCell.font = { bold: true };
      labelCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFCE4D6' } };
      ws.mergeCells(r, 2, r, columns.length);
      ws.getCell(r, 2).value = val || '';
      r++;
    });
    r++; // blank spacer row

    // Item table header row
    const headerRow = ws.getRow(r);
    columns.forEach((c, i) => { headerRow.getCell(i + 1).value = c.header; });
    headerRow.eachCell(cell => {
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFED7D31' } };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
    });
    headerRow.height = 22;
    r++;

    // Item data rows
    dataRows.forEach((row, i) => {
      const dataRow = ws.getRow(r + i);
      Object.keys(row).forEach((k, ci) => { dataRow.getCell(ci + 1).value = row[k]; });
      dataRow.eachCell(cell => {
        if (i % 2 === 1) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF3F6FA' } };
        cell.border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
        cell.alignment = { vertical: 'middle' };
      });
    });

    const buf = await wb.xlsx.writeBuffer();
    const blob = new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AccoFlow_QC_Sheet_${todayStr()}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    this.notify('QC Excel ফাইল ডাউনলোড হচ্ছে...');
  },

  openQCModal() {
    document.getElementById('qc-edit-id').value = '';
    document.getElementById('qc-save-btn-text').innerText = 'Save';
    ['qc-h-order-no', 'qc-h-challan', 'qc-h-supplier', 'qc-h-buyer'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
    document.getElementById('qc-h-date').value = todayStr();
    document.getElementById('qc-tbody').innerHTML = '';
    document.getElementById('qc-add-row-btn').style.display = '';
    this.addQCRow();
    this.populateQCChallanList();
    this.refreshQCForm();
    this.open('qc-modal');
  },

  // ===== QC Report রিডিজাইন: Date/Challan/Order No/Supplier/Buyer এখন উপরে একবারই দেওয়া হেডার
  // ফিল্ড (দেখুন qc-h-* ইনপুটগুলো) — একই Challan-এর অধীনে একাধিক PI/Style/Item এখানে "Add Row"
  // দিয়ে যোগ করা যায়। Save চাপলে হেডারের তথ্য + প্রতিটি সারির আইটেম-তথ্য মিলিয়ে আলাদা আলাদা QC
  // রিপোর্ট এন্ট্রি হিসেবে সংরক্ষিত হয় (saveQC() দেখুন) =====
  addQCRow() {
    const tbody = document.getElementById('qc-tbody');
    if (!tbody) return;
    const row = document.createElement('tr');
    row.className = 'qc-row';
    row.innerHTML = `
      <td><input type="text" class="qc-f-pi" list="so-pi-no-list" placeholder="PI No"></td>
      <td><input type="text" class="qc-f-style-no" placeholder="Style No"></td>
      <td><input type="text" class="qc-f-item-code" list="pi-item-codes-list" placeholder="Item Code" onchange="app.autoFillQCItemFromCode(this)"></td>
      <td><input type="number" class="qc-f-order-qty" placeholder="0" oninput="app.calcQCReject(this)"></td>
      <td><input type="number" class="qc-f-qty" placeholder="0" oninput="app.calcQCReject(this)"></td>
      <td><input type="number" class="qc-f-reject-qty" placeholder="0" oninput="app.calcQCReject(this)"></td>
      <td class="qc-f-reject-pct">0%</td>
      <td class="qc-f-result">-</td>
      <td><textarea class="qc-f-action" placeholder="Corrective/Follow-up action..." style="width:100%;min-height:60px;resize:vertical;"></textarea></td>
      <td class="no-print" style="text-align:center;"><button type="button" class="action-btn action-delete" onclick="app.removeQCRow(this)" title="এই সারি মুছুন"><i class="bi bi-trash"></i></button></td>`;
    tbody.appendChild(row);
    this.populateQCChallanList();
  },

  removeQCRow(btn) {
    const tbody = document.getElementById('qc-tbody');
    if (!tbody) return;
    if (tbody.querySelectorAll('.qc-row').length <= 1) { this.notify('অন্তত একটি সারি থাকতে হবে', 'warn'); return; }
    btn.closest('tr').remove();
  },

  // সাধারণ HTML-escape হেল্পার (XSS এড়ানো ও কোটেশন মার্ক জনিত ভাঙা HTML প্রতিরোধের জন্য)
  // ⚠️ Round 24: collision-free record IDs. IDs used to be computed in the browser as
  // Math.max(existing)+1, so two people saving a new record at the same moment (or a record
  // added by another user / the ZKTeco bridge that this browser had not loaded yet) got the
  // SAME id and the second save silently overwrote the first. Now the database hands out the
  // next id (next_row_id(), migration v24). If that function is not installed yet / the
  // database is unreachable, this falls back to the old local calculation -- but the local
  // maximum also counts Recycle-Bin rows, which the old code ignored. `alsoUsed` lets a caller
  // that creates several rows in one go avoid its own earlier picks.
  async allocId(table, alsoUsed) {
    const used = new Set((alsoUsed || []).map(Number));
    let localMax = 0;
    (this.state[table] || []).forEach(r => { localMax = Math.max(localMax, parseInt(r.id, 10) || 0); });
    (this.trashItems || []).forEach(t => { if (t.module === table && t.record) localMax = Math.max(localMax, parseInt(t.record.id, 10) || 0); });
    used.forEach(u => { localMax = Math.max(localMax, u); });
    let id = localMax + 1;
    if (SheetsDB.isConfigured() && !this._noIdRpc) {
      try {
        const v = await Promise.race([
          SheetsDB.nextRowId(table),
          new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 5000))
        ]);
        if (Number.isFinite(v) && v > 0) id = Math.max(id, v);
      } catch (e) {
        // function missing (migration v24 not run yet) -> stop asking; other errors (offline) just fall back this time
        if (/next_row_id|PGRST202|404|does not exist|could not find/i.test(String(e && e.message))) this._noIdRpc = true;
      }
    }
    while (used.has(id)) id++;
    return id;
  },

  // null/undefined-safe variant: renders '' instead of the text "null"
  esc(v) { return v == null ? '' : this.escapeHtml(v); },

  escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  },

  // ⚠️ নিরাপত্তা ফিক্স: onclick="app.fn('${value}')" প্যাটার্নে শুধু escapeHtml() যথেষ্ট না — কারণ
  // ব্রাউজার আগে HTML attribute-এর entity ডিকোড করে (&#39; → '), তারপর সেই ডিকোড হওয়া টেক্সটটাকে
  // JS কোড হিসেবে রান করে। ফলে escapeHtml দিয়ে ' কে &#39; বানালেও এটি আবার ' হয়ে JS string ভেঙে
  // দিতে পারে। তাই দুই লেয়ারেই এস্কেপ করতে হয়: (১) JS string-এর জন্য \ ও ' এস্কেপ, (২) তার বাইরের
  // HTML attribute-এর জন্য & ও " এস্কেপ — এই হেল্পারটি onclick="...('${...}')" প্যাটার্নে ব্যবহার করুন।
  // Only data:image/... or http(s) URLs may be used as an <img src>; anything else (javascript:,
  // attribute-breaking text, ...) is dropped. Used for receipt/logo images that come from the DB.
  safeImageSrc(v) {
    const t = String(v == null ? '' : v).trim();
    return /^(data:image\/[a-z0-9.+-]+;base64,|https?:\/\/)/i.test(t) ? t : '';
  },

  escapeJsAttr(str) {
    return String(str)
      .replace(/\\/g, '\\\\')
      .replace(/&/g, '&amp;')
      .replace(/'/g, "\\'")
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\n/g, ' ')
      .replace(/\r/g, '');
  },

  // Received Goods-এ থাকা সব Challan No দিয়ে datalist পপুলেট করা হয় — অর্থাৎ যতক্ষণ পর্যন্ত মাল
  // রিসিভ না হবে ততক্ষণ সেই চালানের QC করা সম্ভব হবে না (কারণ চালান নম্বরটাই খুঁজে পাওয়া যাবে না)
  // ===== Received Goods-এর CN No এখন কমা দিয়ে একাধিক চালান নম্বর ধারণ করতে পারে (partial/emergency
  // delivery-এর কারণে) — তাই যেকোনো একটি Challan No দিয়ে খুঁজলেও সঠিক এন্ট্রি যেন পাওয়া যায়, তার
  // জন্য এই হেল্পার ফাংশনগুলো কেন্দ্রীয়ভাবে ব্যবহার করা হয় (QC মডিউলসহ) =====
  splitChallanList(cnNoStr) {
    return String(cnNoStr || '').split(',').map(c => c.trim()).filter(Boolean);
  },

  findReceivedGoodsByChallan(challanNo) {
    const target = String(challanNo || '').trim().toLowerCase();
    if (!target) return null;
    return this.state.receivedGoods.find(r => this.splitChallanList(r.cnNo).some(c => c.toLowerCase() === target));
  },

  challanExistsInReceivedGoods(challanNo) {
    return !!this.findReceivedGoodsByChallan(challanNo);
  },

  populateQCChallanList() {
    const dl = document.getElementById('qc-challan-list');
    if (!dl) return;
    const all = new Set();
    this.state.receivedGoods.forEach(r => this.splitChallanList(r.cnNo).forEach(c => all.add(c)));
    dl.innerHTML = Array.from(all).map(c => `<option value="${this.escapeHtml(c)}">`).join('');
  },

  // Challan No লিখে/সিলেক্ট করলে Received Goods থেকে হেডার তথ্য (Order No/Buyer/Supplier) অটো-ফিল
  // হয়, এবং সেই চালানের প্রতিটি আইটেম (items[]) দিয়ে নিচের টেবিলে আলাদা আলাদা সারি স্বয়ংক্রিয়ভাবে
  // তৈরি হয়ে যায় (PI/Style No/Item Code/Quantity সহ) — ইউজার শুধু QC Qty/Reject Qty দিলেই হয়।
  // Challan খুঁজে না পেলে মানে ঐ মাল এখনো রিসিভ হয়নি।
  autoFillQCFromChallan(el) {
    const challanNo = el.value;
    const rg = this.findReceivedGoodsByChallan(challanNo);
    if (!rg) {
      if (challanNo.trim()) this.notify('এই Challan No-এর কোনো Received Goods এন্ট্রি পাওয়া যায়নি — মাল রিসিভ হওয়ার আগে QC করা যাবে না', 'warn');
      return;
    }
    const set = (id, val) => {
      const target = document.getElementById(id);
      if (!target) return;
      target.value = val || '';
      target.classList.add('autofill-field');
      setTimeout(() => target.classList.remove('autofill-field'), 1500);
    };
    set('qc-h-order-no', rg.orderNo);
    set('qc-h-buyer', rg.buyer);
    const orderData = this.masterData.orders[rg.orderNo] || {};
    set('qc-h-supplier', orderData.supplier || '');

    const items = Array.isArray(rg.items) && rg.items.length ? rg.items : [{ itemCode: rg.itemName, styleNo: rg.styleNo, receivedQty: rg.receivedQty }];
    const tbody = document.getElementById('qc-tbody');
    tbody.innerHTML = '';
    items.forEach(it => {
      this.addQCRow();
      const tr = tbody.lastElementChild;
      tr.querySelector('.qc-f-pi').value = rg.piNo || '';
      tr.querySelector('.qc-f-style-no').value = it.styleNo || '';
      tr.querySelector('.qc-f-item-code').value = it.itemCode || '';
      tr.querySelector('.qc-f-order-qty').value = it.receivedQty || it.orderQty || '';
    });
    this.notify(`Auto-filled from Challan: ${challanNo} (${items.length}টি আইটেম)`);
  },

  // Item Code বাছাই করলে Master Data থেকে ওই একই সারির Style No অটো-ফিল করা হয় (খালি থাকলেই)
  autoFillQCItemFromCode(el) {
    const row = el.closest('tr');
    if (!row) return;
    const item = this.state.masterData.find(m => m.itemCode === el.value.trim());
    if (!item) return;
    const styleEl = row.querySelector('.qc-f-style-no');
    if (styleEl && !styleEl.value) {
      styleEl.value = item.styleNo || '';
      styleEl.classList.add('autofill-field');
      setTimeout(() => styleEl.classList.remove('autofill-field'), 1500);
    }
  },

  // Order No (হেডার) লেখার পর Master Data-এর অর্ডার লিস্ট থেকে Supplier ও Buyer অটো-ফিল করা
  autoFillQCHeaderFromOrder(el) {
    const data = this.masterData.orders[el.value.trim()];
    if (!data) return;
    const supplierEl = document.getElementById('qc-h-supplier');
    const buyerEl = document.getElementById('qc-h-buyer');
    if (supplierEl && !supplierEl.value) supplierEl.value = data.supplier || '';
    if (buyerEl && !buyerEl.value) buyerEl.value = data.buyer || '';
  },

  // QC Qty / Reject Qty টাইপ করার সাথে সাথে ওই একই সারির Reject% ও Result স্বয়ংক্রিয়ভাবে ক্যালকুলেট হয়
  // Maximum Reject Allowance এখন 5% (আগে ছিল 2%)
  calcQCReject(el) {
    const row = el ? el.closest('tr') : document.querySelector('#qc-tbody .qc-row');
    if (!row) return;
    const qcQty = parseFloat(row.querySelector('.qc-f-qty').value) || 0;
    const rejectQty = parseFloat(row.querySelector('.qc-f-reject-qty').value) || 0;
    const pctCell = row.querySelector('.qc-f-reject-pct');
    const resultCell = row.querySelector('.qc-f-result');
    const pct = qcQty ? (rejectQty / qcQty) * 100 : 0;
    pctCell.innerText = pct.toFixed(1) + '%';
    if (!qcQty) { resultCell.innerText = '-'; resultCell.style.color = ''; return; }
    const pass = pct <= this.QC_MAX_REJECT_PCT;
    resultCell.innerText = pass ? 'PASS' : 'FAIL';
    resultCell.style.color = pass ? 'var(--green)' : 'var(--red)';
  },

  // Add QC Report ফর্ম থেকে সেভ করা — Date/Challan/Order No/Supplier/Buyer এখন একবার (হেডারে) দেওয়া
  // হয় এবং প্রতিটি সারির সাথে মিলিয়ে আলাদা আলাদা QC রিপোর্ট এন্ট্রি হিসেবে একসাথে সংরক্ষণ করা হয়;
  // সম্পূর্ণ খালি রাখা কোনো সারি (ব্যবহার না করা Add Row) নীরবে বাদ পড়ে যায়। এডিটের ক্ষেত্রে সবসময় একটাই সারি থাকে।
  async saveQC() {
    const editId = document.getElementById('qc-edit-id').value;
    const header = {
      date: document.getElementById('qc-h-date').value || todayStr(),
      challan: document.getElementById('qc-h-challan').value.trim(),
      orderNo: document.getElementById('qc-h-order-no').value.trim(),
      supplier: document.getElementById('qc-h-supplier').value.trim(),
      buyer: document.getElementById('qc-h-buyer').value.trim()
    };
    if (!header.orderNo) { this.notify('Order No আবশ্যক', 'warn'); return; }
    if (header.challan && !this.challanExistsInReceivedGoods(header.challan)) {
      this.notify('এই Challan No-এর মাল এখনো Received Goods-এ রিসিভ দেখানো হয়নি', 'warn'); return;
    }
    const rows = Array.from(document.querySelectorAll('#qc-tbody .qc-row'));

    const readRow = (tr) => {
      const qcQty = parseFloat(tr.querySelector('.qc-f-qty').value) || 0;
      const rejectQty = parseFloat(tr.querySelector('.qc-f-reject-qty').value) || 0;
      const rejectPct = qcQty ? ((rejectQty / qcQty) * 100).toFixed(1) + '%' : '0%';
      const result = (qcQty ? (rejectQty / qcQty) * 100 : 0) <= this.QC_MAX_REJECT_PCT ? 'Pass' : 'Fail';
      return {
        ...header,
        piNo: tr.querySelector('.qc-f-pi').value.trim(),
        styleNo: tr.querySelector('.qc-f-style-no').value.trim(),
        itemCode: tr.querySelector('.qc-f-item-code').value.trim(),
        qty: parseFloat(tr.querySelector('.qc-f-order-qty').value) || 0,
        qcQty, rejectQty, rejectPct, result,
        action: tr.querySelector('.qc-f-action').value.trim()
      };
    };

    if (editId) {
      const tr = rows[0];
      if (!tr) return;
      const record = readRow(tr);
      if (!record.qcQty) { this.notify('QC Qty আবশ্যক', 'warn'); return; }
      if (record.rejectQty > record.qcQty) { this.notify('Reject Qty cannot be more than QC Qty', 'warn'); return; }
      const idx = this.state.qcList.findIndex(r => r.id == editId);
      if (idx !== -1) this.state.qcList[idx] = { id: parseInt(editId), ...record };
      this.logAudit('Update', 'qcList', editId, record.challan || record.orderNo);
      this.notify('QC রিপোর্ট আপডেট হয়েছে');
    } else {
      const newRecords = [];
      for (const tr of rows) {
        const record = readRow(tr);
        // সম্পূর্ণ খালি সারি (ব্যবহার না করা Add Row) নীরবে বাদ দেওয়া হচ্ছে
        if (!record.itemCode && !record.qcQty && !record.piNo && !record.styleNo) continue;
        if (!record.qcQty) { this.notify('প্রতিটি সারিতে QC Qty আবশ্যক', 'warn'); return; }
        if (record.rejectQty > record.qcQty) { this.notify('Reject Qty cannot be more than QC Qty', 'warn'); return; }
        newRecords.push({ id: await this.allocId('qcList', newRecords.map(r => r.id)), ...record });
      }
      if (!newRecords.length) { this.notify('অন্তত একটি সারি পূরণ করুন', 'warn'); return; }
      this.state.qcList.unshift(...newRecords);
      newRecords.forEach(r => this.logAudit('Create', 'qcList', r.id, r.challan || r.orderNo));
      this.notify(newRecords.length > 1 ? `${newRecords.length}টি QC রিপোর্ট সংরক্ষিত হয়েছে` : 'QC রিপোর্ট সংরক্ষিত হয়েছে');
    }
    await this.persistSheet('qcList');
    this.renderQCList();
    this.close('qc-modal');
  },

  // পূর্বের কোনো QC রিপোর্ট আবার দেখা/এডিট/প্রিন্ট করার জন্য একই মোডাল পুনরায় ব্যবহার করা হয়
  // (এডিট মোডে সবসময় একটাই সারি দেখানো হয়, Add Row বাটনও লুকানো থাকে)
  viewQCReport(id) {
    const row = this.state.qcList.find(r => r.id === id);
    if (!row) return;
    this.populateQCChallanList();
    document.getElementById('qc-h-date').value = row.date || '';
    document.getElementById('qc-h-order-no').value = row.orderNo || '';
    document.getElementById('qc-h-challan').value = row.challan || '';
    document.getElementById('qc-h-supplier').value = row.supplier || '';
    document.getElementById('qc-h-buyer').value = row.buyer || '';
    document.getElementById('qc-tbody').innerHTML = '';
    this.addQCRow();
    const tr = document.querySelector('#qc-tbody .qc-row');
    tr.querySelector('.qc-f-pi').value = row.piNo || '';
    tr.querySelector('.qc-f-style-no').value = row.styleNo || '';
    tr.querySelector('.qc-f-item-code').value = row.itemCode || '';
    tr.querySelector('.qc-f-order-qty').value = row.qty || '';
    tr.querySelector('.qc-f-qty').value = row.qcQty || '';
    tr.querySelector('.qc-f-reject-qty').value = row.rejectQty || '';
    tr.querySelector('.qc-f-action').value = row.action || '';
    tr.querySelector('.action-delete').style.display = 'none';
    document.getElementById('qc-edit-id').value = row.id;
    document.getElementById('qc-save-btn-text').innerText = 'Update';
    document.getElementById('qc-add-row-btn').style.display = 'none';
    this.refreshQCForm();
    this.calcQCReject(tr.querySelector('.qc-f-qty'));
    this.open('qc-modal');
  },

  notify(msg, type) {
    const container = document.getElementById('toast-container');
    const icons = { warn: 'bi-exclamation-triangle-fill', error: 'bi-x-circle-fill', ok: 'bi-check-circle-fill' };
    const colors = { warn: 'var(--yellow)', error: 'var(--red)', ok: 'var(--accent)' };
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<i class="bi ${icons[type] || icons.ok}" style="color:${colors[type] || colors.ok};font-size:16px"></i> ${this.escapeHtml(msg)}`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  },

  getChartData() {
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const statusMap = { Delivered: 0, Partial: 0, Planned: 0, Pending: 0, Delayed: 0, Overdue: 0 };
    this.state.deliveryPlan.forEach(r => {
      const key = r.status === 'Done' ? 'Delivered' : (statusMap[r.status] !== undefined ? r.status : 'Pending');
      if (statusMap[key] !== undefined) statusMap[key]++;
    });

    // ===== Profit Trend (গত ৬ মাস) — বছর+মাস দুটোই মিলিয়ে হিসাব করা হয় (উপরের salesByMonth-এর
    // মতো শুধু মাস দিয়ে না, যাতে ভিন্ন বছরের একই মাসের ডেটা ভুলবশত একসাথে মিশে না যায়) =====
    const profitLabels = [];
    const profitData = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const y = d.getFullYear(), m = d.getMonth();
      const sales = this.state.piList.reduce((s, r) => {
        const rd = new Date(r.date);
        return (!isNaN(rd) && rd.getMonth() === m && rd.getFullYear() === y) ? s + this.parseMoney(r.totalValue) : s;
      }, 0);
      const cost = (this.state.supplierOrders || []).reduce((s, r) => {
        const rd = new Date(r.date);
        return (!isNaN(rd) && rd.getMonth() === m && rd.getFullYear() === y) ? s + this.parseMoney(r.totalValue) : s;
      }, 0);
      profitLabels.push(months[m] + (y !== now.getFullYear() ? ` '${String(y).slice(2)}` : ''));
      profitData.push(Math.round(sales - cost));
    }

    // Attendance Tracking ডোনাট চার্টের জন্য ডেটা (E1) — আজকের hrAttendance এন্ট্রি থেকে
    const today = todayStr();
    const totalEmployees = this.state.hrEmployees.length;
    const todayRecords = this.state.hrAttendance.filter(r => r.date === today);
    const presentToday = todayRecords.filter(r => r.status === 'Present' || r.status === 'Late').length;
    const onLeaveToday = todayRecords.filter(r => r.status === 'On Leave').length;
    const absentToday = Math.max(0, totalEmployees - presentToday - onLeaveToday);

    return {
      attendanceLabels: ['Present Today', 'On Leave', 'Absent'],
      attendanceData: [presentToday, onLeaveToday, absentToday],
      totalEmployees,
      pieLabels: ['Delivered','Partial','Pending','Overdue'],
      pieData: [statusMap.Delivered, statusMap.Partial, statusMap.Planned + statusMap.Pending, statusMap.Delayed + statusMap.Overdue],
      profitLabels, profitData
    };
  },

  charts(forceRecreate) {
    if (forceRecreate) {
      Object.values(this.chartInstances).forEach(c => c.destroy());
      this.chartInstances = {};
    }
    const chartData = this.getChartData();
    // ⚠️ বাগ ফিক্স (A2, থিম রিডিজাইনের পর আপডেট করা): আগে axis/legend/grid রঙ ডার্ক মোডের জন্য
    // হার্ডকোড করা ছিল। এখন body-এর data-app-theme অ্যাট্রিবিউট দেখে রঙ নির্বাচন করা হয় — Classic
    // Glass (ডিফল্ট, ডার্ক) বাদে Aqua Dash থিমটা হালকা ব্যাকগ্রাউন্ডের, তাই সেটার জন্য গাঢ়
    // tick/grid/legend রঙ ব্যবহার করা হচ্ছে। applyAppTheme()
    // থিম পরিবর্তনে charts(true) কল করে instance রিক্রিয়েট করে, তাই নতুন রঙ সাথে সাথে প্রয়োগ হয়।
    const isLight = ['aqua-dash', 'modern-light', 'ocean-blue', 'sunrise-gradient'].includes(document.body.getAttribute('data-app-theme'));
    const tickColor = isLight ? '#475569' : '#64748b';
    const gridColor = isLight ? '#e2e8f0' : '#1e293b';
    const legendColor = isLight ? '#334155' : '#94a3b8';
    const opt = { responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { color: legendColor, font: { family: 'Space Grotesk', size: 10 } } } }, scales: { x: { ticks: { color: tickColor, font: { size: 9 } }, grid: { color: gridColor } }, y: { ticks: { color: tickColor, font: { size: 9 } }, grid: { color: gridColor }, beginAtZero: true } } };
    const attendanceEl = document.getElementById('chartAttendance');
    const pieEl = document.getElementById('chartPie');
    const attBadge = document.getElementById('dash-attendance-badge');
    if (attBadge) attBadge.innerText = `Total: ${chartData.totalEmployees}`;
    if (attendanceEl && !this.chartInstances.attendance) {
      this.chartInstances.attendance = new Chart(attendanceEl.getContext('2d'), { type: 'doughnut', data: { labels: chartData.attendanceLabels, datasets: [{ data: chartData.attendanceData, backgroundColor: ['#10b981','#06b6d4','#ef4444'], borderWidth: 0 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { color: legendColor, font: { family: 'Space Grotesk', size: 10 }, padding: 8 } } }, cutout: '65%' } });
    }
    if (pieEl && !this.chartInstances.pie) {
      this.chartInstances.pie = new Chart(pieEl.getContext('2d'), { type: 'doughnut', data: { labels: chartData.pieLabels, datasets: [{ data: chartData.pieData, backgroundColor: ['#10b981','#f59e0b','#06b6d4','#ef4444'], borderWidth: 0 }] }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { color: legendColor, font: { family: 'Space Grotesk', size: 10 }, padding: 8 } } }, cutout: '65%' } });
    }
    const profitEl = document.getElementById('chartProfit');
    if (profitEl && !this.chartInstances.profit) {
      const barColors = chartData.profitData.map(v => v >= 0 ? '#10b981' : '#ef4444');
      this.chartInstances.profit = new Chart(profitEl.getContext('2d'), { type: 'bar', data: { labels: chartData.profitLabels, datasets: [{ label: 'Profit ($)', data: chartData.profitData, backgroundColor: barColors, borderRadius: 4 }] }, options: opt });
    }
  },

  // ============ REPORTS & BI ============
  // আগে এই বাটনগুলোর কোনো কাজ ছিল না (শুধু "Generating..." টোস্ট দেখাত বা কিছুই করত না) —
  // এখন প্রতিটি রিপোর্ট আসল ডেটা থেকে তৈরি হয়ে প্রিন্ট/PDF ও CSV এক্সপোর্ট করা যাবে
  currentReportType: null,

  REPORT_CONFIG: {
    stock: {
      title: 'Stock Report — Inventory Levels',
      data() { return app.state.masterData; },
      columns: [
        { key: 'itemCode', label: 'Item Code' }, { key: 'description', label: 'Description' },
        { key: 'styleNo', label: 'Style No' }, { key: 'brand', label: 'Brand' },
        { key: 'size', label: 'Size' }, { key: 'unit', label: 'Unit' }, { key: 'stock', label: 'Stock' },
        { key: 'sellingPrice', label: 'Selling Price ($)' }, { key: 'buyingPrice', label: 'Buying Price ($)' }
      ]
    },
    delivery: {
      title: 'Delivery Report — Delivery Logs',
      data() { return app.state.deliveryHist; },
      columns: [
        { key: 'date', label: 'Date' }, { key: 'orderNo', label: 'Order No' }, { key: 'buyer', label: 'Buyer' },
        { key: 'challan', label: 'Challan' }, { key: 'qty', label: 'Qty' }, { key: 'deliveredBy', label: 'Delivered By' }, { key: 'status', label: 'Status' }
      ]
    },
    qc: {
      title: 'QC Report — Pass / Fail Summary',
      data() { return app.state.qcList; },
      columns: [
        { key: 'date', label: 'Date' }, { key: 'challan', label: 'Challan' }, { key: 'orderNo', label: 'Order No' },
        { key: 'itemCode', label: 'Item Code' }, { key: 'qcQty', label: 'QC Qty' }, { key: 'rejectQty', label: 'Reject Qty' },
        { key: 'rejectPct', label: 'Reject %' }, { key: 'result', label: 'Result' }, { key: 'action', label: 'Action' }
      ]
    },
    expense: {
      title: 'Expense Report — Monthly Office Expense',
      data() { return app.state.expenseList; },
      columns: [
        { key: 'date', label: 'Date' }, { key: 'voucherNo', label: 'Voucher No' }, { key: 'category', label: 'Category' },
        { key: 'person', label: 'Person' }, { key: 'purpose', label: 'Purpose' }, { key: 'amount', label: 'Amount' }, { key: 'status', label: 'Status' }
      ]
    },
    salary: {
      title: 'Salary Report — Payroll Summary',
      data() { return app.state.hrSalary; },
      columns: [
        { key: 'employee', label: 'Employee' }, { key: 'month', label: 'Salary Month' }, { key: 'designation', label: 'Designation' }, { key: 'basic', label: 'Basic' },
        { key: 'otHours', label: 'OT Hours' }, { key: 'ot', label: 'OT Amount' }, { key: 'deduction', label: 'Deduction' },
        { key: 'net', label: 'Net Pay' }, { key: 'status', label: 'Status' }
      ]
    },
    attendance: {
      title: 'Attendance Report — Daily Attendance',
      data() { return app.state.hrAttendance; },
      columns: [
        { key: 'date', label: 'Date' }, { key: 'employee', label: 'Employee' }, { key: 'checkIn', label: 'Check In' },
        { key: 'checkOut', label: 'Check Out' }, { key: 'status', label: 'Status' }, { key: 'otHours', label: 'OT Hours' }
      ]
    },
    leaves: {
      title: 'Leave Report — Employee Leave Requests',
      data() { return app.state.hrLeaves; },
      columns: [
        { key: 'employee', label: 'Employee' }, { key: 'startDate', label: 'Start Date' }, { key: 'endDate', label: 'End Date' },
        { key: 'days', label: 'Days' }, { key: 'createdAt', label: 'Requested On' }
      ]
    }
  },

  openReportModal(type) {
    const config = this.REPORT_CONFIG[type];
    if (!config) return;
    this.currentReportType = type;
    document.getElementById('report-modal-title').innerText = config.title;
    const rows = config.data();
    const companyName = this.settings.companyName || 'AccoFlow ERP';
    const today = formatDate(new Date());
    let html = `
      <div style="text-align:center;margin-bottom:16px;">
        <h2 style="margin:0;font-size:18px;">${companyName}</h2>
        <p style="color:var(--text-muted);font-size:11px;margin:4px 0;">${config.title}</p>
        <p style="color:var(--text-dim);font-size:9px;">Generated: ${today} &bull; Total Records: ${rows.length}</p>
      </div>`;
    if (!rows.length) {
      html += `<p style="text-align:center;color:var(--text-muted);padding:30px;">এই রিপোর্টের জন্য কোনো ডেটা পাওয়া যায়নি — প্রথমে সংশ্লিষ্ট সেকশনে ডেটা যোগ করুন।</p>`;
    } else {
      html += `<div class="table-wrap"><table><thead><tr>${config.columns.map(c => `<th>${c.label}</th>`).join('')}</tr></thead><tbody>`;
      rows.forEach(r => {
        html += `<tr>${config.columns.map(c => `<td>${r[c.key] ?? ''}</td>`).join('')}</tr>`;
      });
      html += `</tbody></table></div>`;
    }
    document.getElementById('report-content').innerHTML = html;
    this.open('report-modal');
  },

  exportReportCSV(type) {
    const config = this.REPORT_CONFIG[type];
    if (!config) return;
    const rows = config.data();
    if (!rows.length) { this.notify('এই রিপোর্টের জন্য কোনো ডেটা নেই', 'warn'); return; }
    const header = config.columns.map(c => `"${c.label}"`).join(',');
    const body = rows.map(r => config.columns.map(c => `"${String(r[c.key] ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const csv = header + '\n' + body;
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${type}-report-${todayStr()}.csv`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    this.notify('CSV ডাউনলোড হয়েছে');
  }
};

window.onload = () => {
  app.init();
  // Close dashboard theme picker when clicking outside
  document.addEventListener('click', (e) => {
    const picker = document.getElementById('dash-theme-picker');
    const btn = document.querySelector('.dash-theme-btn');
    if (picker && picker.classList.contains('show') && !picker.contains(e.target) && !btn.contains(e.target)) {
      picker.classList.remove('show');
    }
  });
};
document.querySelectorAll('.modal-ov').forEach(m => m.addEventListener('click', e => { if (e.target === m) m.classList.remove('show'); }));
document.addEventListener('keydown', e => { if (e.key === 'Escape') { document.querySelectorAll('.modal-ov.show').forEach(m => m.classList.remove('show')); const tp = document.getElementById('dash-theme-picker'); if (tp) tp.classList.remove('show'); } });
