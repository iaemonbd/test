/**
 * AccoFlow ERP -- Configuration file
 * ---------------------------------
 * Putting the Supabase Project URL and Anon (Public) Key directly here means every
 * browser/user doesn't have to type this in separately on the Settings page -- the app
 * connects to the database automatically as soon as it starts. Not depending on
 * localStorage/browser cache removes the root cause of the "disconnects after logging out
 * and back in" problem.
 *
 * Where to find these: Supabase Dashboard -> Project Settings -> API -> Project URL and
 * anon/public key
 *
 * Security note: the values in this file are visible/accessible to anyone in the browser
 * (client-side) -- i.e. anyone who views this website's source code can see this URL and
 * Key. This is fine on its own: access to your actual data is controlled by Row Level
 * Security (RLS), which has been enabled on every business table since migration_v13 (see
 * accoflow_combined_schema_v24.sql) -- the anon key alone does not grant read/write access,
 * a valid authenticated Supabase Auth session is also required, and RLS policies then decide
 * what that session is allowed to do. Still, avoid hosting this file/the whole AccoFlow ERP
 * folder somewhere with no login of its own (a public URL with no further access control),
 * since that makes the login screen itself reachable by anyone -- prefer your office
 * network / intranet / VPN, or restrict access at the server level (e.g. .htaccess, Nginx
 * basic-auth) if hosting more broadly.
 */
const ACCOFLOW_CONFIG = {
  SUPABASE_URL: 'https://bskhtvxrbqgyjyccsadd.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_9qXYxBWmR0QzAN88dssP2Q_HyQOtwZj'
};
