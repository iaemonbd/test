/**
 * Supabase (PostgreSQL) database layer -- GarmentsPro ERP
 * Now uses Supabase instead of the old sheets-api.js (Google Apps Script).
 *
 * Important: no function call in app.js needed to change -- this object is still called
 * "SheetsDB" and every method's name/parameters are kept exactly as before (loadAll,
 * saveSheet, upsert, deleteRow, saveSettings, bulkSave, clearAllSheets, ping, isConfigured).
 * Only the internal implementation moved from the Google Sheets API to the Supabase client.
 */

// Every table name is kept exactly matching Code.gs's SHEET_CONFIG
const ALL_TABLES = [
  'piList', 'masterData', 'receivedGoods', 'supplierOrders',
  'deliveryPlan', 'deliveryExec', 'deliveryHist', 'qcList',
  'accBuyer', 'accSupplier', 'buyerPaymentHistory', 'supplierPaymentHistory',
  'expenseList', 'vouchers', 'hrEmployees', 'hrAttendance', 'hrLeaves', 'hrSalary',
  'hrSignatures', 'hrDepartments', 'hrApprovals',
  'users', 'buyers', 'suppliers'
];

const SheetsDB = {
  // Supabase needs two pieces of information: the Project URL and the Anon (public) Key
  // Priority: (1) the value hardcoded directly in js/config.js (if present and not a
  // placeholder) -- this is now the primary/permanent method, to remove the dependency on
  // browser/localStorage.
  // (2) otherwise, whatever was previously saved from Settings into localStorage (backward
  // compatibility).
  url: (function () {
    const cfg = (typeof ACCOFLOW_CONFIG !== 'undefined' && ACCOFLOW_CONFIG.SUPABASE_URL) ? ACCOFLOW_CONFIG.SUPABASE_URL.trim() : '';
    if (cfg && !cfg.includes('your-project-ref')) return cfg.replace(/\/+$/, '');
    return localStorage.getItem('gp_supabase_url') || '';
  })(),
  anonKey: (function () {
    const cfg = (typeof ACCOFLOW_CONFIG !== 'undefined' && ACCOFLOW_CONFIG.SUPABASE_ANON_KEY) ? ACCOFLOW_CONFIG.SUPABASE_ANON_KEY.trim() : '';
    if (cfg && !cfg.includes('paste-your-supabase-anon-public-key-here')) return cfg;
    return localStorage.getItem('gp_supabase_key') || '';
  })(),
  client: null,

  setCredentials(url, anonKey) {
    this.url = (url || '').trim().replace(/\/+$/, '');
    this.anonKey = (anonKey || '').trim();
    if (this.url) localStorage.setItem('gp_supabase_url', this.url); else localStorage.removeItem('gp_supabase_url');
    if (this.anonKey) localStorage.setItem('gp_supabase_key', this.anonKey); else localStorage.removeItem('gp_supabase_key');
    this._initClient();
  },

  // setApiUrl/apiUrl names are also supported for compatibility with old code (harmless even if unused)
  setApiUrl(url) { /* Supabase uses setCredentials() separately -- this is kept only for compatibility */ },

  _initClient() {
    if (this.url && this.anonKey && window.supabase) {
      // ⚠️ Round 13: persistSession:false is kept -- the old app always showed the login
      // screen on refresh (there was no "remembered" session), and the same behaviour is kept
      // after the Supabase Auth migration so users don't unexpectedly see an "auto-logged-in"
      // state. This can be set to true later to add a "Remember Me"-style UX if wanted.
      this.client = window.supabase.createClient(this.url, this.anonKey, {
        auth: { persistSession: false, autoRefreshToken: true }
      });
    } else {
      this.client = null;
    }
  },

  isConfigured() {
    if (!this.client) this._initClient();
    return !!(this.url && this.anonKey && this.client);
  },

  // Used when creating/updating a user or resetting a password from Settings > User
  // Management -- the actual work (creating the Auth account/setting the password) happens
  // server-side in the "admin-manage-user" Edge Function (using the service_role key),
  // because this cannot be done from the browser with the anon key -- Supabase itself blocks
  // it.
  // action: 'create' | 'update' | 'setStatus', payload: { username, role, status, password }
  async adminManageUser(payload) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const { data, error } = await this.client.functions.invoke('admin-manage-user', { body: payload });
    if (error) {
      // ⚠️ Bug fix: supabase-js's error.message here always shows only the generic "Edge
      // Function returned a non-2xx status code" -- the real reason (wrong password length,
      // a permission problem, a missing service_role key, etc.) lives in the response's JSON
      // body (error.context), not in error.message. So the user/we could never see the actual
      // reason without digging through Supabase Dashboard's Edge Function Logs. Now the real
      // reason is pulled directly out of that body and shown.
      let detail = error.message;
      try {
        if (error.context && typeof error.context.json === 'function') {
          const body = await error.context.json();
          if (body && body.error) detail = body.error;
        }
      } catch (e) { /* if the body can't be parsed, the generic message stays -- ignore quietly */ }
      throw new Error('User management action failed: ' + detail);
    }
    if (data && data.error) throw new Error(data.error);
    // ⚠️ Round 14 fix: this used to just assume "success" whenever there was no error. But
    // if Supabase's default template function (or the wrong function) was deployed, that also
    // returns a "successful" HTTP response (e.g. {message:"Hello ..."}) with no error field --
    // so the app would wrongly show "user created" when no Auth account was actually created
    // (the new user couldn't log in). Now the real admin-manage-user function's expected
    // response shape ({ok:true, ...}) is explicitly checked -- a mismatch shows a clear
    // error.
    if (!data || data.ok !== true) {
      throw new Error('Unexpected response from the Edge Function -- likely the wrong/default template code is deployed, redeploy with the real admin-manage-user/index.ts code.');
    }
    return data;
  },

  // For the Roles page -- fetches every user's role+permissions together (only
  // admin/superadmin can see all rows under this RLS policy, per v13's profiles_read policy).
  // ⚠️ Deliberately not part of ALL_TABLES -- so bulkSave()/clearAllSheets() can never
  // accidentally wipe/overwrite the profiles table (which would break the whole Auth
  // system) -- this one read-only function is kept completely separate.
  async loadAllProfiles() {
    if (!this.isConfigured()) return [];
    // the ZKTeco bridge's 'device' service account is not a person -- keep it off the Roles page
    const { data, error } = await this.client.from('profiles').select('username, role, status, permissions').neq('role', 'device');
    if (error) { console.warn('Problem loading profiles:', error.message); return []; }
    return data || [];
  },

  async ping() {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const { error } = await this.client.from('settings').select('key').limit(1);
    if (error) throw new Error(error.message);
    return { ok: true };
  },

  // Round 21: fetches this user's own granular permissions (profiles.permissions JSONB)
  // right after login -- the profiles table's "read own row" policy (in place since v13)
  // allows this.
  async getMyPermissions(authUid) {
    if (!this.isConfigured()) return {};
    const { data, error } = await this.client.from('profiles').select('permissions').eq('id', authUid).single();
    if (error) { console.warn('Problem loading permissions:', error.message); return {}; }
    return (data && data.permissions) || {};
  },

  // When an Admin/Superadmin changes a user's permissions from the Roles page -- the
  // profiles table's "admin/superadmin can write any row" policy (v13) allows this. Targeted
  // by username (not UUID) -- because the client's this.state.users only has the username,
  // not profiles.id (the auth UUID), and this is safe since profiles.username is
  // unique+not-null.
  async saveUserPermissions(username, permissions) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const { error } = await this.client.from('profiles').update({ permissions }).eq('username', username);
    if (error) throw new Error(error.message);
    return { ok: true };
  },

  // Round 16: payment posting now goes through the record_buyer_payment()/
  // record_supplier_payment() Postgres functions built in migration_v16_payment_rpc.sql --
  // validation, row-lock, ledger update, history insert, audit log -- all happen atomically
  // in one DB transaction (not two separate persistSheet() calls like before, where a failure
  // partway through could cause a ledger/history mismatch). Match the payload's keys to the
  // RPC's parameter names (minus the p_ prefix).
  async recordBuyerPayment(payload) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const { data, error } = await this.client.rpc('record_buyer_payment', {
      p_pi_no: payload.piNo,
      p_amount: payload.amount,
      p_method: payload.method,
      p_check_number: payload.checkNumber || '',
      p_remarks: payload.remarks || '',
      p_receipt_image: payload.receiptImage || '',
      p_date: payload.date
    });
    if (error) throw new Error(error.message);
    return data;
  },

  async recordSupplierPayment(payload) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const { data, error } = await this.client.rpc('record_supplier_payment', {
      p_order_no: payload.orderNo,
      p_amount: payload.amount,
      p_method: payload.method,
      p_check_number: payload.checkNumber || '',
      p_remarks: payload.remarks || '',
      p_receipt_image: payload.receiptImage || '',
      p_date: payload.date
    });
    if (error) throw new Error(error.message);
    return data;
  },

  // Round 24: asks the database for the next collision-free id of a table (next_row_id(),
  // migration v24) -- see app.allocId() for why. Throws if the function is not installed.
  async nextRowId(name) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const { data, error } = await this.client.rpc('next_row_id', { p_table: name });
    if (error) throw new Error(error.message);
    return Number(data);
  },

  // Loads data from every table at once -- app.js's loadFromDatabase() expects this structure:
  // { piList: [...], masterData: [...], ..., settings: [{key,value}], orders: [...] }
  async loadAll() {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const result = {};

    // All tables are loaded in parallel, for speed
    const tablePromises = ALL_TABLES.map(async (name) => {
      const { data, error } = await this.client.from(name).select('*');
      if (error) throw new Error(`Problem loading table "${name}": ${error.message}`);
      result[name] = data || [];
    });

    const settingsPromise = this.client.from('settings').select('*').then(({ data, error }) => {
      if (error) throw new Error('Problem loading the settings table: ' + error.message);
      result.settings = data || [];
    });

    const ordersPromise = this.client.from('orders').select('*').then(({ data, error }) => {
      if (error) throw new Error('Problem loading the orders table: ' + error.message);
      result.orders = data || [];
    });

    // auditLog is deliberately not part of ALL_TABLES -- it is only ever appended
    // (inserted), never upserted/deleted via diff-sync (for safety, so old audit records are
    // never accidentally wiped). Only the most recent 500 entries are loaded, to keep
    // performance fine even as the table grows.
    const auditLogPromise = this.client.from('auditLog').select('*').order('timestamp', { ascending: false }).limit(500).then(({ data, error }) => {
      if (error) throw new Error('Problem loading the auditLog table: ' + error.message);
      result.auditLog = data || [];
    });

    await Promise.all([...tablePromises, settingsPromise, ordersPromise, auditLogPromise]);
    return result;
  },

  // Makes the whole table match the given rows array exactly (deletes what's missing, upserts
  // what's present) -- instead of Google Apps Script's "wipe the whole sheet and rewrite it"
  // approach, this reaches the same result in a much safer, faster way (delete + upsert), and
  // the other rows stay intact even if one step fails.
  async saveSheet(name, rows) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const idKey = name === 'orders' ? 'orderNo' : 'id';

    const { data: existing, error: readErr } = await this.client.from(name).select(idKey);
    if (readErr) throw new Error(`Problem reading table "${name}": ${readErr.message}`);

    const existingIds = (existing || []).map(r => r[idKey]);
    const newIds = rows.map(r => r[idKey]);
    const toDelete = existingIds.filter(id => !newIds.includes(id));

    if (toDelete.length) {
      const { error: delErr } = await this.client.from(name).delete().in(idKey, toDelete);
      if (delErr) throw new Error(`Problem deleting old rows from "${name}": ${delErr.message}`);
    }

    if (rows.length) {
      const { error: upsertErr } = await this.client.from(name).upsert(rows, { onConflict: idKey });
      if (upsertErr) throw new Error(`Problem saving to table "${name}": ${upsertErr.message}`);
    }
    return { ok: true };
  },

  // ⚠️ Round 13 fix: unlike saveSheet(), this does not diff-sync "delete what's missing" --
  // it only upserts, never deletes a row. Every single-record save (persistSheet) used to
  // diff-sync the whole table, which caused two problems: (1) every small edit did a
  // read+delete+upsert of the entire table (unnecessary slowness), and (2) more importantly --
  // data loss in a multi-user environment: if another user added a new record and this browser
  // saved an edit without refreshing first, that new record looked "missing" and got
  // permanently deleted from the DB. This method is now used for single-record saves; an
  // actual delete is still always done separately and explicitly via deleteRow(), as before.
  // Whole-table diff-sync (saveSheet/bulkSave) is deliberately left unchanged, only for the
  // "Sync All to Cloud" feature.
  async upsertRows(name, rows) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    if (!rows || !rows.length) return { ok: true };
    const idKey = name === 'orders' ? 'orderNo' : 'id';
    const { error } = await this.client.from(name).upsert(rows, { onConflict: idKey });
    if (error) throw new Error(`Problem saving to table "${name}": ${error.message}`);
    return { ok: true };
  },

  // Adds a new entry to the audit log -- deliberately insert-only (never upsert/delete), so
  // the audit trail can never be accidentally overwritten or erased
  async insertAuditLog(entry) {
    if (!this.isConfigured()) return { ok: false };
    try {
      const { error } = await this.client.from('auditLog').insert(entry);
      if (error) { console.warn('Failed to save audit log:', error.message); return { ok: false }; }
      return { ok: true };
    } catch (e) {
      console.warn('Failed to save audit log:', e.message);
      return { ok: false };
    }
  },

  async upsert(name, row) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const idKey = name === 'orders' ? 'orderNo' : 'id';
    const { error } = await this.client.from(name).upsert(row, { onConflict: idKey });
    if (error) throw new Error(`Problem upserting to table "${name}": ${error.message}`);
    return { ok: true };
  },

  async deleteRow(name, id) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const idKey = name === 'orders' ? 'orderNo' : 'id';
    const { error } = await this.client.from(name).delete().eq(idKey, id);
    if (error) throw new Error(`Problem deleting from "${name}": ${error.message}`);
    // This deleteRow() is the one and only path for every delete (see the comment above), so
    // the tombstone is recorded right here -- so the Online<->Offline dual-endpoint reconcile
    // can tell this id apart as "deliberately deleted" rather than "never synced". If writing
    // the tombstone fails, the actual delete operation should not be blocked (best-effort),
    // hence the separate try/catch.
    try {
      await this.client.from('sync_tombstones').upsert(
        { tableName: name, recordId: String(id) },
        { onConflict: 'tableName,recordId' }
      );
    } catch (e) {
      console.warn(`Failed to write tombstone for "${name}" row ${id} (the delete itself succeeded):`, e);
    }
    return { ok: true };
  },

  // Settings are upserted into the settings table as key/value pairs
  async saveSettings(settingsObj) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    const rows = Object.keys(settingsObj).map(key => ({ key, value: String(settingsObj[key]) }));
    const { error } = await this.client.from('settings').upsert(rows, { onConflict: 'key' });
    if (error) throw new Error('Problem saving Settings: ' + error.message);
    return { ok: true };
  },

  async bulkSave(stateObj) {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    for (const name of Object.keys(stateObj)) {
      if (ALL_TABLES.includes(name) && Array.isArray(stateObj[name])) {
        await this.saveSheet(name, stateObj[name]);
      }
    }
    return { ok: true };
  },

  // For deliberately clearing all data (the Clear All Data feature) -- deletes every row from every table
  async clearAllSheets() {
    if (!this.isConfigured()) throw new Error('Supabase URL/Key is not configured');
    // For safety, Supabase/PostgREST does not allow a delete with no WHERE at all, so a
    // condition that is always true is used instead (.neq(-1) for integer id columns,
    // .neq('__never__') for text columns)
    for (const name of ALL_TABLES) {
      const { error } = await this.client.from(name).delete().neq('id', -1);
      if (error) throw new Error(`Problem clearing "${name}": ${error.message}`);
    }
    const { error: ordErr } = await this.client.from('orders').delete().neq('orderNo', '__never_match__');
    if (ordErr) throw new Error('Problem clearing orders: ' + ordErr.message);
    const { error: setErr } = await this.client.from('settings').delete().neq('key', '__never_match__');
    if (setErr) throw new Error('Problem clearing Settings: ' + setErr.message);
    return { ok: true };
  }
};
