/**
 * js/offline-sync.js — Online ☁️ / Offline 💻 mode and the Offline-first Sync engine (Round 22)
 * ============================================================================
 * This file must load after js/supabase-api.js and before js/app.js (see index.html).
 *
 * == Design summary ==
 * "Online" means the main cloud-hosted Supabase project (the URL/Key given in js/config.js
 * or Settings > Supabase Integration). "Offline" means a self-hosted Supabase instance,
 * usually run via Docker on the office LAN (see docker/README_SELF_HOST.md) -- reachable
 * from within the LAN even with no internet, so the software keeps working fully. Both are
 * genuinely independent Supabase projects -- the same schema (schema.sql + all migrations,
 * including migration_v22) must exist in both places.
 *
 * Three safety layers:
 *  1) Wraps SheetsDB.upsertRows()/deleteRow() -- if the active endpoint is temporarily
 *     unreachable (or the user has deliberately switched to Offline mode), a save/delete
 *     never fails or gets lost -- it just queues in IndexedDB as "pending" and is sent once
 *     the connection returns / Sync Now is pressed.
 *  2) Every table's current copy is mirrored to IndexedDB on every save -- a browser refresh
 *     does not lose pending changes (tracked via the persistDirtyTables metadata).
 *  3) When both endpoints (Online+Offline) are configured, Sync Now runs a genuine two-database
 *     reconcile -- each row's updatedAt (migration_v22) is compared to work out which is newer,
 *     and whichever loses is kept in the conflict log (never silently lost).
 * ============================================================================
 */

const OfflineSync = {
  DB_NAME: 'accoflow_offline_v1',
  DB_VERSION: 1,
  _db: null,

  MODE_KEY: 'af_conn_mode',
  ONLINE_URL_KEY: 'gp_supabase_url', ONLINE_ANON_KEY: 'gp_supabase_key',
  OFFLINE_URL_KEY: 'gp_supabase_url_offline', OFFLINE_ANON_KEY: 'gp_supabase_key_offline',

  // ---------------------------------------------------------------------------
  // IndexedDB — low-level helpers
  // ---------------------------------------------------------------------------
  _openDB() {
    if (this._db) return Promise.resolve(this._db);
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) { reject(new Error('This browser does not support IndexedDB — Offline mode will not work')); return; }
      const req = indexedDB.open(this.DB_NAME, this.DB_VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        // One store holds the full array keyed by table name (a direct mirror of
        // this.state[table]) — keeping it this way instead of a separate store per table
        // matches the app's own data model exactly, and mirroring stays a one-call operation.
        if (!db.objectStoreNames.contains('tables')) db.createObjectStore('tables', { keyPath: 'name' });
        // dirtyTables, pendingDeletes, lastSync, conflicts — all metadata lives here as key/value
        if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
      };
      req.onsuccess = (e) => { this._db = e.target.result; resolve(this._db); };
      req.onerror = () => reject(req.error);
    });
  },
  async _idbPut(store, value) {
    const db = await this._openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).put(value);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  },
  async _idbGet(store, key) {
    const db = await this._openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  },
  async _idbGetAll(store) {
    const db = await this._openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  },

  // ---------------------------------------------------------------------------
  // Metadata: dirty table list, pending deletes, last sync time, conflict log
  // ---------------------------------------------------------------------------
  async _getMeta(key, fallback) { try { const r = await this._idbGet('meta', key); return r ? r.value : fallback; } catch (e) { return fallback; } },
  async _setMeta(key, value) { try { await this._idbPut('meta', { key, value }); } catch (e) { console.warn('Failed to save offline meta:', key, e); } },

  async getDirtyTables() { return await this._getMeta('dirtyTables', []); },
  async markDirty(table) {
    const dirty = await this.getDirtyTables();
    if (!dirty.includes(table)) { dirty.push(table); await this._setMeta('dirtyTables', dirty); }
    this._refreshPendingBadge();
  },
  async clearDirty(table) {
    const dirty = await this.getDirtyTables();
    const next = dirty.filter(t => t !== table);
    if (next.length !== dirty.length) await this._setMeta('dirtyTables', next);
    this._refreshPendingBadge();
  },

  async getPendingDeletes() { return await this._getMeta('pendingDeletes', []); },
  async queueDelete(table, id) {
    const list = await this.getPendingDeletes();
    if (!list.some(d => d.table === table && d.id === id)) {
      list.push({ table, id, queuedAt: new Date().toISOString() });
      await this._setMeta('pendingDeletes', list);
    }
    this._refreshPendingBadge();
  },
  async clearPendingDelete(table, id) {
    const list = await this.getPendingDeletes();
    const next = list.filter(d => !(d.table === table && d.id === id));
    if (next.length !== list.length) await this._setMeta('pendingDeletes', next);
    this._refreshPendingBadge();
  },

  async getConflicts() { return await this._getMeta('conflicts', []); },
  async logConflict(entry) {
    const list = await this.getConflicts();
    list.unshift({ ...entry, at: new Date().toISOString() });
    await this._setMeta('conflicts', list.slice(0, 200)); // old entries drop off, keeps the most recent 200
  },

  async getLastSync() { return await this._getMeta('lastSync', null); },
  async setLastSync(iso) { await this._setMeta('lastSync', iso); },

  async getPendingCount() {
    const dirty = await this.getDirtyTables();
    const deletes = await this.getPendingDeletes();
    return dirty.length + deletes.length;
  },
  _refreshPendingBadge() {
    // Only calls app.js's refreshConnPendingBadge() if it is defined -- never touches the DOM
    // directly here, so this file can work standalone without knowing anything about app.js's
    // internal structure.
    if (window.app && typeof app.refreshConnPendingBadge === 'function') app.refreshConnPendingBadge();
  },

  // ---------------------------------------------------------------------------
  // Table mirror -- persistSheet() calls stampAndMirror() on every save
  // ---------------------------------------------------------------------------
  async mirrorTable(name, rows) {
    try { await this._idbPut('tables', { name, rows: rows || [] }); } catch (e) { console.warn('Offline mirror failed:', name, e); }
  },
  async getMirrored(name) {
    const rec = await this._idbGet('tables', name);
    return rec ? rec.rows : null;
  },
  async getAllMirrored() {
    const recs = await this._idbGetAll('tables');
    const out = {};
    recs.forEach(r => { out[r.name] = r.rows; });
    return out;
  },

  // Stamps updatedAt on every row (a client-side timestamp -- a second safety layer
  // alongside the DB trigger from migration_v22) and mirrors it to IndexedDB right away
  stampAndMirror(name, rows) {
    const nowIso = new Date().toISOString();
    (rows || []).forEach(r => { if (r && typeof r === 'object') r.updatedAt = nowIso; });
    this.mirrorTable(name, rows);
  },

  // ---------------------------------------------------------------------------
  // Connection mode (Online ☁️ / Offline 💻)
  // ---------------------------------------------------------------------------
  getMode() { return localStorage.getItem(this.MODE_KEY) || 'online'; },
  isOfflineMode() { return this.getMode() === 'offline'; },

  getCredentials(mode) {
    if (mode === 'offline') {
      return { url: localStorage.getItem(this.OFFLINE_URL_KEY) || '', key: localStorage.getItem(this.OFFLINE_ANON_KEY) || '' };
    }
    // 'online' -- if a value is hardcoded in js/config.js, it already becomes
    // SheetsDB.url/anonKey's default as soon as supabase-api.js loads (see the start of
    // js/supabase-api.js), so when localStorage is empty here, SheetsDB's current value is
    // simply treated as the "Online" value -- no existing installation's behaviour changes.
    return {
      url: localStorage.getItem(this.ONLINE_URL_KEY) || SheetsDB.url || '',
      key: localStorage.getItem(this.ONLINE_ANON_KEY) || SheetsDB.anonKey || ''
    };
  },

  saveOfflineCredentials(url, key) {
    if (url) localStorage.setItem(this.OFFLINE_URL_KEY, url); else localStorage.removeItem(this.OFFLINE_URL_KEY);
    if (key) localStorage.setItem(this.OFFLINE_ANON_KEY, key); else localStorage.removeItem(this.OFFLINE_ANON_KEY);
  },

  // Switches mode and points SheetsDB at the right URL/Key. ⚠️ Online and Offline are
  // genuinely two separate Supabase projects/instances -- each has its own Auth user base, so
  // after switching modes the previous session is no longer valid and a fresh login is
  // required. This is deliberate/for safety -- no session can "leak" from one project into
  // the other and grant access to the wrong data.
  applyMode(mode) {
    localStorage.setItem(this.MODE_KEY, mode);
    const creds = this.getCredentials(mode);
    SheetsDB.setCredentials(creds.url, creds.key);
  },

  // ---------------------------------------------------------------------------
  // Wraps SheetsDB.upsertRows()/deleteRow() -- every save/delete across the whole app
  // becomes offline-safe automatically, without editing a single call site in app.js
  // ---------------------------------------------------------------------------
  _wired: false,
  _wireSheetsDB() {
    if (this._wired) return; // safety -- wrapping twice would cause an infinite loop
    this._wired = true;

    const origUpsertRows = SheetsDB.upsertRows.bind(SheetsDB);
    SheetsDB.upsertRows = async (name, rows) => {
      this.stampAndMirror(name, rows);
      if (this.isOfflineMode() && !SheetsDB.isConfigured()) return { ok: true, queued: true };
      if (!SheetsDB.isConfigured()) return { ok: true, queued: true };
      try {
        const res = await origUpsertRows(name, rows);
        await this.clearDirty(name);
        return res;
      } catch (e) {
        // Network/server problem -- the data is safe in IndexedDB, just mark it dirty and
        // retry later (on Sync Now or the browser's 'online' event)
        await this.markDirty(name);
        throw e;
      }
    };

    const origDeleteRow = SheetsDB.deleteRow.bind(SheetsDB);
    SheetsDB.deleteRow = async (name, id) => {
      if (!SheetsDB.isConfigured()) { return { ok: true, queued: false }; }
      if (this.isOfflineMode()) { await this.queueDelete(name, id); return { ok: true, queued: true }; }
      try {
        const res = await origDeleteRow(name, id);
        await this.clearPendingDelete(name, id);
        return res;
      } catch (e) {
        await this.queueDelete(name, id);
        throw e;
      }
    };
  },

  // ---------------------------------------------------------------------------
  // Pending-dirty-table hydration -- called right after a fresh login + loadFromDatabase()
  // (see app.js's loadFromDatabase()): for whichever tables are still "dirty" (not yet sent
  // to the server), the IndexedDB-mirrored (not-yet-synced local) version is used instead of
  // the freshly-loaded server data -- otherwise a refresh would lose pending edits.
  // ---------------------------------------------------------------------------
  async overlayDirtyOntoState(appInstance) {
    const dirty = await this.getDirtyTables();
    if (!dirty.length) return 0;
    let restored = 0;
    for (const table of dirty) {
      const mirrored = await this.getMirrored(table);
      if (Array.isArray(mirrored) && Array.isArray(appInstance.state[table])) {
        appInstance.state[table] = mirrored;
        restored++;
      }
    }
    return restored;
  },

  // ---------------------------------------------------------------------------
  // Sync Now -- (a) flushes pending dirty/deletes to the active endpoint, (b) if both
  // endpoints are configured, runs a full two-database reconcile for Super Admin
  // ---------------------------------------------------------------------------
  async syncNow(appInstance) {
    if (!SheetsDB.isConfigured()) return { ok: false, reason: 'not-configured' };
    const result = { flushed: [], deleted: [], reconciled: [], conflicts: [], skippedReconcile: null };

    // (a) flush pending dirty tables (the wired upsertRows will clearDirty itself on success)
    const dirty = await this.getDirtyTables();
    for (const table of dirty) {
      const rows = (appInstance && Array.isArray(appInstance.state[table])) ? appInstance.state[table] : await this.getMirrored(table);
      if (!rows) continue;
      try { await SheetsDB.upsertRows(table, rows); result.flushed.push(table); } catch (e) { /* stays dirty, will retry later */ }
    }

    // flush pending deletes
    const pendingDeletes = await this.getPendingDeletes();
    for (const d of pendingDeletes) {
      try { await SheetsDB.deleteRow(d.table, d.id); result.deleted.push(d); } catch (e) { /* will retry later */ }
    }

    // (b) dual-endpoint reconcile -- only when both Online+Offline URL/Key are configured,
    // and the current user is Super Admin (see explanation below)
    const onlineCreds = this.getCredentials('online');
    const offlineCreds = this.getCredentials('offline');
    if (onlineCreds.url && onlineCreds.key && offlineCreds.url && offlineCreds.key && window.supabase) {
      if (appInstance && appInstance.role === 'superadmin') {
        try {
          const r = await this._reconcileBothEndpoints(appInstance, onlineCreds, offlineCreds);
          result.reconciled = r.reconciled;
          result.conflicts = r.conflicts;
        } catch (e) { console.warn('Online⇄Offline reconcile failed:', e.message); result.skippedReconcile = e.message; }
      } else {
        result.skippedReconcile = 'Only Super Admin can run a full two-database reconcile';
      }
    }

    await this.setLastSync(new Date().toISOString());
    this._refreshPendingBadge();
    return { ok: true, ...result };
  },

  // Two completely separate Supabase projects (Online cloud + Offline self-hosted) are
  // compared and reconciled directly against each other -- each table's id+updatedAt is
  // fetched lightly from both sides:
  //   - an id present on only one side -> pushed to the other side (new record, no conflict)
  //   - present on both but updatedAt differs -> whichever is newer (higher updatedAt) "wins",
  //     the older one is kept in the conflict log (logConflict) so an admin can review it
  //     later if they want -- no data is ever silently lost.
  // ⚠️ Because of RLS, both endpoints need a valid authenticated session -- the already
  // logged-in session on the currently-active endpoint is used as-is; to sign in temporarily
  // to "the other side", the current Super Admin's username/password is used (this is why the
  // Offline Supabase instance must also have the same Super Admin account -- as instructed in
  // docker/README_SELF_HOST.md). If sign-in fails, reconcile is quietly skipped (throws an
  // error) -- but part (a)'s pending flush has already succeeded by that point, so the core
  // "never lose data" guarantee still holds.
  async _reconcileBothEndpoints(appInstance, onlineCreds, offlineCreds) {
    const activeMode = this.getMode();
    const activeClient = SheetsDB.client; // already logged in, RLS-authorised
    const otherCreds = activeMode === 'online' ? offlineCreds : onlineCreds;
    const otherClient = window.supabase.createClient(otherCreds.url, otherCreds.key, { auth: { persistSession: false, autoRefreshToken: true } });

    const email = `${(appInstance.settings.superAdminUser || appInstance.currentUsername || '').toLowerCase()}@accoflow.internal`;
    const pass = appInstance.settings.superAdminPass || '';
    const { error: signInErr } = await otherClient.auth.signInWithPassword({ email, password: pass });
    if (signInErr) throw new Error('Sign-in to the other endpoint failed (check that both Supabase projects have the same Super Admin account): ' + signInErr.message);

    const onlineClient = activeMode === 'online' ? activeClient : otherClient;
    const offlineClient = activeMode === 'online' ? otherClient : activeClient;

    // --- Tombstones: fetch from both sides first, merge, and push any missing ones across so
    // deletions recorded while one endpoint was unreachable still propagate. This set is then
    // used below to tell "never synced" apart from "deleted on the other side" -- without it,
    // an id missing from one side always looked like a new record and got pushed back (deleted
    // records silently reappearing).
    const [onlineTombRes, offlineTombRes] = await Promise.all([
      onlineClient.from('sync_tombstones').select('tableName, recordId, deletedAt'),
      offlineClient.from('sync_tombstones').select('tableName, recordId, deletedAt')
    ]);
    const tombKey = (t, id) => `${t}::${id}`;
    const onlineTombs = new Map((onlineTombRes.data || []).map(r => [tombKey(r.tableName, r.recordId), r]));
    const offlineTombs = new Map((offlineTombRes.data || []).map(r => [tombKey(r.tableName, r.recordId), r]));
    const tombstoned = new Set([...onlineTombs.keys(), ...offlineTombs.keys()]); // union of both sides
    const onlyOnline = [...onlineTombs.values()].filter(r => !offlineTombs.has(tombKey(r.tableName, r.recordId)));
    const onlyOffline = [...offlineTombs.values()].filter(r => !onlineTombs.has(tombKey(r.tableName, r.recordId)));
    if (onlyOnline.length) await offlineClient.from('sync_tombstones').upsert(onlyOnline, { onConflict: 'tableName,recordId' });
    if (onlyOffline.length) await onlineClient.from('sync_tombstones').upsert(onlyOffline, { onConflict: 'tableName,recordId' });

    const reconciled = [];
    const conflicts = [];
    const tombPurged = [];
    for (const table of ALL_TABLES) {
      const idKey = 'id';
      const [onlineRes, offlineRes] = await Promise.all([
        onlineClient.from(table).select(`${idKey}, updatedAt`),
        offlineClient.from(table).select(`${idKey}, updatedAt`)
      ]);
      if (onlineRes.error || offlineRes.error) continue; // skip this table (maybe not in this version's schema), keep going with the rest

      const onlineMap = new Map((onlineRes.data || []).map(r => [r[idKey], r.updatedAt]));
      const offlineMap = new Map((offlineRes.data || []).map(r => [r[idKey], r.updatedAt]));
      const allIds = new Set([...onlineMap.keys(), ...offlineMap.keys()]);

      const toPushOnline = [], toPushOffline = [];
      for (const id of allIds) {
        const onlineTs = onlineMap.get(id), offlineTs = offlineMap.get(id);
        if (tombstoned.has(tombKey(table, String(id)))) {
          // This id was deliberately deleted -- the usual "missing on one side means new"
          // assumption does not apply here. It is removed from whichever side still has it,
          // aligning both sides to "deleted" -- not pushed back to resurrect it.
          if (onlineTs !== undefined) { await onlineClient.from(table).delete().eq(idKey, id); tombPurged.push({ table, id, side: 'online' }); }
          if (offlineTs !== undefined) { await offlineClient.from(table).delete().eq(idKey, id); tombPurged.push({ table, id, side: 'offline' }); }
          continue;
        }
        if (onlineTs === undefined) { toPushOnline.push(id); continue; }
        if (offlineTs === undefined) { toPushOffline.push(id); continue; }
        if (onlineTs === offlineTs) continue;
        if (new Date(onlineTs) > new Date(offlineTs)) { toPushOffline.push(id); conflicts.push({ table, id, winner: 'online', loserUpdatedAt: offlineTs }); }
        else { toPushOnline.push(id); conflicts.push({ table, id, winner: 'offline', loserUpdatedAt: onlineTs }); }
      }

      if (toPushOnline.length) {
        const { data } = await offlineClient.from(table).select('*').in(idKey, toPushOnline);
        if (data && data.length) {
          await onlineClient.from(table).upsert(data, { onConflict: idKey });
          reconciled.push({ table, direction: 'offline→online', count: data.length });
        }
      }
      if (toPushOffline.length) {
        const { data } = await onlineClient.from(table).select('*').in(idKey, toPushOffline);
        if (data && data.length) {
          await offlineClient.from(table).upsert(data, { onConflict: idKey });
          reconciled.push({ table, direction: 'online→offline', count: data.length });
        }
      }
    }

    for (const c of conflicts) await this.logConflict(c);
    if (tombPurged.length) console.info('Sync: removed', tombPurged.length, 'previously-deleted record(s) instead of restoring them', tombPurged);
    try { await otherClient.auth.signOut(); } catch (e) { /* fine either way, the session is persistSession:false anyway */ }
    return { reconciled, conflicts };
  },

  // ---------------------------------------------------------------------------
  // Init -- called once at the start of app.js's init()
  // ---------------------------------------------------------------------------
  async init() {
    this._wireSheetsDB();
    // Sets SheetsDB's credentials according to the saved mode (if a URL/Key is saved for
    // Offline mode it is applied; otherwise supabase-api.js's default/js/config.js's value
    // is left as-is -- so an existing installation behaves exactly as before even after this
    // file is added)
    if (this.isOfflineMode()) {
      const creds = this.getCredentials('offline');
      if (creds.url && creds.key) SheetsDB.setCredentials(creds.url, creds.key);
    }
    // Automatically tries a sync once when the browser's network returns -- if there is no
    // dirty/pending data, syncNow() itself returns quickly, no extra work happens
    window.addEventListener('online', () => { if (window.app && typeof app.manualSyncNow === 'function') app.manualSyncNow(true); });
  }
};
