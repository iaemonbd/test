-- ============================================================================
-- AccoFlow ERP -- Round 24: security hardening + direct ZKTeco -> Supabase push
-- ============================================================================
-- Run in Supabase Dashboard > SQL Editor AFTER accoflow_combined_schema_v23.sql
-- (or just run accoflow_combined_schema_v24.sql, which already contains v23 + this).
-- Idempotent -- safe to re-run.  Take a backup first.
--
-- What this migration does
--   1. is_active_user() no longer treats the new 'device' role (the ZKTeco bridge's
--      service account) as a normal user -> a bridge account can NOT read business data.
--   2. profiles_guard trigger: a plain 'admin' can no longer promote anybody (or
--      themselves) to superadmin, touch a superadmin's row, or change their own
--      role/permissions/status by writing to `profiles` directly through the API.
--   3. record_buyer_payment / record_supplier_payment: the Round-23 version had silently
--      replaced the has_perm('accounts','write') check (v21) with a hard-coded role list.
--      The permission check is restored, the overpayment guard is kept, and amounts are
--      now handled in whole cents (so 0.017-style fractions can never leave a stuck
--      "due 0.002" behind).
--   4. next_row_id(): collision-free ID allocation for tables whose ids are generated
--      in the browser (Math.max()+1 -> two users saving at the same moment overwrote each
--      other's record).  The app calls this RPC and falls back to the old behaviour if it
--      is not installed yet.
--   5. record_zk_attendance(): the ZKTeco bridge now pushes punches straight to Supabase
--      through this function (matching by "zkUserId"/NID exactly like the old browser
--      sync did).  The Telegram relay is gone.
--   6. Scrubs any Telegram bot token that an older version stored in settings.zktecoConfig.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. 'device' accounts are not "active users" for ordinary read policies
-- ---------------------------------------------------------------------------
create or replace function public.is_active_user()
returns boolean
language sql stable
security definer set search_path = public
as $$
  select exists (
    select 1 from profiles
    where id = auth.uid() and status = 'Active' and role <> 'device'
  );
$$;

-- ---------------------------------------------------------------------------
-- 2. profiles_guard -- stop admin -> superadmin escalation done directly on the table
-- ---------------------------------------------------------------------------
-- auth.uid() is NULL for service_role / SQL-editor / Edge-Function admin-client calls, so
-- the trusted server-side paths are not affected (the Edge Function has its own checks).
create or replace function public.profiles_guard()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_caller text;
begin
  if v_uid is null then
    return coalesce(new, old);
  end if;

  select role into v_caller from profiles where id = v_uid and status = 'Active';

  if v_caller = 'superadmin' then
    return coalesce(new, old);
  end if;

  if v_caller is distinct from 'admin' then
    raise exception 'Not authorised to modify profiles';
  end if;

  -- From here: caller is a plain admin
  if tg_op = 'INSERT' then
    if new.role in ('superadmin', 'device') then
      raise exception 'Only a superadmin can create a % account', new.role;
    end if;
  elsif tg_op = 'UPDATE' then
    if old.role in ('superadmin', 'device') or new.role in ('superadmin', 'device') then
      raise exception 'Only a superadmin can modify or create superadmin/device accounts';
    end if;
    if new.id is distinct from old.id then
      raise exception 'profiles.id cannot be changed';
    end if;
    if old.id = v_uid and (
         new.role is distinct from old.role
      or new.status is distinct from old.status
      or new.permissions is distinct from old.permissions
    ) then
      raise exception 'You cannot change your own role, status or permissions';
    end if;
  elsif tg_op = 'DELETE' then
    if old.role in ('superadmin', 'device') or old.id = v_uid then
      raise exception 'Only a superadmin can delete this account';
    end if;
  end if;

  return coalesce(new, old);
end;
$$;

drop trigger if exists trg_profiles_guard on profiles;
create trigger trg_profiles_guard
  before insert or update or delete on profiles
  for each row execute function public.profiles_guard();

-- ---------------------------------------------------------------------------
-- 3. Payment RPCs -- permission check restored (has_perm), whole-cent arithmetic
-- ---------------------------------------------------------------------------
create or replace function public.record_buyer_payment(
  p_pi_no text, p_amount numeric, p_method text, p_check_number text,
  p_remarks text, p_receipt_image text, p_date text
) returns json
language plpgsql security definer set search_path = public
as $$
declare
  v_row "accBuyer"%rowtype;
  v_total numeric; v_received numeric; v_amount numeric;
  v_new_received numeric; v_new_due numeric;
  v_new_status text; v_hist_id bigint; v_username text; v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or not (v_role = 'superadmin' or public.has_perm('accounts', 'write')) then
    raise exception 'Not authorised: you do not have permission to record payments (Accounts module)';
  end if;

  -- Money is handled in whole cents: anything finer than 0.01 is rounded, never carried
  v_amount := round(coalesce(p_amount, 0), 2);
  if v_amount <= 0 then raise exception 'Amount must be at least 0.01'; end if;
  if p_pi_no is null or length(trim(p_pi_no)) = 0 then raise exception 'PI No is required'; end if;

  select * into v_row from "accBuyer" where "piNo" = p_pi_no for update;
  if not found then raise exception 'PI No not found: %', p_pi_no; end if;

  v_total    := round(coalesce(nullif(regexp_replace(coalesce(v_row.total,    '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric, 2);
  v_received := round(coalesce(nullif(regexp_replace(coalesce(v_row.received, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric, 2);

  if v_amount > (v_total - v_received) then
    raise exception 'Payment amount ($%) exceeds the outstanding due ($%) for %',
      to_char(v_amount, 'FM999,999,999,990.00'), to_char(v_total - v_received, 'FM999,999,999,990.00'), p_pi_no;
  end if;

  v_new_received := v_received + v_amount;
  v_new_due      := greatest(v_total - v_new_received, 0);
  v_new_status   := case when v_new_due <= 0 then 'Paid' else 'Due' end;

  update "accBuyer" set
    received = '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    due      = '$' || to_char(v_new_due,      'FM999,999,999,990.00'),
    status   = v_new_status, lc = p_method
  where "piNo" = p_pi_no;

  insert into "buyerPaymentHistory" ("piNo", "buyer", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_pi_no, v_row.buyer, to_char(v_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;

  insert into "auditLog" ("timestamp", username, role, action, module, "recordId", "recordLabel")
  values (
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'buyerPaymentHistory', v_hist_id::text,
    p_pi_no || ' -- $' || to_char(v_amount, 'FM999999999990.00')
  );

  return json_build_object(
    'ok', true, 'historyId', v_hist_id,
    'received', '$' || to_char(v_new_received, 'FM999,999,999,990.00'),
    'due',      '$' || to_char(v_new_due,      'FM999,999,999,990.00'),
    'status', v_new_status
  );
end;
$$;

create or replace function public.record_supplier_payment(
  p_order_no text, p_amount numeric, p_method text, p_check_number text,
  p_remarks text, p_receipt_image text, p_date text
) returns json
language plpgsql security definer set search_path = public
as $$
declare
  v_row "accSupplier"%rowtype;
  v_total numeric; v_paid numeric; v_amount numeric;
  v_new_paid numeric; v_new_due numeric;
  v_hist_id bigint; v_username text; v_role text;
begin
  select username, role into v_username, v_role from profiles where id = auth.uid() and status = 'Active';
  if v_role is null or not (v_role = 'superadmin' or public.has_perm('accounts', 'write')) then
    raise exception 'Not authorised: you do not have permission to record payments (Accounts module)';
  end if;

  v_amount := round(coalesce(p_amount, 0), 2);
  if v_amount <= 0 then raise exception 'Amount must be at least 0.01'; end if;
  if p_order_no is null or length(trim(p_order_no)) = 0 then raise exception 'Order No is required'; end if;

  select * into v_row from "accSupplier" where "orderNo" = p_order_no for update;
  if not found then raise exception 'Order No not found: %', p_order_no; end if;

  v_total := round(coalesce(nullif(regexp_replace(coalesce(v_row.total, '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric, 2);
  v_paid  := round(coalesce(nullif(regexp_replace(coalesce(v_row.paid,  '0'), '[^0-9.\-]', '', 'g'), ''), '0')::numeric, 2);

  if v_amount > (v_total - v_paid) then
    raise exception 'Payment amount ($%) exceeds the outstanding due ($%) for %',
      to_char(v_amount, 'FM999,999,999,990.00'), to_char(v_total - v_paid, 'FM999,999,999,990.00'), p_order_no;
  end if;

  v_new_paid := v_paid + v_amount;
  v_new_due  := greatest(v_total - v_new_paid, 0);

  update "accSupplier" set
    paid = '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    due  = '$' || to_char(v_new_due,  'FM999,999,999,990.00')
  where "orderNo" = p_order_no;

  insert into "supplierPaymentHistory" ("orderNo", "supplier", "amount", "method", "checkNumber", "date", "remarks", "receiptImage")
  values (p_order_no, v_row.supplier, to_char(v_amount, 'FM999999999990.00'), p_method, p_check_number, p_date, p_remarks, p_receipt_image)
  returning id into v_hist_id;

  insert into "auditLog" ("timestamp", username, role, action, module, "recordId", "recordLabel")
  values (
    to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
    v_username, v_role, 'Create', 'supplierPaymentHistory', v_hist_id::text,
    p_order_no || ' -- $' || to_char(v_amount, 'FM999999999990.00')
  );

  return json_build_object(
    'ok', true, 'historyId', v_hist_id,
    'paid', '$' || to_char(v_new_paid, 'FM999,999,999,990.00'),
    'due',  '$' || to_char(v_new_due,  'FM999,999,999,990.00')
  );
end;
$$;

grant execute on function public.record_buyer_payment(text, numeric, text, text, text, text, text) to authenticated;
grant execute on function public.record_supplier_payment(text, numeric, text, text, text, text, text) to authenticated;

-- ---------------------------------------------------------------------------
-- 4. Collision-free ID allocation (replaces browser-side Math.max()+1 race)
-- ---------------------------------------------------------------------------
create table if not exists id_counters (
  table_name text primary key,
  last_id    bigint not null default 0
);
alter table id_counters enable row level security;   -- no policies: only the functions below touch it
revoke all on id_counters from anon, authenticated;

-- internal allocator (no permission check) -- used by next_row_id() and record_zk_attendance()
create or replace function public._alloc_row_id(p_table text)
returns bigint
language plpgsql security definer set search_path = public
as $$
declare
  v_max bigint;
  v_id  bigint;
begin
  if p_table not in (
    'piList','masterData','receivedGoods','supplierOrders','deliveryPlan','deliveryExec','deliveryHist','qcList',
    'accBuyer','accSupplier','buyerPaymentHistory','supplierPaymentHistory','expenseList','vouchers',
    'hrEmployees','hrAttendance','hrLeaves','hrSalary','hrSignatures','hrDepartments','hrApprovals',
    'users','buyers','suppliers'
  ) then
    raise exception 'next_row_id: table not allowed: %', p_table;
  end if;

  execute format('select coalesce(max(id), 0) from %I', p_table) into v_max;

  insert into id_counters (table_name, last_id) values (p_table, v_max + 1)
  on conflict (table_name) do update
    set last_id = greatest(id_counters.last_id, v_max) + 1
  returning last_id into v_id;

  return v_id;
end;
$$;
revoke all on function public._alloc_row_id(text) from public, anon, authenticated;

create or replace function public.next_row_id(p_table text)
returns bigint
language plpgsql security definer set search_path = public
as $$
begin
  if not public.is_active_user() then
    raise exception 'Not authorised';
  end if;
  return public._alloc_row_id(p_table);
end;
$$;
grant execute on function public.next_row_id(text) to authenticated;

-- ---------------------------------------------------------------------------
-- 5. ZKTeco bridge -> Supabase (direct push, no Telegram)
-- ---------------------------------------------------------------------------
-- Permission: has_perm('zkbridge','push') -- true for superadmin, or for the dedicated
-- 'device' account created by scripts/create-bridge-user.mjs (permissions {"zkbridge":{"push":true}}).
-- That account cannot read any other table (see is_active_user() above).
--
-- p_punches: [{ "userId": "12", "time": "08:57", "type": "in"|"out", "timestamp": "<ISO>" }, ...]
--            (`time` = HH:MM in the bridge PC's local time; falls back to timestamp in Asia/Dhaka)
create or replace function public.record_zk_attendance(p_date text, p_punches jsonb)
returns json
language plpgsql security definer set search_path = public
as $$
declare
  v_open text;
  v_p jsonb;
  v_uid text; v_time text; v_type text;
  v_emp record;
  v_n int;
  v_row "hrAttendance"%rowtype;
  v_matched int := 0; v_added int := 0; v_updated int := 0;
  v_unmatched text[] := '{}'; v_conflicts text[] := '{}';
begin
  if not public.has_perm('zkbridge', 'push') then
    raise exception 'Not authorised: this account may not push ZKTeco attendance';
  end if;
  if p_date is null or p_date !~ '^\d{4}-\d{2}-\d{2}$' then
    raise exception 'p_date must be YYYY-MM-DD';
  end if;
  if p_punches is null or jsonb_typeof(p_punches) <> 'array' then
    raise exception 'p_punches must be a JSON array';
  end if;
  if jsonb_array_length(p_punches) > 5000 then
    raise exception 'Too many punches in one call (max 5000)';
  end if;

  perform pg_advisory_xact_lock(hashtext('record_zk_attendance'));

  select coalesce(nullif(value, ''), '09:00') into v_open from settings where key = 'officeOpenTime';
  v_open := coalesce(v_open, '09:00');

  for v_p in select * from jsonb_array_elements(p_punches) loop
    v_uid  := trim(coalesce(v_p->>'userId', ''));
    v_type := coalesce(v_p->>'type', 'in');
    v_time := nullif(trim(coalesce(v_p->>'time', '')), '');
    if v_time is null and nullif(v_p->>'timestamp', '') is not null then
      v_time := to_char((v_p->>'timestamp')::timestamptz at time zone 'Asia/Dhaka', 'HH24:MI');
    end if;
    if v_uid = '' or v_time is null or v_time !~ '^\d{2}:\d{2}$' then continue; end if;

    -- employee match: zkUserId first, NID as fallback (same rule the browser used)
    select count(*) into v_n from "hrEmployees"
      where coalesce("deletedAt", '') = ''
        and (trim(coalesce("zkUserId", '')) = v_uid or trim(coalesce(nid, '')) = v_uid);
    if v_n = 0 then
      if not (v_uid = any(v_unmatched)) then v_unmatched := v_unmatched || v_uid; end if;
      continue;
    elsif v_n > 1 then
      if not (v_uid = any(v_conflicts)) then v_conflicts := v_conflicts || v_uid; end if;
      continue;
    end if;
    select * into v_emp from "hrEmployees"
      where coalesce("deletedAt", '') = ''
        and (trim(coalesce("zkUserId", '')) = v_uid or trim(coalesce(nid, '')) = v_uid);
    v_matched := v_matched + 1;

    select * into v_row from "hrAttendance"
      where date = p_date and employee = v_emp.name and coalesce("deletedAt", '') = ''
      order by id limit 1;
    if not found then
      insert into "hrAttendance" (id, date, employee, "checkIn", "checkOut", status, "otHours")
      values (public._alloc_row_id('hrAttendance'), p_date, v_emp.name, '', '', 'Present', '0')
      returning * into v_row;
      v_added := v_added + 1;
    end if;

    if v_type = 'out' then
      if coalesce(v_row."checkOut", '') = '' or v_time > v_row."checkOut" then
        update "hrAttendance" set "checkOut" = v_time where id = v_row.id;
        v_updated := v_updated + 1;
      end if;
    else
      if coalesce(v_row."checkIn", '') = '' or v_time < v_row."checkIn" then
        update "hrAttendance"
          set "checkIn" = v_time, status = case when v_time > v_open then 'Late' else 'Present' end
          where id = v_row.id;
        v_updated := v_updated + 1;
      end if;
    end if;
  end loop;

  insert into settings (key, value) values (
    'zkBridgeLastPush',
    json_build_object('at', to_char(now() at time zone 'Asia/Dhaka', 'YYYY-MM-DD"T"HH24:MI:SS') || '+06:00',
                      'date', p_date, 'matched', v_matched, 'added', v_added,
                      'unmatched', v_unmatched, 'conflicts', v_conflicts)::text
  ) on conflict (key) do update set value = excluded.value;

  return json_build_object('ok', true, 'matched', v_matched, 'added', v_added, 'updated', v_updated,
                           'unmatched', v_unmatched, 'conflicts', v_conflicts);
end;
$$;
grant execute on function public.record_zk_attendance(text, jsonb) to authenticated;

-- ---------------------------------------------------------------------------
-- 6. Remove any Telegram secrets that older versions saved into settings
-- ---------------------------------------------------------------------------
do $$
begin
  update settings
     set value = ((value::jsonb) - 'telegramBotToken' - 'telegramChatId')::text
   where key = 'zktecoConfig';
exception when others then
  null;  -- value was not valid JSON; nothing to scrub
end $$;
