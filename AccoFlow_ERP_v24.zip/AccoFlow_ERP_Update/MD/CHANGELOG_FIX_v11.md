# AccoFlow ERP — HR Settings কনসোলিডেশন + অ্যাপ্রুভাল ওয়ার্কফ্লো + ক্রিটিক্যাল DB বাগ ফিক্স (রাউন্ড ১১)

তারিখ: ৩১ জুলাই, ২০২৬

---

## 🔴 ক্রিটিক্যাল ডাটাবেস বাগ ফিক্স (ডেলিভারির আগে যাচাই করার সময় পাওয়া)

ইউজারের অনুরোধ অনুযায়ী ডেলিভারির আগে সম্পূর্ণ ডাটাবেস-লজিক অডিট করার সময় **দুইটা প্রি-এক্সিস্টিং বাগ**
পাওয়া গেছে যেগুলো আগের রাউন্ড থেকেই ছিল (HR Module উন্নতি রাউন্ডে):

- **`hrSalary.month`** — Salary Month ফিল্ড app.js-এ যোগ করা হয়েছিল, কিন্তু schema.sql-এ কলাম
  যোগ করা হয়নি।
- **`hrLeaves.days`** — মোট ছুটির দিন ফিল্ড app.js-এ যোগ করা হয়েছিল, কিন্তু schema.sql-এ কলাম
  যোগ করা হয়নি।

**প্রভাব:** Supabase-এর PostgREST API-তে কোনো রেকর্ডে এমন ফিল্ড পাঠানো হলে যেটার জন্য টেবিলে কোনো
কলাম নেই, পুরো Save রিকোয়েস্ট **এরর দিয়ে ব্যর্থ** হয় (silently ড্রপ হয় না)। অর্থাৎ Process Salary বা
Leave of Absence সেভ করলে UI-তে হয়তো সাথে সাথে দেখা যেত (লোকাল state আপডেট হয়ে গিয়েছিল), কিন্তু
আসলে ডাটাবেসে সংরক্ষিত হতো না — পেজ রিফ্রেশ দিলে ডেটা হারিয়ে যেত (persistSheet() এরর ধরে "ক্লাউডে
সেভ হয়নি" নোটিফিকেশন দেখাতো, কিন্তু সহজেই খেয়াল না করলে মিস হয়ে যাওয়ার সুযোগ ছিল)।

**সমাধান:** `alter table "hrSalary" add column if not exists month text;` ও
`alter table "hrLeaves" add column if not exists days text;` যোগ করা হয়েছে।

**যাচাই:** এই রাউন্ডে যোগ হওয়া প্রতিটা নতুন ফিল্ড/টেবিলের জন্য একটা automated cross-check script
লেখা হয়েছে যা app.js-এর প্রতিটা `.push({...})`/অবজেক্ট-লিটারেল ফিল্ড schema.sql-এর কলামের সাথে
মিলিয়ে দেখে — এখন সবকিছু ১০০% সিঙ্ক্রোনাইজড।

---

## ✅ HR Settings — নতুন কেন্দ্রীভূত ব্যবস্থাপনা প্যানেল

HR Module-এর উপরের কর্নারে "+Add Employee" বাটনের জায়গায় এখন **"HR Settings"** বাটন (⚙️ আইকন,
Pending Approval থাকলে সংখ্যা-ব্যাজ দেখায়)। এর ভেতরে ৫টা ট্যাব:

### ১. Employees
- Add/Edit/Activate-Deactivate/Delete — **শুধুমাত্র এখান থেকেই** করা যাবে (ইউজারের অনুরোধ অনুযায়ী)।
  মূল HR Module-এর Employees ট্যাব এখন শুধু দেখার জন্য (Actions কলাম সরিয়ে ফেলা হয়েছে)।
- Add/Edit Employee ফর্মে দুটো নতুন ফিল্ড: **Department** (ড্রপডাউন) ও **Salary Account Number**।

### ২. Signatures
- Chairman ও Managing Director সিগনেচার (আগের মতোই একটাই স্লট) HR Settings-এ স্থানান্তরিত।
- **নতুন: Merchandiser Signatures — একাধিক মার্চেন্ডাইজার যোগ করা যায়** (নাম + Designation +
  সিগনেচার ছবি)। আগে `settings.signMerchandiser`-এ একজনের সিগনেচারই রাখা যেত।
- **Supplier Order Sheet-এ একটা ড্রপডাউন** যোগ করা হয়েছে — প্রতিটা অর্ডারের জন্য কোন মার্চেন্ডাইজার
  সই করছেন তা বেছে নেওয়া যায়, এবং সিলেকশনটা সেই অর্ডার রেকর্ডেই সংরক্ষিত থাকে (আবার খুললে একই
  মার্চেন্ডাইজারের সিগনেচার দেখাবে)। ভবিষ্যতে অন্য কোনো ডকুমেন্টেও merchandiser সিগনেচার লাগলে শুধু
  `class="merch-signature-select"` দেওয়া একটা `<select>` বসালেই যথেষ্ট — কোনো নতুন কোড লাগবে না।

### ৩. Departments
- নতুন Department তৈরি (ডুপ্লিকেট নাম case-insensitive ভাবে আটকানো হয়), Delete করা যায়
  (Super Admin only, বিদ্যমান নিয়ম অনুযায়ী)।
- প্রতিটা Department-এর জন্য ড্রপডাউন থেকে **Department Head** সিলেক্ট করা যায় (Active কর্মচারীদের
  মধ্য থেকে)।

### ৪. OT Rate — 💡 নতুন ডিজাইন (অনুরোধ অনুযায়ী আমার সাজেশন)
আগে প্রতিবার Process Salary করার সময় OT Rate (৳/ঘণ্টা) হাতে টাইপ করতে হতো — প্রতি কর্মচারীর জন্য
আলাদা, অসামঞ্জস্যপূর্ণ, ভুল হওয়ার সুযোগ বেশি। এখন HR Settings-এ দুটো মাত্র সেটিং:

- **Standard Working Hours (মাসিক)** — ডিফল্ট **২০৮ ঘণ্টা** (২৬ কর্মদিবস × ৮ ঘণ্টা)
- **OT Multiplier (%)** — ডিফল্ট **২০০%** (বাংলাদেশ Labour Act ২০০৬-এর প্রচলিত মান)

তারপর প্রতিটা কর্মচারীর OT Rate স্বয়ংক্রিয়ভাবে বের হয়:
```
OT Rate (৳/ঘণ্টা) = (Basic Salary ÷ Standard Working Hours) × (OT Multiplier ÷ 100)
```
বেশি বেতনের কর্মচারীর OT Rate-ও ন্যায্যভাবে বেশি হবে, প্রতি মাসে হাতে টাইপ করার দরকার নেই — Process
Salary মডালে এমপ্লয়ি সিলেক্ট করলেই এই রেট অটো-ফিল হয়ে যায় (তবে ব্যতিক্রমী ক্ষেত্রে ম্যানুয়ালি ওভাররাইড
করার সুযোগও থাকছে)।

### ৫. Pending Approvals — নিচে বিস্তারিত

---

## ✅ HR Settings অ্যাপ্রুভাল ওয়ার্কফ্লো

> *"HR settings' Any changes here will require review by the admin or super admin. It will be
> applied once the admin or super admin confirms."*

HR Module-এ শুধু **'admin'** ও **'superadmin'** রোল প্রবেশ করতে পারে। এখন থেকে:

- **'admin' রোল** HR Settings-এ কোনো পরিবর্তন করলে (Employee Add/Edit/Activate-Deactivate,
  নতুন Signature, নতুন Department, Department Head পরিবর্তন, OT Rate সেটিংস) তা সরাসরি প্রয়োগ না
  হয়ে **"Pending Approval"**-এ জমা থাকে।
- **'superadmin'** নিজে HR Settings-এ পরিবর্তন করলে **সাথে সাথেই প্রয়োগ হয়** (নিজের অনুমোদনের জন্য
  নিজেকে অপেক্ষা করানোর দরকার নেই)।
- Super Admin "Pending Approvals" ট্যাব থেকে প্রতিটা অনুরোধ **Approve** বা **Reject** করতে পারেন।
  Approve করলে ঠিক সেই পরিবর্তনটাই প্রয়োগ হয় যেটা admin প্রস্তাব করেছিলেন (একই অন্তর্নিহিত ফাংশন
  পুনর্ব্যবহার করে, তাই দুই পথের ফলাফল সবসময় অভিন্ন)।
- **Delete অ্যাকশনে এই অ্যাপ্রুভাল-লেয়ারের দরকার নেই** — Delete আগে থেকেই শুধু Super Admin-এর
  এখতিয়ারে (`confirmDelete()`-এ `role !== 'superadmin'` চেক আগে থেকেই ছিল), তাই এখানে দ্বিতীয়
  স্তরের প্রয়োজন নেই।

সব Approve/Reject অ্যাকশন Audit Log-এ লগ হয়, এবং কে/কখন রিভিউ করেছেন তা Pending Approvals
তালিকাতেই দেখা যায়।

---

## 🐛 অন্যান্য বাগ ফিক্স (Image 1 ও Image 2 রেফারেন্স থেকে)

### Add Received Goods — BUYER অটোফিল না হওয়া
`saveSupplierOrder()`-এ Buyer ফিল্ড সবসময় খালি হার্ডকোড করা ছিল। এখন সংশ্লিষ্ট PI No দিয়ে piList
থেকে প্রকৃত Buyer-এর নাম বসানো হয় + পুরনো রেকর্ডের জন্য অটো-ব্যাকফিল।

### Order No — সার্চেবল ইনপুট
৫০০+ Supplier Order থাকলেও `<input list>` + `<datalist>` দিয়ে টাইপ করে দ্রুত খোঁজা যায়
(আগে লম্বা `<select>` স্ক্রল করতে হতো)।

### থিম সিস্টেম সম্পূর্ণ রিডিজাইন
মূল কারণ: `.btn` এর একটা CSS রুল `.btn-accent`-কে ওভাররাইড করে Light Mode-এ পুরো অ্যাপ জুড়ে সব
প্রাইমারি বাটন (Create New PI, Quick Action, Save ইত্যাদি) অদৃশ্য করে দিচ্ছিল। এখন ৪টা সম্পূর্ণ,
টেস্ট করা থিম: **Classic Glass** (অপরিবর্তিত ডিফল্ট), **Clean Light**, **Enterprise Blue**,
**Warm Earthy** — প্রতিটাতে কনট্রাস্ট বাগ স্থায়ীভাবে ঠিক করা (`.btn:not(.btn-accent)`)।

---

## 🧪 ডেলিভারির আগে যা যাচাই করা হয়েছে

- `node --check` সব JS ফাইলে পাস (app.js, config.js, default-data.js, supabase-api.js, sw.js)
- `manifest.json` valid JSON
- CSS ব্রেস ব্যালেন্স (642/642), HTML div ব্যালেন্স (906/906)
- **কোনো ডুপ্লিকেট HTML element ID নেই** (পুরো index.html স্ক্যান করে যাচাই)
- **HTML-এ ব্যবহৃত সব ১১৪টা `app.*()` ফাংশন কল app.js-এ সংজ্ঞায়িত আছে কিনা** — automated
  cross-check script দিয়ে যাচাই (০টা মিসিং)
- **নতুন HR Settings-এর সব `getElementById()` কল সংশ্লিষ্ট HTML element-এর সাথে মেলে কিনা** —
  automated cross-check (০টা মিসিং)
- **app.js-এর প্রতিটা নতুন ফিল্ড schema.sql-এ কলাম হিসেবে আছে কিনা** — automated cross-check
  script (৯টা চেক পয়েন্ট, সব পাস) — এভাবেই উপরের দুইটা ক্রিটিক্যাল বাগ ধরা পড়েছে
- standalone Node টেস্ট স্ক্রিপ্টে (২১টা assertion): OT Rate ক্যালকুলেশন, Approval Workflow-এর
  role-based সিদ্ধান্ত লজিক, Duplicate Department প্রতিরোধ, Signature ড্রপডাউন ম্যাচিং — সব পাস
- `.admin-only`/`.superadmin-only` পারমিশন সিস্টেম নতুন HR Settings মডালেও সঠিকভাবে কাজ করে তা
  নিশ্চিত করা হয়েছে (গ্লোবাল `document.querySelectorAll` দিয়ে কাজ করে বলে মডাল বন্ধ থাকা অবস্থাতেও
  সঠিকভাবে প্রয়োগ হয়)
- সম্পূর্ণ diff রিভিউ করে নিশ্চিত হওয়া গেছে `manifest.json`, `sw.js`, `js/config.js` অপরিবর্তিত আছে —
  শুধু প্রয়োজনীয় ফাইল স্পর্শ করা হয়েছে

## ⏭️ এখনো বাকি (পরের রাউন্ডে)

- **Data Safety → "Complete Order List"** আর্কাইভাল ফিচার (PI + সংশ্লিষ্ট সব ডেটা বায়ার/সাপ্লায়ার
  পেমেন্ট কমপ্লিট হওয়ার পর এক জায়গায় সরিয়ে আনা, বিস্তারিত activity history সহ)
- Image 3-এর রহস্যময় সাদা বাক্স — কোডে সরাসরি কোনো কারণ শনাক্ত করা যায়নি; এখনো দেখা গেলে
  Inspect Element করে ক্লাস/আইডি জানালে খুঁজে বের করা যাবে
