# AccoFlow ERP — QC Inspection Report রিডিজাইন (রাউন্ড ৪)

তারিখ: ২৬ জুলাই, ২০২৬
স্কোপ: **QC Center → Add QC Report** — ইউজার প্রদত্ত রেফারেন্স ডিজাইন অনুযায়ী সম্পূর্ণ নতুন লেআউট

---

## 🎨 নতুন কী পরিবর্তন হলো

**আগে:** প্রতিটি সারিতে (row) নিজস্ব Date, Challan No, Order No, Item Code, Supplier, Buyer — সব আলাদাভাবে টাইপ করতে হতো। একই Challan-এর একাধিক আইটেম QC করতে গেলে বারবার একই তথ্য পুনরায় লিখতে হতো।

**এখন:** রেফারেন্স ডিজাইনের মতোই —
- উপরে একটা কোম্পানির নাম ব্যানার (হালকা নীল) + "QC INSPECTION REPORT" সাবটাইটেল (ধূসর ব্যানার) — Settings-এ সেভ করা company name থেকে ডাইনামিকভাবে বসে।
- **ORDER NO, CHALLAN NO, SUPPLIER, BUYER, DATE** — এখন একবারই উপরে হেডারে দেওয়া হয় (পুরো রিপোর্টের জন্য প্রযোজ্য)।
- নিচের টেবিলে শুধু **PI, STYLE NO, ITEM CODE, QUANTITY, QC QTY, REJECT QTY, REJECT %, RESULT, ACTION** — একই Challan/Order-এর অধীনে একাধিক PI/Style/Item "Add Row" দিয়ে যোগ করা যায়।
- **Challan No দিলেই এখন আরও স্মার্ট অটো-ফিল হয়:** হেডারের Order No/Buyer/Supplier ভরে যায়, এবং Received Goods-এ থাকা সেই চালানের প্রতিটি আইটেম (PI, Style No, Item Code, Quantity) দিয়ে আলাদা আলাদা সারি স্বয়ংক্রিয়ভাবে তৈরি হয়ে যায় — ইউজার শুধু QC Qty/Reject Qty দিলেই কাজ শেষ।
- Item Code বাছাই করলে Master Data থেকে Style No-ও অটো-ফিল হয় (খালি থাকলে)।

## 🗂️ কী কী ফাইলে পরিবর্তন হয়েছে

- **`index.html`** — `qc-modal`-এর পুরো HTML নতুন ডিজাইন অনুযায়ী পুনর্গঠন করা হয়েছে।
- **`css/styles.css`** — নতুন `.qc-doc-*` ক্লাসসমূহ যোগ করা হয়েছে (banner, subbanner, info fields, item table), এবং প্রিন্ট/PDF-এর জন্য A4-রিফ্লো রুলও আপডেট করা হয়েছে।
- **`js/app.js`** — `addQCRow`, `autoFillQCFromChallan`, `saveQC`, `viewQCReport`, `exportQCSheetToExcel`, `exportQCToExcel` রিরাইট করা হয়েছে; নতুন ফাংশন `refreshQCForm()`, `autoFillQCItemFromCode()`, `autoFillQCHeaderFromOrder()` যোগ করা হয়েছে।
- **`schema.sql`** — `qcList` টেবিলে নতুন দুটো কলাম (`piNo`, `styleNo`) যোগ করার মাইগ্রেশন লাইন যোগ করা হয়েছে। **⚠️ Supabase ব্যবহারকারীদের জন্য: নিচের ২ লাইন আপনার Supabase SQL Editor-এ একবার রান করে নিন যাতে নতুন কলাম দুটো ডাটাবেসে যোগ হয়:**
  ```sql
  alter table "qcList" add column if not exists "piNo" text;
  alter table "qcList" add column if not exists "styleNo" text;
  ```
  (এই মাইগ্রেশন না চালালে নতুন QC রিপোর্ট Save করার সময় Supabase-সংযুক্ত ইনস্টলেশনে এরর আসতে পারে — লোকাল/ডেমো মোডে কোনো প্রভাব নেই)

## ✅ পেছনের সামঞ্জস্য (Backward Compatibility)

- পুরনো QC রিপোর্ট ডেটা (আগে সেভ করা রেকর্ড) অক্ষুণ্ণ আছে — নতুন `piNo`/`styleNo` ফিল্ড শুধু খালি দেখাবে, ডেটা হারায়নি।
- QC Center-এর মূল লিস্ট টেবিল (Date/Challan/Order/Item Code/QC Qty/Reject Qty/Reject%/Result/Actions), Delete, Approve-জাতীয় অন্য কোনো ফিচারে হাত দেওয়া হয়নি।
- প্রতিটি পরিবর্তনের পর `node --check js/app.js` দিয়ে সিনট্যাক্স ভ্যারিফাই করা হয়েছে।
