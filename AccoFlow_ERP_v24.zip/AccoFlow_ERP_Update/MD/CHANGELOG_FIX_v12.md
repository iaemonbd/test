# AccoFlow ERP — Complete Order List + Accent Colors পুনরুদ্ধার + Reports রিলোকেশন (রাউন্ড ১২)

তারিখ: ০১ আগস্ট, ২০২৬

এই রাউন্ডে আপনার সর্বশেষ তিনটা অনুরোধই সম্পন্ন করা হয়েছে, ঠিক আপনার নির্দেশ করা অগ্রাধিকার
অনুযায়ী: প্রথমে Complete Order List, তারপর Accent Color + টেক্সচার পুনরুদ্ধার, তারপর Reports & BI
রিলোকেশন।

---

## ✅ ১. Data Safety → Complete Order List (আর্কাইভাল ফিচার)

**কীভাবে কাজ করে:**
- একটা PI তখনই "আর্কাইভের যোগ্য" হিসেবে সাজেস্ট হয় যখন: (ক) Delivery সম্পূর্ণ (`computePIStatus`
  অনুযায়ী "Delivery Complete"), (খ) Buyer Ledger-এ Due = ৳০, (গ) সেই PI-সংশ্লিষ্ট **সব** Supplier
  Order-এর Ledger-এ Due = ৳০।
- Data Safety-তে নতুন **"Complete Order List"** ট্যাব — উপরে "আর্কাইভের জন্য প্রস্তুত PI" সাজেশন
  তালিকা (এক ক্লিকে Archive করা যায়), নিচে ইতিমধ্যে আর্কাইভ করা PI-গুলোর তালিকা।
- Archive করলে সেই PI ও তার সংশ্লিষ্ট সব রেকর্ড (Received Goods, Supplier Order, Delivery
  Challan, QC Report, Buyer/Supplier Ledger) **সাধারণ কার্যক্রমের তালিকা থেকে সরে যায়** — কিন্তু
  **ডেটা ডিলিট/মুভ হয় না**, শুধু একটা `archived` ফ্ল্যাগ ব্যবহার করে ফিল্টার করা হয় (সম্পূর্ণ
  রিভার্সিবল — Unarchive বাটনে এক ক্লিকেই ফেরত আনা যায়)।
- যেকোনো আর্কাইভ করা PI-তে ক্লিক করলে একটা বিস্তারিত ইতিহাস মডাল খোলে — PI তথ্য, সব Supplier
  Order, Received Goods (তারিখ+পরিমাণ সহ), QC রিপোর্ট, Delivery Challan, এবং Buyer ও Supplier
  Ledger-এর পেমেন্ট হিস্ট্রি — সব একসাথে।
- Buyer/Supplier Ledger-এর "Total Invoiced/Received/Paid/Due" সারসংক্ষেপও আর্কাইভ করা PI বাদ
  দিয়ে হিসাব হয় (শুধু বর্তমানে সক্রিয় ব্যবসার প্রকৃত চিত্র দেখাতে)।

**যাচাই:** ১৫টা assertion দিয়ে আর্কাইভ-যোগ্যতা লজিক (ডেলিভারি/পেমেন্ট শর্ত, একাধিক Supplier Order,
ফিল্টারিং) টেস্ট করা হয়েছে — সব পাস।

## ✅ ২. Accent Color (১০টা) পুনরুদ্ধার + প্রতি-কালার টেক্সচার প্যাটার্ন

আপনার অনুরোধ অনুযায়ী **Ocean, Emerald, Sunset, Royal, Ruby, Midnight, RoseGold, Forest, Crimson,
Arctic** — এই ১০টা Accent Color আবার যোগ করা হয়েছে, তবে **নতুন করে ডিজাইন করে**, যাতে আগের কনট্রাস্ট
বাগ ফিরে না আসে:

- **App Theme** (Classic Glass/Clean Light/Enterprise Blue/Warm Earthy) ব্যাকগ্রাউন্ড/টেক্সট রঙ
  ঠিক করে, আর **Accent Color** শুধু বাটন/হাইলাইট/অ্যাক্টিভ ন্যাভ রঙ বদলায় — সম্পূর্ণ আলাদা,
  স্বতন্ত্র দুইটা অক্ষ। তাই **যেকোনো App Theme-এর সাথে যেকোনো Accent Color** নিরাপদে মেশানো যায়
  (Accent Color কখনো ব্যাকগ্রাউন্ড/টেক্সট রঙে হাত দেয় না)।
- **Style Pack এখন স্থায়ীভাবে শুধু Classic Glass** — Flat Corporate/Neon Cyber/Neumorph/Retro
  Terminal ফিরিয়ে আনা হয়নি (আপনার নির্দেশ অনুযায়ী)।
- প্রতিটা Accent Color-এর জন্য আলাদা widget card টেক্সচার প্যাটার্ন — Ocean→Ripples,
  Emerald/Forest→Topographic, Sunset/RoseGold→Paisley, Royal→Hexagonal Art-Deco,
  Midnight→Hexagram Stars, Ruby/Crimson→Calligraphic, Arctic→Chevron — কিন্তু **শুধু Classic
  Glass থিমে** (নতুন তিনটা হালকা থিমের "ক্লিন" লুক অক্ষুণ্ণ রাখতে, ইচ্ছাকৃতভাবে)।
- Header পপওভার ও Settings পেজ — দুই জায়গাতেই Accent Color পিকার যোগ করা হয়েছে।
- প্রতি-ইউজার সংরক্ষণ আগের `theme` কলামই পুনর্ব্যবহার করে (নতুন কোনো ডেটাবেজ মাইগ্রেশন লাগেনি)।

## ✅ ৩. Reports & BI → Data Safety-তে স্থানান্তর

- Sidebar থেকে "Reports & BI" সরিয়ে ফেলা হয়েছে; সব ৭টা রিপোর্ট কার্ড এখন **Data Safety > Backup
  & Excel Export** ট্যাবে (ডাটাবেজ ব্যাকআপ/এক্সপোর্ট সেকশনের ঠিক উপরে)।
- **⚠️ গুরুত্বপূর্ণ পারমিশন ফিক্স:** Data Safety আগে শুধু Admin/Super Admin-এর জন্য ছিল, কিন্তু
  Accountant ও Merchandiser রোলের আগে থেকেই Reports অ্যাক্সেস ছিল। সরাসরি Reports সরিয়ে ফেললে
  এই দুই রোল Reports হারিয়ে ফেলতেন — তাই তাদের জন্য Data Safety পেজে প্রবেশাধিকার দেওয়া হয়েছে,
  কিন্তু **Audit Log, Recycle Bin, ও Complete Order List ট্যাব এখনো শুধু Admin/Super Admin-এর
  জন্য** (এগুলো সংবেদনশীল ডেটা) — Accountant/Merchandiser Data Safety-তে ঢুকলে সরাসরি "Backup &
  Excel Export" ট্যাবেই (Reports সহ) নিয়ে যাওয়া হয়, Audit Log-এর মতো সংবেদনশীল তথ্য দেখতে পারেন না।

**যাচাই:** ৯টা assertion দিয়ে রোল-পারমিশন পরিবর্তন টেস্ট করা হয়েছে — সব পাস।

---

## 🧪 ডেলিভারির আগে যা যাচাই করা হয়েছে

- `node --check` সব JS ফাইলে পাস, `manifest.json` valid JSON
- CSS ব্রেস ব্যালেন্স (৬৫৯/৬৫৯), HTML div ব্যালেন্স (৯৮৩/৯৮৩), কোনো ডুপ্লিকেট element ID নেই
- HTML-এ ব্যবহৃত ১১৫টা `app.*()` ফাংশন কল — সব app.js-এ সংজ্ঞায়িত আছে (০টা মিসিং)
- schema.sql-এর সব নতুন কলাম/টেবিল app.js-এর ফিল্ডের সাথে ক্রস-চেক করা হয়েছে (৯টা চেক পয়েন্ট)
- standalone Node টেস্ট স্ক্রিপ্টে মোট ২৪টা assertion (Complete Order List: ১৫টা, Reports
  রিলোকেশন পারমিশন: ৯টা) — সব পাস
- Reports & BI সরানোর পর একটা রিগ্রেশন বাগ (ডুপ্লিকেট `report-modal` ID + ভুল HTML কমেন্ট লেবেল)
  পাওয়া গিয়েছিল প্রাথমিক এডিটে — সেটা ধরে ঠিক করে পুনরায় div/ID ব্যালেন্স চেক করা হয়েছে
- সম্পূর্ণ diff রিভিউ করে নিশ্চিত হওয়া গেছে `manifest.json`, `sw.js`, `js/config.js` অপরিবর্তিত

## ⏳ এখনো বাকি (আপনার ইনপুট প্রয়োজন)

- **রেফারেন্স থিম ইমেজ** — আপনি বলেছিলেন কিছু রেফারেন্স থিম আপলোড করবেন; এখনো পাইনি। আপলোড করলে
  নতুন App Theme হিসেবে যোগ করে দেব।
