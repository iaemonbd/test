# AccoFlow ERP — কাস্টম পার-ইউজার পারমিশন সিস্টেম (রাউন্ড ২১)

তারিখ: ২৭ আগস্ট, ২০২৬

## যা করা হয়েছে

আপনার অনুরোধ: role-ভিত্তিক ফিক্সড পারমিশন প্যাকেজের বদলে Admin/Superadmin তাদের ইচ্ছামতো
যেকোনো ইউজারকে যেকোনো মডিউলে View/Create-Edit/Delete দিতে পারবেন — কারণ একই ব্যক্তি একাধিক
দায়িত্ব পালন করলে আগের সিস্টেমে সেটা প্রকাশ করা যেত না।

## মূল ধারণা বদল

**আগে:** role (admin/superadmin/accountant/merchandiser/storekeeper) একটা ফিক্সড "প্যাকেজ" —
কোন role কী করতে পারবে তা কোডে হার্ডকোড করা ছিল (রাউন্ড ১৫/১৮)।

**এখন:** প্রতিটা ইউজারের নিজস্ব `profiles.permissions` (JSONB) — প্রতিটা মডিউলে আলাদাভাবে
view/write/delete (কিছু মডিউলে +approve/+export) সেট করা যায়। role এখন শুধু একটা লেবেল আর
নতুন ইউজার তৈরির সময় "কুইক প্রিসেট" — সেভ করার পর সম্পূর্ণ স্বাধীনভাবে বদলানো যায়।

## নিরাপত্তা সীমারেখা (ইচ্ছাকৃত)

"Users" (অ্যাকাউন্ট তৈরি/এডিট/ডিলিট) ও "Settings" (কোম্পানি কনফিগ) — এই দুইটার write/delete
এখনো শুধু literal Admin/Superadmin role-এই বাঁধা, permissions দিয়ে delegate করা যায় না। কারণ:
permissions এডিট করার ক্ষমতা কাউকে দিলে সে কার্যত নিজেকে/অন্য কাউকে যেকোনো পারমিশন দিয়ে
superadmin বানিয়ে ফেলতে পারত (self-escalation) — এটা আপনার নিজের অনুরোধেরই সাথে মেলে
("এডমিন এবং সুপার এডমিন ইচ্ছা অনুযায়ী পারমিশন দিতে পারবে" — অর্থাৎ শুধু তারাই)। এই দুই মডিউলের
"দেখা" (view) অবশ্য এখনো delegate করা যায় (নিরাপদ, শুধু দেখতে দেওয়া)।

## যা যোগ/বদলেছে

**DB (`migration_v21_custom_permissions.sql`):**
- `profiles.permissions` নতুন JSONB কলাম
- `has_perm(module, action)` — নতুন হেল্পার ফাংশন (superadmin bypass + বাকিদের permissions থেকে চেক)
- বিদ্যমান সব ইউজারের permissions **ব্যাকফিল** — role অনুযায়ী ডিফল্ট বসিয়ে, তারপর যাদের লিগ্যাসি
  "soft mode" ট্যাগ (Add User ফর্মের পুরনো checkbox) ছিল তাদের ক্ষেত্রে সেই তালিকার সাথে
  intersection করে view আরও সংকুচিত — যাতে migration চালানোর মুহূর্তে **কারো এক্সেস আচমকা না বদলায়**
- ২০+ টেবিলের write/delete পলিসি `has_perm()`-ভিত্তিক করা হলো (রাউন্ড ১৫/১৮-এর role-চেক প্রতিস্থাপিত)
- Payment RPC দুটোর (`record_buyer_payment`/`record_supplier_payment`) ভেতরের role-চেক
  `has_perm('accounts','write')`-এ বদলানো
- ⚠️ **ইচ্ছাকৃত রক্ষণশীল পরিবর্তন:** delete আগে টেবিল-ভিত্তিক ভিন্ন ছিল (কিছু টেবিলে admin delete
  করতে পারতেন, কিছুতে না)। এখন delete মডিউল-ভিত্তিক একটাই ফ্ল্যাগ — তাই admin-এর ডিফল্ট
  inventory/delivery/qc/accounts/hr/bsinfo delete=false রাখা হলো (আগে যেটা বেশিরভাগ টেবিলে ছিল),
  শুধু expense-এ true। প্রয়োজনে Roles পেজ থেকে যেকোনো সময় আবার চালু করা যাবে।

**UI (`index.html` + `js/app.js`):**
- Add/Edit User মডালে পুরনো flat checkbox তালিকার বদলে **গ্রানুলার গ্রিড** (মডিউল × View/Create-Edit/
  Delete/বিশেষ) + ৫টা কুইক-প্রিসেট বাটন
- Roles পেজের ৫টা স্ট্যাটিক role-card সরিয়ে ব্যাখ্যামূলক নোট (কারণ এখন পারমিশন role-ভিত্তিক না)
- Active Users টেবিলের Permissions কলাম এখন প্রতিটা ইউজারের প্রকৃত মডিউল-অ্যাক্সেসের সামারি দেখায়
- ৫৬টা জায়গায় (৩৩ static + ২৩ dynamic) `.admin-only`/`.superadmin-only` ক্লাসের বদলে সঠিক
  মডিউল-ভিত্তিক ক্লাস (`inventory-write`, `hr-delete`, ইত্যাদি) — HR Settings, Payment Record
  বাটন (রাউন্ড ১৮-এ মিস হয়ে যাওয়া মডাল-ফুটার বাটনসহ), সব delete বাটন
- Settings পেজের Save/Sync বাটনগুলোতে `superadmin-only` ক্লাস যোগ (পেজ-ভিউ এখন delegate-যোগ্য
  হওয়ায় এই সুরক্ষা আগে অনুপস্থিত ছিল, DB আগেও ব্লক করত কিন্তু UI বিভ্রান্তিকর হতো)
- `applyRolePermissions()` → `applyUserPermissions()` — role নয়, ইউজারের permissions অবজেক্ট
  থেকে নেভিগেশন ও সব Write/Delete বাটনের দৃশ্যমানতা নির্ধারণ করে

## ✅ বাস্তবে টেস্ট করা হয়েছে

**DB (real Postgres):**
- storekeeper (plain) → deliveryPlan INSERT ✅, accBuyer UPDATE ❌ (প্রত্যাশিত)
- কাস্টম ইউজার (role=storekeeper + ম্যানুয়ালি accounts.write ও hr.view যোগ করা) →
  accBuyer UPDATE ✅, hrEmployees SELECT ✅ কিন্তু INSERT ❌ (শুধু view দেওয়া ছিল), piList
  INSERT ❌ (inventory.write নেই) — **role-এর বাইরে গিয়েও ঠিক যা দেওয়া হয়েছে তা-ই কাজ করছে**
- 'ali'-এর (legacy tags "Dashboard, Inventory, B&S Info") ব্যাকফিল → QC/Delivery/Accounts
  view=false, Inventory/B&S Info view=true — হুবহু আগের effective access বজায় আছে
- record_buyer_payment() RPC-তে কাস্টম accounts.write থাকা storekeeper সফলভাবে payment
  রেকর্ড করেছে; plain storekeeper ব্লকড হয়েছে
- superadmin সব টেবিলে bypass নিশ্চিত

**ক্লায়েন্ট (Playwright/Chromium দিয়ে বাস্তব ব্রাউজার রেন্ডার):**
- Edit User মডাল খুলে 'ali'-এর গ্রিড সঠিকভাবে populate হয়েছে (তার আসল permissions থেকে)
- গ্রিড থেকে collect করা অবজেক্ট populate করা অবজেক্টের সাথে হুবহু মিলেছে (round-trip নিশ্চিত)
- প্রিসেট বাটন ("Accountant") ক্লিক করলে গ্রিড সঠিকভাবে পূরণ হয়েছে + Role ড্রপডাউন auto-set হয়েছে
- role="storekeeper" কিন্তু কাস্টম permissions (accounts.write=true, inventory কিছুই না) দিয়ে
  লগইন সিমুলেট করে নেভিগেশন যাচাই: Delivery ✅ দৃশ্যমান, Inventory ❌ অদৃশ্য, **Accounts ✅
  দৃশ্যমান (role-এর বাইরে, কাস্টম পারমিশনের কারণে)**, HR ❌ অদৃশ্য — ঠিক যেমনটা চাওয়া হয়েছিল
- কোনো কনসোল এরর পাওয়া যায়নি

## ডিপ্লয়

1. Supabase SQL Editor-এ `migration_v21_custom_permissions.sql` রান করুন (v13, v15, v16, v18
   আগে থেকেই থাকতে হবে)
2. নতুন `index.html`, `js/app.js`, `js/supabase-api.js`, `css/styles.css` — **চারটাই** আপলোড করুন
3. Ctrl+Shift+R দিয়ে হার্ড রিফ্রেশ
4. Roles পেজে গিয়ে বিদ্যমান ইউজারদের পেন্সিল আইকনে ক্লিক করে ব্যাকফিল হওয়া permissions যাচাই করুন,
   প্রয়োজনে সমন্বয় করুন
