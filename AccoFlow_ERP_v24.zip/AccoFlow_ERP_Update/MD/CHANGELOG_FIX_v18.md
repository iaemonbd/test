# AccoFlow ERP — Role Redesign (রাউন্ড ১৮)

তারিখ: ১৩ আগস্ট, ২০২৬ — আপনার ৩টা সিদ্ধান্তের ভিত্তিতে

## আপনার সিদ্ধান্ত

| প্রশ্ন | উত্তর |
|---|---|
| merchandiser কি Inventory & PI-তে Create/Edit পাবে? | ✅ হ্যাঁ, পুরো মডিউলে |
| storekeeper কি Delivery ও QC-তে Create/Edit পাবে? | ✅ হ্যাঁ, দুইটাতেই |
| accountant কি নিজে Payment রেকর্ড করতে পারবে? | ✅ হ্যাঁ |

## যা বদলেছে

**DB (migration_v18_role_redesign.sql):**
- `piList`, `masterData`, `receivedGoods`, `supplierOrders` — INSERT/UPDATE-এ **merchandiser** যোগ
- `accBuyer`, `accSupplier` — INSERT/UPDATE-এ **merchandiser** যোগ (⚠️ নিচে ব্যাখ্যা দেখুন — এটা বাধ্যতামূলক ছিল)
- `deliveryPlan`, `deliveryExec`, `deliveryHist`, `qcList` — INSERT/UPDATE-এ **storekeeper** যোগ
- `record_buyer_payment()`/`record_supplier_payment()` RPC-এর ভেতরের role-চেকে **accountant** যোগ
- **DELETE কোথাও বদলায়নি** — সব টেবিলে এখনো আগের মতোই admin/superadmin (বা যেখানে আগে admin-only ছিল, তাই আছে) — এটা নিয়ে জিজ্ঞাসা করা হয়নি, তাই ছোঁয়া হয়নি

**UI (js/app.js + index.html):** ৯টা জায়গায় সরাসরি `.admin-only` ক্লাসের বদলে নতুন মডিউল-ভিত্তিক ক্লাস
(`inventory-write`, `delivery-write`, `qc-write`, `payment-write`, `expense-write`) — merchandiser/storekeeper/
accountant এখন নিজ নিজ মডিউলের Add/Edit বাটন দেখতে ও ব্যবহার করতে পারবেন। HR/Settings/Users-এর মতো
সত্যিকারের admin-only জায়গাগুলো অপরিবর্তিত রইল।

## ⚠️ একটা জরুরি পার্শ্ব-প্রতিক্রিয়া জেনে রাখুন

merchandiser PI বা Supplier Order সেভ করলে `savePI()`/`saveSupplierOrder()` স্বয়ংক্রিয়ভাবে
`accBuyer`/`accSupplier` ledger-এও total/due আপডেট করে (`syncAccBuyerFromPI`) — তাই merchandiser-কে
শুধু `piList`-এ লেখার অনুমতি দিলেই চলত না, `accBuyer`/`accSupplier`-এও দিতে হয়েছে, নাহলে PI সেভ করার
মাঝপথেই RLS এরর আসত। এর ফলে merchandiser টেকনিক্যালি সরাসরি API/DevTools দিয়ে ওই টেবিলের যেকোনো
কলাম (total/due-সহ) এডিট করতে পারবেন — যদিও UI-তে সেটার কোনো বাটন নেই। **Payment রেকর্ড করা**
(received/paid বদলানো, ব্যালেন্স হিসাব) তবুও শুধু RPC দিয়েই হয় এবং admin/superadmin/accountant-এই
সীমাবদ্ধ — merchandiser payment RPC কল করতে পারবেন না (উপরের টেস্টে যাচাই করা)।

Postgres RLS টেবিল-লেভেলে কাজ করে, নির্দিষ্ট কলামে না — তাই এর চেয়ে সূক্ষ্ম নিয়ন্ত্রণ (যেমন
merchandiser শুধু total/due লিখতে পারবে কিন্তু received/paid না) দিতে হলে ট্রিগার-ভিত্তিক
column-level সুরক্ষা লাগবে, যেটা আরেকটা আলাদা কাজ — বর্তমানে দরকার মনে না হলে বাদ রাখা হলো।

## ✅ বাস্তবে টেস্ট করা হয়েছে (৯টা কেস, সবগুলো প্রত্যাশামতো)

| # | টেস্ট | ফলাফল |
|---|---|---|
| ১ | merchandiser → piList INSERT | ✅ সফল |
| ২ | merchandiser → accBuyer UPDATE | ✅ সফল |
| ৩ | merchandiser → piList DELETE | ✅ ব্লকড (এখনো superadmin-only) |
| ৪ | merchandiser → deliveryPlan INSERT | ✅ ব্লকড (এটা storekeeper-এর মডিউল) |
| ৫ | storekeeper → deliveryPlan INSERT | ✅ সফল |
| ৬ | storekeeper → qcList INSERT | ✅ সফল |
| ৭ | storekeeper → piList INSERT | ✅ ব্লকড (এটা merchandiser-এর মডিউল) |
| ৮ | accountant → record_buyer_payment() RPC | ✅ সফল, ledger সঠিকভাবে আপডেট |
| ৯ | accountant → piList INSERT | ✅ ব্লকড |

## ডিপ্লয়

1. Supabase SQL Editor-এ `migration_v18_role_redesign.sql` রান করুন (v13, v15, v16 আগে থেকেই থাকতে হবে)
2. নতুন `js/app.js` ও `index.html` আপলোড করুন — **দুটোই লাগবে**, একটা বাদ দিলে UI/DB অসামঞ্জস্যপূর্ণ হয়ে যাবে
3. Ctrl+Shift+R দিয়ে হার্ড রিফ্রেশ করে merchandiser/storekeeper/accountant দিয়ে লগইন করে যাচাই করুন
