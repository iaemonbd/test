# AccoFlow ERP — সিকিউরিটি অডিট ফিক্স (রাউন্ড ১৪)

তারিখ: ১২ আগস্ট, ২০২৬

এই রাউন্ডে "AccoFlow ERP V-13 Security & Code Review — Verified Findings Report"-এ চিহ্নিত
৭টি Critical/High আইটেমের মধ্যে যেগুলো **স্বয়ংসম্পূর্ণ, কম-ঝুঁকিপূর্ণ, এবং এখনই নিরাপদে ফিক্স
করা যায়** — সেগুলো করা হয়েছে। বাকি বড় আর্কিটেকচার-পরিবর্তনের আইটেমগুলো (broad RLS পলিসি
পুনর্গঠন, client-side ID generation মাইগ্রেশন, Payment RPC transaction, Telegram token
Edge Function Secret-এ সরানো) ইচ্ছাকৃতভাবে এই রাউন্ডে করা হয়নি — প্রতিটার জন্য business-rule
সিদ্ধান্ত (কোন role কোন টেবিলে কী করতে পারবে, ইত্যাদি) লাগবে, তাই আলাদাভাবে পরবর্তী ধাপে করা হবে।

## ✅ যা ফিক্স করা হয়েছে

### ১. Edge Function — Privilege Escalation বাগ (Critical)
`supabase/functions/admin-manage-user/index.ts`-এ এখন `role === 'superadmin'` সেট করার
অনুরোধ শুধু তখনই গ্রহণ হবে যখন ক্যালার নিজেই ইতিমধ্যে superadmin। আগে যেকোনো admin অন্য কাউকে
(বা নিজেকে) superadmin বানিয়ে নিতে পারতেন। **ডিপ্লয় করতে হবে** (`supabase functions deploy
admin-manage-user` অথবা Dashboard-এ পেস্ট করে রিডিপ্লয়)।

### ২. Payment এন্ট্রিতে Negative Amount আটকানো (Critical)
`js/app.js`-এর `saveBuyerPayment()` ও `saveSupplierPaymentEntry()` — দুটোতেই চেক
`!amount` থেকে `amount <= 0`-এ বদলানো হলো, যাতে ঋণাত্মক (negative) amount দিয়ে ledger
উল্টে দেওয়া না যায়। **কোড-অনলি, রিডিপ্লয় দরকার নেই (শুধু নতুন js/app.js আপলোড করলেই হবে)।**

### ৩. `notify()` টোস্টে XSS ঝুঁকি (High)
টোস্ট মেসেজ আগে escape ছাড়াই `innerHTML`-এ বসত (buyer name, PI No, employee name ইত্যাদি
সরাসরি যেত)। এখন `escapeHtml()` দিয়ে wrap করা হলো — আইকন markup অপরিবর্তিত। **কোড-অনলি।**

### ৪. HR স্পর্শকাতর ডেটা read-lockdown (Critical) — নতুন SQL মাইগ্রেশন লাগবে
`supabase/migration_v14_hr_read_lockdown.sql` — `hrEmployees` ও `hrSalary`-এর SELECT
policy এখন শুধু `admin`/`superadmin` role-এর জন্য (আগে যেকোনো সক্রিয় ইউজার, role নির্বিশেষে,
API দিয়ে NID/বেতন/ব্যাংক তথ্য পড়তে পারতেন)। **Supabase SQL Editor-এ এই নতুন ফাইলটা রান
করতে হবে** (migration_v13_rls_auth.sql আগে থেকেই রান করা থাকতে হবে)।

⚠️ **`hrSignatures` ইচ্ছাকৃতভাবে বাদ**: যাচাই করে দেখা গেছে merchandiser role Supplier Order
Sheet-এ নিজের সিগনেচার সিলেক্ট করতে এটা read করে — লক করলে বৈধ ফিচার ভাঙত। এতে NID/Salary/Bank
তথ্য থাকে না (শুধু নাম+পদবি+সিগনেচার ছবি), তাই ঝুঁকিও কম।

**পার্শ্ব-প্রতিক্রিয়া যা জেনে রাখা ভালো:**
- Login করলে সাইডবারে যে ইউজার-ছবি দেখানো হয় সেটা `hrEmployees` থেকে নাম মিলিয়ে বের হয় —
  admin/superadmin ছাড়া অন্য role-এ লগইন করলে এখন এই ছবি আর দেখাবে না (অ্যাপ ভাঙবে না)।
- Data Safety > Backup & Excel Export-এ non-admin কেউ ব্যাকআপ নিলে Employees/Salary শিট
  বাদ পড়বে — এটা প্রকৃতপক্ষে সঠিক আচরণ, আগেরটাই বাগ ছিল।

## ⏸️ ইচ্ছাকৃতভাবে এই রাউন্ডে করা হয়নি (বড় আর্কিটেকচার পরিবর্তন — সিদ্ধান্তের অপেক্ষায়)

| আইটেম | কেন এখনই না |
|---|---|
| `authenticated_all` broad policy ভেঙে module+role-ভিত্তিক পলিসি (২১ টেবিল) | কোন role কোন টেবিলে read/write/delete করতে পারবে তার সম্পূর্ণ ম্যাট্রিক্স ঠিক করতে হবে; ভুল হলে লাইভ ইউজার লক-আউট হতে পারে |
| `Math.max(id)+1` বাদ দিয়ে Postgres `identity`/`serial` কলাম (৩৮ জায়গা) | schema-লেভেল কলাম টাইপ পরিবর্তন + বিদ্যমান ডেটার সাথে সামঞ্জস্য যাচাই লাগবে |
| Telegram Bot Token → Edge Function Secret | নতুন Edge Function endpoint ডিজাইন + client-side call-site পরিবর্তন লাগবে |
| Payment posting → PostgreSQL RPC/transaction | নতুন RPC ফাংশন ডিজাইন + validate/insert/update একসাথে transaction-এ আনা লাগবে |
| Audit log-এর username/role/timestamp সার্ভার-সাইডে জেনারেট (trigger) | timestamp ফরম্যাট/টাইমজোন বিদ্যমান রেন্ডারিং কোডের সাথে ঠিকভাবে মেলাতে হবে; বড় RLS কাজের সাথে একসাথে করাই ভালো |

এই আইটেমগুলো নিয়ে পরবর্তী ধাপে কাজ করা যাবে — কোনটা আগে করতে চান জানালেই এগোনো যাবে।
