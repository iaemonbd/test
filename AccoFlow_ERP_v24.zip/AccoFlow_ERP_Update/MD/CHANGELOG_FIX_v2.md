# AccoFlow ERP — ফিক্স ও এনহ্যান্সমেন্ট রিপোর্ট (রাউন্ড ২ / V-6.5)

তারিখ: ২১ জুলাই, ২০২৬

এই রাউন্ডে নির্দিষ্ট স্কোপ অনুযায়ী বাগ ফিক্স, লোকালাইজেশন, UI/UX এনহ্যান্সমেন্ট এবং Inventory & PI ওয়ার্কফ্লো আপডেট করা হয়েছে। প্রতিটি পরিবর্তনের আগে আসল কোড পড়ে root cause ভ্যারিফাই করা হয়েছে, এবং পরে syntax + logic টেস্ট করা হয়েছে। অন্য কোনো ফিচার/কোডে হাত দেওয়া হয়নি।

---

## ✅ ফিক্স ১ — Recycle Bin "Restore" কাজ করছিল না

**ফাইল:** `js/app.js` (`restoreFromTrash`)

**আসল কারণ:** `delete record.deletedAt; delete record.deletedBy;` দিয়ে key দুটো জাভাস্ক্রিপ্ট অবজেক্ট থেকে সম্পূর্ণ মুছে ফেলা হতো। এর ফলে Supabase-এ `upsert()` কল করার সময় পাঠানো JSON payload-এ `deletedAt`/`deletedBy` কলাম দুটো একেবারেই থাকত না — তাই PostgREST-এর জেনারেট করা `INSERT ... ON CONFLICT DO UPDATE` কোয়েরিতে এই কলাম দুটো SET হতোই না, এবং ডাটাবেসে পুরনো `deletedAt` টাইমস্ট্যাম্প রয়েই যেত। ফলে UI-তে সাথে সাথে আইটেম Trash থেকে সরে গেলেও (optimistic local state), পরের বার রিফ্রেশ/রিলোড করলে সেটা আবার Trash-এ ফিরে আসত — অর্থাৎ Restore আসলে ডাটাবেসে কখনো স্থায়ী হতোই না।

**সমাধান:** key ডিলিট না করে এখন explicitly `record.deletedAt = null; record.deletedBy = null;` সেট করা হয়, যাতে upsert payload-এ এই দুই কলাম থাকে এবং ডাটাবেসেও সঠিকভাবে null হয়ে যায়। ডেটা সেফটি (audit log, soft-delete মডেল) অক্ষুণ্ণ রাখা হয়েছে।

---

## ✅ ফিক্স ২ — গ্লোবাল টাইমজোন: Bangladesh Standard Time (BST, GMT+6)

**ফাইল:** `js/app.js`

একটামাত্র কেন্দ্রীয় কনফিগ যোগ করা হয়েছে (`APP_TIMEZONE = 'Asia/Dhaka'`) এবং এর উপর ভিত্তি করে চারটা হেল্পার ফাংশন:
- `todayStr()` — "আজ" সবসময় Dhaka টাইমজোন অনুযায়ী `YYYY-MM-DD` রিটার্ন করে (আগে `new Date().toISOString().split('T')[0]` ব্যবহার হতো, যেটা UTC ধরত — মধ্যরাতের কাছাকাছি সময়ে ভুল "আজ" দেখাতে পারত)।
- `nowISO()` — টাইমস্ট্যাম্প (deletedAt, audit log) রেকর্ড করার সময় ব্যবহার হয়, `+06:00` অফসেটসহ।
- `formatDate()` / `formatDateTime()` — ডিসপ্লে ফরম্যাটিংয়ের জন্য (নিচে দেখুন)।

২৮টি জায়গায় `new Date().toISOString().split('T')[0]` কে `todayStr()` দিয়ে প্রতিস্থাপন করা হয়েছে (PI/Order/Voucher/Attendance ফর্মের ডিফল্ট তারিখ, "আজকের" হিসাব ইত্যাদি)। সব ঘড়ি/টাইমস্ট্যাম্প ডিসপ্লে (`clock()`, Trash-এর Deleted At, Audit Log, Last Login, ZKTeco টেস্ট কানেকশন) এখন explicitly `timeZone: 'Asia/Dhaka'` ব্যবহার করে, যাতে ব্যবহারকারীর ডিভাইসের নিজস্ব টাইমজোন যা-ই হোক, অ্যাপে সবসময় বাংলাদেশ সময় দেখায়।

ভবিষ্যতে টাইমজোন বদলাতে হলে শুধু `APP_TIMEZONE`-এর মান বদলালেই পুরো অ্যাপে প্রতিফলিত হবে।

---

## ✅ ফিক্স ৩ — গ্লোবাল ডেট ফরম্যাট: MM/DD/YYYY → DD/MM/YYYY

**ফাইল:** `js/app.js`, `index.html`

- **আসল বাগ:** Reports সেকশনে একটা জায়গায় `new Date().toLocaleDateString()` — কোনো locale specify না করেই — ব্যবহার হচ্ছিল, যেটা ব্রাউজারের ডিফল্ট locale (অনেক সিস্টেমেই en-US, অর্থাৎ M/D/YYYY) অনুযায়ী দেখাত। এটাই ছিল আসল MM/DD/YYYY-এর উৎস।
- টেবিল/ফর্ম/ভিউ/Excel export মিলিয়ে ৩০+ জায়গায় raw `row.date` (PI List, Received Goods, Delivery History, QC Reports, Delivery Plan, Vouchers, Expense List, HR Attendance, HR Employees Join Date ইত্যাদি) এখন কেন্দ্রীয় `formatDate()` দিয়ে DD/MM/YYYY আকারে দেখানো হয়।
- `index.html`-এ `<html lang="en">` কে `<html lang="en-GB">` করা হয়েছে, যাতে Chromium/Edge ব্রাউজারের নেটিভ `<input type="date">` ক্যালেন্ডার-পিকারও dd/mm/yyyy অর্ডারে দেখায়।

**গুরুত্বপূর্ণ টেকনিক্যাল নোট:** HTML5 স্ট্যান্ডার্ড অনুযায়ী `<input type="date">`-এর ভেতরের `value` অ্যাট্রিবিউট সবসময় `YYYY-MM-DD` (ISO) ফরম্যাটেই থাকতে হয় — এটা ব্রাউজারের নিজস্ব নিয়ম, কোনো অ্যাপ কোড দিয়ে বদলানো যায় না। তাই এডিট/সেভ ফর্মের ইনপুট ফিল্ডগুলো (rg-date, pi-modal-date, voucher-entry-date ইত্যাদি) ইচ্ছাকৃতভাবে অপরিবর্তিত রাখা হয়েছে — শুধু **ডিসপ্লে-অনলি** জায়গাগুলো (টেবিল সেল, রিডঅনলি ভিউ, রিপোর্ট, Excel export) DD/MM/YYYY-তে বদলানো হয়েছে। ক্যালেন্ডার-পিকারের ভিজ্যুয়াল অর্ডার (`lang="en-GB"` দিয়ে) মূলত Chromium-ভিত্তিক ব্রাউজারে (Chrome/Edge) সবচেয়ে ভালোভাবে কাজ করে; কিছু পুরনো Firefox বিল্ডে সামান্য ভিন্নতা থাকতে পারে — এটা ওয়েব প্ল্যাটফর্মের সীমাবদ্ধতা।

---

## ✅ এনহ্যান্সমেন্ট ৪ — Master Data-তে HS Code ও Dept যোগ

**ফাইল:** `schema.sql`, `index.html`, `js/app.js`

- `schema.sql`: `masterData` টেবিলে `hsCode` ও `dept` (text) কলাম যোগ, বিদ্যমান ডাটাবেসের জন্য নিরাপদ (idempotent) `alter table ... add column if not exists`।
- `Inventory & PI > Master Data > Add New Item` ফর্মে দুইটা নতুন ইনপুট ফিল্ড।
- Master Data টেবিলে HS Code ও Dept কলাম যোগ (Brand-এর পাশে)।
- `openAddItemModal()`, `editMasterItem()`, `saveMasterItem()`, `renderMasterTable()` — সব জায়গায় ফিল্ড দুটোর রিসেট/পপুলেট/সেভ/রেন্ডার লজিক যোগ করা হয়েছে।

---

## ✅ এনহ্যান্সমেন্ট ৫ — PI Creation-এ Auto-fill সম্প্রসারণ

**ফাইল:** `js/app.js` (`autofillPIItemRow`)

আগে Item Code সিলেক্ট করলে শুধু Description ও Unit Price অটো-ফিল হতো। এখন Master Data-তে থাকা **Style No, HS Code, Dept** — এই তিনটাও অটো-ফিল হয়। সবগুলো ফিল্ডই স্বাভাবিক এডিটেবল `<input>` — অটো-ফিলের পরও ইউজার চাইলে যেকোনো লাইনে ম্যানুয়ালি বদলাতে পারবেন।

---

## ✅ এনহ্যান্সমেন্ট ৬ — ড্যাশবোর্ড: স্ক্রলিং কমানো, প্যাটার্ন টেক্সচার, ডাটাবেজ স্ট্যাটাস

**ফাইল:** `css/styles.css`, `index.html`, `js/app.js`

- **স্ক্রলিং সমস্যার root cause:** গ্রিড লেআউটে (`.widget-grid`) প্রতিটা `.card`-এর নিজস্ব `margin-bottom: 12px` ছিল, যেটা গ্রিডের নিজস্ব `gap: 12px`-এর *উপরে* যোগ হয়ে প্রতি সারির মাঝে ~২৪পিক্সেল ফাঁকা জায়গা তৈরি করছিল (দরকার ছিল ১২পিক্সেল)। এখন গ্রিডের ভেতরের কার্ডগুলোর margin-bottom শূন্য করা হয়েছে (গ্রিডের gap-ই যথেষ্ট)।
- Widget icon ও value-র সাইজ সামান্য কমিয়ে (৪০→৩৬পিক্সেল আইকন, ২৬→২৪পিক্সেল ভ্যালু) কার্ডগুলো আরও কমপ্যাক্ট করা হয়েছে।
- চওড়া মনিটরে (≥1500px) ৯টা widget card এখন ৫ কলামে সাজে (আগে সবসময় ৪ কলাম ছিল) — ফলে ২ সারিতেই শেষ হয়ে যায় (আগে ৩ সারি লাগত), এবং নিচের ৩টা চার্ট দেখতে কম স্ক্রল করা লাগে।
- **Pattern texture:** widget card-গুলোর ব্যাকগ্রাউন্ডে সূক্ষ্ম dot-grid প্যাটার্ন যোগ করা হয়েছে (dark ও light — দুই মোডেই আলাদাভাবে টিউন করা), যাতে টেক্সট রিডেবিলিটি ঠিক থেকেই কার্ডগুলো আরও রিচ/গ্রাফিক্যাল দেখায়।
- **ডাটাবেজ কানেকশন ভেরিফিকেশন:** কোড ঘেঁটে নিশ্চিত হয়েছি যে `dbConnected` / `updateSyncStatus()` লজিক সঠিকভাবেই কাজ করে (app চালু হওয়া, Refresh বাটন চাপা, লগইন — সব জায়গায় ঠিকভাবে আপডেট হয়)। এটাকে আরও স্পষ্ট ও দৃশ্যমান করতে ড্যাশবোর্ডের একদম উপরে একটা নতুন **Database Status strip** যোগ করা হয়েছে যেটা Online/Offline অবস্থা, এবং শেষবার কখন চেক হয়েছে তা দেখায় — টপবারের ছোট ব্যাজের পাশাপাশি এখন ড্যাশবোর্ডেও এক নজরেই বোঝা যাবে।

---

## ✅ এনহ্যান্সমেন্ট ৭ — সফটওয়্যার লোগো ভিজিবিলিটি ফিক্স (ফুটার সাইজ অপরিবর্তিত)

**ফাইল:** `css/styles.css`, `index.html`

- **কারণ:** `assets/logo.png`-এর প্রায় অর্ধেক অংশ transparent এবং visible অংশের গড় রং হালকা ধূসর-টিল — ফলে ছোট সাইজে (ফুটারে ২৪পিক্সেল উচ্চতায়) ডার্ক ব্যাকগ্রাউন্ডে লোগোটা ভালোভাবে বোঝা যাচ্ছিল না।
- **সমাধান (ফুটার):** লোগোটাকে একটা হালকা কনট্রাস্ট "চিপ" (gradient background + বর্ডার)-এ wrap করা হয়েছে, এবং `brightness/contrast/saturate` ফিল্টার দিয়ে রং আরও স্পষ্ট করা হয়েছে। চিপের উচ্চতা ঠিক আগের ২৪পিক্সেলই রাখা হয়েছে (`box-sizing: border-box`) — **ফুটারের সামগ্রিক সাইজ একবিন্দুও বাড়েনি।**
- লগইন স্ক্রিনের লোগোতেও একই কালার-বুস্ট ফিল্টার যোগ করা হয়েছে সামঞ্জস্যের জন্য (সাইজ সেখানে আগে থেকেই যথেষ্ট বড়, তাই শুধু কালার এনহ্যান্স করা হয়েছে)।

---

## ✅ এনহ্যান্সমেন্ট ৮ — Transitions & Animations (Modal Close + Accessibility)

**ফাইল:** `css/styles.css`, `js/app.js`

- Modal খোলার অ্যানিমেশন আগে থেকেই ভালো ছিল (pop-in বাউন্স ইফেক্ট)। এখন **বন্ধ করার সময়ও** একটা মসৃণ fade + scale-out ট্রানজিশন হয় (আগে সাথে সাথে অদৃশ্য হয়ে যেত) — `app.close()`-এ `.closing` ক্লাস যোগ করে অ্যানিমেশন শেষ হওয়ার পর (animationend ইভেন্ট + সেফটি ফলব্যাক টাইমআউট) `.show` সরানো হয়।
- `prefers-reduced-motion: reduce` মিডিয়া-কোয়েরি যোগ করা হয়েছে — যেসব ইউজার সিস্টেম সেটিংসে মোশন-সংবেদনশীলতা চালু রেখেছেন, তাদের জন্য সব অ্যানিমেশন/ট্রানজিশন প্রায় বন্ধ হয়ে যাবে (ফাংশনালিটি ঠিক থেকেই)।

---

## 🧪 QA / টেস্টিং নোট

- **Static/Syntax QA (এই সেশনে সম্পন্ন):** `node --check` দিয়ে `app.js`, `supabase-api.js`, `config.js`, `default-data.js` — চারটা ফাইলেই সিনট্যাক্স ভ্যালিডেট করা হয়েছে (কোনো এরর নেই)। `index.html`-এর div ব্যালান্স ও duplicate ID চেক করা হয়েছে (কোনো সমস্যা নেই)। `css/styles.css`-এর ব্রেস ব্যালান্স চেক করা হয়েছে (ঠিক আছে)। প্রতিটা লজিক পরিবর্তনের আগে-পরে সংশ্লিষ্ট কোড ম্যানুয়ালি ট্রেস করে যাচাই করা হয়েছে (বিশেষত Restore বাগ, upsert payload behavior, PI ফর্মের cell-index ম্যাপিং)।
- **যা সরাসরি টেস্ট করা যায়নি:** এই ডেভেলপমেন্ট এনভায়রনমেন্টে ইন্টারনেট/Docker অ্যাক্সেস বন্ধ, তাই বাস্তব Supabase Docker কন্টেইনারের সাথে লাইভ অনলাইন/অফলাইন সিঙ্ক আচরণ (network drop/reconnect, উভয় মোডে ব্রাউজারে সরাসরি ক্লিক করে) সরাসরি রান করে দেখানো সম্ভব হয়নি। **ডেলিভারির আগে অনুগ্রহ করে নিজেদের self-hosted Docker এনভায়রনমেন্টে অন্তত এই চেকগুলো করে নেবেন:**
  1. `schema.sql`-এর নতুন ALTER স্টেটমেন্টগুলো (hsCode, dept) Supabase-এ রান করা।
  2. একটা রেকর্ড ডিলিট করে Recycle Bin থেকে Restore করে, তারপর পেজ রিফ্রেশ/রিলোড করে নিশ্চিত হওয়া যে সেটা আবার Trash-এ ফিরে আসছে না।
  3. Master Data-তে নতুন আইটেম যোগ করে HS Code/Dept সেভ হচ্ছে কিনা, এবং PI ফর্মে সেই Item Code সিলেক্ট করলে Style No/HS Code/Dept অটো-ফিল হচ্ছে কিনা।
  4. Docker/ইন্টারনেট বন্ধ করে অ্যাপ লোড করে দেখা যে ড্যাশবোর্ডের নতুন Database Status strip সঠিকভাবে "Offline" দেখাচ্ছে কিনা, এবং পরে সংযোগ ফিরিয়ে Refresh চাপলে "Online" এ বদলাচ্ছে কিনা।

---

## 📁 পরিবর্তিত ফাইল সমূহ

| ফাইল | পরিবর্তনের ধরন |
|---|---|
| `js/app.js` | বাগ ফিক্স, নতুন হেল্পার ফাংশন, timezone/date সংশোধন, autofill, master data, dashboard, modal |
| `index.html` | `lang` অ্যাট্রিবিউট, Master Data ফর্ম/টেবিল, Dashboard DB status strip, footer logo চিপ |
| `css/styles.css` | dashboard grid fix, pattern texture, DB status strip, footer/login logo, modal transition, reduced-motion |
| `schema.sql` | `masterData` টেবিলে `hsCode`, `dept` কলাম |

কোনো অপ্রাসঙ্গিক ফাইল বা ফিচারে হাত দেওয়া হয়নি — নির্দিষ্ট স্কোপের মধ্যেই সব পরিবর্তন সীমাবদ্ধ রাখা হয়েছে।

---

## ✅ রাউন্ড ২.১ — ইউজার ফিডব্যাক অনুযায়ী পরিমার্জন (স্ক্রিনশট থেকে)

**ফাইল:** `js/app.js`, `index.html`, `css/styles.css`

1. **ঘড়ি — ১২ ঘণ্টা ফরম্যাটে (BDT)**: টপবারের লাইভ ঘড়ি আগে ২৪-ঘণ্টা ফরম্যাটে (যেমন `15:35:04`) দেখাত। এখন ১২-ঘণ্টা AM/PM ফরম্যাটে (যেমন `03:35:04 PM`) Asia/Dhaka টাইমজোন অনুযায়ী দেখায়। সামঞ্জস্যের জন্য Audit Log/Trash-এর টাইমস্ট্যাম্প (`formatDateTime()`), Last Login, ZKTeco টেস্ট-কানেকশন সময়ও ১২-ঘণ্টা ফরম্যাটে বদলানো হয়েছে।
   - *সতর্কতা যা মাথায় রাখা হয়েছে:* `lastLogin` ফিল্ডে আগে `toLocaleString('en-GB',...)` ব্যবহার হতো যেটাতে তারিখ+সময় একসাথে থাকে। ১২-ঘণ্টা সময়ের জন্য শুধু locale `en-US`-এ বদলালে তারিখের অংশও ভুলবশত আবার MM/DD/YYYY-তে ফিরে যেত — তাই এখানে কেন্দ্রীয় `formatDateTime()` হেল্পার ব্যবহার করা হয়েছে, যাতে তারিখ (DD/MM/YYYY) ও সময় (১২-ঘণ্টা) — দুটোই সঠিক থাকে।
2. **ড্যাশবোর্ডে Database Status**: আগের লম্বা বাক্য (skit strip) সরিয়ে একটা ছোট, পরিষ্কার পিল বসানো হয়েছে — একটা পালস-করা সবুজ ডট + "Live" লেখা (সংযুক্ত থাকলে), বা হলুদ ডট + "Offline" (সংযোগ না থাকলে)। বিস্তারিত তথ্য (কখন শেষ চেক হয়েছে) এখন হোভার করলে টুলটিপ হিসেবে দেখা যায় — মূল UI অনেক পরিষ্কার/কম জায়গা নেয়।
3. **নতুন Widget: Total Payable (Supplier Due)**: ড্যাশবোর্ডের খালি জায়গায় Supplier Ledger (`accSupplier`)-এর মোট বকেয়ার (due) উপর ভিত্তি করে একটা নতুন কার্ড যোগ করা হয়েছে — ঠিক "Total Due" (Buyer outstanding) কার্ডের মতোই ডিজাইন, কিন্তু কমলা রঙের অ্যাকসেন্টে, যাতে সহজেই আলাদা বোঝা যায়।

## 🔐 RLS (Row Level Security) নিয়ে সিদ্ধান্ত (কোনো কোড পরিবর্তন হয়নি)

ইউজার Supabase Table Editor-এ "RLS disabled" ব্যাজ দেখে জিজ্ঞেস করেছিলেন এটা enable করা যায় কিনা। উত্তর: **এখনই enable করা হয়নি**, কারণ —
- এই অ্যাপ Supabase Auth ব্যবহার করে না (নিজস্ব `users` টেবিল + শেয়ার্ড anon key দিয়ে কাস্টম লগইন)।
- policy ছাড়া RLS চালু করলে Postgres ডিফল্টভাবে **সব অ্যাক্সেস ব্লক** করে দেয় — পুরো অ্যাপ সাথে সাথে অচল হয়ে যাবে।
- আপাতত সুপারিশ: শুধু LAN-এ চালু রাখা অবস্থায় RLS বন্ধ রেখে সার্ভার ইন্টারনেটে এক্সপোজ না করা (গাইডেই উল্লেখ আছে)। ইন্টারনেটে এক্সপোজ/রিমোট অ্যাক্সেসের প্ল্যান করলে তখন Supabase Auth + সঠিক RLS policy একসাথে implement করা দরকার — এটা একটা আলাদা কাজ হিসেবে পরে করা যেতে পারে।

---

## ✅ রাউন্ড ৩ — থিম-ভিত্তিক ড্যাশবোর্ড টেক্সচার (নতুন কাস্টমাইজেশন ফিচার)

**উদ্দেশ্য:** ব্যবহারকারী কালার থিম বদলালে ড্যাশবোর্ডের widget card-এর ব্যাকগ্রাউন্ড প্যাটার্নও automatically বদলে যায় — সফটওয়্যার আরও নিজের মনমতো কাস্টমাইজ করার সুযোগ।

**ফাইল:** `assets/textures/*.svg` (নতুন, ১৪টা ফাইল), `css/styles.css`

- ৭টা আলাদা seamless (নিখুঁতভাবে tile হওয়া) SVG প্যাটার্ন তৈরি করা হয়েছে: **Ripples** (জলতরঙ্গ), **Chevron** (ধারালো জিগজ্যাগ), **Topographic** (ভূ-প্রকৃতির কনট্যুর রেখা), **Hexagonal Art-Deco**, **Paisley Swirl**, **Hexagram Stars** (৬-কোণা তারা), এবং **Abstract Calligraphic Flourish**।
- প্রতিটা প্যাটার্ন গাণিতিকভাবে (Python দিয়ে) জেনারেট করা হয়েছে যাতে ১০০% seamless হয় এবং সম্পূর্ণ **original** থাকে — কোনো স্টক ছবি সরাসরি কপি করা হয়নি (কপিরাইট এড়াতে)। "Calligraphy" প্যাটার্নটা ইচ্ছাকৃতভাবে সম্পূর্ণ বিমূর্ত/non-representational রাখা হয়েছে — কোনো প্রকৃত আরবি বা অন্য কোনো ভাষার অক্ষর/শব্দ নয়, শুধু ক্যালিগ্রাফির মতো প্রবাহমান আকার (ধর্মীয়/লিখিত কনটেন্ট সংক্রান্ত সংবেদনশীলতা এড়াতে)।
- প্রতিটা প্যাটার্নের dark ও light — দুই মোডের জন্য আলাদা টোন-টিউনড ভার্সন আছে (মোট ১৪টা ফাইল), প্রতিটাই ১-২ KB থেকে ২৯ KB-এর মধ্যে (সবগুলো মিলিয়ে ~১৮৮ KB, খুবই lightweight)।
- **থিম ↔ প্যাটার্ন ম্যাপিং:**

  | থিম | প্যাটার্ন |
  |---|---|
  | Ocean (ডিফল্ট) | Ripples |
  | Arctic | Chevron |
  | Emerald, Forest | Topographic |
  | Royal | Hexagonal Art-Deco |
  | Sunset, RoseGold | Paisley Swirl |
  | Midnight | Hexagram Stars |
  | Ruby, Crimson | Abstract Calligraphic Flourish |

- **কোনো নতুন JavaScript লজিক লাগেনি** — থিম বদলানোর সিস্টেম আগে থেকেই `body[data-theme="..."]` অ্যাট্রিবিউট ব্যবহার করে, তাই শুধু CSS-এ প্রতিটা থিমের জন্য নির্দিষ্ট `background-image` রুল যোগ করাই যথেষ্ট হয়েছে — থিম সিলেক্ট করার সাথে সাথেই টেক্সচারও বদলে যাবে।
- **শুধুমাত্র ড্যাশবোর্ডে** প্রভাব — অন্য কোনো পেজ/টেবিল/মডালে কোনো পরিবর্তন হয়নি।
- প্রতিটা প্যাটার্ন Node.js `sharp` লাইব্রেরি দিয়ে বাস্তবে রেন্ডার করে (ক) 3×3 টাইলড প্রিভিউতে সিমলেসনেস, এবং (খ) বাস্তব widget-card সাইজে স্যাম্পল টেক্সট বসিয়ে readability — দুটোই যাচাই করার পর চূড়ান্ত করা হয়েছে।

---

## ✅ v-7.4 আপডেট — সম্পূর্ণ ব্যাকলগ বাস্তবায়ন (Inventory & PI, Delivery Center, Office Expense, HR Module, Dashboard)

এই বড় আপডেটে ব্যবহারকারীর দেওয়া সম্পূর্ণ পেন্ডিং লিস্টের প্রতিটা আইটেম implement করা হয়েছে। বাস্তবায়নের আগে প্রতিটা রিকোয়েস্ট আলাদা মেসেজে যাচাই করে একটা চেকলিস্ট বানানো হয়েছিল, এবং সেই চেকলিস্টের বাইরে কোনো পরিবর্তন করা হয়নি।

### A. Inventory & PI
- **PI Status**: এখন `computePIStatus()` ফাংশন দিয়ে supplierOrders/receivedGoods/qcList/deliveryHist-এর সাথে piNo/orderNo মিলিয়ে বাস্তব multi-stage status বের করা হয় — Order Pending → Order Placed → Received Partial/Full → QC Fail/Pending → Ready for Delivery → Delivery Partial/Complete। PI List টেবিল ও View Proforma Invoice — দুই জায়গাতেই এটা দেখায়।
- **Supplier Order Sheet**: Supplier ফিল্ডে datalist অটো-সাজেস্ট (নাম-শুধু), এবং PI No দিলে সেই PI-এর সব লাইন আইটেম (Item Code/Description/Style No/Qty, Master Data থেকে Brand ও Buying Price ক্রস-রেফারেন্স করে) automatically টেবিলে বসে যায়।
- **PI ফর্ম**: Consignee এখন শুধু নাম (ঠিকানা না), Notify Party এখন বায়ারের Bank Name+Branch, নতুন "Buyer's Bank A/C No" ফিল্ড (আগের খালি জায়গায়), Buyer(If Other) অটো-ফিলের নির্ভরযোগ্যতা বাড়ানো হয়েছে (onchange বাইন্ডিং যোগ)।
- **Buyer Directory**: Bank Name, Branch — schema, ফর্ম, টেবিল, সেভ ফাংশন সব জায়গায় সম্পূর্ণ।
- **View Proforma Invoice**: সম্পূর্ণ রিডিজাইন — এখন Buyer/Consignee, Shipping & Terms, পুরো Line Items টেবিল, Grand Total, Bank Details — সবকিছু দেখায় (আগে শুধু সারাংশ দেখাত)।

### B. Delivery Center (সম্পূর্ণ রিডিজাইন)
- "+ Log Delivery" বাটন ও এর ভাঙা পুরনো মোডাল সরানো হয়েছে।
- "Challan Generator" এখন পূর্ণ-স্ক্রিন মোডাল (X ক্লোজ + Minimize/Maximize টগল সহ), আলাদা ট্যাব না।
- নতুন "Save DB" বাটন — সেভ করলে "Planning & Overdue"-তে যোগ হয়, View/Edit/Status (Hold/Complete ড্রপডাউন) অ্যাকশন সহ। Complete করলে "History Timeline"-এ চলে যায়; Hold করলে সেখানেই থাকে, লাল হাইলাইট সহ।
- Date/Address/PI No — এখন ৩টা আলাদা কলামে, Address একটা wrap-করা টেক্সটএরিয়ায় (আগে সংকীর্ণ এক কলামে গাদাগাদি ছিল)।
- "Delivered By" — এখন HR Module > Employees থেকে নাম বাছাইয়ের ড্রপডাউন (আগে ফাঁকা সিগনেচার লাইন ছিল)।

### C. Office Expense (সম্পূর্ণ রিডিজাইন)
- "VOUCHERS" কার্ড → "Basic Expense" (Approved থাকা, ভাউচার-ক্যাটাগরি বাদে সব খরচের যোগফল)।
- "OFFICE RENT" কার্ড সম্পূর্ণ বাদ।
- "+ Add Expense" → "+ Add Voucher" (Voucher Entry ট্যাবে নিয়ে যায়); পুরনো Add Expense মোডাল ও ফাংশন সরানো হয়েছে।
- "Vouchers" ট্যাব বাদ — Voucher Entry এখন সরাসরি Expense List-এ status "Pending" নিয়ে সেভ হয়। Expense List-এ View/Approve/Reject অ্যাকশন (Super Admin/Admin/Accountant-এর জন্য গেটেড); Reject করতে একটা ছোট কারণ লেখা বাধ্যতামূলক; View করলে ট্রান্সপোর্ট রো-সহ সম্পূর্ণ ভাউচার দেখা যায়।
- Voucher Entry > Purpose — এখন ড্রপডাউন (Office Rent, Utilities, Equipment, Voucher, Entertainment, Others)।
- ⚠️ নোট: পুরনো আলাদা "vouchers" টেবিলের কোনো পুরনো ডেটা থাকলে সেটা নতুন Expense List ফ্লোতে automatically migrate হয়নি — এটা স্বচ্ছভাবে জানিয়ে রাখা হলো।

### D. HR Module
- **Leave of Absence**: Attendance ট্যাবে নতুন বাটন — মডালে Employee ড্রপডাউন, Start/End Date, লিভ অ্যাপ্লিকেশনের ছবি আপলোড। সেভ করলে সেই তারিখ রেঞ্জের প্রতিটা দিনে (আগে থেকে আসল চেক-ইন থাকা তারিখ বাদে) hrAttendance-এ "On Leave" এন্ট্রি automatically তৈরি হয়। কেউ ছুটির দিনে আসলে অফিসে এলে Check-In করলে সেটা এই "On Leave" প্লেসহোল্ডারকে সঠিকভাবে ওভাররাইট করে (ব্লক করে না)।
- **5-Star Rating**: Employees টেবিলে automated রেটিং — Punctuality ও Overtime/Extended Hours থেকে হিসাব হয়, শুধু চলতি ক্যালেন্ডার মাসের ডেটা থেকে গণনা করা হয় বলে প্রতি মাসের ১ তারিখে নিজে থেকেই "রিসেট" হয়ে যায় (আলাদা কোনো রিসেট-জব দরকার হয় না)।

### E. Dashboard
- "Sales vs Delivery" চার্ট সম্পূর্ণ সরানো হয়েছে, বদলে নতুন Attendance Tracking ডোনাট চার্ট (Present Today / On Leave / Absent, Total Employees ব্যাজে দেখায়)।

### 🔧 Database Schema পরিবর্তন (ব্যবহারের আগে schema.sql-এর নতুন ALTER স্টেটমেন্টগুলো Supabase-এ রান করুন)
- `buyers`: bankName, bankBranch যোগ
- `expenseList`: rejectNote, voucherDetails (jsonb) যোগ
- `deliveryPlan`: challanData (jsonb) যোগ
- নতুন টেবিল: `hrLeaves`

### 🧪 QA
- প্রতিটা পরিবর্তনের পরে `node --check` দিয়ে সিনট্যাক্স, HTML div-ব্যালান্স/duplicate-ID চেক, এবং CSS ব্রেস-ব্যালান্স — সবই ভ্যালিডেট করা হয়েছে। কোনো এরর পাওয়া যায়নি। তবে যথারীতি এই এনভায়রনমেন্টে লাইভ Supabase/ব্রাউজার টেস্ট সম্ভব হয়নি — ডেলিভারির আগে নিজেদের এনভায়রনমেন্টে অন্তত মূল ফ্লোগুলো (PI তৈরি/এডিট, Challan সেভ/স্ট্যাটাস, Voucher Approve/Reject, Leave সেভ) একবার হাতে-কলমে চেক করে নেবেন।
