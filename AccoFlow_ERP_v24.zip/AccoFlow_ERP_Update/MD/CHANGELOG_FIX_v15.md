# AccoFlow ERP — সিকিউরিটি অডিট ফিক্স (রাউন্ড ১৫)

তারিখ: ১২-১৩ আগস্ট, ২০২৬

রিপোর্টের ১.১ নং আইটেম: `authenticated_all` broad policy (২১ টেবিল) ভেঙে module+role-ভিত্তিক
policy বানানো। **এই রাউন্ডে আসল কাজ শুরুর আগে js/app.js ও index.html-এর প্রতিটা টেবিলের
Add/Edit/Delete বাটনের ক্লাস (admin-only, superadmin-only) সরাসরি খুঁজে বের করা হয়েছে** — কোনো
role-পারমিশন অনুমান করে বসানো হয়নি। তারপর একটা লোকাল PostgreSQL 16 ইনস্টল করে (`apt-get install
postgresql`) schema.sql + সব মাইগ্রেশন চালিয়ে, Supabase-এর `anon`/`authenticated` role এবং
`auth.uid()` সিমুলেট করে, ৫টা ভিন্ন role দিয়ে বাস্তবে টেস্ট করে দেখা হয়েছে policy গুলো ঠিকমতো
allow/block করছে কিনা — শুধু কোড পড়ে অনুমান করে না।

## যা পাওয়া গেছে (আগে না জানা)

- `piList`, `masterData`, `receivedGoods`, `supplierOrders`, `deliveryPlan`, `qcList` ইত্যাদির
  Add/Edit বাটন — এমনকি `accBuyer`/`accSupplier`-এর "Add Payment" বাটনও — ইতিমধ্যে UI-তে
  `admin-only` ক্লাসে গার্ড করা ছিল। অর্থাৎ merchandiser/storekeeper role বর্তমানে এসব টেবিলে
  মূলত **শুধু দেখতে পান, লিখতে পারেন না** — যদিও তাদের ন্যাভিগেশনে এই পেজগুলো দেখানো হয়।
- ব্যতিক্রম: `expenseList` — Voucher Entry ফর্ম (saveVoucherEntry) কোনো role-ক্লাস ছাড়াই আছে,
  আর Approve/Reject বাটনের JS-এ সরাসরি accountant-কেও অনুমতি দেওয়া আছে।
- `hrSignatures` merchandiser role read করে Supplier Order Sheet-এ সিগনেচার বসাতে (আগেই v14-এ
  পাওয়া গিয়েছিল, এখানে আবার নিশ্চিত হলো)।

## ফিক্স

`supabase/migration_v15_module_role_write_policies.sql` — ২০টা টেবিলের (`orders` বাদে) জন্য:

| | INSERT/UPDATE | DELETE |
|---|---|---|
| বেশিরভাগ টেবিল (piList, deliveryPlan, qcList, accBuyer/Supplier, buyer/supplierPaymentHistory, hrAttendance/Leaves/Departments/Approvals, buyers, suppliers, supplierOrders, vouchers) | admin, superadmin | superadmin |
| masterData, receivedGoods | admin, superadmin | admin, superadmin |
| expenseList | admin, superadmin, **accountant** | admin, superadmin |

SELECT ইচ্ছাকৃতভাবে অপরিবর্তিত (সব active user) — কারণ Dashboard সব role-এর জন্যই উন্মুক্ত এবং
অনেক টেবিল থেকে ডেটা টানে। `orders` টেবিলও অপরিবর্তিত (কম-ঝুঁকির derived index, একাধিক ফ্লো থেকে লেখা হয়)।

## ✅ বাস্তবে টেস্ট করা হয়েছে (অনুমান নয়)

লোকাল Postgres-এ ৫টা টেস্ট ইউজার (admin, storekeeper, accountant, merchandiser, superadmin)
বানিয়ে `SET ROLE authenticated` + সিমুলেটেড `auth.uid()` দিয়ে নিশ্চিত করা হয়েছে:
- storekeeper `piList` INSERT → **ব্লকড** ✅ (আগে সম্ভব ছিল)
- storekeeper `accBuyer` UPDATE → **০ রো, ব্লকড** ✅
- storekeeper `hrEmployees`/`hrSignatures` SELECT → যথাক্রমে ব্লকড/খোলা, ঠিক যেমনটা চাওয়া হয়েছিল ✅
- admin `piList` DELETE → ব্লকড (superadmin-only) ✅, `masterData` DELETE → সফল (admin-only) ✅
- accountant `expenseList` INSERT → সফল, DELETE → ব্লকড, `piList` INSERT → ব্লকড ✅
- merchandiser `orders` INSERT → সফল (ইচ্ছাকৃতভাবে খোলা) ✅

## ডিপ্লয়

Supabase SQL Editor-এ `migration_v15_module_role_write_policies.sql` রান করুন (v13, v14 আগে
থেকেই রান করা থাকতে হবে)। এটা শুধু DB-লেভেল — নতুন js/app.js প্রয়োজন নেই এই রাউন্ডের জন্য
(তবে রাউন্ড ১৬-এর সাথে একসাথে ডিপ্লয় করাই সুবিধাজনক)।
