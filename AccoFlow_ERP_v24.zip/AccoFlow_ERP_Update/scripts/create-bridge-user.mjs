// ============================================================================
// AccoFlow ERP — create-bridge-user.mjs
// ============================================================================
// ZKTeco Bridge-এর জন্য আলাদা, সীমিত-ক্ষমতার "device" অ্যাকাউন্ট তৈরি করে।
//
// এই অ্যাকাউন্ট শুধু record_zk_attendance() ফাংশন চালাতে পারে (অ্যাটেনডেন্স পুশ)।
// PI, Accounts, HR, ইউজার — কোনো টেবিলই পড়তে/লিখতে পারে না (migration v24 দেখুন)।
// তাই ব্রিজের পিসি বা config.json কখনো ফাঁস হলেও ব্যবসায়িক ডেটা নিরাপদ থাকে।
//
// ⚠️ শুধু আপনার নিজের কম্পিউটারের টার্মিনালে চালান। service_role/secret key কখনো
//    কাউকে বা কোনো চ্যাটে পাঠাবেন না।
//
// ব্যবহার (migration_v24 / accoflow_combined_schema_v24.sql আগে রান করা থাকতে হবে):
//   npm install @supabase/supabase-js
//   SUPABASE_URL="https://xxxx.supabase.co" \
//   SUPABASE_SERVICE_ROLE_KEY="..." \
//   node scripts/create-bridge-user.mjs            # নতুন অ্যাকাউন্ট (পাসওয়ার্ড প্রিন্ট হবে)
//   node scripts/create-bridge-user.mjs --reset    # আগে থেকে থাকলে নতুন পাসওয়ার্ড বসানো
//
// ঐচ্ছিক: BRIDGE_USERNAME (ডিফল্ট: zkbridge)
// ============================================================================

import { createClient } from '@supabase/supabase-js';
import { randomBytes } from 'crypto';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const USERNAME = (process.env.BRIDGE_USERNAME || 'zkbridge').trim().toLowerCase();
const EMAIL = `${USERNAME}@accoflow.internal`;
const RESET = process.argv.includes('--reset');

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error('❌ SUPABASE_URL এবং SUPABASE_SERVICE_ROLE_KEY এনভায়রনমেন্ট ভ্যারিয়েবল সেট করুন (উপরের কমেন্ট দেখুন)।');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, { auth: { persistSession: false } });
const password = randomBytes(18).toString('base64url'); // ২৪ অক্ষর

async function findUserId() {
  const { data: prof } = await supabase.from('profiles').select('id').eq('username', USERNAME).maybeSingle();
  return prof ? prof.id : null;
}

async function main() {
  let id = await findUserId();

  if (id) {
    if (!RESET) {
      console.log(`ℹ️  "${USERNAME}" নামে অ্যাকাউন্ট আগে থেকেই আছে। নতুন পাসওয়ার্ড চাইলে --reset দিয়ে চালান।`);
      return;
    }
    const { error } = await supabase.auth.admin.updateUserById(id, { password, ban_duration: 'none' });
    if (error) throw error;
  } else {
    const { data, error } = await supabase.auth.admin.createUser({
      email: EMAIL, password, email_confirm: true, user_metadata: { username: USERNAME, device: true },
    });
    if (error) throw error;
    id = data.user.id;
  }

  const { error: profErr } = await supabase.from('profiles').upsert({
    id, username: USERNAME, role: 'device', status: 'Active',
    permissions: { zkbridge: { push: true } },
  });
  if (profErr) throw profErr;

  console.log('\n✅ Bridge device অ্যাকাউন্ট প্রস্তুত।\n');
  console.log(`   bridgeUsername : ${USERNAME}`);
  console.log(`   bridgePassword : ${password}`);
  console.log('\nZKTECO_BRIDGE/config.json-এ এই দুটো মান বসান (অথবা ACCOFLOW_BRIDGE_USERNAME / ACCOFLOW_BRIDGE_PASSWORD এনভায়রনমেন্ট ভ্যারিয়েবলে)।');
  console.log('পাসওয়ার্ডটা এখন কোথাও কপি করে নিন — এটা আর দেখানো হবে না।');
}

main().catch((e) => { console.error('❌ ব্যর্থ:', e.message || e); process.exit(1); });
