// ============================================================================
// AccoFlow ERP — bootstrap-auth-users.mjs
// ============================================================================
// এই স্ক্রিপ্টটা একবারই রান করার জন্য — বিদ্যমান "users" টেবিলের সব ইউজারকে Supabase Auth-এ
// রূপান্তর করে (Auth অ্যাকাউন্ট + profiles রো তৈরি করে)।
//
// ⚠️⚠️ এই স্ক্রিপ্টটা শুধু আপনার নিজের কম্পিউটারে, টার্মিনালে রান করুন — কখনো এই স্ক্রিপ্ট বা
// এর SERVICE_ROLE_KEY কোনো চ্যাটে/AI-কে পাঠাবেন না। service_role key দিয়ে RLS সম্পূর্ণ
// বাইপাস করে পুরো ডাটাবেসে যেকোনো কিছু করা যায় — এটা anon key-এর চেয়ে অনেক বেশি স্পর্শকাতর।
//
// প্রস্তুতি:
//   1. npm install @supabase/supabase-js
//   2. Supabase Dashboard > Project Settings > API থেকে:
//        - Project URL
//        - service_role key (secret — anon key না!)
//   3. নিচের এনভায়রনমেন্ট ভ্যারিয়েবল সেট করে রান করুন:
//        SUPABASE_URL="https://xxxx.supabase.co" \
//        SUPABASE_SERVICE_ROLE_KEY="ey...." \
//        SUPER_ADMIN_USERNAME="emon" \
//        node scripts/bootstrap-auth-users.mjs
//
// এই স্ক্রিপ্ট প্রতিটা ইউজারের জন্য একটা নতুন র‍্যান্ডম পাসওয়ার্ড জেনারেট করে (বিদ্যমান SHA-256
// হ্যাশ থেকে আসল পাসওয়ার্ড ফিরিয়ে আনা সম্ভব না, তাই নতুন পাসওয়ার্ড লাগবেই) এবং সেগুলো
// bootstrap-passwords-output.json ফাইলে লিখে রাখে — প্রতিটা ইউজারকে নিরাপদভাবে (ব্যক্তিগতভাবে,
// ইমেইল/চ্যাটে না) তার নতুন পাসওয়ার্ড জানিয়ে দিন, তারপর এই ফাইলটা ডিলিট করে দিন।
// ============================================================================

import { createClient } from '@supabase/supabase-js';
import { randomBytes } from 'crypto';
import { writeFileSync } from 'fs';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const SUPER_ADMIN_USERNAME = process.env.SUPER_ADMIN_USERNAME || 'emon';
const EMAIL_DOMAIN = 'accoflow.internal';

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error('❌ SUPABASE_URL এবং SUPABASE_SERVICE_ROLE_KEY এনভায়রনমেন্ট ভ্যারিয়েবল সেট করা লাগবে। উপরের কমেন্ট দেখুন।');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

function genPassword() {
  // ১২ ক্যারেক্টার, URL-সেফ র‍্যান্ডম পাসওয়ার্ড
  return randomBytes(9).toString('base64url');
}

async function ensureAuthUser(username, password) {
  const email = `${username.trim().toLowerCase()}@${EMAIL_DOMAIN}`;
  const { data, error } = await supabase.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { username },
  });
  if (error) {
    // ইতিমধ্যে তৈরি থাকলে (স্ক্রিপ্ট দ্বিতীয়বার রান হলে) স্কিপ করে বিদ্যমান ইউজার খুঁজে বের করা হচ্ছে
    if (String(error.message || '').toLowerCase().includes('already') ) {
      const { data: list } = await supabase.auth.admin.listUsers();
      const existing = list?.users?.find(u => u.email === email);
      return { id: existing?.id, alreadyExisted: true };
    }
    throw error;
  }
  return { id: data.user.id, alreadyExisted: false };
}

async function upsertProfile(id, username, role, status) {
  const { error } = await supabase.from('profiles').upsert({ id, username, role, status });
  if (error) throw error;
}

async function main() {
  const passwordReport = {};

  console.log('▶ বিদ্যমান users টেবিল থেকে ইউজার লোড করা হচ্ছে...');
  const { data: users, error: usersErr } = await supabase.from('users').select('*');
  if (usersErr) { console.error('❌ users টেবিল পড়তে ব্যর্থ:', usersErr.message); process.exit(1); }

  // Super Admin (settings.superAdminUser) — users টেবিলে নেই, আলাদাভাবে যোগ করা হচ্ছে
  const allAccounts = [
    { username: SUPER_ADMIN_USERNAME, role: 'superadmin', status: 'Active' },
    ...users
      .filter(u => u.status !== undefined) // ডিলিটেড/ট্র্যাশড না এমন সবাই (deletedAt চেক নিচে)
      .filter(u => !u.deletedAt)
      .map(u => ({ username: u.username, role: u.role, status: u.status || 'Active' })),
  ];

  console.log(`▶ মোট ${allAccounts.length}টা অ্যাকাউন্ট মাইগ্রেট করা হবে (Super Admin সহ)।\n`);

  for (const acc of allAccounts) {
    if (!acc.username) continue;
    try {
      const password = genPassword();
      const { id, alreadyExisted } = await ensureAuthUser(acc.username, password);
      if (!id) { console.warn(`⚠️  ${acc.username}: Auth id পাওয়া যায়নি, স্কিপ করা হলো`); continue; }
      await upsertProfile(id, acc.username, acc.role || 'staff', acc.status || 'Active');
      if (!alreadyExisted) passwordReport[acc.username] = password;
      console.log(`✅ ${acc.username} — ${alreadyExisted ? 'আগে থেকেই ছিল, profile সিঙ্ক করা হলো' : 'নতুন Auth অ্যাকাউন্ট তৈরি হলো'}`);
    } catch (e) {
      console.error(`❌ ${acc.username} ব্যর্থ:`, e.message || e);
    }
  }

  if (Object.keys(passwordReport).length) {
    writeFileSync('bootstrap-passwords-output.json', JSON.stringify(passwordReport, null, 2));
    console.log('\n📄 নতুন পাসওয়ার্ডগুলো bootstrap-passwords-output.json ফাইলে লেখা হয়েছে।');
    console.log('   ⚠️  প্রতিটা ইউজারকে ব্যক্তিগতভাবে (মুখে/SMS/সরাসরি — ইমেইল/চ্যাটে না) জানিয়ে দিন,');
    console.log('   তারপর এই ফাইলটা অবিলম্বে ডিলিট করুন। এটা কখনো গিট/শেয়ার্ড ফোল্ডারে রাখবেন না।');
  } else {
    console.log('\n(কোনো নতুন পাসওয়ার্ড জেনারেট হয়নি — সব অ্যাকাউন্ট আগে থেকেই ছিল)');
  }

  console.log('\n✔ মাইগ্রেশন সম্পন্ন।');
}

main();
