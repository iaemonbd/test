# AccoFlow ERP — Offline Mode-এর জন্য Self-Hosted Supabase (Docker) সেটআপ

এই ফোল্ডারে **অফিসিয়াল Supabase self-hosting Docker স্ট্যাক** হুবহু আছে (সরাসরি
`github.com/supabase/supabase`-এর `docker/` ফোল্ডার থেকে নেওয়া — `docker-compose.yml`,
`.env.example`, ও পুরো `volumes/` ফোল্ডার)। AccoFlow ERP-এর **Offline 💻 মোড** এই স্ট্যাকের
সাথে কথা বলে — অর্থাৎ ইন্টারনেট না থাকলেও অফিসের LAN-এর ভেতর থেকে ERP পুরোপুরি কাজ করবে।

> 💡 **Windows/WSL2-এ ধাপে-ধাপে বিস্তারিত (Docker Desktop ইনস্টল, ফায়ারওয়াল, অটো-স্টার্ট,
> ব্যাকআপ ইত্যাদি) চাইলে দেখুন:** `MD/AccoFlow_ERP_LAN_SelfHost_Guide.md` — এই ফাইলটা তার
> সংক্ষিপ্ত, Linux/general-purpose সংস্করণ, এবং app-side (Settings টগল, v22 মাইগ্রেশন, Sync)
> ইন্টিগ্রেশনের উপর বেশি মনোযোগ দেয়।

> ℹ️ Supabase নিয়মিত এই স্ট্যাক আপডেট করে। এই ফোল্ডারটা যেদিন তৈরি করা হয়েছে সেদিনের সর্বশেষ
> সংস্করণ — ভবিষ্যতে সন্দেহ হলে সবসময় অফিসিয়াল গাইড দিয়ে মিলিয়ে নিন:
> https://supabase.com/docs/guides/self-hosting/docker

---

## ধাপ ১ — প্রস্তুতি

একটা কম্পিউটার/সার্ভার লাগবে যেটা সবসময় অফিসের LAN-এ চালু থাকে (একটা পুরনো ডেস্কটপ, mini-PC,
বা NAS হলেও চলবে)। তাতে ইনস্টল থাকতে হবে:

- **Docker Engine** ও **Docker Compose v2** ([docs.docker.com/get-docker](https://docs.docker.com/get-docker/))
- কমপক্ষে ২ GB RAM ও ১০ GB ফাঁকা ডিস্ক (ডেটা যত বাড়বে তত বেশি লাগবে)

## ধাপ ২ — `.env` ফাইল তৈরি ও সিক্রেট বসানো

```bash
cd docker
cp .env.example .env
```

এখন `.env` ফাইল খুলে অন্তত এই মানগুলো **অবশ্যই** বদলান (ডিফল্ট রাখলে যে কেউ আপনার ডেটাবেসে ঢুকতে
পারবে):

- `POSTGRES_PASSWORD` — একটা শক্তিশালী পাসওয়ার্ড
- `JWT_SECRET`, `ANON_KEY`, `SERVICE_ROLE_KEY` — অফিসিয়াল গাইডের জেনারেটর দিয়ে বানান:
  https://supabase.com/docs/guides/self-hosting/docker#securing-your-services (JWT_SECRET আগে
  বসান, তারপর সেটা দিয়ে ANON_KEY/SERVICE_ROLE_KEY জেনারেট করুন)
- `DASHBOARD_USERNAME` / `DASHBOARD_PASSWORD` — Supabase Studio-তে লগইনের জন্য
- `SITE_URL` — `http://<এই-সার্ভারের-LAN-IP>:8000` দিন (উদাহরণ: `http://192.168.1.50:8000`)

## ধাপ ৩ — স্ট্যাক চালু করা

```bash
docker compose up -d
```

কয়েক মিনিট পর সব কন্টেইনার "healthy" হয়ে যাবে। `http://<সার্ভারের-IP>:8000` এ ব্রাউজার দিয়ে
ঢুকলে Supabase Studio দেখা উচিত (উপরের `DASHBOARD_USERNAME`/`PASSWORD` দিয়ে লগইন করুন)।

## ধাপ ৪ — AccoFlow-এর স্কিমা এই ইনস্ট্যান্সে বসানো

Studio-এর **SQL Editor**-এ গিয়ে ক্রমানুসারে রান করুন (অথবা আগে তৈরি করা
`accoflow_combined_schema.sql` ফাইলটা একবারে রান করুন, যেটা schema.sql + v13 থেকে v21 পর্যন্ত
সব মাইগ্রেশন একসাথে করে দেয়):

1. `accoflow_combined_schema.sql` (schema + v13–v21, আগে দেওয়া হয়েছে)
2. `supabase/migration_v22_offline_sync.sql` (এই আপডেটে নতুন — Online/Offline conflict-detection
   কলাম)

⚠️ **অনলাইন (ক্লাউড) প্রজেক্টেও** `migration_v22_offline_sync.sql` রান করে নিন, নাহলে দুই পাশের
স্কিমা না মিললে Sync ফিচার ভুল আচরণ করতে পারে।

## ধাপ ৫ — প্রথম Auth ইউজার তৈরি (Super Admin)

`MD/RLS_AUTH_MIGRATION_GUIDE.md`-এ বর্ণিত পদ্ধতিতেই এখানেও করতে হবে:

1. Studio > Authentication > Users > **Add User** — একই username যেটা আপনার অনলাইন প্রজেক্টে Super
   Admin হিসেবে আছে, ইমেইল ফরম্যাট: `<username>@accoflow.internal`
2. SQL Editor-এ:
   ```sql
   insert into profiles (id, username, role, status)
   select id, '<username>', 'superadmin', 'Active'
   from auth.users where email = '<username>@accoflow.internal';
   ```

⚠️ **গুরুত্বপূর্ণ:** এই Super Admin ইউজারনেম ও পাসওয়ার্ড **অনলাইন প্রজেক্টের Super Admin-এর সাথে
হুবহু মিলিয়ে** তৈরি করুন। AccoFlow-এর "Sync Now" ফিচার Online ⇄ Offline দুই ডাটাবেস মেলানোর সময়
এই একই Super Admin অ্যাকাউন্ট দিয়ে অন্য পাশে সাময়িকভাবে সাইন-ইন করে — দুই পাশে না মিললে পূর্ণ
reconcile কাজ করবে না (তবে সাধারণ সেভ/সিঙ্ক ঠিকই কাজ করবে)।

## ধাপ ৬ — `admin-manage-user` Edge Function ডিপ্লয়

⚠️ **রাউন্ড ২৩ সংশোধনী:** আগে এই ধাপে `supabase functions deploy ... --project-ref ...`
(Supabase CLI-এর cloud-ভিত্তিক কমান্ড) লেখা ছিল, যা এই self-hosted Docker স্ট্যাকে কাজ করে না।
এই `docker-compose.yml`-এর `functions` সার্ভিস আসলে volume-mount দিয়ে ফাংশন লোড করে — cloud-এর
মতো আলাদা "deploy" ধাপের দরকার নেই।

**সঠিক পদ্ধতি:**

1. ফাংশনের কোড এই লোকেশনে থাকতে হবে (এই প্যাকেজে ইতিমধ্যে বসানো আছে, দেখুন
   `docker/volumes/functions/admin-manage-user/index.ts`):
   ```text
   docker/volumes/functions/admin-manage-user/index.ts
   ```
   এটা `docker/volumes/functions/main/index.ts` রাউটার স্বয়ংক্রিয়ভাবে
   `http://<সার্ভার-IP>:8000/functions/v1/admin-manage-user`-এ সার্ভ করবে।

2. `.env`-এ `FUNCTIONS_VERIFY_JWT=false` রাখুন (এটা সব ফাংশনের জন্য প্রযোজ্য — cloud-এর
   per-function `--no-verify-jwt` ফ্ল্যাগের বদলে এই একটা env var; এই ফাংশন নিজেই
   Authorization header/caller-role ভেতরে যাচাই করে, তাই এটা নিরাপদ)।

3. `functions` কন্টেইনার রিস্টার্ট করে নতুন কোড লোড করান:
   ```bash
   docker compose up -d --force-recreate functions
   ```

4. যাচাই করুন — টার্মিনাল থেকে (ANON_KEY দিয়ে, কোনো valid JWT ছাড়াই এটা 401 দেওয়ার কথা,
   যেটা প্রমাণ করে ফাংশনটা আসলে লোড হয়েছে):
   ```bash
   curl -i http://<সার্ভার-IP>:8000/functions/v1/admin-manage-user \
     -H "Content-Type: application/json" -d '{}'
   ```
   কোনো এরর ছাড়া `401 অবৈধ সেশন` বা এই জাতীয় JSON রেসপন্স এলে বুঝবেন ফাংশন সঠিকভাবে লোড হয়েছে।
   `404`/connection-refused পেলে ধাপ ৩ আবার করুন।

5. (ঐচ্ছিক) `ALLOWED_ORIGINS` env var সেট করে দিলে CORS আরও সংকুচিত হবে — দেখুন
   `supabase/functions/admin-manage-user/index.ts`-এর উপরের কমেন্ট।

## ধাপ ৭ — AccoFlow ERP-এ Offline কনফিগ বসানো

1. AccoFlow ERP-এ Super Admin দিয়ে লগইন করুন (Online মোডে)
2. Settings > **Online / Offline Mode** কার্ডে যান
3. **Offline Supabase URL** ফিল্ডে দিন: `http://<সার্ভারের-LAN-IP>:8000`
4. **Offline Supabase Anon Key** ফিল্ডে `.env`-এর `ANON_KEY` মান দিন
5. **"Offline সংযোগ টেস্ট করুন"** চাপুন — সফল হলে **"সংরক্ষণ করুন"** চাপুন
6. এখন উপরের ☁️/💻 টগল চাপলে Offline মোডে সুইচ হবে (পুনরায় লগইন করতে হবে — এটা স্বাভাবিক, কারণ
   এটা একটা আলাদা ডাটাবেস/Auth সিস্টেম)

## কীভাবে কাজ করে (সংক্ষেপে)

- **Online ☁️** মোডে ERP আপনার ক্লাউড Supabase প্রজেক্টের সাথে কথা বলে (আগের মতোই)।
- **Offline 💻** মোডে ERP এই LAN Docker ইনস্ট্যান্সের সাথে কথা বলে — ইন্টারনেট না থাকলেও কাজ
  করবে, শুধু এই সার্ভারটা LAN-এ চালু ও পৌঁছানো যায় এমন থাকতে হবে।
- প্রতিটা সেভ ব্রাউজারের নিজস্ব IndexedDB-তেও মিরর হয় — সক্রিয় এন্ডপয়েন্ট (Online বা Offline,
  যেটাই বেছে নেওয়া থাকুক) সাময়িকভাবে অপৌঁছনীয় হলে পরিবর্তন হারায় না, "পেন্ডিং" থেকে যায় এবং
  সংযোগ ফিরলেই (বা "Sync Now" চাপলে) স্বয়ংক্রিয়ভাবে পাঠানো হয়।
- দুই এন্ডপয়েন্টই (Online + Offline) কনফিগার করা থাকলে, Super Admin "Sync Now" চাপলে দুই
  ডাটাবেসের মধ্যে একটা পূর্ণ reconcile হয় — প্রতিটা রেকর্ডের `updatedAt` সময় তুলনা করে কোনটা
  নতুন বোঝা হয়; সংঘাত (conflict) হলে নতুনটাই রাখা হয় এবং পুরনোটা লোকালি একটা conflict লগে
  সংরক্ষিত থাকে (কখনো নীরবে হারায় না)।

## সীমাবদ্ধতা (সততার সাথে জানিয়ে রাখা ভালো)

- ERP-তে **প্রথমবার লগইন করতে** সবসময় সক্রিয় এন্ডপয়েন্টে (Online বা Offline, যেটা বেছে নেওয়া
  আছে) নেটওয়ার্ক সংযোগ লাগবে — কারণ পাসওয়ার্ড যাচাই Supabase Auth সার্ভার-সাইডে হয় (RLS
  নিরাপত্তার জন্য ইচ্ছাকৃত ডিজাইন, দেখুন `MD/RLS_AUTH_MIGRATION_GUIDE.md`)। অর্থাৎ ইন্টারনেট
  **ও** LAN দুটোই একসাথে সম্পূর্ণ বিচ্ছিন্ন হলে (কোনো এন্ডপয়েন্টই পৌঁছানো যাচ্ছে না) নতুন করে
  লগইন করা যাবে না — এটা "Offline Mode = কোনো নেটওয়ার্ক ছাড়াই" না, বরং "Offline Mode =
  ইন্টারনেট ছাড়াই, LAN-এর নিজস্ব ব্যাকএন্ড দিয়ে" কাজ করা।
- ইতিমধ্যে লগইন করা অবস্থায় সাময়িক সংযোগ বিচ্ছিন্নতা (কয়েক সেকেন্ড/মিনিট) সম্পূর্ণ নিরাপদ —
  IndexedDB queue এই সময়ের সব পরিবর্তন ধরে রাখে এবং সংযোগ ফিরলেই পাঠিয়ে দেয়।
