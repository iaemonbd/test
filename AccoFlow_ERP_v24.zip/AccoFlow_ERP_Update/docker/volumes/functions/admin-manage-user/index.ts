// ============================================================================
// AccoFlow ERP — admin-manage-user (Edge Function)
// ============================================================================
// এই ফাংশনটা service_role key ব্যবহার করে Supabase Auth-এ ইউজার তৈরি/আপডেট/পাসওয়ার্ড-রিসেট
// করে — এই কাজটা ব্রাউজার থেকে সরাসরি করা যায় না (এবং করা উচিতও না, কারণ সেজন্য service_role
// key ব্রাউজারে পাঠাতে হতো, যা anon key-এর চেয়েও অনেক বেশি ক্ষমতাশালী — পুরো ডাটাবেসে RLS
// বাইপাস করে সব কিছু করতে পারে)।
//
// ডিপ্লয়: supabase functions deploy admin-manage-user
// (service_role key স্বয়ংক্রিয়ভাবেই SUPABASE_SERVICE_ROLE_KEY এনভায়রনমেন্ট ভ্যারিয়েবল হিসেবে
// পাওয়া যায় — আলাদা করে সেট করার দরকার নেই)
// ============================================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
// ⚠️ ২০২৬-এ Supabase key সিস্টেম বদলেছে (legacy service_role → নতুন "secret" key,
// sb_secret_xxx)। কোন এনভায়রনমেন্ট ভ্যারিয়েবলে এটা স্বয়ংক্রিয়ভাবে পাওয়া যাবে তা আপনার প্রজেক্ট
// কবে তৈরি হয়েছে তার উপর নির্ভর করতে পারে — তাই কয়েকটা সম্ভাব্য নাম চেষ্টা করা হচ্ছে। কোনোটাই
// কাজ না করলে টার্মিনালে রান করুন:
//   supabase secrets set MANUAL_SECRET_KEY=<Dashboard থেকে কপি করা secret/service_role key>
// এবং তারপর আবার ডিপ্লয় করুন।
const SERVICE_ROLE_KEY =
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ||
  Deno.env.get('MANUAL_SECRET_KEY') ||
  (() => {
    try {
      const parsed = JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS') || '{}');
      return parsed?.default || Object.values(parsed)[0];
    } catch { return undefined; }
  })();
if (!SERVICE_ROLE_KEY) throw new Error('service_role/secret key পাওয়া যায়নি — উপরের কমেন্ট দেখে MANUAL_SECRET_KEY সেট করুন');
const EMAIL_DOMAIN = 'accoflow.internal'; // username@accoflow.internal — কখনো আসল ইমেইল না, শুধু Supabase Auth-এর জন্য দরকারি ফরম্যাট মেলানো

// Round 14 fix: CORS headers were added here. Without them the browser blocks the request at
// the preflight (OPTIONS) step (especially when the app is opened from file://), and the
// supabase-js SDK just reports "Failed to send a request to the Edge Function" -- even when
// the function code and deployment are otherwise fine.
//
// Round 23 fix: '*' allowed any website to call this function from a signed-in user's browser.
// The real authorisation check below (JWT + profiles.role) means '*' was not a full bypass, but
// it was broader than necessary. Set ALLOWED_ORIGINS (comma-separated, e.g.
// "https://erp.yourcompany.com,http://192.168.1.50:3000") as a Supabase secret/env var to lock
// this down to your real deployment origin(s). Left unset, it falls back to the old '*'
// behaviour so existing deployments do not silently break -- but setting it is recommended.
const ALLOWED_ORIGINS = (Deno.env.get('ALLOWED_ORIGINS') || '')
  .split(',').map((s) => s.trim()).filter(Boolean);

function corsHeadersFor(req: Request) {
  const origin = req.headers.get('Origin') || '';
  const allowOrigin = ALLOWED_ORIGINS.length === 0
    ? '*' // ALLOWED_ORIGINS not configured -- keep old behaviour, unrestricted
    : (ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0]);
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Vary': 'Origin',
  };
}

function jsonResponse(body: unknown, status = 200, corsHeaders: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders },
  });
}

Deno.serve(async (req) => {
  const corsHeaders = corsHeadersFor(req);
  // Browser's CORS preflight request -- answered immediately with an empty 200 response
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders });

  if (req.method !== 'POST') return jsonResponse({ error: 'POST only' }, 405, corsHeaders);

  const authHeader = req.headers.get('Authorization') || '';
  const callerJwt = authHeader.replace('Bearer ', '');
  if (!callerJwt) return jsonResponse({ error: 'Authorization header প্রয়োজন' }, 401, corsHeaders);

  // ক্যালার আসলে কে এবং তার role কী — এটা service_role client দিয়ে নিজে যাচাই করা হচ্ছে,
  // ক্যালার নিজে যা দাবি করে সেটার উপর ভরসা না করে
  const adminClient = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
  const { data: callerData, error: callerErr } = await adminClient.auth.getUser(callerJwt);
  if (callerErr || !callerData?.user) return jsonResponse({ error: 'অবৈধ সেশন' }, 401, corsHeaders);

  const { data: callerProfile } = await adminClient
    .from('profiles')
    .select('role, status')
    .eq('id', callerData.user.id)
    .maybeSingle();

  if (!callerProfile || callerProfile.status !== 'Active' || !['admin', 'superadmin'].includes(callerProfile.role)) {
    return jsonResponse({ error: 'এই কাজের জন্য admin/superadmin পারমিশন প্রয়োজন' }, 403, corsHeaders);
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: 'অবৈধ JSON body' }, 400, corsHeaders);
  }

  const { action, username, role, status, password } = body || {};
  if (!username) return jsonResponse({ error: 'username প্রয়োজন' }, 400, corsHeaders);

  // ⚠️ নিরাপত্তা ফিক্স: এতদিন caller admin/superadmin কিনা শুধু চেক হতো, কিন্তু request body-তে
  // role যা-ই পাঠানো হোক না কেন সরাসরি profiles-এ বসে যেত — ফলে একজন সাধারণ admin অন্য কাউকে
  // (বা নিজেকে) superadmin বানিয়ে নিতে পারত। এখন থেকে role==='superadmin' সেট করার অনুরোধ শুধু
  // তখনই গ্রহণ করা হবে যখন ক্যালার নিজেই ইতিমধ্যে superadmin (create ও update/setStatus — দুই
  // action-এর জন্যই প্রযোজ্য, কারণ দুটোই role ফিল্ড গ্রহণ করে)।
  if (role === 'superadmin' && callerProfile.role !== 'superadmin') {
    return jsonResponse({ error: 'শুধুমাত্র superadmin অন্য কাউকে superadmin করতে পারবে' }, 403, corsHeaders);
  }

  // ⚠️ Round 24 hardening: a plain admin must never be able to touch a superadmin or a
  // 'device' (ZKTeco bridge) account -- not to change its role/status, reset its password, or
  // delete it -- and must not change their own role/status. Before this, only the *new* role
  // being 'superadmin' was blocked, so an admin could still take over a superadmin by
  // resetting that account's password.
  if (callerProfile.role !== 'superadmin') {
    if (role === 'device') {
      return jsonResponse({ error: 'শুধুমাত্র superadmin device অ্যাকাউন্ট তৈরি/পরিবর্তন করতে পারবে' }, 403, corsHeaders);
    }
    if (action === 'update' || action === 'setStatus' || action === 'delete') {
      const { data: target } = await adminClient
        .from('profiles').select('id, role, status').eq('username', username).maybeSingle();
      if (target && ['superadmin', 'device'].includes(target.role)) {
        return jsonResponse({ error: 'শুধুমাত্র superadmin এই অ্যাকাউন্টে পরিবর্তন করতে পারবে' }, 403, corsHeaders);
      }
      if (target && target.id === callerData.user.id && ((role !== undefined && role !== target.role) || (status !== undefined && status !== target.status) || action === 'delete')) {
        return jsonResponse({ error: 'আপনি নিজের role/status পরিবর্তন বা নিজের অ্যাকাউন্ট ডিলিট করতে পারবেন না' }, 403, corsHeaders);
      }
    }
  }

  const syntheticEmail = `${String(username).trim().toLowerCase()}@${EMAIL_DOMAIN}`;

  try {
    if (action === 'create') {
      if (!password) return jsonResponse({ error: 'নতুন ইউজারের জন্য password প্রয়োজন' }, 400, corsHeaders);
      const { data: created, error: createErr } = await adminClient.auth.admin.createUser({
        email: syntheticEmail,
        password,
        email_confirm: true, // সিন্থেটিক ইমেইল, তাই confirmation ইমেইল পাঠানোর প্রয়োজন/সুযোগ নেই
        user_metadata: { username },
      });
      if (createErr) return jsonResponse({ error: 'Auth ইউজার তৈরি ব্যর্থ: ' + createErr.message }, 400, corsHeaders);

      const { error: profileErr } = await adminClient.from('profiles').insert({
        id: created.user.id,
        username,
        role: role || 'staff',
        status: status || 'Active',
      });
      if (profileErr) return jsonResponse({ error: 'profiles-এ সেভ ব্যর্থ: ' + profileErr.message }, 400, corsHeaders);

      return jsonResponse({ ok: true, id: created.user.id }, 200, corsHeaders);
    }

    if (action === 'update' || action === 'setStatus') {
      const { data: existing } = await adminClient.from('profiles').select('id').eq('username', username).maybeSingle();
      if (!existing) return jsonResponse({ error: `"${username}" নামে কোনো Auth প্রোফাইল পাওয়া যায়নি — আগে bootstrap script দিয়ে মাইগ্রেট করুন` }, 404, corsHeaders);

      const patch: Record<string, unknown> = {};
      if (role !== undefined) patch.role = role;
      if (status !== undefined) patch.status = status;
      if (Object.keys(patch).length) {
        const { error: updErr } = await adminClient.from('profiles').update(patch).eq('id', existing.id);
        if (updErr) return jsonResponse({ error: 'profiles আপডেট ব্যর্থ: ' + updErr.message }, 400, corsHeaders);
      }

      // status Inactive করা হলে Auth অ্যাকাউন্টও ব্যান করে দেওয়া হচ্ছে, যাতে সে Supabase Auth
      // দিয়ে সরাসরি (অ্যাপ UI বাইপাস করেও) লগইন করতে না পারে
      if (status === 'Inactive') {
        await adminClient.auth.admin.updateUserById(existing.id, { ban_duration: '876000h' }); // ~১০০ বছর, কার্যত স্থায়ী
      } else if (status === 'Active') {
        await adminClient.auth.admin.updateUserById(existing.id, { ban_duration: 'none' });
      }

      if (password) {
        const { error: passErr } = await adminClient.auth.admin.updateUserById(existing.id, { password });
        if (passErr) return jsonResponse({ error: 'পাসওয়ার্ড পরিবর্তন ব্যর্থ: ' + passErr.message }, 400, corsHeaders);
      }

      return jsonResponse({ ok: true }, 200, corsHeaders);
    }

    if (action === 'delete') {
      // ⚠️ রাউন্ড ১৪ ফিক্স: আগে "Permanently Delete" (Recycle Bin থেকে) শুধু users টেবিলের রো
      // মুছত, কিন্তু Supabase Auth অ্যাকাউন্ট ও profiles রো অক্ষতই থেকে যেত — ফলে সেই
      // username/email দিয়ে আর নতুন ইউজার তৈরি করা যেত না ("already exists" এরর)। এই action
      // পুরো Auth অ্যাকাউন্টটাই মুছে দেয় (profiles রো cascade-এ নিজে থেকেই মুছে যায়, কারণ
      // profiles.id-এ "on delete cascade" আছে) — এখন সেই username আবার ব্যবহার করা যাবে।
      const { data: existing } = await adminClient.from('profiles').select('id').eq('username', username).maybeSingle();
      if (!existing) return jsonResponse({ ok: true }, 200, corsHeaders); // আগে থেকেই নেই, ধরে নেওয়া হচ্ছে ইতিমধ্যে পরিষ্কার
      const { error: delErr } = await adminClient.auth.admin.deleteUser(existing.id);
      if (delErr) return jsonResponse({ error: 'Auth অ্যাকাউন্ট ডিলিট ব্যর্থ: ' + delErr.message }, 400, corsHeaders);
      return jsonResponse({ ok: true }, 200, corsHeaders);
    }

    return jsonResponse({ error: 'অজানা action — "create", "update", "setStatus", বা "delete" ব্যবহার করুন' }, 400, corsHeaders);
  } catch (e) {
    return jsonResponse({ error: 'অপ্রত্যাশিত এরর: ' + (e as Error).message }, 500, corsHeaders);
  }
});
